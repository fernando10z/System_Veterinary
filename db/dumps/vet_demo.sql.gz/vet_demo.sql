-- Snapshot de la base del ERP Veterinario
-- Generado el 2026-09-20 desde el commit e5384d7 con db/scripts/exportar-snapshot.sh
-- Incluye esquema, catálogos y las dos empresas de demostración.
-- La fuente de verdad son las migraciones: si esto y db/migrations/ no
-- coinciden, manda db/migrations/.

--
-- PostgreSQL database dump
--

\restrict II8HBfhg7sMPd6avo7dD71qQAXjt5GLZHB2DL1h6TrQhlp9YIOOD9JKylYmcNb9

-- Dumped from database version 16.13
-- Dumped by pg_dump version 16.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY core.vacunas DROP CONSTRAINT IF EXISTS vacunas_veterinario_id_fkey;
ALTER TABLE IF EXISTS ONLY core.vacunas DROP CONSTRAINT IF EXISTS vacunas_mascota_id_fkey;
ALTER TABLE IF EXISTS ONLY core.vacunas DROP CONSTRAINT IF EXISTS vacunas_esquema_id_fkey;
ALTER TABLE IF EXISTS ONLY core.vacunas DROP CONSTRAINT IF EXISTS vacunas_empresa_id_fkey;
ALTER TABLE IF EXISTS ONLY core.vacunas DROP CONSTRAINT IF EXISTS vacunas_consulta_id_fkey;
ALTER TABLE IF EXISTS ONLY core.users DROP CONSTRAINT IF EXISTS users_rol_id_fkey;
ALTER TABLE IF EXISTS ONLY core.users DROP CONSTRAINT IF EXISTS users_especializacion_id_fkey;
ALTER TABLE IF EXISTS ONLY core.users DROP CONSTRAINT IF EXISTS users_empresa_id_fkey;
ALTER TABLE IF EXISTS ONLY core.tratamientos DROP CONSTRAINT IF EXISTS tratamientos_veterinario_id_fkey;
ALTER TABLE IF EXISTS ONLY core.tratamientos DROP CONSTRAINT IF EXISTS tratamientos_mascota_id_fkey;
ALTER TABLE IF EXISTS ONLY core.tratamientos DROP CONSTRAINT IF EXISTS tratamientos_empresa_id_fkey;
ALTER TABLE IF EXISTS ONLY core.tratamientos DROP CONSTRAINT IF EXISTS tratamientos_consulta_id_fkey;
ALTER TABLE IF EXISTS ONLY core.stock DROP CONSTRAINT IF EXISTS stock_producto_id_fkey;
ALTER TABLE IF EXISTS ONLY core.stock DROP CONSTRAINT IF EXISTS stock_empresa_id_fkey;
ALTER TABLE IF EXISTS ONLY core.stock DROP CONSTRAINT IF EXISTS stock_almacen_id_fkey;
ALTER TABLE IF EXISTS ONLY core.sesiones DROP CONSTRAINT IF EXISTS sesiones_user_id_fkey;
ALTER TABLE IF EXISTS ONLY core.servicios DROP CONSTRAINT IF EXISTS servicios_empresa_id_fkey;
ALTER TABLE IF EXISTS ONLY core.servicios DROP CONSTRAINT IF EXISTS servicios_categoria_id_fkey;
ALTER TABLE IF EXISTS ONLY core.rol_permisos DROP CONSTRAINT IF EXISTS rol_permisos_rol_id_fkey;
ALTER TABLE IF EXISTS ONLY core.rol_permisos DROP CONSTRAINT IF EXISTS rol_permisos_permiso_id_fkey;
ALTER TABLE IF EXISTS ONLY core.recordatorios DROP CONSTRAINT IF EXISTS recordatorios_mascota_id_fkey;
ALTER TABLE IF EXISTS ONLY core.recordatorios DROP CONSTRAINT IF EXISTS recordatorios_empresa_id_fkey;
ALTER TABLE IF EXISTS ONLY core.recordatorios DROP CONSTRAINT IF EXISTS recordatorios_cliente_id_fkey;
ALTER TABLE IF EXISTS ONLY core.razas DROP CONSTRAINT IF EXISTS razas_especie_id_fkey;
ALTER TABLE IF EXISTS ONLY core.razas DROP CONSTRAINT IF EXISTS razas_empresa_id_fkey;
ALTER TABLE IF EXISTS ONLY core.proveedores DROP CONSTRAINT IF EXISTS proveedores_empresa_id_fkey;
ALTER TABLE IF EXISTS ONLY core.proveedores DROP CONSTRAINT IF EXISTS proveedores_categoria_id_fkey;
ALTER TABLE IF EXISTS ONLY core.proveedor_contactos DROP CONSTRAINT IF EXISTS proveedor_contactos_proveedor_id_fkey;
ALTER TABLE IF EXISTS ONLY core.productos DROP CONSTRAINT IF EXISTS productos_empresa_id_fkey;
ALTER TABLE IF EXISTS ONLY core.productos DROP CONSTRAINT IF EXISTS productos_categoria_id_fkey;
ALTER TABLE IF EXISTS ONLY core.plantillas_mensaje DROP CONSTRAINT IF EXISTS plantillas_mensaje_empresa_id_fkey;
ALTER TABLE IF EXISTS ONLY core.permisos_laborales DROP CONSTRAINT IF EXISTS permisos_laborales_user_id_fkey;
ALTER TABLE IF EXISTS ONLY core.permisos_laborales DROP CONSTRAINT IF EXISTS permisos_laborales_empresa_id_fkey;
ALTER TABLE IF EXISTS ONLY core.permisos_laborales DROP CONSTRAINT IF EXISTS permisos_laborales_aprobado_por_fkey;
ALTER TABLE IF EXISTS ONLY core.pagos_proveedor DROP CONSTRAINT IF EXISTS pagos_proveedor_proveedor_id_fkey;
ALTER TABLE IF EXISTS ONLY core.pagos_proveedor DROP CONSTRAINT IF EXISTS pagos_proveedor_orden_compra_id_fkey;
ALTER TABLE IF EXISTS ONLY core.pagos_proveedor DROP CONSTRAINT IF EXISTS pagos_proveedor_empresa_id_fkey;
ALTER TABLE IF EXISTS ONLY core.pagos DROP CONSTRAINT IF EXISTS pagos_empresa_id_fkey;
ALTER TABLE IF EXISTS ONLY core.pagos DROP CONSTRAINT IF EXISTS pagos_cliente_id_fkey;
ALTER TABLE IF EXISTS ONLY core.pago_aplicaciones DROP CONSTRAINT IF EXISTS pago_aplicaciones_pago_id_fkey;
ALTER TABLE IF EXISTS ONLY core.pago_aplicaciones DROP CONSTRAINT IF EXISTS pago_aplicaciones_comprobante_id_fkey;
ALTER TABLE IF EXISTS ONLY core.ordenes_servicio DROP CONSTRAINT IF EXISTS ordenes_servicio_veterinario_id_fkey;
ALTER TABLE IF EXISTS ONLY core.ordenes_servicio DROP CONSTRAINT IF EXISTS ordenes_servicio_servicio_id_fkey;
ALTER TABLE IF EXISTS ONLY core.ordenes_servicio DROP CONSTRAINT IF EXISTS ordenes_servicio_mascota_id_fkey;
ALTER TABLE IF EXISTS ONLY core.ordenes_servicio DROP CONSTRAINT IF EXISTS ordenes_servicio_empresa_id_fkey;
ALTER TABLE IF EXISTS ONLY core.ordenes_servicio DROP CONSTRAINT IF EXISTS ordenes_servicio_consulta_id_fkey;
ALTER TABLE IF EXISTS ONLY core.ordenes_servicio DROP CONSTRAINT IF EXISTS ordenes_servicio_cliente_id_fkey;
ALTER TABLE IF EXISTS ONLY core.ordenes_servicio DROP CONSTRAINT IF EXISTS ordenes_servicio_cita_id_fkey;
ALTER TABLE IF EXISTS ONLY core.ordenes_compra DROP CONSTRAINT IF EXISTS ordenes_compra_proveedor_id_fkey;
ALTER TABLE IF EXISTS ONLY core.ordenes_compra DROP CONSTRAINT IF EXISTS ordenes_compra_empresa_id_fkey;
ALTER TABLE IF EXISTS ONLY core.ordenes_compra DROP CONSTRAINT IF EXISTS ordenes_compra_almacen_id_fkey;
ALTER TABLE IF EXISTS ONLY core.orden_compra_items DROP CONSTRAINT IF EXISTS orden_compra_items_producto_id_fkey;
ALTER TABLE IF EXISTS ONLY core.orden_compra_items DROP CONSTRAINT IF EXISTS orden_compra_items_orden_compra_id_fkey;
ALTER TABLE IF EXISTS ONLY core.notificaciones DROP CONSTRAINT IF EXISTS notificaciones_user_id_fkey;
ALTER TABLE IF EXISTS ONLY core.notificaciones DROP CONSTRAINT IF EXISTS notificaciones_empresa_id_fkey;
ALTER TABLE IF EXISTS ONLY core.notas_medicas DROP CONSTRAINT IF EXISTS notas_medicas_user_id_fkey;
ALTER TABLE IF EXISTS ONLY core.notas_medicas DROP CONSTRAINT IF EXISTS notas_medicas_mascota_id_fkey;
ALTER TABLE IF EXISTS ONLY core.notas_medicas DROP CONSTRAINT IF EXISTS notas_medicas_empresa_id_fkey;
ALTER TABLE IF EXISTS ONLY core.movimientos_inventario DROP CONSTRAINT IF EXISTS movimientos_inventario_producto_id_fkey;
ALTER TABLE IF EXISTS ONLY core.movimientos_inventario DROP CONSTRAINT IF EXISTS movimientos_inventario_mascota_id_fkey;
ALTER TABLE IF EXISTS ONLY core.movimientos_inventario DROP CONSTRAINT IF EXISTS movimientos_inventario_lote_id_fkey;
ALTER TABLE IF EXISTS ONLY core.movimientos_inventario DROP CONSTRAINT IF EXISTS movimientos_inventario_empresa_id_fkey;
ALTER TABLE IF EXISTS ONLY core.movimientos_inventario DROP CONSTRAINT IF EXISTS movimientos_inventario_consulta_id_fkey;
ALTER TABLE IF EXISTS ONLY core.movimientos_inventario DROP CONSTRAINT IF EXISTS movimientos_inventario_cliente_id_fkey;
ALTER TABLE IF EXISTS ONLY core.movimientos_inventario DROP CONSTRAINT IF EXISTS movimientos_inventario_almacen_id_fkey;
ALTER TABLE IF EXISTS ONLY core.movimientos_inventario DROP CONSTRAINT IF EXISTS movimientos_inventario_almacen_destino_id_fkey;
ALTER TABLE IF EXISTS ONLY core.movimientos_caja DROP CONSTRAINT IF EXISTS movimientos_caja_pago_id_fkey;
ALTER TABLE IF EXISTS ONLY core.movimientos_caja DROP CONSTRAINT IF EXISTS movimientos_caja_empresa_id_fkey;
ALTER TABLE IF EXISTS ONLY core.movimientos_caja DROP CONSTRAINT IF EXISTS movimientos_caja_comprobante_id_fkey;
ALTER TABLE IF EXISTS ONLY core.movimientos_caja DROP CONSTRAINT IF EXISTS movimientos_caja_caja_id_fkey;
ALTER TABLE IF EXISTS ONLY core.mascotas DROP CONSTRAINT IF EXISTS mascotas_raza_id_fkey;
ALTER TABLE IF EXISTS ONLY core.mascotas_extraviadas DROP CONSTRAINT IF EXISTS mascotas_extraviadas_mascota_id_fkey;
ALTER TABLE IF EXISTS ONLY core.mascotas_extraviadas DROP CONSTRAINT IF EXISTS mascotas_extraviadas_empresa_id_fkey;
ALTER TABLE IF EXISTS ONLY core.mascotas DROP CONSTRAINT IF EXISTS mascotas_especie_id_fkey;
ALTER TABLE IF EXISTS ONLY core.mascotas DROP CONSTRAINT IF EXISTS mascotas_empresa_id_fkey;
ALTER TABLE IF EXISTS ONLY core.mascotas DROP CONSTRAINT IF EXISTS mascotas_cliente_id_fkey;
ALTER TABLE IF EXISTS ONLY core.lotes DROP CONSTRAINT IF EXISTS lotes_producto_id_fkey;
ALTER TABLE IF EXISTS ONLY core.lotes DROP CONSTRAINT IF EXISTS lotes_empresa_id_fkey;
ALTER TABLE IF EXISTS ONLY core.insumos_utilizados DROP CONSTRAINT IF EXISTS insumos_utilizados_producto_id_fkey;
ALTER TABLE IF EXISTS ONLY core.insumos_utilizados DROP CONSTRAINT IF EXISTS insumos_utilizados_orden_servicio_id_fkey;
ALTER TABLE IF EXISTS ONLY core.insumos_utilizados DROP CONSTRAINT IF EXISTS insumos_utilizados_mascota_id_fkey;
ALTER TABLE IF EXISTS ONLY core.insumos_utilizados DROP CONSTRAINT IF EXISTS insumos_utilizados_hospitalizacion_id_fkey;
ALTER TABLE IF EXISTS ONLY core.insumos_utilizados DROP CONSTRAINT IF EXISTS insumos_utilizados_empresa_id_fkey;
ALTER TABLE IF EXISTS ONLY core.insumos_utilizados DROP CONSTRAINT IF EXISTS insumos_utilizados_consulta_id_fkey;
ALTER TABLE IF EXISTS ONLY core.insumos_utilizados DROP CONSTRAINT IF EXISTS insumos_utilizados_cirugia_id_fkey;
ALTER TABLE IF EXISTS ONLY core.hospitalizaciones DROP CONSTRAINT IF EXISTS hospitalizaciones_veterinario_id_fkey;
ALTER TABLE IF EXISTS ONLY core.hospitalizaciones DROP CONSTRAINT IF EXISTS hospitalizaciones_mascota_id_fkey;
ALTER TABLE IF EXISTS ONLY core.hospitalizaciones DROP CONSTRAINT IF EXISTS hospitalizaciones_empresa_id_fkey;
ALTER TABLE IF EXISTS ONLY core.hospitalizaciones DROP CONSTRAINT IF EXISTS hospitalizaciones_consultorio_id_fkey;
ALTER TABLE IF EXISTS ONLY core.hospitalizacion_evoluciones DROP CONSTRAINT IF EXISTS hospitalizacion_evoluciones_user_id_fkey;
ALTER TABLE IF EXISTS ONLY core.hospitalizacion_evoluciones DROP CONSTRAINT IF EXISTS hospitalizacion_evoluciones_hospitalizacion_id_fkey;
ALTER TABLE IF EXISTS ONLY core.horarios_atencion DROP CONSTRAINT IF EXISTS horarios_atencion_empresa_id_fkey;
ALTER TABLE IF EXISTS ONLY core.historia_clinica DROP CONSTRAINT IF EXISTS historia_clinica_veterinario_id_fkey;
ALTER TABLE IF EXISTS ONLY core.historia_clinica DROP CONSTRAINT IF EXISTS historia_clinica_mascota_id_fkey;
ALTER TABLE IF EXISTS ONLY core.historia_clinica DROP CONSTRAINT IF EXISTS historia_clinica_empresa_id_fkey;
ALTER TABLE IF EXISTS ONLY core.historia_clinica DROP CONSTRAINT IF EXISTS historia_clinica_cliente_id_fkey;
ALTER TABLE IF EXISTS ONLY core.historia_clinica DROP CONSTRAINT IF EXISTS historia_clinica_cita_id_fkey;
ALTER TABLE IF EXISTS ONLY core.vacunas DROP CONSTRAINT IF EXISTS fk_vacunas_producto;
ALTER TABLE IF EXISTS ONLY core.tratamientos DROP CONSTRAINT IF EXISTS fk_tratamientos_producto;
ALTER TABLE IF EXISTS ONLY core.servicios DROP CONSTRAINT IF EXISTS fk_servicios_producto;
ALTER TABLE IF EXISTS ONLY core.pagos DROP CONSTRAINT IF EXISTS fk_pagos_caja;
ALTER TABLE IF EXISTS ONLY core.ordenes_servicio DROP CONSTRAINT IF EXISTS fk_ordenes_servicio_comprobante;
ALTER TABLE IF EXISTS ONLY core.movimientos_inventario DROP CONSTRAINT IF EXISTS fk_movimientos_proveedor;
ALTER TABLE IF EXISTS ONLY core.movimientos_inventario DROP CONSTRAINT IF EXISTS fk_movimientos_oc;
ALTER TABLE IF EXISTS ONLY core.movimientos_inventario DROP CONSTRAINT IF EXISTS fk_movimientos_comprobante;
ALTER TABLE IF EXISTS ONLY core.desparasitaciones DROP CONSTRAINT IF EXISTS fk_desparasitaciones_producto;
ALTER TABLE IF EXISTS ONLY core.comprobantes DROP CONSTRAINT IF EXISTS fk_comprobantes_caja;
ALTER TABLE IF EXISTS ONLY core.examenes DROP CONSTRAINT IF EXISTS examenes_veterinario_id_fkey;
ALTER TABLE IF EXISTS ONLY core.examenes DROP CONSTRAINT IF EXISTS examenes_servicio_id_fkey;
ALTER TABLE IF EXISTS ONLY core.examenes DROP CONSTRAINT IF EXISTS examenes_mascota_id_fkey;
ALTER TABLE IF EXISTS ONLY core.examenes DROP CONSTRAINT IF EXISTS examenes_empresa_id_fkey;
ALTER TABLE IF EXISTS ONLY core.examenes DROP CONSTRAINT IF EXISTS examenes_consulta_id_fkey;
ALTER TABLE IF EXISTS ONLY core.evaluaciones_personal DROP CONSTRAINT IF EXISTS evaluaciones_personal_user_id_fkey;
ALTER TABLE IF EXISTS ONLY core.evaluaciones_personal DROP CONSTRAINT IF EXISTS evaluaciones_personal_evaluador_id_fkey;
ALTER TABLE IF EXISTS ONLY core.evaluaciones_personal DROP CONSTRAINT IF EXISTS evaluaciones_personal_empresa_id_fkey;
ALTER TABLE IF EXISTS ONLY core.esquemas_vacunacion DROP CONSTRAINT IF EXISTS esquemas_vacunacion_especie_id_fkey;
ALTER TABLE IF EXISTS ONLY core.esquemas_vacunacion DROP CONSTRAINT IF EXISTS esquemas_vacunacion_empresa_id_fkey;
ALTER TABLE IF EXISTS ONLY core.documentos_medicos DROP CONSTRAINT IF EXISTS documentos_medicos_mascota_id_fkey;
ALTER TABLE IF EXISTS ONLY core.documentos_medicos DROP CONSTRAINT IF EXISTS documentos_medicos_empresa_id_fkey;
ALTER TABLE IF EXISTS ONLY core.documentos_medicos DROP CONSTRAINT IF EXISTS documentos_medicos_consulta_id_fkey;
ALTER TABLE IF EXISTS ONLY core.disponibilidad DROP CONSTRAINT IF EXISTS disponibilidad_user_id_fkey;
ALTER TABLE IF EXISTS ONLY core.disponibilidad DROP CONSTRAINT IF EXISTS disponibilidad_permiso_id_fkey;
ALTER TABLE IF EXISTS ONLY core.disponibilidad DROP CONSTRAINT IF EXISTS disponibilidad_empresa_id_fkey;
ALTER TABLE IF EXISTS ONLY core.disponibilidad DROP CONSTRAINT IF EXISTS disponibilidad_consultorio_id_fkey;
ALTER TABLE IF EXISTS ONLY core.desparasitaciones DROP CONSTRAINT IF EXISTS desparasitaciones_veterinario_id_fkey;
ALTER TABLE IF EXISTS ONLY core.desparasitaciones DROP CONSTRAINT IF EXISTS desparasitaciones_mascota_id_fkey;
ALTER TABLE IF EXISTS ONLY core.desparasitaciones DROP CONSTRAINT IF EXISTS desparasitaciones_empresa_id_fkey;
ALTER TABLE IF EXISTS ONLY core.desparasitaciones DROP CONSTRAINT IF EXISTS desparasitaciones_consulta_id_fkey;
ALTER TABLE IF EXISTS ONLY core.contratos_personal DROP CONSTRAINT IF EXISTS contratos_personal_user_id_fkey;
ALTER TABLE IF EXISTS ONLY core.contratos_personal DROP CONSTRAINT IF EXISTS contratos_personal_empresa_id_fkey;
ALTER TABLE IF EXISTS ONLY core.consultorios DROP CONSTRAINT IF EXISTS consultorios_empresa_id_fkey;
ALTER TABLE IF EXISTS ONLY core.consultas DROP CONSTRAINT IF EXISTS consultas_veterinario_id_fkey;
ALTER TABLE IF EXISTS ONLY core.consultas DROP CONSTRAINT IF EXISTS consultas_mascota_id_fkey;
ALTER TABLE IF EXISTS ONLY core.consultas DROP CONSTRAINT IF EXISTS consultas_empresa_id_fkey;
ALTER TABLE IF EXISTS ONLY core.consultas DROP CONSTRAINT IF EXISTS consultas_cliente_id_fkey;
ALTER TABLE IF EXISTS ONLY core.consultas DROP CONSTRAINT IF EXISTS consultas_cita_id_fkey;
ALTER TABLE IF EXISTS ONLY core.comunicaciones DROP CONSTRAINT IF EXISTS comunicaciones_user_id_fkey;
ALTER TABLE IF EXISTS ONLY core.comunicaciones DROP CONSTRAINT IF EXISTS comunicaciones_mascota_id_fkey;
ALTER TABLE IF EXISTS ONLY core.comunicaciones DROP CONSTRAINT IF EXISTS comunicaciones_empresa_id_fkey;
ALTER TABLE IF EXISTS ONLY core.comunicaciones DROP CONSTRAINT IF EXISTS comunicaciones_cliente_id_fkey;
ALTER TABLE IF EXISTS ONLY core.comprobantes DROP CONSTRAINT IF EXISTS comprobantes_mascota_id_fkey;
ALTER TABLE IF EXISTS ONLY core.comprobantes DROP CONSTRAINT IF EXISTS comprobantes_empresa_id_fkey;
ALTER TABLE IF EXISTS ONLY core.comprobantes DROP CONSTRAINT IF EXISTS comprobantes_documento_ref_id_fkey;
ALTER TABLE IF EXISTS ONLY core.comprobantes DROP CONSTRAINT IF EXISTS comprobantes_consulta_id_fkey;
ALTER TABLE IF EXISTS ONLY core.comprobantes DROP CONSTRAINT IF EXISTS comprobantes_cliente_id_fkey;
ALTER TABLE IF EXISTS ONLY core.comprobantes DROP CONSTRAINT IF EXISTS comprobantes_cita_id_fkey;
ALTER TABLE IF EXISTS ONLY core.comprobante_pse_log DROP CONSTRAINT IF EXISTS comprobante_pse_log_comprobante_id_fkey;
ALTER TABLE IF EXISTS ONLY core.comprobante_items DROP CONSTRAINT IF EXISTS comprobante_items_servicio_id_fkey;
ALTER TABLE IF EXISTS ONLY core.comprobante_items DROP CONSTRAINT IF EXISTS comprobante_items_producto_id_fkey;
ALTER TABLE IF EXISTS ONLY core.comprobante_items DROP CONSTRAINT IF EXISTS comprobante_items_orden_servicio_id_fkey;
ALTER TABLE IF EXISTS ONLY core.comprobante_items DROP CONSTRAINT IF EXISTS comprobante_items_item_ref_id_fkey;
ALTER TABLE IF EXISTS ONLY core.comprobante_items DROP CONSTRAINT IF EXISTS comprobante_items_insumo_id_fkey;
ALTER TABLE IF EXISTS ONLY core.comprobante_items DROP CONSTRAINT IF EXISTS comprobante_items_comprobante_id_fkey;
ALTER TABLE IF EXISTS ONLY core.clientes DROP CONSTRAINT IF EXISTS clientes_empresa_id_fkey;
ALTER TABLE IF EXISTS ONLY core.clausulas DROP CONSTRAINT IF EXISTS clausulas_empresa_id_fkey;
ALTER TABLE IF EXISTS ONLY core.citas DROP CONSTRAINT IF EXISTS citas_veterinario_id_fkey;
ALTER TABLE IF EXISTS ONLY core.citas DROP CONSTRAINT IF EXISTS citas_servicio_id_fkey;
ALTER TABLE IF EXISTS ONLY core.citas DROP CONSTRAINT IF EXISTS citas_mascota_id_fkey;
ALTER TABLE IF EXISTS ONLY core.citas_lista_espera DROP CONSTRAINT IF EXISTS citas_lista_espera_veterinario_id_fkey;
ALTER TABLE IF EXISTS ONLY core.citas_lista_espera DROP CONSTRAINT IF EXISTS citas_lista_espera_servicio_id_fkey;
ALTER TABLE IF EXISTS ONLY core.citas_lista_espera DROP CONSTRAINT IF EXISTS citas_lista_espera_mascota_id_fkey;
ALTER TABLE IF EXISTS ONLY core.citas_lista_espera DROP CONSTRAINT IF EXISTS citas_lista_espera_empresa_id_fkey;
ALTER TABLE IF EXISTS ONLY core.citas_lista_espera DROP CONSTRAINT IF EXISTS citas_lista_espera_cliente_id_fkey;
ALTER TABLE IF EXISTS ONLY core.citas_historial DROP CONSTRAINT IF EXISTS citas_historial_cita_id_fkey;
ALTER TABLE IF EXISTS ONLY core.citas DROP CONSTRAINT IF EXISTS citas_empresa_id_fkey;
ALTER TABLE IF EXISTS ONLY core.citas DROP CONSTRAINT IF EXISTS citas_consultorio_id_fkey;
ALTER TABLE IF EXISTS ONLY core.citas DROP CONSTRAINT IF EXISTS citas_cliente_id_fkey;
ALTER TABLE IF EXISTS ONLY core.cirugias DROP CONSTRAINT IF EXISTS cirugias_servicio_id_fkey;
ALTER TABLE IF EXISTS ONLY core.cirugias DROP CONSTRAINT IF EXISTS cirugias_mascota_id_fkey;
ALTER TABLE IF EXISTS ONLY core.cirugias DROP CONSTRAINT IF EXISTS cirugias_empresa_id_fkey;
ALTER TABLE IF EXISTS ONLY core.cirugias DROP CONSTRAINT IF EXISTS cirugias_consultorio_id_fkey;
ALTER TABLE IF EXISTS ONLY core.cirugias DROP CONSTRAINT IF EXISTS cirugias_cita_id_fkey;
ALTER TABLE IF EXISTS ONLY core.cirugias DROP CONSTRAINT IF EXISTS cirugias_cirujano_id_fkey;
ALTER TABLE IF EXISTS ONLY core.cirugias DROP CONSTRAINT IF EXISTS cirugias_anestesista_id_fkey;
ALTER TABLE IF EXISTS ONLY core.categorias DROP CONSTRAINT IF EXISTS categorias_padre_id_fkey;
ALTER TABLE IF EXISTS ONLY core.categorias DROP CONSTRAINT IF EXISTS categorias_empresa_id_fkey;
ALTER TABLE IF EXISTS ONLY core.cajas DROP CONSTRAINT IF EXISTS cajas_user_cierre_id_fkey;
ALTER TABLE IF EXISTS ONLY core.cajas DROP CONSTRAINT IF EXISTS cajas_user_apertura_id_fkey;
ALTER TABLE IF EXISTS ONLY core.cajas DROP CONSTRAINT IF EXISTS cajas_empresa_id_fkey;
ALTER TABLE IF EXISTS ONLY core.asistencia DROP CONSTRAINT IF EXISTS asistencia_user_id_fkey;
ALTER TABLE IF EXISTS ONLY core.asistencia DROP CONSTRAINT IF EXISTS asistencia_empresa_id_fkey;
ALTER TABLE IF EXISTS ONLY core.almacenes DROP CONSTRAINT IF EXISTS almacenes_empresa_id_fkey;
DROP TRIGGER IF EXISTS tg_vacunas_updated_at ON core.vacunas;
DROP TRIGGER IF EXISTS tg_users_validate_rol_scope ON core.users;
DROP TRIGGER IF EXISTS tg_users_updated_at ON core.users;
DROP TRIGGER IF EXISTS tg_tratamientos_updated_at ON core.tratamientos;
DROP TRIGGER IF EXISTS tg_stock_updated_at ON core.stock;
DROP TRIGGER IF EXISTS tg_servicios_updated_at ON core.servicios;
DROP TRIGGER IF EXISTS tg_roles_updated_at ON core.roles;
DROP TRIGGER IF EXISTS tg_razas_updated_at ON core.razas;
DROP TRIGGER IF EXISTS tg_proveedores_updated_at ON core.proveedores;
DROP TRIGGER IF EXISTS tg_proveedor_contactos_updated_at ON core.proveedor_contactos;
DROP TRIGGER IF EXISTS tg_productos_updated_at ON core.productos;
DROP TRIGGER IF EXISTS tg_plantillas_mensaje_updated_at ON core.plantillas_mensaje;
DROP TRIGGER IF EXISTS tg_permisos_laborales_updated_at ON core.permisos_laborales;
DROP TRIGGER IF EXISTS tg_ordenes_servicio_updated_at ON core.ordenes_servicio;
DROP TRIGGER IF EXISTS tg_ordenes_compra_updated_at ON core.ordenes_compra;
DROP TRIGGER IF EXISTS tg_notas_medicas_updated_at ON core.notas_medicas;
DROP TRIGGER IF EXISTS tg_normalizar_user ON core.users;
DROP TRIGGER IF EXISTS tg_normalizar_servicio ON core.servicios;
DROP TRIGGER IF EXISTS tg_normalizar_raza ON core.razas;
DROP TRIGGER IF EXISTS tg_normalizar_proveedor_contacto ON core.proveedor_contactos;
DROP TRIGGER IF EXISTS tg_normalizar_proveedor ON core.proveedores;
DROP TRIGGER IF EXISTS tg_normalizar_producto ON core.productos;
DROP TRIGGER IF EXISTS tg_normalizar_mascota ON core.mascotas;
DROP TRIGGER IF EXISTS tg_normalizar_especie ON core.especies;
DROP TRIGGER IF EXISTS tg_normalizar_empresa ON core.empresas;
DROP TRIGGER IF EXISTS tg_normalizar_cliente ON core.clientes;
DROP TRIGGER IF EXISTS tg_movimiento_aplicar_stock ON core.movimientos_inventario;
DROP TRIGGER IF EXISTS tg_mascotas_updated_at ON core.mascotas;
DROP TRIGGER IF EXISTS tg_mascotas_extraviadas_updated_at ON core.mascotas_extraviadas;
DROP TRIGGER IF EXISTS tg_mascota_fallecida ON core.mascotas;
DROP TRIGGER IF EXISTS tg_lotes_updated_at ON core.lotes;
DROP TRIGGER IF EXISTS tg_hospitalizaciones_updated_at ON core.hospitalizaciones;
DROP TRIGGER IF EXISTS tg_horarios_atencion_updated_at ON core.horarios_atencion;
DROP TRIGGER IF EXISTS tg_historia_clinica_updated_at ON core.historia_clinica;
DROP TRIGGER IF EXISTS tg_evaluacion_promedio ON core.evaluaciones_personal;
DROP TRIGGER IF EXISTS tg_esquemas_vacunacion_updated_at ON core.esquemas_vacunacion;
DROP TRIGGER IF EXISTS tg_especies_updated_at ON core.especies;
DROP TRIGGER IF EXISTS tg_especializaciones_updated_at ON core.especializaciones;
DROP TRIGGER IF EXISTS tg_empresas_updated_at ON core.empresas;
DROP TRIGGER IF EXISTS tg_disponibilidad_updated_at ON core.disponibilidad;
DROP TRIGGER IF EXISTS tg_contratos_personal_updated_at ON core.contratos_personal;
DROP TRIGGER IF EXISTS tg_consultorios_updated_at ON core.consultorios;
DROP TRIGGER IF EXISTS tg_consultas_updated_at ON core.consultas;
DROP TRIGGER IF EXISTS tg_consulta_sync_peso ON core.consultas;
DROP TRIGGER IF EXISTS tg_comprobantes_updated_at ON core.comprobantes;
DROP TRIGGER IF EXISTS tg_comprobante_recalcular ON core.comprobante_items;
DROP TRIGGER IF EXISTS tg_clientes_updated_at ON core.clientes;
DROP TRIGGER IF EXISTS tg_clausulas_updated_at ON core.clausulas;
DROP TRIGGER IF EXISTS tg_citas_updated_at ON core.citas;
DROP TRIGGER IF EXISTS tg_cirugias_updated_at ON core.cirugias;
DROP TRIGGER IF EXISTS tg_categorias_updated_at ON core.categorias;
DROP TRIGGER IF EXISTS tg_cajas_updated_at ON core.cajas;
DROP TRIGGER IF EXISTS tg_asistencia_updated_at ON core.asistencia;
DROP TRIGGER IF EXISTS tg_asistencia_horas ON core.asistencia;
DROP TRIGGER IF EXISTS tg_almacenes_updated_at ON core.almacenes;
DROP INDEX IF EXISTS core.uq_razas_por_empresa;
DROP INDEX IF EXISTS core.uq_razas_globales;
DROP INDEX IF EXISTS core.uq_ordenes_servicio_origen;
DROP INDEX IF EXISTS core.uq_mascotas_microchip;
DROP INDEX IF EXISTS core.uq_caja_abierta_por_user;
DROP INDEX IF EXISTS core.ix_vacunas_refuerzo;
DROP INDEX IF EXISTS core.ix_vacunas_mascota;
DROP INDEX IF EXISTS core.ix_users_veterinario;
DROP INDEX IF EXISTS core.ix_users_rol;
DROP INDEX IF EXISTS core.ix_users_estado;
DROP INDEX IF EXISTS core.ix_users_empresa;
DROP INDEX IF EXISTS core.ix_users_email_lower;
DROP INDEX IF EXISTS core.ix_tratamientos_mascota;
DROP INDEX IF EXISTS core.ix_tratamientos_activos;
DROP INDEX IF EXISTS core.ix_stock_empresa;
DROP INDEX IF EXISTS core.ix_sesiones_user;
DROP INDEX IF EXISTS core.ix_servicios_tipo;
DROP INDEX IF EXISTS core.ix_servicios_nombre_trgm;
DROP INDEX IF EXISTS core.ix_servicios_empresa;
DROP INDEX IF EXISTS core.ix_rol_permisos_permiso;
DROP INDEX IF EXISTS core.ix_recordatorios_pend;
DROP INDEX IF EXISTS core.ix_razas_especie;
DROP INDEX IF EXISTS core.ix_razas_empresa;
DROP INDEX IF EXISTS core.ix_proveedores_razon_trgm;
DROP INDEX IF EXISTS core.ix_proveedores_empresa;
DROP INDEX IF EXISTS core.ix_proveedor_contactos;
DROP INDEX IF EXISTS core.ix_productos_nombre_trgm;
DROP INDEX IF EXISTS core.ix_productos_empresa;
DROP INDEX IF EXISTS core.ix_productos_critico;
DROP INDEX IF EXISTS core.ix_plantillas_mensaje;
DROP INDEX IF EXISTS core.ix_permisos_modulo;
DROP INDEX IF EXISTS core.ix_permisos_laborales;
DROP INDEX IF EXISTS core.ix_pagos_proveedor;
DROP INDEX IF EXISTS core.ix_pagos_empresa;
DROP INDEX IF EXISTS core.ix_pagos_cliente;
DROP INDEX IF EXISTS core.ix_pago_aplicaciones_pago;
DROP INDEX IF EXISTS core.ix_pago_aplicaciones_comp;
DROP INDEX IF EXISTS core.ix_ordenes_servicio_pend;
DROP INDEX IF EXISTS core.ix_ordenes_servicio_mascota;
DROP INDEX IF EXISTS core.ix_ordenes_servicio_empresa;
DROP INDEX IF EXISTS core.ix_ordenes_compra_proveedor;
DROP INDEX IF EXISTS core.ix_ordenes_compra_empresa;
DROP INDEX IF EXISTS core.ix_oc_items;
DROP INDEX IF EXISTS core.ix_notificaciones_user;
DROP INDEX IF EXISTS core.ix_notas_mascota;
DROP INDEX IF EXISTS core.ix_movimientos_producto;
DROP INDEX IF EXISTS core.ix_movimientos_empresa;
DROP INDEX IF EXISTS core.ix_mov_caja;
DROP INDEX IF EXISTS core.ix_mascotas_nombre_trgm;
DROP INDEX IF EXISTS core.ix_mascotas_extraviadas;
DROP INDEX IF EXISTS core.ix_mascotas_estado;
DROP INDEX IF EXISTS core.ix_mascotas_especie;
DROP INDEX IF EXISTS core.ix_mascotas_empresa;
DROP INDEX IF EXISTS core.ix_mascotas_cliente;
DROP INDEX IF EXISTS core.ix_lotes_vencimiento;
DROP INDEX IF EXISTS core.ix_lista_espera_empresa;
DROP INDEX IF EXISTS core.ix_insumos_empresa;
DROP INDEX IF EXISTS core.ix_insumos_consulta;
DROP INDEX IF EXISTS core.ix_hospitalizaciones_mascota;
DROP INDEX IF EXISTS core.ix_hospitalizaciones_empresa;
DROP INDEX IF EXISTS core.ix_hosp_evol;
DROP INDEX IF EXISTS core.ix_horarios_empresa;
DROP INDEX IF EXISTS core.ix_historia_tipo;
DROP INDEX IF EXISTS core.ix_historia_mascota;
DROP INDEX IF EXISTS core.ix_historia_empresa;
DROP INDEX IF EXISTS core.ix_examenes_mascota;
DROP INDEX IF EXISTS core.ix_evaluaciones;
DROP INDEX IF EXISTS core.ix_esquemas_vac_empresa;
DROP INDEX IF EXISTS core.ix_empresas_razon_trgm;
DROP INDEX IF EXISTS core.ix_empresas_estado;
DROP INDEX IF EXISTS core.ix_documentos_mascota;
DROP INDEX IF EXISTS core.ix_disponibilidad_permiso;
DROP INDEX IF EXISTS core.ix_disponibilidad;
DROP INDEX IF EXISTS core.ix_desparasitaciones_mascota;
DROP INDEX IF EXISTS core.ix_contratos_personal;
DROP INDEX IF EXISTS core.ix_consultas_vet;
DROP INDEX IF EXISTS core.ix_consultas_mascota;
DROP INDEX IF EXISTS core.ix_consultas_empresa;
DROP INDEX IF EXISTS core.ix_comunicaciones_seguim;
DROP INDEX IF EXISTS core.ix_comunicaciones_cliente;
DROP INDEX IF EXISTS core.ix_comprobantes_por_enviar;
DROP INDEX IF EXISTS core.ix_comprobantes_pend;
DROP INDEX IF EXISTS core.ix_comprobantes_empresa;
DROP INDEX IF EXISTS core.ix_comprobantes_cliente;
DROP INDEX IF EXISTS core.ix_comprobante_pse_log;
DROP INDEX IF EXISTS core.ix_comprobante_items_ref;
DROP INDEX IF EXISTS core.ix_comprobante_items;
DROP INDEX IF EXISTS core.ix_clientes_telefono;
DROP INDEX IF EXISTS core.ix_clientes_nombre_trgm;
DROP INDEX IF EXISTS core.ix_clientes_estado;
DROP INDEX IF EXISTS core.ix_clientes_empresa;
DROP INDEX IF EXISTS core.ix_clientes_doc_trgm;
DROP INDEX IF EXISTS core.ix_clausulas_empresa;
DROP INDEX IF EXISTS core.ix_citas_veterinario;
DROP INDEX IF EXISTS core.ix_citas_mascota;
DROP INDEX IF EXISTS core.ix_citas_historial_cita;
DROP INDEX IF EXISTS core.ix_citas_estado;
DROP INDEX IF EXISTS core.ix_citas_empresa_fecha;
DROP INDEX IF EXISTS core.ix_citas_cliente;
DROP INDEX IF EXISTS core.ix_cirugias_mascota;
DROP INDEX IF EXISTS core.ix_cirugias_empresa;
DROP INDEX IF EXISTS core.ix_categorias_empresa;
DROP INDEX IF EXISTS core.ix_cajas_empresa;
DROP INDEX IF EXISTS core.ix_audit_log_user;
DROP INDEX IF EXISTS core.ix_audit_log_entidad;
DROP INDEX IF EXISTS core.ix_audit_log_empresa;
DROP INDEX IF EXISTS core.ix_asistencia_empresa;
ALTER TABLE IF EXISTS ONLY core.vacunas DROP CONSTRAINT IF EXISTS vacunas_pkey;
ALTER TABLE IF EXISTS ONLY core.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY core.users DROP CONSTRAINT IF EXISTS users_email_key;
ALTER TABLE IF EXISTS ONLY core.users DROP CONSTRAINT IF EXISTS uq_users_documento;
ALTER TABLE IF EXISTS ONLY core.stock DROP CONSTRAINT IF EXISTS uq_stock;
ALTER TABLE IF EXISTS ONLY core.servicios DROP CONSTRAINT IF EXISTS uq_servicios_codigo;
ALTER TABLE IF EXISTS ONLY core.proveedores DROP CONSTRAINT IF EXISTS uq_proveedores_doc;
ALTER TABLE IF EXISTS ONLY core.productos DROP CONSTRAINT IF EXISTS uq_productos_codigo;
ALTER TABLE IF EXISTS ONLY core.plantillas_mensaje DROP CONSTRAINT IF EXISTS uq_plantillas_mensaje;
ALTER TABLE IF EXISTS ONLY core.ordenes_compra DROP CONSTRAINT IF EXISTS uq_ordenes_compra_numero;
ALTER TABLE IF EXISTS ONLY core.lotes DROP CONSTRAINT IF EXISTS uq_lotes;
ALTER TABLE IF EXISTS ONLY core.consultorios DROP CONSTRAINT IF EXISTS uq_consultorios_nombre;
ALTER TABLE IF EXISTS ONLY core.comprobantes DROP CONSTRAINT IF EXISTS uq_comprobantes_numero;
ALTER TABLE IF EXISTS ONLY core.clientes DROP CONSTRAINT IF EXISTS uq_clientes_documento;
ALTER TABLE IF EXISTS ONLY core.categorias DROP CONSTRAINT IF EXISTS uq_categorias_codigo;
ALTER TABLE IF EXISTS ONLY core.asistencia DROP CONSTRAINT IF EXISTS uq_asistencia;
ALTER TABLE IF EXISTS ONLY core.almacenes DROP CONSTRAINT IF EXISTS uq_almacenes_codigo;
ALTER TABLE IF EXISTS ONLY core.tratamientos DROP CONSTRAINT IF EXISTS tratamientos_pkey;
ALTER TABLE IF EXISTS ONLY core.stock DROP CONSTRAINT IF EXISTS stock_pkey;
ALTER TABLE IF EXISTS ONLY core.sesiones DROP CONSTRAINT IF EXISTS sesiones_pkey;
ALTER TABLE IF EXISTS ONLY core.sesiones DROP CONSTRAINT IF EXISTS sesiones_jti_key;
ALTER TABLE IF EXISTS ONLY core.servicios DROP CONSTRAINT IF EXISTS servicios_pkey;
ALTER TABLE IF EXISTS ONLY core.roles DROP CONSTRAINT IF EXISTS roles_pkey;
ALTER TABLE IF EXISTS ONLY core.roles DROP CONSTRAINT IF EXISTS roles_codigo_key;
ALTER TABLE IF EXISTS ONLY core.rol_permisos DROP CONSTRAINT IF EXISTS rol_permisos_pkey;
ALTER TABLE IF EXISTS ONLY core.recordatorios DROP CONSTRAINT IF EXISTS recordatorios_pkey;
ALTER TABLE IF EXISTS ONLY core.razas DROP CONSTRAINT IF EXISTS razas_pkey;
ALTER TABLE IF EXISTS ONLY core.proveedores DROP CONSTRAINT IF EXISTS proveedores_pkey;
ALTER TABLE IF EXISTS ONLY core.proveedor_contactos DROP CONSTRAINT IF EXISTS proveedor_contactos_pkey;
ALTER TABLE IF EXISTS ONLY core.productos DROP CONSTRAINT IF EXISTS productos_pkey;
ALTER TABLE IF EXISTS ONLY core.plantillas_mensaje DROP CONSTRAINT IF EXISTS plantillas_mensaje_pkey;
ALTER TABLE IF EXISTS ONLY core.permisos DROP CONSTRAINT IF EXISTS permisos_pkey;
ALTER TABLE IF EXISTS ONLY core.permisos_laborales DROP CONSTRAINT IF EXISTS permisos_laborales_pkey;
ALTER TABLE IF EXISTS ONLY core.permisos DROP CONSTRAINT IF EXISTS permisos_codigo_key;
ALTER TABLE IF EXISTS ONLY core.pagos_proveedor DROP CONSTRAINT IF EXISTS pagos_proveedor_pkey;
ALTER TABLE IF EXISTS ONLY core.pagos DROP CONSTRAINT IF EXISTS pagos_pkey;
ALTER TABLE IF EXISTS ONLY core.pago_aplicaciones DROP CONSTRAINT IF EXISTS pago_aplicaciones_pkey;
ALTER TABLE IF EXISTS ONLY core.ordenes_servicio DROP CONSTRAINT IF EXISTS ordenes_servicio_pkey;
ALTER TABLE IF EXISTS ONLY core.ordenes_compra DROP CONSTRAINT IF EXISTS ordenes_compra_pkey;
ALTER TABLE IF EXISTS ONLY core.orden_compra_items DROP CONSTRAINT IF EXISTS orden_compra_items_pkey;
ALTER TABLE IF EXISTS ONLY core.notificaciones DROP CONSTRAINT IF EXISTS notificaciones_pkey;
ALTER TABLE IF EXISTS ONLY core.notas_medicas DROP CONSTRAINT IF EXISTS notas_medicas_pkey;
ALTER TABLE IF EXISTS ONLY core.movimientos_inventario DROP CONSTRAINT IF EXISTS movimientos_inventario_pkey;
ALTER TABLE IF EXISTS ONLY core.movimientos_caja DROP CONSTRAINT IF EXISTS movimientos_caja_pkey;
ALTER TABLE IF EXISTS ONLY core.mascotas DROP CONSTRAINT IF EXISTS mascotas_pkey;
ALTER TABLE IF EXISTS ONLY core.mascotas_extraviadas DROP CONSTRAINT IF EXISTS mascotas_extraviadas_pkey;
ALTER TABLE IF EXISTS ONLY core.lotes DROP CONSTRAINT IF EXISTS lotes_pkey;
ALTER TABLE IF EXISTS ONLY core.insumos_utilizados DROP CONSTRAINT IF EXISTS insumos_utilizados_pkey;
ALTER TABLE IF EXISTS ONLY core.hospitalizaciones DROP CONSTRAINT IF EXISTS hospitalizaciones_pkey;
ALTER TABLE IF EXISTS ONLY core.hospitalizacion_evoluciones DROP CONSTRAINT IF EXISTS hospitalizacion_evoluciones_pkey;
ALTER TABLE IF EXISTS ONLY core.horarios_atencion DROP CONSTRAINT IF EXISTS horarios_atencion_pkey;
ALTER TABLE IF EXISTS ONLY core.historia_clinica DROP CONSTRAINT IF EXISTS historia_clinica_pkey;
ALTER TABLE IF EXISTS ONLY core.examenes DROP CONSTRAINT IF EXISTS examenes_pkey;
ALTER TABLE IF EXISTS ONLY core.evaluaciones_personal DROP CONSTRAINT IF EXISTS evaluaciones_personal_pkey;
ALTER TABLE IF EXISTS ONLY core.esquemas_vacunacion DROP CONSTRAINT IF EXISTS esquemas_vacunacion_pkey;
ALTER TABLE IF EXISTS ONLY core.especies DROP CONSTRAINT IF EXISTS especies_pkey;
ALTER TABLE IF EXISTS ONLY core.especies DROP CONSTRAINT IF EXISTS especies_codigo_key;
ALTER TABLE IF EXISTS ONLY core.especializaciones DROP CONSTRAINT IF EXISTS especializaciones_pkey;
ALTER TABLE IF EXISTS ONLY core.especializaciones DROP CONSTRAINT IF EXISTS especializaciones_codigo_key;
ALTER TABLE IF EXISTS ONLY core.empresas DROP CONSTRAINT IF EXISTS empresas_ruc_key;
ALTER TABLE IF EXISTS ONLY core.empresas DROP CONSTRAINT IF EXISTS empresas_pkey;
ALTER TABLE IF EXISTS ONLY core.documentos_medicos DROP CONSTRAINT IF EXISTS documentos_medicos_pkey;
ALTER TABLE IF EXISTS ONLY core.disponibilidad DROP CONSTRAINT IF EXISTS disponibilidad_pkey;
ALTER TABLE IF EXISTS ONLY core.desparasitaciones DROP CONSTRAINT IF EXISTS desparasitaciones_pkey;
ALTER TABLE IF EXISTS ONLY core.correlativos DROP CONSTRAINT IF EXISTS correlativos_pkey;
ALTER TABLE IF EXISTS ONLY core.contratos_personal DROP CONSTRAINT IF EXISTS contratos_personal_pkey;
ALTER TABLE IF EXISTS ONLY core.consultorios DROP CONSTRAINT IF EXISTS consultorios_pkey;
ALTER TABLE IF EXISTS ONLY core.consultas DROP CONSTRAINT IF EXISTS consultas_pkey;
ALTER TABLE IF EXISTS ONLY core.comunicaciones DROP CONSTRAINT IF EXISTS comunicaciones_pkey;
ALTER TABLE IF EXISTS ONLY core.comprobantes DROP CONSTRAINT IF EXISTS comprobantes_pkey;
ALTER TABLE IF EXISTS ONLY core.comprobante_pse_log DROP CONSTRAINT IF EXISTS comprobante_pse_log_pkey;
ALTER TABLE IF EXISTS ONLY core.comprobante_items DROP CONSTRAINT IF EXISTS comprobante_items_pkey;
ALTER TABLE IF EXISTS ONLY core.clientes DROP CONSTRAINT IF EXISTS clientes_pkey;
ALTER TABLE IF EXISTS ONLY core.clausulas DROP CONSTRAINT IF EXISTS clausulas_pkey;
ALTER TABLE IF EXISTS ONLY core.citas DROP CONSTRAINT IF EXISTS citas_pkey;
ALTER TABLE IF EXISTS ONLY core.citas_lista_espera DROP CONSTRAINT IF EXISTS citas_lista_espera_pkey;
ALTER TABLE IF EXISTS ONLY core.citas_historial DROP CONSTRAINT IF EXISTS citas_historial_pkey;
ALTER TABLE IF EXISTS ONLY core.cirugias DROP CONSTRAINT IF EXISTS cirugias_pkey;
ALTER TABLE IF EXISTS ONLY core.categorias DROP CONSTRAINT IF EXISTS categorias_pkey;
ALTER TABLE IF EXISTS ONLY core.cajas DROP CONSTRAINT IF EXISTS cajas_pkey;
ALTER TABLE IF EXISTS ONLY core.audit_log DROP CONSTRAINT IF EXISTS audit_log_pkey;
ALTER TABLE IF EXISTS ONLY core.asistencia DROP CONSTRAINT IF EXISTS asistencia_pkey;
ALTER TABLE IF EXISTS ONLY core.almacenes DROP CONSTRAINT IF EXISTS almacenes_pkey;
DROP TABLE IF EXISTS core.vacunas;
DROP TABLE IF EXISTS core.users;
DROP TABLE IF EXISTS core.tratamientos;
DROP TABLE IF EXISTS core.stock;
DROP TABLE IF EXISTS core.sesiones;
DROP TABLE IF EXISTS core.servicios;
DROP TABLE IF EXISTS core.roles;
DROP TABLE IF EXISTS core.rol_permisos;
DROP TABLE IF EXISTS core.recordatorios;
DROP TABLE IF EXISTS core.razas;
DROP TABLE IF EXISTS core.proveedores;
DROP TABLE IF EXISTS core.proveedor_contactos;
DROP TABLE IF EXISTS core.productos;
DROP TABLE IF EXISTS core.plantillas_mensaje;
DROP TABLE IF EXISTS core.permisos_laborales;
DROP TABLE IF EXISTS core.permisos;
DROP TABLE IF EXISTS core.pagos_proveedor;
DROP TABLE IF EXISTS core.pagos;
DROP TABLE IF EXISTS core.pago_aplicaciones;
DROP TABLE IF EXISTS core.ordenes_servicio;
DROP TABLE IF EXISTS core.ordenes_compra;
DROP TABLE IF EXISTS core.orden_compra_items;
DROP TABLE IF EXISTS core.notificaciones;
DROP TABLE IF EXISTS core.notas_medicas;
DROP TABLE IF EXISTS core.movimientos_inventario;
DROP TABLE IF EXISTS core.movimientos_caja;
DROP TABLE IF EXISTS core.mascotas_extraviadas;
DROP TABLE IF EXISTS core.mascotas;
DROP TABLE IF EXISTS core.lotes;
DROP TABLE IF EXISTS core.insumos_utilizados;
DROP TABLE IF EXISTS core.hospitalizaciones;
DROP TABLE IF EXISTS core.hospitalizacion_evoluciones;
DROP TABLE IF EXISTS core.horarios_atencion;
DROP TABLE IF EXISTS core.historia_clinica;
DROP TABLE IF EXISTS core.examenes;
DROP TABLE IF EXISTS core.evaluaciones_personal;
DROP TABLE IF EXISTS core.esquemas_vacunacion;
DROP TABLE IF EXISTS core.especies;
DROP TABLE IF EXISTS core.especializaciones;
DROP TABLE IF EXISTS core.empresas;
DROP TABLE IF EXISTS core.documentos_medicos;
DROP TABLE IF EXISTS core.disponibilidad;
DROP TABLE IF EXISTS core.desparasitaciones;
DROP TABLE IF EXISTS core.correlativos;
DROP TABLE IF EXISTS core.contratos_personal;
DROP TABLE IF EXISTS core.consultorios;
DROP TABLE IF EXISTS core.consultas;
DROP TABLE IF EXISTS core.comunicaciones;
DROP TABLE IF EXISTS core.comprobantes;
DROP TABLE IF EXISTS core.comprobante_pse_log;
DROP TABLE IF EXISTS core.comprobante_items;
DROP TABLE IF EXISTS core.clientes;
DROP TABLE IF EXISTS core.clausulas;
DROP TABLE IF EXISTS core.citas_lista_espera;
DROP TABLE IF EXISTS core.citas_historial;
DROP TABLE IF EXISTS core.citas;
DROP TABLE IF EXISTS core.cirugias;
DROP TABLE IF EXISTS core.categorias;
DROP TABLE IF EXISTS core.cajas;
DROP TABLE IF EXISTS core.audit_log;
DROP TABLE IF EXISTS core.asistencia;
DROP TABLE IF EXISTS core.almacenes;
DROP FUNCTION IF EXISTS internal.validar_ruc(p_ruc character varying);
DROP FUNCTION IF EXISTS internal.validar_payload(p_payload jsonb, p_claves text[]);
DROP FUNCTION IF EXISTS internal.validar_dni(p_dni character varying);
DROP FUNCTION IF EXISTS internal.usuario_objetivo(p_actor uuid, p_target uuid, p_empresa uuid, p_permiso character varying);
DROP FUNCTION IF EXISTS internal.tiene_permiso(p_user_id uuid, p_codigo_permiso character varying);
DROP FUNCTION IF EXISTS internal.telefono_whatsapp(p_telefono text);
DROP FUNCTION IF EXISTS internal.siguiente_numero_documento(p_empresa_id uuid, p_tipo_documento character varying, p_serie character varying);
DROP FUNCTION IF EXISTS internal.siguiente_numero(p_empresa_id uuid, p_prefijo character varying, p_ancho integer);
DROP FUNCTION IF EXISTS internal.render_plantilla(p_texto text, p_vars jsonb);
DROP FUNCTION IF EXISTS internal.registrar_kardex(p_empresa_id uuid, p_producto_id uuid, p_almacen_id uuid, p_tipo core.tipo_movimiento_inventario, p_motivo core.motivo_movimiento, p_cantidad numeric, p_user_id uuid, p_refs jsonb);
DROP FUNCTION IF EXISTS internal.registrar_evento_clinico(p_empresa_id uuid, p_mascota_id uuid, p_cliente_id uuid, p_veterinario_id uuid, p_tipo core.tipo_evento_clinico, p_titulo character varying, p_resumen text, p_entidad_id uuid, p_cita_id uuid, p_fecha timestamp with time zone);
DROP FUNCTION IF EXISTS internal.registrar_cargo_servicio(p_empresa_id uuid, p_servicio_id uuid, p_mascota_id uuid, p_user_id uuid, p_cantidad numeric, p_refs jsonb);
DROP FUNCTION IF EXISTS internal.registrar_auditoria(p_user_id uuid, p_empresa_id uuid, p_accion character varying, p_entidad character varying, p_entidad_id uuid, p_antes jsonb, p_despues jsonb);
DROP FUNCTION IF EXISTS internal.recalcular_saldo_comprobante(p_comprobante_id uuid);
DROP FUNCTION IF EXISTS internal.prioridad_mas_grave(a core.prioridad_cita, b core.prioridad_cita);
DROP FUNCTION IF EXISTS internal.plantilla_de(p_empresa_id uuid, p_tipo text);
DROP FUNCTION IF EXISTS internal.password_invalida(p_password text, p_email text);
DROP FUNCTION IF EXISTS internal.normalizar_texto(p_valor text);
DROP FUNCTION IF EXISTS internal.normalizar_telefono(p_valor text);
DROP FUNCTION IF EXISTS internal.normalizar_nombre(p_valor text);
DROP FUNCTION IF EXISTS internal.normalizar_documento(p_valor text);
DROP FUNCTION IF EXISTS internal.normalizar_correo(p_valor text);
DROP FUNCTION IF EXISTS internal.normalizar_codigo(p_valor text);
DROP FUNCTION IF EXISTS internal.normalizar(p_texto text);
DROP FUNCTION IF EXISTS internal.mover_stock(p_empresa_id uuid, p_producto_id uuid, p_tipo core.tipo_movimiento_inventario, p_motivo core.motivo_movimiento, p_cantidad numeric, p_user_id uuid, p_almacen_id uuid, p_refs jsonb);
DROP FUNCTION IF EXISTS internal.membrete_empresa(p_empresa_id uuid);
DROP FUNCTION IF EXISTS internal.lotes_a_consumir(p_producto_id uuid, p_cantidad numeric, p_incluir_vencidos boolean);
DROP FUNCTION IF EXISTS internal.hay_solapamiento_cita(p_empresa_id uuid, p_veterinario_id uuid, p_inicio timestamp with time zone, p_duracion_min integer, p_excluir_cita uuid);
DROP FUNCTION IF EXISTS internal.firma_profesional(p_user_id uuid);
DROP FUNCTION IF EXISTS internal.ficha_paciente(p_mascota_id uuid);
DROP FUNCTION IF EXISTS internal.es_de_empresa(p_user_id uuid, p_is_super_admin boolean, p_empresa_contexto uuid, p_empresa_registro uuid);
DROP FUNCTION IF EXISTS internal.es_acceso_global(p_user_id uuid, p_is_super_admin boolean);
DROP FUNCTION IF EXISTS internal.error_jsonb(p_code text, p_message text, p_field text);
DROP FUNCTION IF EXISTS internal.empresa_efectiva(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean);
DROP FUNCTION IF EXISTS internal.edad_mascota(p_fecha_nacimiento date, p_edad_aprox_meses integer);
DROP FUNCTION IF EXISTS internal.consumir_producto_clinico(p_empresa_id uuid, p_producto_id uuid, p_cantidad numeric, p_user_id uuid, p_refs jsonb);
DROP FUNCTION IF EXISTS internal.calcular_igv(p_base numeric, p_tasa numeric);
DROP FUNCTION IF EXISTS internal.assert_permiso(p_user_id uuid, p_codigo_permiso character varying);
DROP FUNCTION IF EXISTS internal.assert_acceso_empresa(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean);
DROP FUNCTION IF EXISTS core.trg_users_validate_rol_scope();
DROP FUNCTION IF EXISTS core.trg_touch_updated_at();
DROP FUNCTION IF EXISTS core.trg_normalizar_user();
DROP FUNCTION IF EXISTS core.trg_normalizar_taxonomia();
DROP FUNCTION IF EXISTS core.trg_normalizar_servicio();
DROP FUNCTION IF EXISTS core.trg_normalizar_proveedor();
DROP FUNCTION IF EXISTS core.trg_normalizar_producto();
DROP FUNCTION IF EXISTS core.trg_normalizar_mascota();
DROP FUNCTION IF EXISTS core.trg_normalizar_empresa();
DROP FUNCTION IF EXISTS core.trg_normalizar_contacto();
DROP FUNCTION IF EXISTS core.trg_normalizar_cliente();
DROP FUNCTION IF EXISTS core.trg_movimiento_aplicar_stock();
DROP FUNCTION IF EXISTS core.trg_mascota_fallecida();
DROP FUNCTION IF EXISTS core.trg_evaluacion_promedio();
DROP FUNCTION IF EXISTS core.trg_consulta_sync_peso();
DROP FUNCTION IF EXISTS core.trg_comprobante_recalcular();
DROP FUNCTION IF EXISTS core.trg_asistencia_horas();
DROP FUNCTION IF EXISTS app.sp_vacuna_aplicar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb);
DROP FUNCTION IF EXISTS app.sp_users_reset_password(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid, p_password_temp text);
DROP FUNCTION IF EXISTS app.sp_users_eliminar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid);
DROP FUNCTION IF EXISTS app.sp_users_crear(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb);
DROP FUNCTION IF EXISTS app.sp_users_cambiar_rol(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid, p_rol_id uuid, p_empresa_destino uuid);
DROP FUNCTION IF EXISTS app.sp_users_cambiar_estado(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid, p_estado character varying);
DROP FUNCTION IF EXISTS app.sp_users_actualizar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid, p_payload jsonb);
DROP FUNCTION IF EXISTS app.sp_tratamiento_registrar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb);
DROP FUNCTION IF EXISTS app.sp_tratamiento_cambiar_estado(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid, p_estado character varying);
DROP FUNCTION IF EXISTS app.sp_servicio_guardar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb);
DROP FUNCTION IF EXISTS app.sp_servicio_eliminar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid);
DROP FUNCTION IF EXISTS app.sp_rol_set_permisos(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_rol_id uuid, p_codigos jsonb);
DROP FUNCTION IF EXISTS app.sp_rol_eliminar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_rol_id uuid);
DROP FUNCTION IF EXISTS app.sp_rol_crear(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb);
DROP FUNCTION IF EXISTS app.sp_recordatorios_generar_citas(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_dias integer);
DROP FUNCTION IF EXISTS app.sp_recordatorio_contactar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid, p_payload jsonb);
DROP FUNCTION IF EXISTS app.sp_recordatorio_completar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid);
DROP FUNCTION IF EXISTS app.sp_raza_guardar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb);
DROP FUNCTION IF EXISTS app.sp_proveedor_guardar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb);
DROP FUNCTION IF EXISTS app.sp_proveedor_eliminar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid);
DROP FUNCTION IF EXISTS app.sp_proveedor_contacto_guardar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb);
DROP FUNCTION IF EXISTS app.sp_producto_guardar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb);
DROP FUNCTION IF EXISTS app.sp_producto_eliminar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid);
DROP FUNCTION IF EXISTS app.sp_portal_solicitar_cita(p_cliente_id uuid, p_payload jsonb);
DROP FUNCTION IF EXISTS app.sp_portal_login(p_documento character varying, p_password text);
DROP FUNCTION IF EXISTS app.sp_portal_cambiar_password(p_cliente_id uuid, p_password_actual text, p_password_nuevo text);
DROP FUNCTION IF EXISTS app.sp_plantilla_mensaje_guardar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb);
DROP FUNCTION IF EXISTS app.sp_permiso_solicitar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb);
DROP FUNCTION IF EXISTS app.sp_permiso_resolver(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid, p_estado character varying, p_comentario text);
DROP FUNCTION IF EXISTS app.sp_pago_registrar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb);
DROP FUNCTION IF EXISTS app.sp_pago_proveedor_registrar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb);
DROP FUNCTION IF EXISTS app.sp_pago_anular(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid, p_motivo text);
DROP FUNCTION IF EXISTS app.sp_orden_servicio_crear(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb);
DROP FUNCTION IF EXISTS app.sp_orden_compra_recibir(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid, p_recepcion jsonb);
DROP FUNCTION IF EXISTS app.sp_orden_compra_crear(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb);
DROP FUNCTION IF EXISTS app.sp_orden_compra_cambiar_estado(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid, p_estado character varying);
DROP FUNCTION IF EXISTS app.sp_notificacion_marcar_leida(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid);
DROP FUNCTION IF EXISTS app.sp_nota_medica_crear(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb);
DROP FUNCTION IF EXISTS app.sp_nota_credito_emitir(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb);
DROP FUNCTION IF EXISTS app.sp_mascota_reportar_extravio(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb);
DROP FUNCTION IF EXISTS app.sp_mascota_marcar_encontrada(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid);
DROP FUNCTION IF EXISTS app.sp_mascota_eliminar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid);
DROP FUNCTION IF EXISTS app.sp_mascota_crear(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb);
DROP FUNCTION IF EXISTS app.sp_mascota_actualizar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid, p_payload jsonb);
DROP FUNCTION IF EXISTS app.sp_lote_registrar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb);
DROP FUNCTION IF EXISTS app.sp_lista_espera_resolver(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid);
DROP FUNCTION IF EXISTS app.sp_lista_espera_anotar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb);
DROP FUNCTION IF EXISTS app.sp_inventario_movimiento(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb);
DROP FUNCTION IF EXISTS app.sp_insumo_consumir(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb);
DROP FUNCTION IF EXISTS app.sp_hospitalizacion_ingresar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb);
DROP FUNCTION IF EXISTS app.sp_hospitalizacion_evolucion(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb);
DROP FUNCTION IF EXISTS app.sp_hospitalizacion_alta(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid, p_payload jsonb);
DROP FUNCTION IF EXISTS app.sp_horarios_atencion_guardar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_horarios jsonb);
DROP FUNCTION IF EXISTS app.sp_examen_registrar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb);
DROP FUNCTION IF EXISTS app.sp_evaluacion_registrar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb);
DROP FUNCTION IF EXISTS app.sp_esquema_vacunacion_guardar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb);
DROP FUNCTION IF EXISTS app.sp_especie_guardar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb);
DROP FUNCTION IF EXISTS app.sp_especializacion_guardar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb);
DROP FUNCTION IF EXISTS app.sp_empresa_crear(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb);
DROP FUNCTION IF EXISTS app.sp_empresa_actualizar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid, p_payload jsonb);
DROP FUNCTION IF EXISTS app.sp_documento_medico_registrar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb);
DROP FUNCTION IF EXISTS app.sp_disponibilidad_guardar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb);
DROP FUNCTION IF EXISTS app.sp_disponibilidad_eliminar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid);
DROP FUNCTION IF EXISTS app.sp_desparasitacion_registrar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb);
DROP FUNCTION IF EXISTS app.sp_contrato_personal_guardar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb);
DROP FUNCTION IF EXISTS app.sp_consultorio_guardar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb);
DROP FUNCTION IF EXISTS app.sp_consulta_crear(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb);
DROP FUNCTION IF EXISTS app.sp_consulta_cerrar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid);
DROP FUNCTION IF EXISTS app.sp_consulta_actualizar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid, p_payload jsonb);
DROP FUNCTION IF EXISTS app.sp_comunicacion_registrar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb);
DROP FUNCTION IF EXISTS app.sp_comprobante_recibir_respuesta(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid, p_payload jsonb);
DROP FUNCTION IF EXISTS app.sp_comprobante_pse_log(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid, p_payload jsonb);
DROP FUNCTION IF EXISTS app.sp_comprobante_marcar_enviado(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid, p_request_id character varying, p_request jsonb);
DROP FUNCTION IF EXISTS app.sp_comprobante_emitir(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb);
DROP FUNCTION IF EXISTS app.sp_comprobante_anular(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid, p_motivo text);
DROP FUNCTION IF EXISTS app.sp_comprobante_actualizar_sunat(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid, p_payload jsonb);
DROP FUNCTION IF EXISTS app.sp_cliente_eliminar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid);
DROP FUNCTION IF EXISTS app.sp_cliente_crear(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb);
DROP FUNCTION IF EXISTS app.sp_cliente_actualizar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid, p_payload jsonb);
DROP FUNCTION IF EXISTS app.sp_cliente_activar_portal(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid, p_password text);
DROP FUNCTION IF EXISTS app.sp_clausula_guardar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb);
DROP FUNCTION IF EXISTS app.sp_cita_reprogramar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid, p_fecha_hora timestamp with time zone, p_motivo text, p_veterinario_id uuid);
DROP FUNCTION IF EXISTS app.sp_cita_registrar_llegada(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb);
DROP FUNCTION IF EXISTS app.sp_cita_eliminar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid);
DROP FUNCTION IF EXISTS app.sp_cita_crear(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb);
DROP FUNCTION IF EXISTS app.sp_cita_cambiar_estado(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid, p_estado character varying, p_motivo text);
DROP FUNCTION IF EXISTS app.sp_cirugia_registrar_resultado(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid, p_payload jsonb);
DROP FUNCTION IF EXISTS app.sp_cirugia_programar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb);
DROP FUNCTION IF EXISTS app.sp_categoria_guardar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb);
DROP FUNCTION IF EXISTS app.sp_caja_movimiento(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb);
DROP FUNCTION IF EXISTS app.sp_caja_cerrar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid, p_monto_contado numeric, p_observaciones text);
DROP FUNCTION IF EXISTS app.sp_caja_abrir(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_monto_apertura numeric, p_observaciones text);
DROP FUNCTION IF EXISTS app.sp_auth_solicitar_reset(p_email character varying);
DROP FUNCTION IF EXISTS app.sp_auth_reset_password(p_token character varying, p_password_nuevo text);
DROP FUNCTION IF EXISTS app.sp_auth_login(p_email character varying, p_password text);
DROP FUNCTION IF EXISTS app.sp_auth_cambiar_password(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_password_actual text, p_password_nuevo text);
DROP FUNCTION IF EXISTS app.sp_asistencia_marcar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_target_user_id uuid);
DROP FUNCTION IF EXISTS app.fn_veterinarios_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean);
DROP FUNCTION IF EXISTS app.fn_vacunas_carne(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_mascota_id uuid);
DROP FUNCTION IF EXISTS app.fn_users_obtener(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid);
DROP FUNCTION IF EXISTS app.fn_users_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_filtros jsonb, p_page integer, p_page_size integer);
DROP FUNCTION IF EXISTS app.fn_servicios_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_filtros jsonb);
DROP FUNCTION IF EXISTS app.fn_sala_espera(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_filtros jsonb);
DROP FUNCTION IF EXISTS app.fn_roles_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean);
DROP FUNCTION IF EXISTS app.fn_reporte_ventas(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_desde date, p_hasta date);
DROP FUNCTION IF EXISTS app.fn_reporte_inventario(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_desde date, p_hasta date);
DROP FUNCTION IF EXISTS app.fn_reporte_ejecutivo(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_desde date, p_hasta date);
DROP FUNCTION IF EXISTS app.fn_reporte_clinico(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_desde date, p_hasta date);
DROP FUNCTION IF EXISTS app.fn_recordatorios_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_dias integer);
DROP FUNCTION IF EXISTS app.fn_proveedores_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_filtros jsonb, p_page integer, p_page_size integer);
DROP FUNCTION IF EXISTS app.fn_productos_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_filtros jsonb, p_page integer, p_page_size integer);
DROP FUNCTION IF EXISTS app.fn_portal_mis_mascotas(p_cliente_id uuid);
DROP FUNCTION IF EXISTS app.fn_portal_mis_comprobantes(p_cliente_id uuid);
DROP FUNCTION IF EXISTS app.fn_portal_mis_citas(p_cliente_id uuid, p_incluir_pasadas boolean);
DROP FUNCTION IF EXISTS app.fn_portal_historial(p_cliente_id uuid, p_mascota_id uuid);
DROP FUNCTION IF EXISTS app.fn_plantillas_mensaje_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean);
DROP FUNCTION IF EXISTS app.fn_permisos_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean);
DROP FUNCTION IF EXISTS app.fn_permisos_laborales_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_filtros jsonb);
DROP FUNCTION IF EXISTS app.fn_pendiente_facturar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_cliente_id uuid);
DROP FUNCTION IF EXISTS app.fn_pagos_proveedor_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_filtros jsonb);
DROP FUNCTION IF EXISTS app.fn_pagos_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_filtros jsonb, p_page integer, p_page_size integer);
DROP FUNCTION IF EXISTS app.fn_ordenes_compra_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_filtros jsonb, p_page integer, p_page_size integer);
DROP FUNCTION IF EXISTS app.fn_notificaciones_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_solo_no_leidas boolean, p_limit integer);
DROP FUNCTION IF EXISTS app.fn_movimientos_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_filtros jsonb, p_page integer, p_page_size integer);
DROP FUNCTION IF EXISTS app.fn_mascotas_extraviadas_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_solo_activos boolean);
DROP FUNCTION IF EXISTS app.fn_mascota_obtener(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid);
DROP FUNCTION IF EXISTS app.fn_mascota_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_filtros jsonb, p_page integer, p_page_size integer);
DROP FUNCTION IF EXISTS app.fn_mascota_historia(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_mascota_id uuid, p_tipo character varying, p_limit integer);
DROP FUNCTION IF EXISTS app.fn_lista_espera_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_filtros jsonb);
DROP FUNCTION IF EXISTS app.fn_inventario_alertas(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean);
DROP FUNCTION IF EXISTS app.fn_hospitalizaciones_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_solo_activas boolean);
DROP FUNCTION IF EXISTS app.fn_horarios_atencion_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean);
DROP FUNCTION IF EXISTS app.fn_esquemas_vacunacion_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_especie_id uuid);
DROP FUNCTION IF EXISTS app.fn_especies_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_incluir_inactivos boolean);
DROP FUNCTION IF EXISTS app.fn_especializaciones_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean);
DROP FUNCTION IF EXISTS app.fn_equipo_resumen(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_desde date, p_hasta date);
DROP FUNCTION IF EXISTS app.fn_empresa_pse_config(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_empresa_target uuid);
DROP FUNCTION IF EXISTS app.fn_empresa_obtener(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid);
DROP FUNCTION IF EXISTS app.fn_empresa_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_filtros jsonb);
DROP FUNCTION IF EXISTS app.fn_documentos_medicos_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_mascota_id uuid);
DROP FUNCTION IF EXISTS app.fn_doc_receta(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_consulta_id uuid);
DROP FUNCTION IF EXISTS app.fn_doc_historia_clinica(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_mascota_id uuid);
DROP FUNCTION IF EXISTS app.fn_doc_consentimiento(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_cirugia_id uuid);
DROP FUNCTION IF EXISTS app.fn_doc_certificado_salud(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_mascota_id uuid, p_payload jsonb);
DROP FUNCTION IF EXISTS app.fn_doc_carne_vacunacion(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_mascota_id uuid);
DROP FUNCTION IF EXISTS app.fn_doc_alta_hospitalaria(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_hospitalizacion_id uuid);
DROP FUNCTION IF EXISTS app.fn_disponibilidad_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_desde date, p_hasta date, p_target_user_id uuid);
DROP FUNCTION IF EXISTS app.fn_dashboard_resumen(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_desde date, p_hasta date);
DROP FUNCTION IF EXISTS app.fn_cuentas_por_cobrar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_filtros jsonb);
DROP FUNCTION IF EXISTS app.fn_consultorios_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean);
DROP FUNCTION IF EXISTS app.fn_consultas_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_filtros jsonb, p_page integer, p_page_size integer);
DROP FUNCTION IF EXISTS app.fn_consulta_obtener(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid);
DROP FUNCTION IF EXISTS app.fn_comunicaciones_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_cliente_id uuid, p_limit integer);
DROP FUNCTION IF EXISTS app.fn_comprobantes_por_enviar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean);
DROP FUNCTION IF EXISTS app.fn_comprobantes_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_filtros jsonb, p_page integer, p_page_size integer);
DROP FUNCTION IF EXISTS app.fn_comprobante_pse_datos(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid);
DROP FUNCTION IF EXISTS app.fn_comprobante_obtener(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid);
DROP FUNCTION IF EXISTS app.fn_cliente_obtener(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid);
DROP FUNCTION IF EXISTS app.fn_cliente_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_filtros jsonb, p_page integer, p_page_size integer);
DROP FUNCTION IF EXISTS app.fn_cliente_buscar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_query text, p_limit integer);
DROP FUNCTION IF EXISTS app.fn_clausulas_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_tipo character varying);
DROP FUNCTION IF EXISTS app.fn_citas_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_filtros jsonb, p_page integer, p_page_size integer);
DROP FUNCTION IF EXISTS app.fn_citas_disponibilidad(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_veterinario_id uuid, p_fecha date, p_duracion_min integer);
DROP FUNCTION IF EXISTS app.fn_citas_agenda_dia(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_fecha date);
DROP FUNCTION IF EXISTS app.fn_cita_obtener(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid);
DROP FUNCTION IF EXISTS app.fn_cirugias_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_filtros jsonb);
DROP FUNCTION IF EXISTS app.fn_categorias_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_ambito character varying);
DROP FUNCTION IF EXISTS app.fn_cajas_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_filtros jsonb);
DROP FUNCTION IF EXISTS app.fn_caja_actual(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean);
DROP FUNCTION IF EXISTS app.fn_auth_perfil(p_user_id uuid);
DROP FUNCTION IF EXISTS app.fn_auditoria_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_filtros jsonb, p_page integer, p_page_size integer);
DROP FUNCTION IF EXISTS app.fn_asistencia_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_desde date, p_hasta date, p_target_user_id uuid);
DROP FUNCTION IF EXISTS app.fn_archivo_autorizar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_key text, p_modo text);
DROP FUNCTION IF EXISTS app.fn_almacenes_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean);
DROP TYPE IF EXISTS core.via_administracion;
DROP TYPE IF EXISTS core.tipo_servicio;
DROP TYPE IF EXISTS core.tipo_producto;
DROP TYPE IF EXISTS core.tipo_permiso_laboral;
DROP TYPE IF EXISTS core.tipo_movimiento_inventario;
DROP TYPE IF EXISTS core.tipo_movimiento_caja;
DROP TYPE IF EXISTS core.tipo_item_comprobante;
DROP TYPE IF EXISTS core.tipo_evento_clinico;
DROP TYPE IF EXISTS core.tipo_documento_identidad;
DROP TYPE IF EXISTS core.tipo_disponibilidad;
DROP TYPE IF EXISTS core.tipo_contrato_empleado;
DROP TYPE IF EXISTS core.tipo_comunicacion;
DROP TYPE IF EXISTS core.tipo_comprobante;
DROP TYPE IF EXISTS core.tamanio_mascota;
DROP TYPE IF EXISTS core.sexo_mascota;
DROP TYPE IF EXISTS core.scope_rol;
DROP TYPE IF EXISTS core.prioridad_cita;
DROP TYPE IF EXISTS core.origen_cita;
DROP TYPE IF EXISTS core.motivo_movimiento;
DROP TYPE IF EXISTS core.moneda_codigo;
DROP TYPE IF EXISTS core.metodo_pago;
DROP TYPE IF EXISTS core.estado_user;
DROP TYPE IF EXISTS core.estado_tratamiento;
DROP TYPE IF EXISTS core.estado_solicitud;
DROP TYPE IF EXISTS core.estado_proveedor;
DROP TYPE IF EXISTS core.estado_pago;
DROP TYPE IF EXISTS core.estado_orden_servicio;
DROP TYPE IF EXISTS core.estado_orden_compra;
DROP TYPE IF EXISTS core.estado_mascota;
DROP TYPE IF EXISTS core.estado_hospitalizacion;
DROP TYPE IF EXISTS core.estado_generico;
DROP TYPE IF EXISTS core.estado_empresa;
DROP TYPE IF EXISTS core.estado_consulta;
DROP TYPE IF EXISTS core.estado_comprobante;
DROP TYPE IF EXISTS core.estado_cliente;
DROP TYPE IF EXISTS core.estado_cita;
DROP TYPE IF EXISTS core.estado_cirugia;
DROP TYPE IF EXISTS core.estado_caja;
DROP TYPE IF EXISTS core.estado_asistencia;
DROP TYPE IF EXISTS core.canal_notificacion;
DROP TYPE IF EXISTS core.accion_cita;
DROP EXTENSION IF EXISTS unaccent;
DROP EXTENSION IF EXISTS pgcrypto;
DROP EXTENSION IF EXISTS pg_trgm;
DROP EXTENSION IF EXISTS btree_gin;
DROP SCHEMA IF EXISTS internal;
DROP SCHEMA IF EXISTS core;
DROP SCHEMA IF EXISTS audit;
DROP SCHEMA IF EXISTS app;
--
-- Name: app; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA app;


--
-- Name: SCHEMA app; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA app IS 'Única superficie del backend. vet_app_user solo tiene EXECUTE aquí.';


--
-- Name: audit; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA audit;


--
-- Name: SCHEMA audit; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA audit IS 'Auditoría dedicada (core.audit_log vive en core para coherencia de FKs).';


--
-- Name: core; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA core;


--
-- Name: SCHEMA core; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA core IS 'Tablas, ENUMs y triggers. NUNCA accedido directamente por el backend.';


--
-- Name: internal; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA internal;


--
-- Name: SCHEMA internal; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA internal IS 'Helpers privados reutilizados por SPs/FNs públicas.';


--
-- Name: btree_gin; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS btree_gin WITH SCHEMA public;


--
-- Name: EXTENSION btree_gin; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION btree_gin IS 'support for indexing common datatypes in GIN';


--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: unaccent; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS unaccent WITH SCHEMA public;


--
-- Name: EXTENSION unaccent; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION unaccent IS 'text search dictionary that removes accents';


--
-- Name: accion_cita; Type: TYPE; Schema: core; Owner: -
--

CREATE TYPE core.accion_cita AS ENUM (
    'creada',
    'confirmada',
    'reprogramada',
    'cancelada',
    'atendida',
    'no_asistio'
);


--
-- Name: canal_notificacion; Type: TYPE; Schema: core; Owner: -
--

CREATE TYPE core.canal_notificacion AS ENUM (
    'sistema',
    'correo',
    'whatsapp',
    'sms'
);


--
-- Name: estado_asistencia; Type: TYPE; Schema: core; Owner: -
--

CREATE TYPE core.estado_asistencia AS ENUM (
    'puntual',
    'tardanza',
    'falta',
    'justificada'
);


--
-- Name: estado_caja; Type: TYPE; Schema: core; Owner: -
--

CREATE TYPE core.estado_caja AS ENUM (
    'abierta',
    'cerrada',
    'cuadrada'
);


--
-- Name: estado_cirugia; Type: TYPE; Schema: core; Owner: -
--

CREATE TYPE core.estado_cirugia AS ENUM (
    'programada',
    'en_quirofano',
    'realizada',
    'cancelada'
);


--
-- Name: estado_cita; Type: TYPE; Schema: core; Owner: -
--

CREATE TYPE core.estado_cita AS ENUM (
    'programada',
    'confirmada',
    'en_espera',
    'en_atencion',
    'completada',
    'cancelada',
    'no_asistio'
);


--
-- Name: estado_cliente; Type: TYPE; Schema: core; Owner: -
--

CREATE TYPE core.estado_cliente AS ENUM (
    'activo',
    'inactivo',
    'bloqueado'
);


--
-- Name: estado_comprobante; Type: TYPE; Schema: core; Owner: -
--

CREATE TYPE core.estado_comprobante AS ENUM (
    'borrador',
    'emitido',
    'pendiente_envio',
    'enviado_sunat',
    'aceptado_sunat',
    'observado_sunat',
    'rechazado_sunat',
    'anulado'
);


--
-- Name: estado_consulta; Type: TYPE; Schema: core; Owner: -
--

CREATE TYPE core.estado_consulta AS ENUM (
    'borrador',
    'cerrada',
    'anulada'
);


--
-- Name: estado_empresa; Type: TYPE; Schema: core; Owner: -
--

CREATE TYPE core.estado_empresa AS ENUM (
    'activa',
    'suspendida',
    'cerrada'
);


--
-- Name: estado_generico; Type: TYPE; Schema: core; Owner: -
--

CREATE TYPE core.estado_generico AS ENUM (
    'activo',
    'inactivo'
);


--
-- Name: estado_hospitalizacion; Type: TYPE; Schema: core; Owner: -
--

CREATE TYPE core.estado_hospitalizacion AS ENUM (
    'ingresado',
    'en_observacion',
    'alta',
    'fallecido',
    'derivado'
);


--
-- Name: estado_mascota; Type: TYPE; Schema: core; Owner: -
--

CREATE TYPE core.estado_mascota AS ENUM (
    'activo',
    'inactivo',
    'fallecido',
    'extraviado'
);


--
-- Name: estado_orden_compra; Type: TYPE; Schema: core; Owner: -
--

CREATE TYPE core.estado_orden_compra AS ENUM (
    'borrador',
    'enviada',
    'en_transito',
    'recibida_parcial',
    'recibida',
    'cancelada'
);


--
-- Name: estado_orden_servicio; Type: TYPE; Schema: core; Owner: -
--

CREATE TYPE core.estado_orden_servicio AS ENUM (
    'pendiente',
    'en_curso',
    'completado',
    'anulado'
);


--
-- Name: estado_pago; Type: TYPE; Schema: core; Owner: -
--

CREATE TYPE core.estado_pago AS ENUM (
    'pendiente',
    'parcial',
    'pagado',
    'anulado'
);


--
-- Name: estado_proveedor; Type: TYPE; Schema: core; Owner: -
--

CREATE TYPE core.estado_proveedor AS ENUM (
    'activo',
    'inactivo',
    'bloqueado'
);


--
-- Name: estado_solicitud; Type: TYPE; Schema: core; Owner: -
--

CREATE TYPE core.estado_solicitud AS ENUM (
    'pendiente',
    'aprobado',
    'rechazado',
    'cancelado'
);


--
-- Name: estado_tratamiento; Type: TYPE; Schema: core; Owner: -
--

CREATE TYPE core.estado_tratamiento AS ENUM (
    'activo',
    'completado',
    'suspendido'
);


--
-- Name: estado_user; Type: TYPE; Schema: core; Owner: -
--

CREATE TYPE core.estado_user AS ENUM (
    'activo',
    'inactivo',
    'bloqueado',
    'solicitud'
);


--
-- Name: metodo_pago; Type: TYPE; Schema: core; Owner: -
--

CREATE TYPE core.metodo_pago AS ENUM (
    'efectivo',
    'tarjeta',
    'transferencia',
    'yape',
    'plin',
    'deposito',
    'credito',
    'mixto'
);


--
-- Name: moneda_codigo; Type: TYPE; Schema: core; Owner: -
--

CREATE TYPE core.moneda_codigo AS ENUM (
    'PEN',
    'USD'
);


--
-- Name: motivo_movimiento; Type: TYPE; Schema: core; Owner: -
--

CREATE TYPE core.motivo_movimiento AS ENUM (
    'compra',
    'venta',
    'uso_clinico',
    'donacion',
    'ajuste_inventario',
    'devolucion',
    'vencido',
    'traslado'
);


--
-- Name: origen_cita; Type: TYPE; Schema: core; Owner: -
--

CREATE TYPE core.origen_cita AS ENUM (
    'mostrador',
    'telefono',
    'whatsapp',
    'portal',
    'recurrente'
);


--
-- Name: prioridad_cita; Type: TYPE; Schema: core; Owner: -
--

CREATE TYPE core.prioridad_cita AS ENUM (
    'normal',
    'preferente',
    'urgencia',
    'emergencia'
);


--
-- Name: scope_rol; Type: TYPE; Schema: core; Owner: -
--

CREATE TYPE core.scope_rol AS ENUM (
    'global',
    'global_restricted',
    'empresa'
);


--
-- Name: sexo_mascota; Type: TYPE; Schema: core; Owner: -
--

CREATE TYPE core.sexo_mascota AS ENUM (
    'macho',
    'hembra',
    'desconocido'
);


--
-- Name: tamanio_mascota; Type: TYPE; Schema: core; Owner: -
--

CREATE TYPE core.tamanio_mascota AS ENUM (
    'toy',
    'pequenio',
    'mediano',
    'grande',
    'gigante'
);


--
-- Name: tipo_comprobante; Type: TYPE; Schema: core; Owner: -
--

CREATE TYPE core.tipo_comprobante AS ENUM (
    'factura',
    'boleta',
    'nota_venta',
    'nota_credito',
    'nota_debito'
);


--
-- Name: tipo_comunicacion; Type: TYPE; Schema: core; Owner: -
--

CREATE TYPE core.tipo_comunicacion AS ENUM (
    'llamada',
    'correo',
    'whatsapp',
    'sms',
    'presencial',
    'otro'
);


--
-- Name: tipo_contrato_empleado; Type: TYPE; Schema: core; Owner: -
--

CREATE TYPE core.tipo_contrato_empleado AS ENUM (
    'indefinido',
    'plazo_fijo',
    'locacion',
    'practicante',
    'freelance'
);


--
-- Name: tipo_disponibilidad; Type: TYPE; Schema: core; Owner: -
--

CREATE TYPE core.tipo_disponibilidad AS ENUM (
    'laboral',
    'guardia',
    'libre',
    'vacaciones',
    'permiso',
    'capacitacion'
);


--
-- Name: tipo_documento_identidad; Type: TYPE; Schema: core; Owner: -
--

CREATE TYPE core.tipo_documento_identidad AS ENUM (
    'DNI',
    'CE',
    'RUC',
    'PASAPORTE'
);


--
-- Name: tipo_evento_clinico; Type: TYPE; Schema: core; Owner: -
--

CREATE TYPE core.tipo_evento_clinico AS ENUM (
    'consulta',
    'vacuna',
    'desparasitacion',
    'tratamiento',
    'cirugia',
    'hospitalizacion',
    'examen',
    'nota',
    'documento',
    'peso'
);


--
-- Name: tipo_item_comprobante; Type: TYPE; Schema: core; Owner: -
--

CREATE TYPE core.tipo_item_comprobante AS ENUM (
    'servicio',
    'producto',
    'otro'
);


--
-- Name: tipo_movimiento_caja; Type: TYPE; Schema: core; Owner: -
--

CREATE TYPE core.tipo_movimiento_caja AS ENUM (
    'ingreso',
    'egreso'
);


--
-- Name: tipo_movimiento_inventario; Type: TYPE; Schema: core; Owner: -
--

CREATE TYPE core.tipo_movimiento_inventario AS ENUM (
    'entrada',
    'salida',
    'ajuste_positivo',
    'ajuste_negativo',
    'transferencia',
    'merma',
    'vencimiento'
);


--
-- Name: tipo_permiso_laboral; Type: TYPE; Schema: core; Owner: -
--

CREATE TYPE core.tipo_permiso_laboral AS ENUM (
    'personal',
    'vacaciones',
    'medico',
    'duelo',
    'capacitacion'
);


--
-- Name: tipo_producto; Type: TYPE; Schema: core; Owner: -
--

CREATE TYPE core.tipo_producto AS ENUM (
    'medicamento',
    'insumo',
    'alimento',
    'accesorio',
    'vacuna',
    'otro'
);


--
-- Name: tipo_servicio; Type: TYPE; Schema: core; Owner: -
--

CREATE TYPE core.tipo_servicio AS ENUM (
    'consulta',
    'vacunacion',
    'cirugia',
    'laboratorio',
    'imagen',
    'grooming',
    'hospitalizacion',
    'desparasitacion',
    'otro'
);


--
-- Name: via_administracion; Type: TYPE; Schema: core; Owner: -
--

CREATE TYPE core.via_administracion AS ENUM (
    'oral',
    'subcutanea',
    'intramuscular',
    'intravenosa',
    'topica',
    'oftalmica',
    'otica',
    'inhalatoria',
    'rectal'
);


--
-- Name: fn_almacenes_listar(uuid, uuid, boolean); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_almacenes_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_emp  UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_data JSONB;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'inventario:ver');

  SELECT COALESCE(jsonb_agg(x ORDER BY x.es_principal DESC, x.nombre), '[]'::jsonb) INTO v_data
  FROM (
    SELECT a.id, a.codigo, a.nombre, a.ubicacion, a.es_principal, a.estado,
           (SELECT COALESCE(SUM(s.cantidad), 0) FROM core.stock s WHERE s.almacen_id = a.id) AS unidades,
           (SELECT count(DISTINCT s.producto_id) FROM core.stock s
             WHERE s.almacen_id = a.id AND s.cantidad > 0) AS productos
    FROM core.almacenes a WHERE a.empresa_id = v_emp
  ) x;

  RETURN jsonb_build_object('ok', true, 'data', v_data);

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_archivo_autorizar(uuid, uuid, boolean, text, text); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_archivo_autorizar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_key text, p_modo text DEFAULT 'descargar'::text) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $_$
DECLARE
  v_emp     UUID    := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_global  BOOLEAN := internal.es_acceso_global(p_user_id, p_is_super_admin);
  v_prefijo TEXT;
  v_area    TEXT;
  v_emp_key UUID;
BEGIN
  IF p_key IS NULL OR btrim(p_key) = '' THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('VALIDATION_ERROR','Indica la clave del archivo','key'));
  END IF;

  -- Un objeto de MinIO no tiene rutas relativas: si aparecen, alguien está
  -- probando a salirse del prefijo de su empresa.
  IF p_key LIKE '%..%' OR p_key LIKE '//%' OR p_key LIKE '%//%'
     OR p_key LIKE '/%' OR length(p_key) > 512 THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('VALIDATION_ERROR','La clave del archivo no es válida','key'));
  END IF;

  v_prefijo := split_part(p_key, '/', 1);
  v_area    := split_part(p_key, '/', 2);

  IF v_area = '' OR split_part(p_key, '/', 3) = '' THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('VALIDATION_ERROR','La clave del archivo no es válida','key'));
  END IF;

  -- ---- ¿de qué empresa es el objeto? ----------------------------------------
  IF v_prefijo = 'global' THEN
    IF NOT v_global THEN
      RETURN jsonb_build_object('ok', false,
        'error', internal.error_jsonb('NOT_FOUND','Archivo no encontrado'));
    END IF;
  ELSIF v_prefijo ~ '^e_[0-9a-fA-F-]{36}$' THEN
    v_emp_key := substring(v_prefijo from 3)::uuid;
    -- Misma convención que el resto del ERP: si el registro es de otra empresa
    -- se responde NOT_FOUND, no FORBIDDEN, para no confirmar que existe.
    IF NOT v_global AND v_emp_key IS DISTINCT FROM v_emp THEN
      RETURN jsonb_build_object('ok', false,
        'error', internal.error_jsonb('NOT_FOUND','Archivo no encontrado'));
    END IF;
  ELSE
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('VALIDATION_ERROR','La clave del archivo no es válida','key'));
  END IF;

  -- ---- ¿el área existe, y quién entra en ella? ------------------------------
  IF v_area NOT IN ('clinico','documentos','resultados','consentimientos','logos') THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('VALIDATION_ERROR',
        'Área de archivo no reconocida','area'));
  END IF;

  IF v_area = 'logos' THEN
    -- El logo sale impreso en cada receta y cada comprobante: lo lee todo el
    -- personal. Cambiarlo es configurar la empresa.
    IF p_modo <> 'descargar' THEN
      PERFORM internal.assert_permiso(p_user_id, 'empresa:configurar');
    END IF;
  ELSIF p_modo = 'descargar' THEN
    PERFORM internal.assert_permiso(p_user_id, 'clinico:ver');
  ELSE
    PERFORM internal.assert_permiso(p_user_id, 'clinico:registrar');
  END IF;

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object(
    'key',        p_key,
    'area',       v_area,
    'empresa_id', COALESCE(v_emp_key, v_emp)));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$_$;


--
-- Name: FUNCTION fn_archivo_autorizar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_key text, p_modo text); Type: COMMENT; Schema: app; Owner: -
--

COMMENT ON FUNCTION app.fn_archivo_autorizar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_key text, p_modo text) IS 'Autoriza subir/descargar un objeto de MinIO: empresa dueña, área y permiso.';


--
-- Name: fn_asistencia_listar(uuid, uuid, boolean, date, date, uuid); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_asistencia_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_desde date, p_hasta date, p_target_user_id uuid DEFAULT NULL::uuid) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_emp     UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_data    JSONB;
  v_resumen JSONB;
  -- Quien no administra RRHH ve su propio registro y nada más. Un veterinario
  -- necesita consultar sus horas; no necesita las de sus compañeros.
  v_todos   BOOLEAN := internal.tiene_permiso(p_user_id, 'rrhh:gestionar')
                       OR internal.es_acceso_global(p_user_id, p_is_super_admin);
  v_scope   UUID;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'rrhh:ver');
  v_scope := CASE WHEN v_todos THEN p_target_user_id ELSE p_user_id END;

  SELECT COALESCE(jsonb_agg(x ORDER BY x.fecha DESC, x.profesional), '[]'::jsonb) INTO v_data
  FROM (
    SELECT a.id, a.fecha, a.hora_entrada, a.hora_salida, a.horas_trabajadas,
           a.estado, a.observaciones, a.user_id,
           trim(u.nombres || ' ' || COALESCE(u.apellido_paterno,'')) AS profesional,
           u.foto_url, r.nombre AS rol
    FROM core.asistencia a
    JOIN core.users u ON u.id = a.user_id
    LEFT JOIN core.roles r ON r.id = u.rol_id
    WHERE a.empresa_id = v_emp
      AND a.fecha BETWEEN p_desde AND p_hasta
      AND (v_scope IS NULL OR a.user_id = v_scope)
  ) x;

  SELECT jsonb_build_object(
    'dias',      count(*),
    'puntuales', count(*) FILTER (WHERE a.estado = 'puntual'),
    'tardanzas', count(*) FILTER (WHERE a.estado = 'tardanza'),
    'faltas',    count(*) FILTER (WHERE a.estado = 'falta'),
    'horas_totales', COALESCE(SUM(a.horas_trabajadas), 0)
  ) INTO v_resumen
  FROM core.asistencia a
  WHERE a.empresa_id = v_emp AND a.fecha BETWEEN p_desde AND p_hasta
    AND (v_scope IS NULL OR a.user_id = v_scope);

  RETURN jsonb_build_object('ok', true, 'data', v_data, 'meta', v_resumen);

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_auditoria_listar(uuid, uuid, boolean, jsonb, integer, integer); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_auditoria_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_filtros jsonb DEFAULT '{}'::jsonb, p_page integer DEFAULT 1, p_page_size integer DEFAULT 50) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_global BOOLEAN := internal.es_acceso_global(p_user_id, p_is_super_admin);
  v_emp    UUID    := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_size   INT     := LEAST(GREATEST(COALESCE(p_page_size, 50), 1), 200);
  v_page   INT     := GREATEST(COALESCE(p_page, 1), 1);
  v_total  INT;
  v_data   JSONB;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'auditoria:ver');

  SELECT count(*) INTO v_total
  FROM core.audit_log a
  WHERE (v_global OR a.empresa_id = v_emp)
    AND (p_filtros->>'entidad' IS NULL OR a.entidad = p_filtros->>'entidad')
    AND (p_filtros->>'accion'  IS NULL OR a.accion = p_filtros->>'accion')
    AND (p_filtros->>'user_id' IS NULL OR a.user_id = (p_filtros->>'user_id')::uuid)
    AND (p_filtros->>'desde' IS NULL OR a.created_at >= (p_filtros->>'desde')::timestamptz)
    AND (p_filtros->>'hasta' IS NULL OR a.created_at <  (p_filtros->>'hasta')::timestamptz);

  SELECT COALESCE(jsonb_agg(x), '[]'::jsonb) INTO v_data
  FROM (
    SELECT a.id, a.accion, a.entidad, a.entidad_id, a.diff, a.ip, a.created_at,
           a.user_id,
           trim(u.nombres || ' ' || COALESCE(u.apellido_paterno,'')) AS usuario,
           u.email AS usuario_email,
           e.nombre_comercial AS empresa
    FROM core.audit_log a
    LEFT JOIN core.users u ON u.id = a.user_id
    LEFT JOIN core.empresas e ON e.id = a.empresa_id
    WHERE (v_global OR a.empresa_id = v_emp)
      AND (p_filtros->>'entidad' IS NULL OR a.entidad = p_filtros->>'entidad')
      AND (p_filtros->>'accion'  IS NULL OR a.accion = p_filtros->>'accion')
      AND (p_filtros->>'user_id' IS NULL OR a.user_id = (p_filtros->>'user_id')::uuid)
      AND (p_filtros->>'desde' IS NULL OR a.created_at >= (p_filtros->>'desde')::timestamptz)
      AND (p_filtros->>'hasta' IS NULL OR a.created_at <  (p_filtros->>'hasta')::timestamptz)
    ORDER BY a.created_at DESC
    LIMIT v_size OFFSET (v_page - 1) * v_size
  ) x;

  RETURN jsonb_build_object('ok', true, 'data', v_data, 'meta', jsonb_build_object(
    'total', v_total, 'page', v_page, 'pageSize', v_size,
    'pages', GREATEST(CEIL(v_total::numeric / v_size)::int, 1)));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_auth_perfil(uuid); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_auth_perfil(p_user_id uuid) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_user     RECORD;
  v_rol      JSONB;
  v_permisos JSONB;
  v_empresa  JSONB;
BEGIN
  SELECT u.* INTO v_user FROM core.users u
   WHERE u.id = p_user_id AND u.deleted_at IS NULL;

  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Usuario no encontrado'));
  END IF;

  SELECT to_jsonb(r) INTO v_rol FROM core.roles r WHERE r.id = v_user.rol_id;

  SELECT COALESCE(jsonb_agg(p.codigo ORDER BY p.codigo), '[]'::jsonb) INTO v_permisos
  FROM core.rol_permisos rp
  JOIN core.permisos p ON p.id = rp.permiso_id
  WHERE rp.rol_id = v_user.rol_id;

  IF v_user.empresa_id IS NOT NULL THEN
    SELECT to_jsonb(e) - 'pse_password_enc' INTO v_empresa
    FROM core.empresas e WHERE e.id = v_user.empresa_id;
  END IF;

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object(
    'user', to_jsonb(v_user) - 'password_hash' - 'password_reset_token',
    'rol', v_rol, 'permisos', v_permisos, 'empresa', v_empresa
  ));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_caja_actual(uuid, uuid, boolean); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_caja_actual(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_emp  UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_data JSONB;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'caja:ver');

  SELECT to_jsonb(x) INTO v_data FROM (
    SELECT c.id, c.numero, c.fecha_apertura, c.monto_apertura, c.estado,
           COALESCE((SELECT SUM(monto) FROM core.movimientos_caja mc
                      WHERE mc.caja_id = c.id AND mc.tipo = 'ingreso'), 0) AS ingresos,
           COALESCE((SELECT SUM(monto) FROM core.movimientos_caja mc
                      WHERE mc.caja_id = c.id AND mc.tipo = 'egreso'), 0) AS egresos,
           COALESCE((SELECT SUM(CASE WHEN tipo='ingreso' THEN monto ELSE -monto END)
                       FROM core.movimientos_caja mc
                      WHERE mc.caja_id = c.id AND mc.metodo = 'efectivo'), 0) AS efectivo,
           (SELECT count(*) FROM core.movimientos_caja mc WHERE mc.caja_id = c.id) AS movimientos,
           (SELECT COALESCE(jsonb_agg(jsonb_build_object(
                     'id', mc.id, 'tipo', mc.tipo, 'metodo', mc.metodo,
                     'concepto', mc.concepto, 'monto', mc.monto, 'fecha', mc.fecha)
                   ORDER BY mc.fecha DESC), '[]'::jsonb)
              FROM core.movimientos_caja mc WHERE mc.caja_id = c.id) AS detalle
    FROM core.cajas c
    WHERE c.empresa_id = v_emp AND c.user_apertura_id = p_user_id AND c.estado = 'abierta'
    LIMIT 1
  ) x;

  RETURN jsonb_build_object('ok', true, 'data', v_data);

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_cajas_listar(uuid, uuid, boolean, jsonb); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_cajas_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_filtros jsonb DEFAULT '{}'::jsonb) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_global BOOLEAN := internal.es_acceso_global(p_user_id, p_is_super_admin);
  v_emp    UUID    := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_data   JSONB;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'caja:ver');

  SELECT COALESCE(jsonb_agg(x ORDER BY x.fecha_apertura DESC), '[]'::jsonb) INTO v_data
  FROM (
    SELECT c.id, c.numero, c.fecha_apertura, c.fecha_cierre, c.monto_apertura,
           c.total_ingresos, c.total_egresos, c.total_efectivo, c.total_tarjeta,
           c.total_digital, c.monto_esperado, c.monto_contado, c.diferencia,
           c.estado, c.observaciones,
           trim(ua.nombres || ' ' || COALESCE(ua.apellido_paterno,'')) AS abierta_por,
           trim(uc.nombres || ' ' || COALESCE(uc.apellido_paterno,'')) AS cerrada_por
    FROM core.cajas c
    JOIN core.users ua ON ua.id = c.user_apertura_id
    LEFT JOIN core.users uc ON uc.id = c.user_cierre_id
    WHERE (v_global OR c.empresa_id = v_emp)
      AND (p_filtros->>'estado' IS NULL OR c.estado::text = p_filtros->>'estado')
      AND (p_filtros->>'desde' IS NULL OR c.fecha_apertura >= (p_filtros->>'desde')::timestamptz)
      AND (p_filtros->>'hasta' IS NULL OR c.fecha_apertura <  (p_filtros->>'hasta')::timestamptz)
    LIMIT 200
  ) x;

  RETURN jsonb_build_object('ok', true, 'data', v_data);

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_categorias_listar(uuid, uuid, boolean, character varying); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_categorias_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_ambito character varying DEFAULT NULL::character varying) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_global BOOLEAN := internal.es_acceso_global(p_user_id, p_is_super_admin);
  v_emp    UUID    := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_data   JSONB;
BEGIN
  SELECT COALESCE(jsonb_agg(x ORDER BY x.ambito, x.orden, x.nombre), '[]'::jsonb) INTO v_data
  FROM (
    SELECT c.id, c.ambito, c.codigo, c.nombre, c.descripcion, c.padre_id, c.orden, c.estado
    FROM core.categorias c
    WHERE (v_global OR c.empresa_id = v_emp)
      AND (p_ambito IS NULL OR c.ambito = p_ambito)
  ) x;

  RETURN jsonb_build_object('ok', true, 'data', v_data);

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_cirugias_listar(uuid, uuid, boolean, jsonb); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_cirugias_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_filtros jsonb DEFAULT '{}'::jsonb) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_global BOOLEAN := internal.es_acceso_global(p_user_id, p_is_super_admin);
  v_emp    UUID    := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_data   JSONB;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'clinico:ver');

  SELECT COALESCE(jsonb_agg(x ORDER BY x.fecha DESC NULLS LAST), '[]'::jsonb) INTO v_data
  FROM (
    SELECT c.id, c.codigo, c.nombre, c.descripcion, c.estado,
           COALESCE(c.fecha_inicio, c.fecha_programada) AS fecha,
           c.fecha_programada, c.fecha_inicio, c.fecha_fin,
           c.anestesia_tipo, c.hallazgos, c.complicaciones, c.resultado,
           c.consentimiento_firmado,
           c.mascota_id, m.nombre AS mascota, m.foto_url AS mascota_foto,
           esp.nombre AS especie,
           trim(cl.nombres || ' ' || COALESCE(cl.apellido_paterno,'')) AS cliente,
           trim(u.nombres || ' ' || COALESCE(u.apellido_paterno,'')) AS cirujano,
           co.nombre AS quirofano
    FROM core.cirugias c
    JOIN core.mascotas m ON m.id = c.mascota_id
    JOIN core.clientes cl ON cl.id = m.cliente_id
    JOIN core.especies esp ON esp.id = m.especie_id
    LEFT JOIN core.users u ON u.id = c.cirujano_id
    LEFT JOIN core.consultorios co ON co.id = c.consultorio_id
    WHERE (v_global OR c.empresa_id = v_emp)
      AND (p_filtros->>'estado'     IS NULL OR c.estado::text = p_filtros->>'estado')
      AND (p_filtros->>'mascota_id' IS NULL OR c.mascota_id = (p_filtros->>'mascota_id')::uuid)
      AND (p_filtros->>'desde' IS NULL OR COALESCE(c.fecha_inicio, c.fecha_programada) >= (p_filtros->>'desde')::timestamptz)
      AND (p_filtros->>'hasta' IS NULL OR COALESCE(c.fecha_inicio, c.fecha_programada) <  (p_filtros->>'hasta')::timestamptz)
  ) x;

  RETURN jsonb_build_object('ok', true, 'data', v_data);

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_cita_obtener(uuid, uuid, boolean, uuid); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_cita_obtener(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_global BOOLEAN := internal.es_acceso_global(p_user_id, p_is_super_admin);
  v_emp    UUID    := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_data   JSONB;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'citas:listar');

  SELECT to_jsonb(x) INTO v_data FROM (
    SELECT c.*,
           m.nombre AS mascota, m.foto_url AS mascota_foto, m.alergias,
           m.condiciones_cronicas, m.peso_kg,
           esp.nombre AS especie, r.nombre AS raza,
           internal.edad_mascota(m.fecha_nacimiento, m.edad_aproximada_meses) AS edad,
           trim(cl.nombres || ' ' || COALESCE(cl.apellido_paterno,'')) AS cliente,
           cl.telefono AS cliente_telefono, cl.correo AS cliente_correo,
           trim(u.nombres || ' ' || COALESCE(u.apellido_paterno,'')) AS veterinario,
           s.nombre AS servicio, s.precio AS servicio_precio,
           co.nombre AS consultorio,
           (SELECT COALESCE(jsonb_agg(jsonb_build_object(
                     'accion', ch.accion, 'fecha_hora_antes', ch.fecha_hora_antes,
                     'fecha_hora_despues', ch.fecha_hora_despues, 'motivo', ch.motivo,
                     'created_at', ch.created_at,
                     'usuario', trim(uh.nombres || ' ' || COALESCE(uh.apellido_paterno,'')))
                   ORDER BY ch.created_at DESC), '[]'::jsonb)
              FROM core.citas_historial ch
              LEFT JOIN core.users uh ON uh.id = ch.user_id
             WHERE ch.cita_id = c.id) AS historial,
           (SELECT cs.id FROM core.consultas cs
             WHERE cs.cita_id = c.id AND cs.deleted_at IS NULL LIMIT 1) AS consulta_id
    FROM core.citas c
    JOIN core.mascotas m  ON m.id = c.mascota_id
    JOIN core.clientes cl ON cl.id = c.cliente_id
    JOIN core.especies esp ON esp.id = m.especie_id
    LEFT JOIN core.razas r ON r.id = m.raza_id
    LEFT JOIN core.users u ON u.id = c.veterinario_id
    LEFT JOIN core.servicios s ON s.id = c.servicio_id
    LEFT JOIN core.consultorios co ON co.id = c.consultorio_id
    WHERE c.id = p_id AND c.deleted_at IS NULL
      AND (v_global OR c.empresa_id = v_emp)
  ) x;

  IF v_data IS NULL THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Cita no encontrada'));
  END IF;

  RETURN jsonb_build_object('ok', true, 'data', v_data);

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_citas_agenda_dia(uuid, uuid, boolean, date); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_citas_agenda_dia(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_fecha date DEFAULT NULL::date) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_emp   UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_fecha DATE := COALESCE(p_fecha, CURRENT_DATE);
  v_data  JSONB;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'citas:listar');

  SELECT jsonb_build_object(
    'fecha', v_fecha,
    'resumen', jsonb_build_object(
      'total',       count(*),
      'programadas', count(*) FILTER (WHERE c.estado = 'programada'),
      'confirmadas', count(*) FILTER (WHERE c.estado = 'confirmada'),
      'en_espera',   count(*) FILTER (WHERE c.estado = 'en_espera'),
      'en_atencion', count(*) FILTER (WHERE c.estado = 'en_atencion'),
      'completadas', count(*) FILTER (WHERE c.estado = 'completada'),
      'canceladas',  count(*) FILTER (WHERE c.estado = 'cancelada'),
      'no_asistio',  count(*) FILTER (WHERE c.estado = 'no_asistio'),
      'urgencias',   count(*) FILTER (WHERE c.prioridad IN ('urgencia','emergencia'))
    )
  ) INTO v_data
  FROM core.citas c
  WHERE c.empresa_id = v_emp AND c.deleted_at IS NULL
    AND c.fecha_hora::date = v_fecha;

  RETURN jsonb_build_object('ok', true, 'data', v_data);

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_citas_disponibilidad(uuid, uuid, boolean, uuid, date, integer); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_citas_disponibilidad(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_veterinario_id uuid, p_fecha date, p_duracion_min integer DEFAULT NULL::integer) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_emp      UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_dur      INT;
  v_slots    JSONB := '[]'::jsonb;
  v_rango    RECORD;
  v_cursor   TIMESTAMPTZ;
  v_fin      TIMESTAMPTZ;
  v_ocupado  BOOLEAN;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'citas:listar');

  SELECT COALESCE(p_duracion_min, duracion_cita_min) INTO v_dur
    FROM core.empresas WHERE id = v_emp;
  v_dur := COALESCE(v_dur, 30);

  -- Franjas candidatas: la disponibilidad declarada del profesional para esa
  -- fecha; si no declaró nada, el horario de atención de la empresa.
  FOR v_rango IN
    SELECT d.hora_inicio, d.hora_fin
      FROM core.disponibilidad d
     WHERE d.empresa_id = v_emp AND d.user_id = p_veterinario_id
       AND d.fecha = p_fecha AND d.tipo IN ('laboral','guardia')
    UNION ALL
    SELECT h.hora_inicio, h.hora_fin
      FROM core.horarios_atencion h
     WHERE h.empresa_id = v_emp AND h.activo = true
       AND h.dia_semana = EXTRACT(DOW FROM p_fecha)::int
       AND NOT EXISTS (SELECT 1 FROM core.disponibilidad d2
                        WHERE d2.empresa_id = v_emp AND d2.user_id = p_veterinario_id
                          AND d2.fecha = p_fecha AND d2.tipo IN ('laboral','guardia'))
    ORDER BY 1
  LOOP
    v_cursor := (p_fecha + v_rango.hora_inicio)::timestamptz;
    v_fin    := (p_fecha + v_rango.hora_fin)::timestamptz;

    WHILE v_cursor + (v_dur || ' minutes')::interval <= v_fin LOOP
      v_ocupado := internal.hay_solapamiento_cita(v_emp, p_veterinario_id, v_cursor, v_dur);

      -- Un permiso aprobado bloquea la franja aunque haya horario
      IF NOT v_ocupado THEN
        v_ocupado := EXISTS (
          SELECT 1 FROM core.permisos_laborales pl
           WHERE pl.user_id = p_veterinario_id AND pl.estado = 'aprobado'
             AND p_fecha BETWEEN pl.fecha_inicio AND pl.fecha_fin);
      END IF;

      v_slots := v_slots || jsonb_build_object(
        'inicio', v_cursor,
        'fin', v_cursor + (v_dur || ' minutes')::interval,
        'disponible', NOT v_ocupado);

      v_cursor := v_cursor + (v_dur || ' minutes')::interval;
    END LOOP;
  END LOOP;

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object(
    'fecha', p_fecha, 'veterinario_id', p_veterinario_id,
    'duracion_min', v_dur, 'slots', v_slots));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_citas_listar(uuid, uuid, boolean, jsonb, integer, integer); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_citas_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_filtros jsonb DEFAULT '{}'::jsonb, p_page integer DEFAULT 1, p_page_size integer DEFAULT 50) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_global BOOLEAN := internal.es_acceso_global(p_user_id, p_is_super_admin);
  v_emp    UUID    := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_desde  TIMESTAMPTZ := COALESCE(NULLIF(p_filtros->>'desde','')::timestamptz, date_trunc('day', now()));
  v_hasta  TIMESTAMPTZ := COALESCE(NULLIF(p_filtros->>'hasta','')::timestamptz, date_trunc('day', now()) + INTERVAL '1 day');
  v_buscar TEXT    := internal.normalizar(p_filtros->>'buscar');
  v_size   INT     := LEAST(GREATEST(COALESCE(p_page_size, 50), 1), 200);
  v_page   INT     := GREATEST(COALESCE(p_page, 1), 1);
  v_total  INT;
  v_data   JSONB;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'citas:listar');

  SELECT count(*) INTO v_total
  FROM core.citas c
  JOIN core.mascotas m ON m.id = c.mascota_id
  JOIN core.clientes cl ON cl.id = c.cliente_id
  WHERE c.deleted_at IS NULL
    AND (v_global OR c.empresa_id = v_emp)
    AND c.fecha_hora >= v_desde AND c.fecha_hora < v_hasta
    AND (p_filtros->>'estado'         IS NULL OR c.estado::text = p_filtros->>'estado')
    AND (p_filtros->>'veterinario_id' IS NULL OR c.veterinario_id = (p_filtros->>'veterinario_id')::uuid)
    AND (p_filtros->>'mascota_id'     IS NULL OR c.mascota_id = (p_filtros->>'mascota_id')::uuid)
    AND (p_filtros->>'cliente_id'     IS NULL OR c.cliente_id = (p_filtros->>'cliente_id')::uuid)
    AND (v_buscar IS NULL OR v_buscar = '' OR
         internal.normalizar(m.nombre) LIKE '%' || v_buscar || '%' OR
         internal.normalizar(cl.nombres || ' ' || COALESCE(cl.apellido_paterno,'')) LIKE '%' || v_buscar || '%');

  SELECT COALESCE(jsonb_agg(x), '[]'::jsonb) INTO v_data
  FROM (
    SELECT c.id, c.codigo, c.fecha_hora, c.duracion_min, c.motivo, c.estado,
           c.prioridad, c.origen, c.observaciones, c.empresa_id,
           c.hora_llegada, c.hora_atencion, c.hora_salida,
           c.motivo_cancelacion, c.created_at,
           -- Paciente
           c.mascota_id, m.nombre AS mascota, m.foto_url AS mascota_foto,
           m.alergias, m.sexo AS mascota_sexo, m.peso_kg,
           esp.nombre AS especie, r.nombre AS raza,
           internal.edad_mascota(m.fecha_nacimiento, m.edad_aproximada_meses) AS edad,
           -- Propietario
           c.cliente_id,
           trim(cl.nombres || ' ' || COALESCE(cl.apellido_paterno,'') || ' ' ||
                COALESCE(cl.apellido_materno,'')) AS cliente,
           cl.telefono AS cliente_telefono,
           -- Profesional y recurso
           c.veterinario_id,
           trim(u.nombres || ' ' || COALESCE(u.apellido_paterno,'')) AS veterinario,
           u.color_agenda,
           c.servicio_id, s.nombre AS servicio, s.precio AS servicio_precio,
           c.consultorio_id, co.nombre AS consultorio,
           -- ¿Ya se atendió? (hay consulta ligada)
           EXISTS (SELECT 1 FROM core.consultas cs
                    WHERE cs.cita_id = c.id AND cs.deleted_at IS NULL) AS tiene_consulta
    FROM core.citas c
    JOIN core.mascotas m  ON m.id = c.mascota_id
    JOIN core.clientes cl ON cl.id = c.cliente_id
    JOIN core.especies esp ON esp.id = m.especie_id
    LEFT JOIN core.razas r ON r.id = m.raza_id
    LEFT JOIN core.users u ON u.id = c.veterinario_id
    LEFT JOIN core.servicios s ON s.id = c.servicio_id
    LEFT JOIN core.consultorios co ON co.id = c.consultorio_id
    WHERE c.deleted_at IS NULL
      AND (v_global OR c.empresa_id = v_emp)
      AND c.fecha_hora >= v_desde AND c.fecha_hora < v_hasta
      AND (p_filtros->>'estado'         IS NULL OR c.estado::text = p_filtros->>'estado')
      AND (p_filtros->>'veterinario_id' IS NULL OR c.veterinario_id = (p_filtros->>'veterinario_id')::uuid)
      AND (p_filtros->>'mascota_id'     IS NULL OR c.mascota_id = (p_filtros->>'mascota_id')::uuid)
      AND (p_filtros->>'cliente_id'     IS NULL OR c.cliente_id = (p_filtros->>'cliente_id')::uuid)
      AND (v_buscar IS NULL OR v_buscar = '' OR
           internal.normalizar(m.nombre) LIKE '%' || v_buscar || '%' OR
           internal.normalizar(cl.nombres || ' ' || COALESCE(cl.apellido_paterno,'')) LIKE '%' || v_buscar || '%')
    ORDER BY c.fecha_hora
    LIMIT v_size OFFSET (v_page - 1) * v_size
  ) x;

  RETURN jsonb_build_object('ok', true, 'data', v_data, 'meta', jsonb_build_object(
    'total', v_total, 'page', v_page, 'pageSize', v_size,
    'pages', GREATEST(CEIL(v_total::numeric / v_size)::int, 1),
    'desde', v_desde, 'hasta', v_hasta));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_clausulas_listar(uuid, uuid, boolean, character varying); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_clausulas_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_tipo character varying DEFAULT NULL::character varying) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_emp  UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_data JSONB;
BEGIN
  SELECT COALESCE(jsonb_agg(to_jsonb(c) ORDER BY c.orden, c.titulo), '[]'::jsonb) INTO v_data
  FROM core.clausulas c
  WHERE c.empresa_id = v_emp AND (p_tipo IS NULL OR c.tipo = p_tipo);

  RETURN jsonb_build_object('ok', true, 'data', v_data);

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_cliente_buscar(uuid, uuid, boolean, text, integer); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_cliente_buscar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_query text, p_limit integer DEFAULT 20) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_global BOOLEAN := internal.es_acceso_global(p_user_id, p_is_super_admin);
  v_emp    UUID    := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_q      TEXT    := internal.normalizar(p_query);
  v_data   JSONB;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'clientes:listar');

  IF v_q IS NULL OR length(v_q) < 2 THEN
    RETURN jsonb_build_object('ok', true, 'data', '[]'::jsonb);
  END IF;

  SELECT COALESCE(jsonb_agg(x), '[]'::jsonb) INTO v_data
  FROM (
    SELECT c.id, c.codigo, c.numero_documento, c.telefono, c.correo,
           trim(c.nombres || ' ' || COALESCE(c.apellido_paterno,'') || ' ' ||
                COALESCE(c.apellido_materno,'')) AS nombre_completo,
           (SELECT COALESCE(jsonb_agg(jsonb_build_object(
                     'id', m.id, 'nombre', m.nombre, 'especie', e.nombre) ORDER BY m.nombre), '[]'::jsonb)
              FROM core.mascotas m JOIN core.especies e ON e.id = m.especie_id
             WHERE m.cliente_id = c.id AND m.deleted_at IS NULL AND m.estado = 'activo') AS mascotas
    FROM core.clientes c
    WHERE c.deleted_at IS NULL AND c.estado = 'activo'
      AND (v_global OR c.empresa_id = v_emp)
      AND (internal.normalizar(c.nombres || ' ' || COALESCE(c.apellido_paterno,'') || ' ' ||
                               COALESCE(c.apellido_materno,'')) LIKE '%' || v_q || '%'
           OR c.numero_documento LIKE p_query || '%'
           OR COALESCE(c.telefono,'') LIKE '%' || p_query || '%'
           OR EXISTS (SELECT 1 FROM core.mascotas m
                       WHERE m.cliente_id = c.id AND m.deleted_at IS NULL
                         AND internal.normalizar(m.nombre) LIKE v_q || '%'))
    ORDER BY c.apellido_paterno NULLS LAST, c.nombres
    LIMIT LEAST(COALESCE(p_limit, 20), 50)
  ) x;

  RETURN jsonb_build_object('ok', true, 'data', v_data);

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_cliente_listar(uuid, uuid, boolean, jsonb, integer, integer); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_cliente_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_filtros jsonb DEFAULT '{}'::jsonb, p_page integer DEFAULT 1, p_page_size integer DEFAULT 20) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_global BOOLEAN := internal.es_acceso_global(p_user_id, p_is_super_admin);
  v_emp    UUID    := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_buscar TEXT    := internal.normalizar(p_filtros->>'buscar');
  v_raw    TEXT    := COALESCE(p_filtros->>'buscar','');
  v_size   INT     := LEAST(GREATEST(COALESCE(p_page_size, 20), 1), 100);
  v_page   INT     := GREATEST(COALESCE(p_page, 1), 1);
  v_total  INT;
  v_data   JSONB;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'clientes:listar');

  SELECT count(*) INTO v_total
  FROM core.clientes c
  WHERE c.deleted_at IS NULL
    AND (v_global OR c.empresa_id = v_emp)
    AND (p_filtros->>'estado' IS NULL OR c.estado::text = p_filtros->>'estado')
    AND (p_filtros->>'con_portal' IS NULL
         OR c.portal_acceso = (p_filtros->>'con_portal')::boolean)
    AND (v_buscar IS NULL OR v_buscar = '' OR
         internal.normalizar(c.nombres || ' ' || COALESCE(c.apellido_paterno,'') || ' ' ||
                             COALESCE(c.apellido_materno,'') || ' ' || COALESCE(c.razon_social,''))
           LIKE '%' || v_buscar || '%'
         OR c.numero_documento LIKE '%' || v_raw || '%'
         OR COALESCE(c.telefono,'') LIKE '%' || v_raw || '%'
         -- buscar también por el nombre de alguna de sus mascotas
         OR EXISTS (SELECT 1 FROM core.mascotas m
                     WHERE m.cliente_id = c.id AND m.deleted_at IS NULL
                       AND internal.normalizar(m.nombre) LIKE '%' || v_buscar || '%'));

  SELECT COALESCE(jsonb_agg(x), '[]'::jsonb) INTO v_data
  FROM (
    SELECT c.id, c.codigo, c.tipo_documento, c.numero_documento,
           c.nombres, c.apellido_paterno, c.apellido_materno, c.razon_social,
           trim(c.nombres || ' ' || COALESCE(c.apellido_paterno,'') || ' ' ||
                COALESCE(c.apellido_materno,'')) AS nombre_completo,
           c.telefono, c.telefono_alterno, c.correo, c.direccion,
           c.portal_acceso, c.estado, c.acepta_marketing, c.created_at,
           (SELECT count(*) FROM core.mascotas m
             WHERE m.cliente_id = c.id AND m.deleted_at IS NULL
               AND m.estado = 'activo') AS total_mascotas,
           (SELECT COALESCE(jsonb_agg(jsonb_build_object(
                     'id', m.id, 'nombre', m.nombre, 'especie', e.nombre, 'foto_url', m.foto_url)
                   ORDER BY m.nombre), '[]'::jsonb)
              FROM core.mascotas m
              JOIN core.especies e ON e.id = m.especie_id
             WHERE m.cliente_id = c.id AND m.deleted_at IS NULL AND m.estado = 'activo') AS mascotas,
           (SELECT max(ci.fecha_hora) FROM core.citas ci
             WHERE ci.cliente_id = c.id AND ci.deleted_at IS NULL
               AND ci.estado = 'completada'
               AND (v_global OR ci.empresa_id = v_emp)) AS ultima_visita,
           (SELECT COALESCE(SUM(cp.saldo_pendiente), 0) FROM core.comprobantes cp
             WHERE cp.cliente_id = c.id AND cp.deleted_at IS NULL
               AND cp.estado_pago <> 'pagado' AND cp.anulado_at IS NULL
               AND (v_global OR cp.empresa_id = v_emp)) AS deuda_pendiente
    FROM core.clientes c
    WHERE c.deleted_at IS NULL
      AND (v_global OR c.empresa_id = v_emp)
      AND (p_filtros->>'estado' IS NULL OR c.estado::text = p_filtros->>'estado')
      AND (p_filtros->>'con_portal' IS NULL
           OR c.portal_acceso = (p_filtros->>'con_portal')::boolean)
      AND (v_buscar IS NULL OR v_buscar = '' OR
           internal.normalizar(c.nombres || ' ' || COALESCE(c.apellido_paterno,'') || ' ' ||
                               COALESCE(c.apellido_materno,'') || ' ' || COALESCE(c.razon_social,''))
             LIKE '%' || v_buscar || '%'
           OR c.numero_documento LIKE '%' || v_raw || '%'
           OR COALESCE(c.telefono,'') LIKE '%' || v_raw || '%'
           OR EXISTS (SELECT 1 FROM core.mascotas m
                       WHERE m.cliente_id = c.id AND m.deleted_at IS NULL
                         AND internal.normalizar(m.nombre) LIKE '%' || v_buscar || '%'))
    ORDER BY c.apellido_paterno NULLS LAST, c.nombres
    LIMIT v_size OFFSET (v_page - 1) * v_size
  ) x;

  RETURN jsonb_build_object('ok', true, 'data', v_data, 'meta', jsonb_build_object(
    'total', v_total, 'page', v_page, 'pageSize', v_size,
    'pages', GREATEST(CEIL(v_total::numeric / v_size)::int, 1)));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_cliente_obtener(uuid, uuid, boolean, uuid); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_cliente_obtener(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_global BOOLEAN := internal.es_acceso_global(p_user_id, p_is_super_admin);
  v_emp    UUID    := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_data   JSONB;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'clientes:listar');

  SELECT to_jsonb(x) INTO v_data FROM (
    SELECT c.id, c.codigo, c.tipo_documento, c.numero_documento,
           c.nombres, c.apellido_paterno, c.apellido_materno, c.razon_social,
           trim(c.nombres || ' ' || COALESCE(c.apellido_paterno,'') || ' ' ||
                COALESCE(c.apellido_materno,'')) AS nombre_completo,
           c.telefono, c.telefono_alterno, c.correo, c.direccion, c.ubigeo,
           c.fecha_nacimiento, c.linea_credito, c.dias_credito, c.acepta_marketing,
           c.portal_acceso, c.portal_ultimo_login_at, c.estado, c.observaciones,
           c.created_at,
           (SELECT COALESCE(jsonb_agg(jsonb_build_object(
                     'id', m.id, 'codigo', m.codigo, 'nombre', m.nombre,
                     'especie', e.nombre, 'especie_id', m.especie_id,
                     'raza', r.nombre,
                     'sexo', m.sexo, 'peso_kg', m.peso_kg, 'foto_url', m.foto_url,
                     'estado', m.estado,
                     'edad', internal.edad_mascota(m.fecha_nacimiento, m.edad_aproximada_meses),
                     'alergias', m.alergias)
                   ORDER BY m.nombre), '[]'::jsonb)
              FROM core.mascotas m
              JOIN core.especies e ON e.id = m.especie_id
              LEFT JOIN core.razas r ON r.id = m.raza_id
             WHERE m.cliente_id = c.id AND m.deleted_at IS NULL) AS mascotas,
           (SELECT COALESCE(jsonb_agg(jsonb_build_object(
                     'id', ci.id, 'fecha_hora', ci.fecha_hora, 'estado', ci.estado,
                     'motivo', ci.motivo, 'mascota', m2.nombre,
                     'servicio', s.nombre)
                   ORDER BY ci.fecha_hora DESC), '[]'::jsonb)
              FROM (SELECT * FROM core.citas ci2
                     WHERE ci2.cliente_id = c.id AND ci2.deleted_at IS NULL
                       AND (v_global OR ci2.empresa_id = v_emp)
                     ORDER BY ci2.fecha_hora DESC LIMIT 10) ci
              JOIN core.mascotas m2 ON m2.id = ci.mascota_id
              LEFT JOIN core.servicios s ON s.id = ci.servicio_id) AS ultimas_citas,
           (SELECT COALESCE(SUM(cp.saldo_pendiente), 0) FROM core.comprobantes cp
             WHERE cp.cliente_id = c.id AND cp.deleted_at IS NULL
               AND cp.estado_pago <> 'pagado' AND cp.anulado_at IS NULL
               AND (v_global OR cp.empresa_id = v_emp)) AS deuda_pendiente,
           (SELECT COALESCE(SUM(cp.total), 0) FROM core.comprobantes cp
             WHERE cp.cliente_id = c.id AND cp.deleted_at IS NULL
               AND cp.anulado_at IS NULL
               AND (v_global OR cp.empresa_id = v_emp)) AS facturado_historico
    FROM core.clientes c
    WHERE c.id = p_id AND c.deleted_at IS NULL
      AND (v_global OR c.empresa_id = v_emp)
  ) x;

  IF v_data IS NULL THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Cliente no encontrado'));
  END IF;

  RETURN jsonb_build_object('ok', true, 'data', v_data);

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_comprobante_obtener(uuid, uuid, boolean, uuid); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_comprobante_obtener(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_global BOOLEAN := internal.es_acceso_global(p_user_id, p_is_super_admin);
  v_emp    UUID    := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_data   JSONB;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'facturacion:ver');

  SELECT to_jsonb(x) INTO v_data FROM (
    SELECT c.*,
           jsonb_build_object(
             'id', cl.id, 'nombre_completo', trim(cl.nombres || ' ' || COALESCE(cl.apellido_paterno,'') || ' ' ||
                                                  COALESCE(cl.apellido_materno,'')),
             'razon_social', cl.razon_social,
             'tipo_documento', cl.tipo_documento, 'numero_documento', cl.numero_documento,
             'direccion', cl.direccion, 'telefono', cl.telefono, 'correo', cl.correo
           ) AS cliente,
           jsonb_build_object(
             'ruc', e.ruc, 'razon_social', e.razon_social,
             'nombre_comercial', e.nombre_comercial, 'direccion', e.direccion_fiscal,
             'telefono', e.telefono, 'correo', e.correo, 'logo_url', e.logo_url
           ) AS emisor,
           m.nombre AS mascota,
           (SELECT COALESCE(jsonb_agg(jsonb_build_object(
                     'id', i.id, 'tipo_item', i.tipo_item, 'codigo', i.codigo,
                     'descripcion', i.descripcion, 'cantidad', i.cantidad,
                     'precio_unitario', i.precio_unitario, 'descuento', i.descuento,
                     'afecto_igv', i.afecto_igv, 'tipo_afectacion_igv', i.tipo_afectacion_igv,
                     'unidad_medida', i.unidad_medida, 'subtotal', i.subtotal,
                     'igv', i.igv, 'total', i.total) ORDER BY i.orden), '[]'::jsonb)
              FROM core.comprobante_items i WHERE i.comprobante_id = c.id) AS items,
           -- Últimos intentos contra el PSE: cuando SUNAT rechaza, el mensaje
           -- del proveedor es lo único que dice por qué.
           (SELECT COALESCE(jsonb_agg(jsonb_build_object(
                     'intento', l.intento, 'operacion', l.operacion, 'exito', l.exito,
                     'mensaje', l.mensaje, 'fecha', l.created_at)
                     ORDER BY l.created_at DESC), '[]'::jsonb)
              FROM (SELECT * FROM core.comprobante_pse_log
                     WHERE comprobante_id = c.id ORDER BY created_at DESC LIMIT 5) l) AS pse_log,
           (SELECT COALESCE(jsonb_agg(jsonb_build_object(
                     'id', pg.id, 'numero', pg.numero, 'metodo', pg.metodo,
                     'monto_aplicado', pa.monto_aplicado, 'fecha_pago', pg.fecha_pago,
                     'referencia', pg.referencia) ORDER BY pg.fecha_pago), '[]'::jsonb)
              FROM core.pago_aplicaciones pa
              JOIN core.pagos pg ON pg.id = pa.pago_id
             WHERE pa.comprobante_id = c.id AND pg.anulado_at IS NULL) AS pagos,
           -- El documento que esta nota corrige, y las notas que corrigen a este.
           (SELECT jsonb_build_object('id', r.id, 'numero_completo', r.numero_completo,
                                      'tipo', r.tipo, 'total', r.total)
              FROM core.comprobantes r WHERE r.id = c.documento_ref_id) AS documento_ref,
           (SELECT COALESCE(jsonb_agg(jsonb_build_object(
                     'id', nc.id, 'numero_completo', nc.numero_completo,
                     'total', nc.total, 'motivo', nc.motivo_nota,
                     'fecha_emision', nc.fecha_emision) ORDER BY nc.fecha_emision), '[]'::jsonb)
              FROM core.comprobantes nc
             WHERE nc.documento_ref_id = c.id AND nc.deleted_at IS NULL) AS notas_credito
    FROM core.comprobantes c
    JOIN core.clientes cl ON cl.id = c.cliente_id
    JOIN core.empresas e  ON e.id = c.empresa_id
    LEFT JOIN core.mascotas m ON m.id = c.mascota_id
    WHERE c.id = p_id AND c.deleted_at IS NULL
      AND (v_global OR c.empresa_id = v_emp)
  ) x;

  IF v_data IS NULL THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Comprobante no encontrado'));
  END IF;

  RETURN jsonb_build_object('ok', true, 'data', v_data);

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_comprobante_pse_datos(uuid, uuid, boolean, uuid); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_comprobante_pse_datos(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_emp   UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_c     RECORD;
  v_cab   JSONB;
  v_items JSONB;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'facturacion:emitir');

  SELECT c.*, e.ruc, e.pse_ruc, e.razon_social, e.nombre_comercial, e.direccion_fiscal,
         e.ubigeo, e.urbanizacion, e.distrito, e.provincia, e.departamento,
         e.emite_electronico, e.igv_tasa,
         cl.tipo_documento AS cli_tipo_doc, cl.numero_documento AS cli_num_doc,
         COALESCE(NULLIF(cl.razon_social,''),
                  trim(cl.nombres || ' ' || COALESCE(cl.apellido_paterno,'') || ' ' ||
                       COALESCE(cl.apellido_materno,''))) AS cli_razon_social,
         cl.direccion AS cli_direccion, cl.ubigeo AS cli_ubigeo, cl.correo AS cli_correo,
         ref.serie AS ref_serie, ref.numero AS ref_numero, ref.tipo AS ref_tipo
    INTO v_c
    FROM core.comprobantes c
    JOIN core.empresas e ON e.id = c.empresa_id
    JOIN core.clientes cl ON cl.id = c.cliente_id
    LEFT JOIN core.comprobantes ref ON ref.id = c.documento_ref_id
   WHERE c.id = p_id AND c.deleted_at IS NULL
     AND internal.es_de_empresa(p_user_id, p_is_super_admin, v_emp, c.empresa_id);

  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Comprobante no encontrado'));
  END IF;

  -- La nota de venta es un documento interno: no existe para SUNAT.
  IF v_c.tipo = 'nota_venta' THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('BUSINESS_RULE',
        'Una nota de venta no se envía a SUNAT: es un documento interno'));
  END IF;

  SELECT COALESCE(jsonb_agg(jsonb_build_object(
           'descripcion',         i.descripcion,
           'codigo',              i.codigo,
           'unidad_medida',       i.unidad_medida,
           'cantidad',            i.cantidad,
           'precio_unitario',     i.precio_unitario,
           'tipo_afectacion_igv', CASE WHEN i.afecto_igv THEN i.tipo_afectacion_igv ELSE '20' END,
           'igv_porcentaje',      round(COALESCE(v_c.igv_tasa, 0.18) * 100, 2),
           'subtotal',            i.subtotal,
           'igv',                 i.igv,
           'total',               i.total) ORDER BY i.orden), '[]'::jsonb)
    INTO v_items
    FROM core.comprobante_items i WHERE i.comprobante_id = p_id;

  v_cab := jsonb_build_object(
    'id', v_c.id,
    'tipo', v_c.tipo,
    'serie', v_c.serie,
    'numero', v_c.numero,
    'numero_completo', v_c.numero_completo,
    'estado', v_c.estado,
    'empresa_id', v_c.empresa_id,
    'emite_electronico', v_c.emite_electronico,
    'fecha_emision', to_char(v_c.fecha_emision AT TIME ZONE 'America/Lima', 'YYYY-MM-DD'),
    'hora_emision',  to_char(v_c.fecha_emision AT TIME ZONE 'America/Lima', 'HH24:MI:SS'),
    'fecha_vencimiento', v_c.fecha_vencimiento,
    'moneda', v_c.moneda,
    'tipo_cambio', COALESCE(v_c.tipo_cambio, 1),
    'subtotal', v_c.subtotal,
    'igv', v_c.igv,
    'total', v_c.total,
    'descuento_global', v_c.descuento_global,
    'observaciones', v_c.observaciones,
    'motivo_nota', v_c.motivo_nota,
    'codigo_tipo_nota', v_c.codigo_tipo_nota,
    'pse_request_id', v_c.pse_request_id,
    -- Gravado / exonerado salen de la afectación de cada línea, no de un total
    -- suelto: si un ítem va exonerado, su base no puede sumar al gravado.
    'subtotal_gravado', (
      SELECT COALESCE(SUM(i.subtotal), 0) FROM core.comprobante_items i
       WHERE i.comprobante_id = p_id AND i.afecto_igv),
    'subtotal_exonerado', (
      SELECT COALESCE(SUM(i.subtotal), 0) FROM core.comprobante_items i
       WHERE i.comprobante_id = p_id AND NOT i.afecto_igv),
    -- Contado o crédito: lo decide que el comprobante tenga vencimiento futuro.
    'forma_pago', CASE
      WHEN v_c.fecha_vencimiento IS NOT NULL
           AND v_c.fecha_vencimiento > (v_c.fecha_emision AT TIME ZONE 'America/Lima')::date
      THEN 'credito' ELSE 'contado' END,
    'emisor', jsonb_build_object(
      'ruc', COALESCE(NULLIF(v_c.pse_ruc,''), v_c.ruc),
      'razon_social', v_c.razon_social,
      'nombre_comercial', v_c.nombre_comercial,
      'direccion_fiscal', v_c.direccion_fiscal,
      'ubigeo', v_c.ubigeo,
      'urbanizacion', v_c.urbanizacion,
      'distrito', v_c.distrito,
      'provincia', v_c.provincia,
      'departamento', v_c.departamento),
    'cliente', jsonb_build_object(
      'tipo_documento', v_c.cli_tipo_doc,
      'numero_documento', v_c.cli_num_doc,
      'razon_social', v_c.cli_razon_social,
      'direccion', v_c.cli_direccion,
      'ubigeo', v_c.cli_ubigeo,
      'correo', v_c.cli_correo),
    'documento_ref', CASE WHEN v_c.ref_serie IS NOT NULL THEN jsonb_build_object(
      'tipo', v_c.ref_tipo, 'serie', v_c.ref_serie, 'numero', v_c.ref_numero) END);

  RETURN jsonb_build_object('ok', true,
    'data', jsonb_build_object('comprobante', v_cab, 'items', v_items));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_comprobantes_listar(uuid, uuid, boolean, jsonb, integer, integer); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_comprobantes_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_filtros jsonb DEFAULT '{}'::jsonb, p_page integer DEFAULT 1, p_page_size integer DEFAULT 20) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_global BOOLEAN := internal.es_acceso_global(p_user_id, p_is_super_admin);
  v_emp    UUID    := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_buscar TEXT    := internal.normalizar(p_filtros->>'buscar');
  v_raw    TEXT    := COALESCE(p_filtros->>'buscar','');
  v_size   INT     := LEAST(GREATEST(COALESCE(p_page_size, 20), 1), 100);
  v_page   INT     := GREATEST(COALESCE(p_page, 1), 1);
  v_total  INT;
  v_data   JSONB;
  v_totales JSONB;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'facturacion:ver');

  SELECT count(*) INTO v_total
  FROM core.comprobantes c
  JOIN core.clientes cl ON cl.id = c.cliente_id
  WHERE c.deleted_at IS NULL AND (v_global OR c.empresa_id = v_emp)
    AND (p_filtros->>'tipo'        IS NULL OR c.tipo::text = p_filtros->>'tipo')
    AND (p_filtros->>'estado'      IS NULL OR c.estado::text = p_filtros->>'estado')
    AND (p_filtros->>'estado_pago' IS NULL OR c.estado_pago::text = p_filtros->>'estado_pago')
    AND (p_filtros->>'cliente_id'  IS NULL OR c.cliente_id = (p_filtros->>'cliente_id')::uuid)
    AND (p_filtros->>'desde' IS NULL OR c.fecha_emision >= (p_filtros->>'desde')::timestamptz)
    AND (p_filtros->>'hasta' IS NULL OR c.fecha_emision <  (p_filtros->>'hasta')::timestamptz)
    AND (v_buscar IS NULL OR v_buscar = '' OR
         c.numero_completo LIKE '%' || upper(v_raw) || '%' OR
         internal.normalizar(cl.nombres || ' ' || COALESCE(cl.apellido_paterno,'')) LIKE '%' || v_buscar || '%' OR
         cl.numero_documento LIKE '%' || v_raw || '%');

  SELECT COALESCE(jsonb_agg(x), '[]'::jsonb) INTO v_data
  FROM (
    SELECT c.id, c.tipo, c.serie, c.numero, c.numero_completo,
           c.fecha_emision, c.fecha_vencimiento, c.moneda,
           c.subtotal, c.descuento_global, c.igv, c.total, c.saldo_pendiente,
           c.estado, c.estado_pago, c.sunat_codigo, c.sunat_mensaje,
           c.pdf_url, c.xml_url, c.anulado_at, c.observaciones,
           c.cliente_id,
           trim(cl.nombres || ' ' || COALESCE(cl.apellido_paterno,'') || ' ' ||
                COALESCE(cl.apellido_materno,'')) AS cliente,
           COALESCE(cl.razon_social, trim(cl.nombres || ' ' || COALESCE(cl.apellido_paterno,''))) AS cliente_facturacion,
           cl.numero_documento AS cliente_documento, cl.tipo_documento AS cliente_tipo_doc,
           m.nombre AS mascota,
           (SELECT count(*) FROM core.comprobante_items i WHERE i.comprobante_id = c.id) AS items
    FROM core.comprobantes c
    JOIN core.clientes cl ON cl.id = c.cliente_id
    LEFT JOIN core.mascotas m ON m.id = c.mascota_id
    WHERE c.deleted_at IS NULL AND (v_global OR c.empresa_id = v_emp)
      AND (p_filtros->>'tipo'        IS NULL OR c.tipo::text = p_filtros->>'tipo')
      AND (p_filtros->>'estado'      IS NULL OR c.estado::text = p_filtros->>'estado')
      AND (p_filtros->>'estado_pago' IS NULL OR c.estado_pago::text = p_filtros->>'estado_pago')
      AND (p_filtros->>'cliente_id'  IS NULL OR c.cliente_id = (p_filtros->>'cliente_id')::uuid)
      AND (p_filtros->>'desde' IS NULL OR c.fecha_emision >= (p_filtros->>'desde')::timestamptz)
      AND (p_filtros->>'hasta' IS NULL OR c.fecha_emision <  (p_filtros->>'hasta')::timestamptz)
      AND (v_buscar IS NULL OR v_buscar = '' OR
           c.numero_completo LIKE '%' || upper(v_raw) || '%' OR
           internal.normalizar(cl.nombres || ' ' || COALESCE(cl.apellido_paterno,'')) LIKE '%' || v_buscar || '%' OR
           cl.numero_documento LIKE '%' || v_raw || '%')
    ORDER BY c.fecha_emision DESC
    LIMIT v_size OFFSET (v_page - 1) * v_size
  ) x;

  -- Totales del filtro completo (no solo de la página) para las tarjetas KPI
  SELECT jsonb_build_object(
    'facturado', COALESCE(SUM(c.total) FILTER (WHERE c.anulado_at IS NULL), 0),
    'cobrado',   COALESCE(SUM(c.total - c.saldo_pendiente) FILTER (WHERE c.anulado_at IS NULL), 0),
    'pendiente', COALESCE(SUM(c.saldo_pendiente) FILTER (WHERE c.anulado_at IS NULL), 0)
  ) INTO v_totales
  FROM core.comprobantes c
  WHERE c.deleted_at IS NULL AND (v_global OR c.empresa_id = v_emp)
    AND (p_filtros->>'desde' IS NULL OR c.fecha_emision >= (p_filtros->>'desde')::timestamptz)
    AND (p_filtros->>'hasta' IS NULL OR c.fecha_emision <  (p_filtros->>'hasta')::timestamptz);

  RETURN jsonb_build_object('ok', true, 'data', v_data, 'meta', jsonb_build_object(
    'total', v_total, 'page', v_page, 'pageSize', v_size,
    'pages', GREATEST(CEIL(v_total::numeric / v_size)::int, 1),
    'totales', v_totales));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_comprobantes_por_enviar(uuid, uuid, boolean); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_comprobantes_por_enviar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_global BOOLEAN := internal.es_acceso_global(p_user_id, p_is_super_admin);
  v_emp    UUID    := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_data   JSONB;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'facturacion:emitir');

  SELECT COALESCE(jsonb_agg(x ORDER BY x.fecha_emision), '[]'::jsonb) INTO v_data
  FROM (
    SELECT c.id, c.numero_completo, c.tipo, c.fecha_emision, c.total, c.estado,
           c.sunat_codigo, c.sunat_mensaje, c.enviado_pse_at,
           trim(cl.nombres || ' ' || COALESCE(cl.apellido_paterno,'')) AS cliente,
           (SELECT count(*) FROM core.comprobante_pse_log l WHERE l.comprobante_id = c.id) AS intentos
      FROM core.comprobantes c
      JOIN core.clientes cl ON cl.id = c.cliente_id
      JOIN core.empresas e  ON e.id = c.empresa_id
     WHERE c.deleted_at IS NULL
       AND c.tipo <> 'nota_venta'
       AND e.emite_electronico
       AND c.estado IN ('emitido','pendiente_envio','enviado_sunat','rechazado_sunat')
       AND (v_global OR c.empresa_id = v_emp)
  ) x;

  RETURN jsonb_build_object('ok', true, 'data', v_data);

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_comunicaciones_listar(uuid, uuid, boolean, uuid, integer); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_comunicaciones_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_cliente_id uuid DEFAULT NULL::uuid, p_limit integer DEFAULT 50) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_global BOOLEAN := internal.es_acceso_global(p_user_id, p_is_super_admin);
  v_emp    UUID    := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_data   JSONB;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'clientes:listar');

  SELECT COALESCE(jsonb_agg(x ORDER BY x.fecha DESC), '[]'::jsonb) INTO v_data
  FROM (
    SELECT co.id, co.tipo, co.asunto, co.mensaje, co.fecha,
           co.requiere_seguimiento, co.fecha_seguimiento,
           co.cliente_id, co.mascota_id,
           trim(c.nombres || ' ' || COALESCE(c.apellido_paterno,'')) AS cliente,
           m.nombre AS mascota,
           trim(u.nombres || ' ' || COALESCE(u.apellido_paterno,'')) AS registrado_por
    FROM core.comunicaciones co
    JOIN core.clientes c ON c.id = co.cliente_id
    LEFT JOIN core.mascotas m ON m.id = co.mascota_id
    LEFT JOIN core.users u ON u.id = co.user_id
    WHERE (v_global OR co.empresa_id = v_emp)
      AND (p_cliente_id IS NULL OR co.cliente_id = p_cliente_id)
    ORDER BY co.fecha DESC
    LIMIT LEAST(COALESCE(p_limit, 50), 200)
  ) x;

  RETURN jsonb_build_object('ok', true, 'data', v_data);

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_consulta_obtener(uuid, uuid, boolean, uuid); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_consulta_obtener(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_global BOOLEAN := internal.es_acceso_global(p_user_id, p_is_super_admin);
  v_emp    UUID    := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_data   JSONB;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'clinico:ver');

  SELECT to_jsonb(x) INTO v_data FROM (
    SELECT c.*,
           m.nombre AS mascota, m.foto_url AS mascota_foto, m.alergias,
           m.condiciones_cronicas,
           esp.nombre AS especie, r.nombre AS raza,
           internal.edad_mascota(m.fecha_nacimiento, m.edad_aproximada_meses) AS edad,
           trim(cl.nombres || ' ' || COALESCE(cl.apellido_paterno,'')) AS cliente,
           cl.telefono AS cliente_telefono,
           trim(u.nombres || ' ' || COALESCE(u.apellido_paterno,'')) AS veterinario,
           u.colegiatura,
           (SELECT COALESCE(jsonb_agg(jsonb_build_object(
                     'id', iu.id, 'producto_id', iu.producto_id, 'producto', pr.nombre,
                     'cantidad', iu.cantidad, 'precio_unitario', iu.precio_unitario,
                     'facturado', iu.facturado)), '[]'::jsonb)
              FROM core.insumos_utilizados iu
              JOIN core.productos pr ON pr.id = iu.producto_id
             WHERE iu.consulta_id = c.id) AS insumos,
           (SELECT COALESCE(jsonb_agg(jsonb_build_object(
                     'id', ex.id, 'tipo', ex.tipo, 'nombre', ex.nombre,
                     'fecha_solicitud', ex.fecha_solicitud, 'fecha_resultado', ex.fecha_resultado,
                     'resultado', ex.resultado, 'valores', ex.valores,
                     'archivo_url', ex.archivo_url)), '[]'::jsonb)
              FROM core.examenes ex WHERE ex.consulta_id = c.id) AS examenes,
           (SELECT COALESCE(jsonb_agg(jsonb_build_object(
                     'id', os.id, 'servicio', s.nombre, 'cantidad', os.cantidad,
                     'precio_unitario', os.precio_unitario, 'total', os.total,
                     'estado', os.estado, 'facturado', os.facturado)), '[]'::jsonb)
              FROM core.ordenes_servicio os
              JOIN core.servicios s ON s.id = os.servicio_id
             WHERE os.consulta_id = c.id) AS servicios,
           (SELECT COALESCE(jsonb_agg(jsonb_build_object(
                     'id', t.id, 'medicamento', t.medicamento, 'dosis', t.dosis,
                     'via', t.via, 'frecuencia_horas', t.frecuencia_horas,
                     'duracion_dias', t.duracion_dias, 'estado', t.estado)), '[]'::jsonb)
              FROM core.tratamientos t WHERE t.consulta_id = c.id) AS tratamientos
    FROM core.consultas c
    JOIN core.mascotas m  ON m.id = c.mascota_id
    JOIN core.clientes cl ON cl.id = c.cliente_id
    JOIN core.especies esp ON esp.id = m.especie_id
    LEFT JOIN core.razas r ON r.id = m.raza_id
    LEFT JOIN core.users u ON u.id = c.veterinario_id
    WHERE c.id = p_id AND c.deleted_at IS NULL
      AND (v_global OR c.empresa_id = v_emp)
  ) x;

  IF v_data IS NULL THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Consulta no encontrada'));
  END IF;

  RETURN jsonb_build_object('ok', true, 'data', v_data);

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_consultas_listar(uuid, uuid, boolean, jsonb, integer, integer); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_consultas_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_filtros jsonb DEFAULT '{}'::jsonb, p_page integer DEFAULT 1, p_page_size integer DEFAULT 20) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_global BOOLEAN := internal.es_acceso_global(p_user_id, p_is_super_admin);
  v_emp    UUID    := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_size   INT     := LEAST(GREATEST(COALESCE(p_page_size, 20), 1), 100);
  v_page   INT     := GREATEST(COALESCE(p_page, 1), 1);
  v_total  INT;
  v_data   JSONB;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'clinico:ver');

  SELECT count(*) INTO v_total
  FROM core.consultas c
  WHERE c.deleted_at IS NULL AND (v_global OR c.empresa_id = v_emp)
    AND (p_filtros->>'mascota_id'     IS NULL OR c.mascota_id = (p_filtros->>'mascota_id')::uuid)
    AND (p_filtros->>'veterinario_id' IS NULL OR c.veterinario_id = (p_filtros->>'veterinario_id')::uuid)
    AND (p_filtros->>'estado'         IS NULL OR c.estado::text = p_filtros->>'estado')
    AND (p_filtros->>'desde' IS NULL OR c.fecha >= (p_filtros->>'desde')::timestamptz)
    AND (p_filtros->>'hasta' IS NULL OR c.fecha <  (p_filtros->>'hasta')::timestamptz);

  SELECT COALESCE(jsonb_agg(x), '[]'::jsonb) INTO v_data
  FROM (
    SELECT c.id, c.codigo, c.fecha, c.motivo, c.diagnostico, c.estado,
           c.peso_kg, c.temperatura_c, c.proxima_visita,
           c.mascota_id, m.nombre AS mascota, m.foto_url AS mascota_foto,
           esp.nombre AS especie,
           c.cliente_id,
           trim(cl.nombres || ' ' || COALESCE(cl.apellido_paterno,'')) AS cliente,
           c.veterinario_id,
           trim(u.nombres || ' ' || COALESCE(u.apellido_paterno,'')) AS veterinario
    FROM core.consultas c
    JOIN core.mascotas m  ON m.id = c.mascota_id
    JOIN core.clientes cl ON cl.id = c.cliente_id
    JOIN core.especies esp ON esp.id = m.especie_id
    LEFT JOIN core.users u ON u.id = c.veterinario_id
    WHERE c.deleted_at IS NULL AND (v_global OR c.empresa_id = v_emp)
      AND (p_filtros->>'mascota_id'     IS NULL OR c.mascota_id = (p_filtros->>'mascota_id')::uuid)
      AND (p_filtros->>'veterinario_id' IS NULL OR c.veterinario_id = (p_filtros->>'veterinario_id')::uuid)
      AND (p_filtros->>'estado'         IS NULL OR c.estado::text = p_filtros->>'estado')
      AND (p_filtros->>'desde' IS NULL OR c.fecha >= (p_filtros->>'desde')::timestamptz)
      AND (p_filtros->>'hasta' IS NULL OR c.fecha <  (p_filtros->>'hasta')::timestamptz)
    ORDER BY c.fecha DESC
    LIMIT v_size OFFSET (v_page - 1) * v_size
  ) x;

  RETURN jsonb_build_object('ok', true, 'data', v_data, 'meta', jsonb_build_object(
    'total', v_total, 'page', v_page, 'pageSize', v_size,
    'pages', GREATEST(CEIL(v_total::numeric / v_size)::int, 1)));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_consultorios_listar(uuid, uuid, boolean); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_consultorios_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_global BOOLEAN := internal.es_acceso_global(p_user_id, p_is_super_admin);
  v_emp    UUID    := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_data   JSONB;
BEGIN
  SELECT COALESCE(jsonb_agg(to_jsonb(c) ORDER BY c.nombre), '[]'::jsonb) INTO v_data
  FROM core.consultorios c
  WHERE (v_global OR c.empresa_id = v_emp);

  RETURN jsonb_build_object('ok', true, 'data', v_data);

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_cuentas_por_cobrar(uuid, uuid, boolean, jsonb); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_cuentas_por_cobrar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_filtros jsonb DEFAULT '{}'::jsonb) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_global BOOLEAN := internal.es_acceso_global(p_user_id, p_is_super_admin);
  v_emp    UUID    := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_data   JSONB;
  v_resumen JSONB;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'facturacion:ver');

  SELECT COALESCE(jsonb_agg(x ORDER BY x.dias_vencido DESC NULLS LAST), '[]'::jsonb) INTO v_data
  FROM (
    SELECT c.id, c.numero_completo, c.tipo, c.fecha_emision, c.fecha_vencimiento,
           c.total, c.saldo_pendiente, c.estado_pago, c.moneda,
           c.cliente_id,
           trim(cl.nombres || ' ' || COALESCE(cl.apellido_paterno,'')) AS cliente,
           cl.telefono AS cliente_telefono, cl.numero_documento,
           GREATEST((CURRENT_DATE - c.fecha_vencimiento), 0) AS dias_vencido,
           CASE
             WHEN c.fecha_vencimiento IS NULL OR c.fecha_vencimiento >= CURRENT_DATE THEN 'por_vencer'
             WHEN CURRENT_DATE - c.fecha_vencimiento <= 30 THEN '1_30'
             WHEN CURRENT_DATE - c.fecha_vencimiento <= 60 THEN '31_60'
             WHEN CURRENT_DATE - c.fecha_vencimiento <= 90 THEN '61_90'
             ELSE 'mas_90'
           END AS tramo
    FROM core.comprobantes c
    JOIN core.clientes cl ON cl.id = c.cliente_id
    WHERE c.deleted_at IS NULL AND c.anulado_at IS NULL
      AND (v_global OR c.empresa_id = v_emp)
      AND c.saldo_pendiente > 0
      AND (p_filtros->>'cliente_id' IS NULL OR c.cliente_id = (p_filtros->>'cliente_id')::uuid)
  ) x;

  SELECT jsonb_build_object(
    'total_deuda', COALESCE(SUM(c.saldo_pendiente), 0),
    'por_vencer',  COALESCE(SUM(c.saldo_pendiente) FILTER (
                     WHERE c.fecha_vencimiento IS NULL OR c.fecha_vencimiento >= CURRENT_DATE), 0),
    'vencido',     COALESCE(SUM(c.saldo_pendiente) FILTER (
                     WHERE c.fecha_vencimiento < CURRENT_DATE), 0),
    'documentos',  count(*),
    'clientes',    count(DISTINCT c.cliente_id)
  ) INTO v_resumen
  FROM core.comprobantes c
  WHERE c.deleted_at IS NULL AND c.anulado_at IS NULL
    AND (v_global OR c.empresa_id = v_emp)
    AND c.saldo_pendiente > 0;

  RETURN jsonb_build_object('ok', true, 'data', v_data, 'meta', v_resumen);

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_dashboard_resumen(uuid, uuid, boolean, date, date); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_dashboard_resumen(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_desde date DEFAULT NULL::date, p_hasta date DEFAULT NULL::date) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_global BOOLEAN := internal.es_acceso_global(p_user_id, p_is_super_admin);
  v_emp    UUID    := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_desde  DATE    := COALESCE(p_desde, date_trunc('month', CURRENT_DATE)::date);
  v_hasta  DATE    := COALESCE(p_hasta, CURRENT_DATE);
  -- Mismo número de días hacia atrás, para comparar contra el periodo anterior
  v_dias   INT     := GREATEST((v_hasta - v_desde) + 1, 1);
  v_prev_d DATE    := v_desde - v_dias;
  v_prev_h DATE    := v_desde - 1;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'dashboard:ver');

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object(

    'periodo', jsonb_build_object('desde', v_desde, 'hasta', v_hasta, 'dias', v_dias),

    -- ---- Agenda de hoy ----
    'hoy', (
      SELECT jsonb_build_object(
        'citas',       count(*),
        'completadas', count(*) FILTER (WHERE c.estado = 'completada'),
        'en_espera',   count(*) FILTER (WHERE c.estado = 'en_espera'),
        'en_atencion', count(*) FILTER (WHERE c.estado = 'en_atencion'),
        'pendientes',  count(*) FILTER (WHERE c.estado IN ('programada','confirmada')),
        'urgencias',   count(*) FILTER (WHERE c.prioridad IN ('urgencia','emergencia')))
      FROM core.citas c
      WHERE (v_global OR c.empresa_id = v_emp) AND c.deleted_at IS NULL
        AND c.fecha_hora::date = CURRENT_DATE),

    -- ---- Ingresos del periodo, con comparativo ----
    'ingresos', (
      SELECT jsonb_build_object(
        'facturado', COALESCE(SUM(cp.total), 0),
        'cobrado',   COALESCE(SUM(cp.total - cp.saldo_pendiente), 0),
        'pendiente', COALESCE(SUM(cp.saldo_pendiente), 0),
        'documentos', count(*),
        'ticket_promedio', CASE WHEN count(*) > 0
                           THEN round(COALESCE(SUM(cp.total),0) / count(*), 2) ELSE 0 END)
      FROM core.comprobantes cp
      WHERE (v_global OR cp.empresa_id = v_emp)
        AND cp.deleted_at IS NULL AND cp.anulado_at IS NULL
        AND cp.fecha_emision::date BETWEEN v_desde AND v_hasta),

    'ingresos_periodo_anterior', (
      SELECT COALESCE(SUM(cp.total), 0)
      FROM core.comprobantes cp
      WHERE (v_global OR cp.empresa_id = v_emp)
        AND cp.deleted_at IS NULL AND cp.anulado_at IS NULL
        AND cp.fecha_emision::date BETWEEN v_prev_d AND v_prev_h),

    -- ---- Actividad clínica ----
    'clinico', (
      SELECT jsonb_build_object(
        'consultas',   (SELECT count(*) FROM core.consultas co
                         WHERE (v_global OR co.empresa_id = v_emp) AND co.deleted_at IS NULL
                           AND co.fecha::date BETWEEN v_desde AND v_hasta),
        'cirugias',    (SELECT count(*) FROM core.cirugias ci
                         WHERE (v_global OR ci.empresa_id = v_emp) AND ci.estado = 'realizada'
                           AND ci.fecha_inicio::date BETWEEN v_desde AND v_hasta),
        'vacunas',     (SELECT count(*) FROM core.vacunas v
                         WHERE (v_global OR v.empresa_id = v_emp)
                           AND v.fecha_aplicacion BETWEEN v_desde AND v_hasta),
        'hospitalizados', (SELECT count(*) FROM core.hospitalizaciones h
                            WHERE (v_global OR h.empresa_id = v_emp)
                              AND h.estado IN ('ingresado','en_observacion')))),

    -- ---- Pacientes y clientes ----
    'pacientes', (
      SELECT jsonb_build_object(
        'total_activos', (SELECT count(*) FROM core.mascotas m
                           WHERE m.deleted_at IS NULL AND m.estado = 'activo'
                             AND (v_global OR m.empresa_id = v_emp)),
        'nuevos',        (SELECT count(*) FROM core.mascotas m
                           WHERE m.deleted_at IS NULL
                             AND (v_global OR m.empresa_id = v_emp)
                             AND m.created_at::date BETWEEN v_desde AND v_hasta),
        'clientes_activos', (SELECT count(*) FROM core.clientes c
                              WHERE c.deleted_at IS NULL AND c.estado = 'activo'
                                AND (v_global OR c.empresa_id = v_emp)),
        'clientes_nuevos',  (SELECT count(*) FROM core.clientes c
                              WHERE c.deleted_at IS NULL
                                AND (v_global OR c.empresa_id = v_emp)
                                AND c.created_at::date BETWEEN v_desde AND v_hasta))),

    -- ---- Alertas que exigen acción ----
    'alertas', jsonb_build_object(
      'stock_critico', (SELECT count(*) FROM core.productos p
                         WHERE p.empresa_id = v_emp AND p.deleted_at IS NULL
                           AND p.estado = 'activo' AND p.stock_actual <= p.stock_minimo),
      'por_vencer',    (SELECT count(*) FROM core.lotes l
                         WHERE l.empresa_id = v_emp AND l.cantidad > 0
                           AND l.fecha_vencimiento BETWEEN CURRENT_DATE AND CURRENT_DATE + 90),
      'refuerzos_pendientes', (SELECT count(*) FROM core.vacunas v
                                WHERE (v_global OR v.empresa_id = v_emp)
                                  AND v.proximo_refuerzo BETWEEN CURRENT_DATE AND CURRENT_DATE + 30),
      'deuda_vencida', (SELECT COALESCE(SUM(cp.saldo_pendiente), 0) FROM core.comprobantes cp
                         WHERE (v_global OR cp.empresa_id = v_emp)
                           AND cp.deleted_at IS NULL AND cp.anulado_at IS NULL
                           AND cp.saldo_pendiente > 0 AND cp.fecha_vencimiento < CURRENT_DATE),
      'permisos_pendientes', (SELECT count(*) FROM core.permisos_laborales pl
                               WHERE pl.empresa_id = v_emp AND pl.estado = 'pendiente')),

    -- ---- Serie diaria para el gráfico ----
    'serie_diaria', (
      SELECT COALESCE(jsonb_agg(jsonb_build_object(
        'fecha', d::date,
        'citas', (SELECT count(*) FROM core.citas c
                   WHERE (v_global OR c.empresa_id = v_emp) AND c.deleted_at IS NULL
                     AND c.fecha_hora::date = d::date),
        'ingresos', (SELECT COALESCE(SUM(cp.total), 0) FROM core.comprobantes cp
                      WHERE (v_global OR cp.empresa_id = v_emp)
                        AND cp.deleted_at IS NULL AND cp.anulado_at IS NULL
                        AND cp.fecha_emision::date = d::date)
      ) ORDER BY d), '[]'::jsonb)
      FROM generate_series(v_desde, v_hasta, '1 day'::interval) d),

    -- ---- Top servicios del periodo ----
    'top_servicios', (
      SELECT COALESCE(jsonb_agg(t), '[]'::jsonb) FROM (
        SELECT s.nombre, s.tipo, count(*) AS veces,
               COALESCE(SUM(os.total), 0) AS ingresos
        FROM core.ordenes_servicio os
        JOIN core.servicios s ON s.id = os.servicio_id
        WHERE (v_global OR os.empresa_id = v_emp)
          AND os.fecha::date BETWEEN v_desde AND v_hasta
          AND os.estado <> 'anulado'
        GROUP BY s.nombre, s.tipo
        ORDER BY ingresos DESC
        LIMIT 8) t),

    -- ---- Distribución por especie ----
    'por_especie', (
      SELECT COALESCE(jsonb_agg(t), '[]'::jsonb) FROM (
        SELECT e.nombre AS especie, e.icono, count(*) AS pacientes
        FROM core.mascotas m
        JOIN core.especies e ON e.id = m.especie_id
        WHERE m.deleted_at IS NULL AND m.estado = 'activo'
          AND (v_global OR m.empresa_id = v_emp)
        GROUP BY e.nombre, e.icono
        ORDER BY pacientes DESC) t)
  ));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_disponibilidad_listar(uuid, uuid, boolean, date, date, uuid); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_disponibilidad_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_desde date, p_hasta date, p_target_user_id uuid DEFAULT NULL::uuid) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_emp  UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_data JSONB;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'citas:listar');

  SELECT COALESCE(jsonb_agg(x ORDER BY x.fecha, x.hora_inicio), '[]'::jsonb) INTO v_data
  FROM (
    SELECT d.id, d.fecha, d.hora_inicio, d.hora_fin, d.tipo, d.nota,
           d.user_id, trim(u.nombres || ' ' || COALESCE(u.apellido_paterno,'')) AS profesional,
           u.color_agenda, u.es_veterinario,
           co.nombre AS consultorio
    FROM core.disponibilidad d
    JOIN core.users u ON u.id = d.user_id
    LEFT JOIN core.consultorios co ON co.id = d.consultorio_id
    WHERE d.empresa_id = v_emp
      AND d.fecha BETWEEN p_desde AND p_hasta
      AND (p_target_user_id IS NULL OR d.user_id = p_target_user_id)
  ) x;

  RETURN jsonb_build_object('ok', true, 'data', v_data);

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_doc_alta_hospitalaria(uuid, uuid, boolean, uuid); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_doc_alta_hospitalaria(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_hospitalizacion_id uuid) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_emp  UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_h    RECORD;
  v_evo  JSONB;
  v_med  JSONB;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'clinico:ver');

  SELECT h.* INTO v_h FROM core.hospitalizaciones h
   WHERE h.id = p_hospitalizacion_id
     AND internal.es_de_empresa(p_user_id, p_is_super_admin, v_emp, h.empresa_id);
  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Hospitalización no encontrada'));
  END IF;

  SELECT COALESCE(jsonb_agg(jsonb_build_object(
           'fecha_hora', e.fecha_hora,
           'temperatura_c', e.temperatura_c,
           'frecuencia_cardiaca', e.frecuencia_cardiaca,
           'frecuencia_respiratoria', e.frecuencia_respiratoria,
           'come', e.come, 'orina', e.orina, 'defeca', e.defeca,
           'nota', e.nota,
           'registrado_por', trim(u.nombres || ' ' || COALESCE(u.apellido_paterno,'')))
           ORDER BY e.fecha_hora), '[]'::jsonb) INTO v_evo
    FROM core.hospitalizacion_evoluciones e
    LEFT JOIN core.users u ON u.id = e.user_id
   WHERE e.hospitalizacion_id = p_hospitalizacion_id;

  -- Lo que se le administró durante el internamiento.
  SELECT COALESCE(jsonb_agg(jsonb_build_object(
           'producto', pr.nombre, 'cantidad', iu.cantidad, 'fecha', iu.fecha)
           ORDER BY iu.fecha), '[]'::jsonb) INTO v_med
    FROM core.insumos_utilizados iu
    JOIN core.productos pr ON pr.id = iu.producto_id
   WHERE iu.hospitalizacion_id = p_hospitalizacion_id;

  RETURN jsonb_build_object('ok', true, 'data',
    internal.ficha_paciente(v_h.mascota_id) || jsonb_build_object(
      'tipo_documento', 'alta_hospitalaria',
      'emisor',      internal.membrete_empresa(v_h.empresa_id),
      'profesional', internal.firma_profesional(v_h.veterinario_id),
      'hospitalizacion', jsonb_build_object(
        'id', v_h.id, 'codigo', v_h.codigo, 'jaula', v_h.jaula,
        'motivo', v_h.motivo, 'diagnostico', v_h.diagnostico,
        'fecha_ingreso', v_h.fecha_ingreso, 'fecha_alta', v_h.fecha_alta,
        'indicaciones_alta', v_h.indicaciones_alta,
        'estado', v_h.estado,
        'dias', GREATEST(1, CEIL(EXTRACT(EPOCH FROM (
                  COALESCE(v_h.fecha_alta, now()) - v_h.fecha_ingreso)) / 86400.0)::int)),
      'evoluciones', v_evo,
      'medicacion', v_med));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_doc_carne_vacunacion(uuid, uuid, boolean, uuid); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_doc_carne_vacunacion(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_mascota_id uuid) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_global BOOLEAN := internal.es_acceso_global(p_user_id, p_is_super_admin);
  v_emp    UUID    := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_m      RECORD;
  v_vac    JSONB;
  v_desp   JSONB;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'clinico:ver');

  SELECT m.* INTO v_m FROM core.mascotas m
   WHERE m.id = p_mascota_id AND m.deleted_at IS NULL
     AND (v_global OR m.empresa_id = v_emp);
  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Paciente no encontrado'));
  END IF;

  SELECT COALESCE(jsonb_agg(jsonb_build_object(
           'nombre_vacuna',    v.nombre_vacuna,
           'laboratorio',      v.laboratorio,
           'lote',             v.lote,
           'fecha_aplicacion', v.fecha_aplicacion,
           'dosis_numero',     v.dosis_numero,
           'proximo_refuerzo', v.proximo_refuerzo,
           'via',              v.via,
           'veterinario',      trim(u.nombres || ' ' || COALESCE(u.apellido_paterno,'')),
           'colegiatura',      u.colegiatura,
           -- Se compara sin tildes: la vacuna se registra como "Antirrábica",
           -- "antirrabica" o "Rabia" según quién la cargue.
           'antirrabica',      internal.normalizar(v.nombre_vacuna) LIKE '%rabi%',
           'situacion', CASE
             WHEN v.proximo_refuerzo IS NULL             THEN 'sin_refuerzo'
             WHEN v.proximo_refuerzo < CURRENT_DATE      THEN 'vencida'
             WHEN v.proximo_refuerzo <= CURRENT_DATE + 30 THEN 'por_vencer'
             ELSE 'vigente' END)
           ORDER BY v.fecha_aplicacion DESC), '[]'::jsonb) INTO v_vac
    FROM core.vacunas v
    LEFT JOIN core.users u ON u.id = v.veterinario_id
   WHERE v.mascota_id = p_mascota_id
     AND (v_global OR v.empresa_id = v_emp);

  -- El carné peruano lleva también la desparasitación: es lo que se revisa
  -- junto con la vacuna en cualquier control.
  SELECT COALESCE(jsonb_agg(jsonb_build_object(
           'producto',         d.producto_nombre,
           'tipo',             d.tipo,
           'dosis',            d.dosis,
           'fecha_aplicacion', d.fecha_aplicacion,
           'proxima_dosis',    d.proxima_dosis)
           ORDER BY d.fecha_aplicacion DESC), '[]'::jsonb) INTO v_desp
    FROM core.desparasitaciones d
   WHERE d.mascota_id = p_mascota_id
     AND (v_global OR d.empresa_id = v_emp);

  RETURN jsonb_build_object('ok', true, 'data',
    internal.ficha_paciente(p_mascota_id) || jsonb_build_object(
      'tipo_documento', 'carne_vacunacion',
      'emisor', internal.membrete_empresa(v_m.empresa_id),
      'vacunas', v_vac,
      'desparasitaciones', v_desp,
      'antirrabica_vigente', EXISTS (
        SELECT 1 FROM jsonb_array_elements(v_vac) v
         WHERE (v->>'antirrabica')::boolean
           AND (v->>'situacion') IN ('vigente','por_vencer','sin_refuerzo'))));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_doc_certificado_salud(uuid, uuid, boolean, uuid, jsonb); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_doc_certificado_salud(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_mascota_id uuid, p_payload jsonb DEFAULT '{}'::jsonb) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_global   BOOLEAN := internal.es_acceso_global(p_user_id, p_is_super_admin);
  v_emp      UUID    := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_m        RECORD;
  v_rabia    RECORD;
  v_desp     RECORD;
  v_consulta RECORD;
  -- El literal se castea al concatenar: sin el ::text, Postgres resuelve
  -- `anyarray || anyarray` e intenta leer la frase como un array.
  v_faltas   TEXT[] := ARRAY[]::TEXT[];
  v_firma    JSONB;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'clinico:ver');

  SELECT m.* INTO v_m FROM core.mascotas m
   WHERE m.id = p_mascota_id AND m.deleted_at IS NULL
     AND (v_global OR m.empresa_id = v_emp);
  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Paciente no encontrado'));
  END IF;

  -- Quien firma es el veterinario indicado, o el usuario si es veterinario.
  v_firma := internal.firma_profesional(
    COALESCE(NULLIF(p_payload->>'veterinario_id','')::uuid, p_user_id));

  IF NOT COALESCE((v_firma->>'es_veterinario')::boolean, false)
     OR COALESCE(v_firma->>'colegiatura','') = '' THEN
    v_faltas := v_faltas || 'El certificado lo firma un médico veterinario colegiado'::text;
  END IF;

  SELECT v.* INTO v_rabia FROM core.vacunas v
   WHERE v.mascota_id = p_mascota_id
     AND internal.normalizar(v.nombre_vacuna) LIKE '%rabi%'
     AND (v_global OR v.empresa_id = v_emp)
   ORDER BY v.fecha_aplicacion DESC LIMIT 1;

  IF v_rabia.id IS NULL THEN
    v_faltas := v_faltas || 'No hay vacunación antirrábica registrada'::text;
  ELSIF v_rabia.proximo_refuerzo IS NOT NULL AND v_rabia.proximo_refuerzo < CURRENT_DATE THEN
    v_faltas := v_faltas || 'La vacunación antirrábica está vencida'::text;
  END IF;

  SELECT d.* INTO v_desp FROM core.desparasitaciones d
   WHERE d.mascota_id = p_mascota_id
     AND (v_global OR d.empresa_id = v_emp)
   ORDER BY d.fecha_aplicacion DESC LIMIT 1;

  IF v_desp.id IS NULL THEN
    v_faltas := v_faltas || 'No hay desparasitación registrada'::text;
  ELSIF v_desp.fecha_aplicacion < CURRENT_DATE - 180 THEN
    v_faltas := v_faltas || 'La última desparasitación tiene más de 6 meses'::text;
  END IF;

  -- El examen clínico que sustenta el certificado: la última consulta cerrada.
  SELECT c.* INTO v_consulta FROM core.consultas c
   WHERE c.mascota_id = p_mascota_id AND c.estado = 'cerrada' AND c.deleted_at IS NULL
     AND (v_global OR c.empresa_id = v_emp)
   ORDER BY c.fecha DESC LIMIT 1;

  IF v_consulta.id IS NULL THEN
    v_faltas := v_faltas || 'No hay un examen clínico cerrado que sustente el certificado'::text;
  ELSIF v_consulta.fecha < now() - INTERVAL '10 days' THEN
    v_faltas := v_faltas || 'El último examen clínico tiene más de 10 días'::text;
  END IF;

  RETURN jsonb_build_object('ok', true, 'data',
    internal.ficha_paciente(p_mascota_id) || jsonb_build_object(
      'tipo_documento', 'certificado_salud',
      'emisor',      internal.membrete_empresa(v_m.empresa_id),
      'profesional', v_firma,
      'fecha_emision', CURRENT_DATE,
      'motivo',  COALESCE(NULLIF(p_payload->>'motivo',''), 'Viaje'),
      'destino', NULLIF(p_payload->>'destino',''),
      'antirrabica', CASE WHEN v_rabia.id IS NOT NULL THEN jsonb_build_object(
        'nombre_vacuna', v_rabia.nombre_vacuna, 'laboratorio', v_rabia.laboratorio,
        'lote', v_rabia.lote, 'fecha_aplicacion', v_rabia.fecha_aplicacion,
        'proximo_refuerzo', v_rabia.proximo_refuerzo) END,
      'desparasitacion', CASE WHEN v_desp.id IS NOT NULL THEN jsonb_build_object(
        'producto', v_desp.producto_nombre, 'tipo', v_desp.tipo,
        'fecha_aplicacion', v_desp.fecha_aplicacion) END,
      'examen_clinico', CASE WHEN v_consulta.id IS NOT NULL THEN jsonb_build_object(
        'fecha', v_consulta.fecha, 'peso_kg', v_consulta.peso_kg,
        'temperatura_c', v_consulta.temperatura_c,
        'examen_fisico', v_consulta.examen_fisico,
        'diagnostico', v_consulta.diagnostico) END,
      -- Lo que impide que el certificado sirva. El documento se devuelve igual
      -- —el veterinario decide—, pero la pantalla lo advierte antes de imprimir.
      'observaciones_previas', to_jsonb(v_faltas),
      'apto', array_length(v_faltas, 1) IS NULL));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_doc_consentimiento(uuid, uuid, boolean, uuid); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_doc_consentimiento(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_cirugia_id uuid) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_emp UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_cir RECORD;
  v_cla JSONB;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'clinico:ver');

  SELECT c.*, s.nombre AS servicio, s.precio AS servicio_precio
    INTO v_cir
    FROM core.cirugias c
    LEFT JOIN core.servicios s ON s.id = c.servicio_id
   WHERE c.id = p_cirugia_id
     AND internal.es_de_empresa(p_user_id, p_is_super_admin, v_emp, c.empresa_id);
  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Cirugía no encontrada'));
  END IF;

  SELECT COALESCE(jsonb_agg(jsonb_build_object(
           'titulo', cl.titulo, 'contenido', cl.contenido) ORDER BY cl.orden), '[]'::jsonb)
    INTO v_cla
    FROM core.clausulas cl
   WHERE cl.empresa_id = v_cir.empresa_id
     AND cl.tipo = 'consentimiento' AND cl.estado = 'activo';

  RETURN jsonb_build_object('ok', true, 'data',
    internal.ficha_paciente(v_cir.mascota_id) || jsonb_build_object(
      'tipo_documento', 'consentimiento',
      'emisor',      internal.membrete_empresa(v_cir.empresa_id),
      'profesional', internal.firma_profesional(v_cir.cirujano_id),
      'anestesista', internal.firma_profesional(v_cir.anestesista_id),
      'cirugia', jsonb_build_object(
        'id', v_cir.id, 'codigo', v_cir.codigo, 'nombre', v_cir.nombre,
        'descripcion', v_cir.descripcion,
        'fecha_programada', v_cir.fecha_programada,
        'anestesia_tipo', v_cir.anestesia_tipo,
        'servicio', v_cir.servicio,
        'precio_referencial', v_cir.servicio_precio,
        'estado', v_cir.estado,
        'consentimiento_firmado', v_cir.consentimiento_firmado),
      'clausulas', v_cla));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_doc_historia_clinica(uuid, uuid, boolean, uuid); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_doc_historia_clinica(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_mascota_id uuid) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_global BOOLEAN := internal.es_acceso_global(p_user_id, p_is_super_admin);
  v_emp    UUID    := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_m      RECORD;
  v_cons   JSONB;
  v_linea  JSONB;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'clinico:ver');

  SELECT m.* INTO v_m FROM core.mascotas m
   WHERE m.id = p_mascota_id AND m.deleted_at IS NULL
     AND (v_global OR m.empresa_id = v_emp);
  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Paciente no encontrado'));
  END IF;

  -- Sólo las consultas cerradas: un borrador no es un documento clínico.
  SELECT COALESCE(jsonb_agg(jsonb_build_object(
           'codigo', c.codigo, 'fecha', c.fecha, 'motivo', c.motivo,
           'anamnesis', c.anamnesis, 'peso_kg', c.peso_kg,
           'temperatura_c', c.temperatura_c,
           'frecuencia_cardiaca', c.frecuencia_cardiaca,
           'frecuencia_respiratoria', c.frecuencia_respiratoria,
           'mucosas', c.mucosas, 'condicion_corporal', c.condicion_corporal,
           'examen_fisico', c.examen_fisico,
           'diagnostico', c.diagnostico,
           'diagnostico_diferencial', c.diagnostico_diferencial,
           'pronostico', c.pronostico,
           'plan_terapeutico', c.plan_terapeutico,
           'prescripcion', c.prescripcion,
           'indicaciones_casa', c.indicaciones_casa,
           'veterinario', trim(u.nombres || ' ' || COALESCE(u.apellido_paterno,'')),
           'colegiatura', u.colegiatura)
           ORDER BY c.fecha DESC), '[]'::jsonb) INTO v_cons
    FROM core.consultas c
    LEFT JOIN core.users u ON u.id = c.veterinario_id
   WHERE c.mascota_id = p_mascota_id AND c.deleted_at IS NULL AND c.estado = 'cerrada'
     AND (v_global OR c.empresa_id = v_emp);

  SELECT COALESCE(jsonb_agg(jsonb_build_object(
           'fecha', h.fecha, 'tipo_evento', h.tipo_evento,
           'titulo', h.titulo, 'resumen', h.resumen)
           ORDER BY h.fecha DESC), '[]'::jsonb) INTO v_linea
    FROM core.historia_clinica h
   WHERE h.mascota_id = p_mascota_id
     AND (v_global OR h.empresa_id = v_emp);

  RETURN jsonb_build_object('ok', true, 'data',
    internal.ficha_paciente(p_mascota_id) || jsonb_build_object(
      'tipo_documento', 'historia_clinica',
      'emisor', internal.membrete_empresa(v_m.empresa_id),
      'fecha_emision', CURRENT_DATE,
      'consultas', v_cons,
      'linea_tiempo', v_linea,
      'vacunas', (app.fn_doc_carne_vacunacion(
                    p_user_id, p_empresa_id, p_is_super_admin, p_mascota_id)->'data'->'vacunas')));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_doc_receta(uuid, uuid, boolean, uuid); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_doc_receta(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_consulta_id uuid) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_emp UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_c   RECORD;
  v_med JSONB;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'clinico:ver');

  SELECT c.* INTO v_c FROM core.consultas c
   WHERE c.id = p_consulta_id AND c.deleted_at IS NULL
     AND internal.es_de_empresa(p_user_id, p_is_super_admin, v_emp, c.empresa_id);
  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Consulta no encontrada'));
  END IF;

  SELECT COALESCE(jsonb_agg(jsonb_build_object(
           'medicamento',      t.medicamento,
           'principio_activo', COALESCE(t.principio_activo, pr.principio_activo),
           'presentacion',     pr.presentacion,
           'dosis',            t.dosis,
           'via',              t.via,
           'frecuencia_horas', t.frecuencia_horas,
           'duracion_dias',    t.duracion_dias,
           'indicaciones',     t.indicaciones,
           'requiere_receta',  COALESCE(pr.requiere_receta, false),
           'controlado',       COALESCE(pr.controlado, false))
           ORDER BY t.created_at), '[]'::jsonb) INTO v_med
    FROM core.tratamientos t
    LEFT JOIN core.productos pr ON pr.id = t.producto_id
   WHERE t.consulta_id = p_consulta_id;

  RETURN jsonb_build_object('ok', true, 'data',
    internal.ficha_paciente(v_c.mascota_id) || jsonb_build_object(
      'tipo_documento', 'receta',
      'emisor',      internal.membrete_empresa(v_c.empresa_id),
      'profesional', internal.firma_profesional(v_c.veterinario_id),
      'consulta', jsonb_build_object(
        'id', v_c.id, 'codigo', v_c.codigo, 'fecha', v_c.fecha,
        'motivo', v_c.motivo, 'diagnostico', v_c.diagnostico,
        'peso_kg', v_c.peso_kg,
        'prescripcion', v_c.prescripcion,
        'indicaciones_casa', v_c.indicaciones_casa,
        'proxima_visita', v_c.proxima_visita,
        'cerrada', v_c.estado = 'cerrada'),
      'medicamentos', v_med,
      -- Si hay algo controlado, el papel tiene que decirlo: cambia cómo se
      -- despacha y cómo se archiva.
      'tiene_controlados', EXISTS (
        SELECT 1 FROM jsonb_array_elements(v_med) m WHERE (m->>'controlado')::boolean)));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_documentos_medicos_listar(uuid, uuid, boolean, uuid); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_documentos_medicos_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_mascota_id uuid) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_global BOOLEAN := internal.es_acceso_global(p_user_id, p_is_super_admin);
  v_emp    UUID    := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_data   JSONB;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'clinico:ver');

  IF NOT EXISTS (SELECT 1 FROM core.mascotas
                  WHERE id = p_mascota_id AND deleted_at IS NULL
                    AND (v_global OR empresa_id = v_emp)) THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Paciente no encontrado'));
  END IF;

  SELECT COALESCE(jsonb_agg(x ORDER BY x.created_at DESC), '[]'::jsonb) INTO v_data
  FROM (
    SELECT d.id, d.tipo, d.titulo, d.descripcion, d.storage_key, d.mime_type,
           d.tamanio_bytes, d.created_at,
           trim(u.nombres || ' ' || COALESCE(u.apellido_paterno,'')) AS subido_por
    FROM core.documentos_medicos d
    LEFT JOIN core.users u ON u.id = d.created_by
    WHERE d.mascota_id = p_mascota_id
      AND (v_global OR d.empresa_id = v_emp)
  ) x;

  RETURN jsonb_build_object('ok', true, 'data', v_data);

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_empresa_listar(uuid, uuid, boolean, jsonb); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_empresa_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_filtros jsonb DEFAULT '{}'::jsonb) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_global BOOLEAN := internal.es_acceso_global(p_user_id, p_is_super_admin);
  v_emp    UUID    := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_buscar TEXT    := internal.normalizar(p_filtros->>'buscar');
  v_data   JSONB;
BEGIN
  SELECT COALESCE(jsonb_agg(x ORDER BY x.razon_social), '[]'::jsonb) INTO v_data
  FROM (
    SELECT e.id, e.ruc, e.razon_social, e.nombre_comercial, e.direccion_fiscal,
           e.telefono, e.correo, e.logo_url, e.estado,
           e.serie_factura_default, e.serie_boleta_default, e.igv_tasa,
           e.aforo_consultorios, e.duracion_cita_min, e.created_at,
           (SELECT count(*) FROM core.users u
             WHERE u.empresa_id = e.id AND u.deleted_at IS NULL) AS total_personal,
           (SELECT count(*) FROM core.citas c
             WHERE c.empresa_id = e.id AND c.deleted_at IS NULL
               AND c.fecha_hora::date = CURRENT_DATE) AS citas_hoy
    FROM core.empresas e
    WHERE e.deleted_at IS NULL
      AND (v_global OR e.id = v_emp)
      AND (p_filtros->>'estado' IS NULL OR e.estado::text = p_filtros->>'estado')
      AND (v_buscar IS NULL OR v_buscar = '' OR
           internal.normalizar(e.razon_social) LIKE '%' || v_buscar || '%' OR
           e.ruc LIKE '%' || v_buscar || '%')
  ) x;

  RETURN jsonb_build_object('ok', true, 'data', v_data);

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_empresa_obtener(uuid, uuid, boolean, uuid); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_empresa_obtener(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid DEFAULT NULL::uuid) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_target UUID := COALESCE(p_id, internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin));
  v_data   JSONB;
BEGIN
  PERFORM internal.assert_acceso_empresa(p_user_id, v_target, p_is_super_admin);

  SELECT to_jsonb(e) - 'pse_password_enc' INTO v_data
  FROM core.empresas e WHERE e.id = v_target AND e.deleted_at IS NULL;

  -- La clave del PSE ya no sale nunca; el usuario y el endpoint tampoco tienen
  -- por qué verlos recepción ni el almacén: es media credencial, y con ella el
  -- proveedor solo pide la otra mitad.
  IF v_data IS NOT NULL
     AND NOT internal.tiene_permiso(p_user_id, 'empresa:configurar') THEN
    v_data := v_data - 'pse_usuario' - 'pse_endpoint';
  END IF;

  IF v_data IS NULL THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Empresa no encontrada'));
  END IF;

  RETURN jsonb_build_object('ok', true, 'data', v_data);

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_empresa_pse_config(uuid, uuid, boolean, uuid); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_empresa_pse_config(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_empresa_target uuid DEFAULT NULL::uuid) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_target UUID := COALESCE(p_empresa_target,
                            internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin));
  v_data   JSONB;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'facturacion:emitir');

  IF v_target IS NULL THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('VALIDATION_ERROR','No hay empresa objetivo'));
  END IF;

  -- Un administrador de empresa no puede leer las credenciales de otra.
  IF NOT internal.es_acceso_global(p_user_id, p_is_super_admin)
     AND v_target <> internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin) THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Empresa no encontrada'));
  END IF;

  SELECT jsonb_build_object(
    'empresa_id',        e.id,
    'ruc',               e.ruc,
    'ruc_pse',           COALESCE(NULLIF(e.pse_ruc,''), e.ruc),
    'razon_social',      e.razon_social,
    'nombre_comercial',  e.nombre_comercial,
    'direccion_fiscal',  e.direccion_fiscal,
    'ubigeo',            e.ubigeo,
    'urbanizacion',      e.urbanizacion,
    'distrito',          e.distrito,
    'provincia',         e.provincia,
    'departamento',      e.departamento,
    'endpoint',          e.pse_endpoint,
    'usuario',           e.pse_usuario,
    'password_enc',      e.pse_password_enc,
    'proveedor',         e.pse_proveedor,
    'emite_electronico', e.emite_electronico
  ) INTO v_data
  FROM core.empresas e WHERE e.id = v_target AND e.deleted_at IS NULL;

  IF v_data IS NULL THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Empresa no encontrada'));
  END IF;

  RETURN jsonb_build_object('ok', true, 'data', v_data);

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_equipo_resumen(uuid, uuid, boolean, date, date); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_equipo_resumen(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_desde date DEFAULT NULL::date, p_hasta date DEFAULT NULL::date) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_emp   UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_desde DATE := COALESCE(p_desde, date_trunc('month', CURRENT_DATE)::date);
  v_hasta DATE := COALESCE(p_hasta, CURRENT_DATE);
  v_data  JSONB;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'rrhh:ver');

  SELECT COALESCE(jsonb_agg(x ORDER BY x.profesional), '[]'::jsonb) INTO v_data
  FROM (
    SELECT u.id AS user_id,
           trim(u.nombres || ' ' || COALESCE(u.apellido_paterno,'')) AS profesional,
           u.foto_url, u.es_veterinario, u.colegiatura, u.color_agenda, u.estado,
           r.nombre AS rol, esp.nombre AS especializacion,
           (SELECT jsonb_build_object('tipo', cp.tipo, 'cargo', cp.cargo,
                                      'fecha_inicio', cp.fecha_inicio, 'fecha_fin', cp.fecha_fin)
              FROM core.contratos_personal cp
             WHERE cp.user_id = u.id AND cp.vigente = true LIMIT 1) AS contrato,
           (SELECT count(*) FROM core.citas c
             WHERE c.veterinario_id = u.id AND c.deleted_at IS NULL
               AND c.fecha_hora::date BETWEEN v_desde AND v_hasta
               AND c.estado = 'completada') AS citas_atendidas,
           (SELECT count(*) FROM core.consultas co
             WHERE co.veterinario_id = u.id AND co.deleted_at IS NULL
               AND co.fecha::date BETWEEN v_desde AND v_hasta) AS consultas,
           (SELECT count(*) FROM core.cirugias ci
             WHERE ci.cirujano_id = u.id AND ci.estado = 'realizada'
               AND ci.fecha_inicio::date BETWEEN v_desde AND v_hasta) AS cirugias,
           (SELECT COALESCE(SUM(a.horas_trabajadas), 0) FROM core.asistencia a
             WHERE a.user_id = u.id AND a.fecha BETWEEN v_desde AND v_hasta) AS horas_trabajadas,
           (SELECT count(*) FROM core.asistencia a
             WHERE a.user_id = u.id AND a.fecha BETWEEN v_desde AND v_hasta
               AND a.estado = 'tardanza') AS tardanzas,
           (SELECT round(avg(ev.promedio), 2) FROM core.evaluaciones_personal ev
             WHERE ev.user_id = u.id) AS evaluacion_promedio
    FROM core.users u
    LEFT JOIN core.roles r ON r.id = u.rol_id
    LEFT JOIN core.especializaciones esp ON esp.id = u.especializacion_id
    WHERE u.empresa_id = v_emp AND u.deleted_at IS NULL
  ) x;

  RETURN jsonb_build_object('ok', true, 'data', v_data,
    'meta', jsonb_build_object('desde', v_desde, 'hasta', v_hasta));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_especializaciones_listar(uuid, uuid, boolean); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_especializaciones_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_global BOOLEAN := internal.es_acceso_global(p_user_id, p_is_super_admin);
  v_emp    UUID    := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_data   JSONB;
BEGIN
  SELECT COALESCE(jsonb_agg(x ORDER BY x.nombre), '[]'::jsonb) INTO v_data
  FROM (
    SELECT e.id, e.codigo, e.nombre, e.descripcion, e.estado,
           (SELECT count(*) FROM core.users u
             WHERE u.especializacion_id = e.id AND u.deleted_at IS NULL
               AND (v_global OR u.empresa_id = v_emp)) AS veterinarios
    FROM core.especializaciones e
  ) x;

  RETURN jsonb_build_object('ok', true, 'data', v_data);

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_especies_listar(uuid, uuid, boolean, boolean); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_especies_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_incluir_inactivos boolean DEFAULT false) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_global BOOLEAN := internal.es_acceso_global(p_user_id, p_is_super_admin);
  v_emp    UUID    := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_data   JSONB;
BEGIN
  SELECT COALESCE(jsonb_agg(x ORDER BY x.nombre), '[]'::jsonb) INTO v_data
  FROM (
    SELECT e.id, e.codigo, e.nombre, e.nombre_cria, e.icono, e.estado,
           -- El conteo es de la empresa que consulta, no de toda la instalación.
           (SELECT count(*) FROM core.mascotas m
             WHERE m.especie_id = e.id AND m.deleted_at IS NULL
               AND (v_global OR m.empresa_id = v_emp)) AS total_pacientes,
           -- Razas globales (empresa_id NULL) más las que agregó esta empresa.
           (SELECT COALESCE(jsonb_agg(jsonb_build_object(
                     'id', r.id, 'nombre', r.nombre, 'tamanio_referencia', r.tamanio_referencia,
                     'peso_min_kg', r.peso_min_kg, 'peso_max_kg', r.peso_max_kg,
                     'esperanza_vida', r.esperanza_vida, 'estado', r.estado,
                     'propia', r.empresa_id IS NOT NULL)
                   ORDER BY r.nombre), '[]'::jsonb)
              FROM core.razas r
             WHERE r.especie_id = e.id
               AND (r.empresa_id IS NULL OR v_global OR r.empresa_id = v_emp)
               AND (p_incluir_inactivos OR r.estado = 'activo')) AS razas
    FROM core.especies e
    WHERE (p_incluir_inactivos OR e.estado = 'activo')
  ) x;

  RETURN jsonb_build_object('ok', true, 'data', v_data);

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_esquemas_vacunacion_listar(uuid, uuid, boolean, uuid); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_esquemas_vacunacion_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_especie_id uuid DEFAULT NULL::uuid) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_emp  UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_data JSONB;
BEGIN
  SELECT COALESCE(jsonb_agg(x ORDER BY x.especie, x.nombre), '[]'::jsonb) INTO v_data
  FROM (
    SELECT ev.id, ev.nombre, ev.descripcion, ev.obligatoria, ev.edad_inicio_semanas,
           ev.intervalo_dias, ev.dosis_totales, ev.revacunacion_meses, ev.estado,
           ev.especie_id, e.nombre AS especie
    FROM core.esquemas_vacunacion ev
    JOIN core.especies e ON e.id = ev.especie_id
    WHERE ev.empresa_id = v_emp
      AND (p_especie_id IS NULL OR ev.especie_id = p_especie_id)
  ) x;

  RETURN jsonb_build_object('ok', true, 'data', v_data);

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_horarios_atencion_listar(uuid, uuid, boolean); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_horarios_atencion_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_emp  UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_data JSONB;
BEGIN
  SELECT COALESCE(jsonb_agg(to_jsonb(h) ORDER BY h.dia_semana, h.hora_inicio), '[]'::jsonb) INTO v_data
  FROM core.horarios_atencion h WHERE h.empresa_id = v_emp;

  RETURN jsonb_build_object('ok', true, 'data', v_data);

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_hospitalizaciones_listar(uuid, uuid, boolean, boolean); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_hospitalizaciones_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_solo_activas boolean DEFAULT true) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_global BOOLEAN := internal.es_acceso_global(p_user_id, p_is_super_admin);
  v_emp    UUID    := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_data   JSONB;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'clinico:ver');

  SELECT COALESCE(jsonb_agg(x ORDER BY x.fecha_ingreso DESC), '[]'::jsonb) INTO v_data
  FROM (
    SELECT h.id, h.codigo, h.jaula, h.motivo, h.diagnostico, h.estado,
           h.fecha_ingreso, h.fecha_alta, h.indicaciones_alta,
           EXTRACT(DAY FROM (COALESCE(h.fecha_alta, now()) - h.fecha_ingreso))::int AS dias_internado,
           h.mascota_id, m.nombre AS mascota, m.foto_url AS mascota_foto, m.peso_kg,
           esp.nombre AS especie,
           trim(cl.nombres || ' ' || COALESCE(cl.apellido_paterno,'')) AS cliente,
           cl.telefono AS cliente_telefono,
           trim(u.nombres || ' ' || COALESCE(u.apellido_paterno,'')) AS veterinario,
           (SELECT jsonb_build_object(
                     'fecha_hora', e.fecha_hora, 'temperatura_c', e.temperatura_c,
                     'nota', e.nota)
              FROM core.hospitalizacion_evoluciones e
             WHERE e.hospitalizacion_id = h.id
             ORDER BY e.fecha_hora DESC LIMIT 1) AS ultima_evolucion
    FROM core.hospitalizaciones h
    JOIN core.mascotas m ON m.id = h.mascota_id
    JOIN core.clientes cl ON cl.id = m.cliente_id
    JOIN core.especies esp ON esp.id = m.especie_id
    LEFT JOIN core.users u ON u.id = h.veterinario_id
    WHERE (v_global OR h.empresa_id = v_emp)
      AND (p_solo_activas = false OR h.estado IN ('ingresado','en_observacion'))
  ) x;

  RETURN jsonb_build_object('ok', true, 'data', v_data);

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_inventario_alertas(uuid, uuid, boolean); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_inventario_alertas(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_emp UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'inventario:ver');

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object(
    'stock_critico', (
      SELECT COALESCE(jsonb_agg(jsonb_build_object(
        'id', p.id, 'codigo', p.codigo, 'nombre', p.nombre,
        'stock_actual', p.stock_actual, 'stock_minimo', p.stock_minimo,
        'unidad_medida', p.unidad_medida, 'tipo', p.tipo
      ) ORDER BY p.stock_actual), '[]'::jsonb)
      FROM core.productos p
      WHERE p.empresa_id = v_emp AND p.deleted_at IS NULL AND p.estado = 'activo'
        AND p.stock_actual <= p.stock_minimo),
    'por_vencer', (
      SELECT COALESCE(jsonb_agg(jsonb_build_object(
        'lote_id', l.id, 'producto_id', p.id, 'producto', p.nombre,
        'numero_lote', l.numero_lote, 'fecha_vencimiento', l.fecha_vencimiento,
        'cantidad', l.cantidad,
        'dias_restantes', (l.fecha_vencimiento - CURRENT_DATE)
      ) ORDER BY l.fecha_vencimiento), '[]'::jsonb)
      FROM core.lotes l
      JOIN core.productos p ON p.id = l.producto_id
      WHERE l.empresa_id = v_emp AND l.cantidad > 0
        AND l.fecha_vencimiento IS NOT NULL
        AND l.fecha_vencimiento <= CURRENT_DATE + 90),
    'vencidos', (
      SELECT COALESCE(jsonb_agg(jsonb_build_object(
        'lote_id', l.id, 'producto', p.nombre, 'numero_lote', l.numero_lote,
        'fecha_vencimiento', l.fecha_vencimiento, 'cantidad', l.cantidad
      ) ORDER BY l.fecha_vencimiento), '[]'::jsonb)
      FROM core.lotes l
      JOIN core.productos p ON p.id = l.producto_id
      WHERE l.empresa_id = v_emp AND l.cantidad > 0
        AND l.fecha_vencimiento < CURRENT_DATE)
  ));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_lista_espera_listar(uuid, uuid, boolean, jsonb); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_lista_espera_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_filtros jsonb DEFAULT '{}'::jsonb) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_global BOOLEAN := internal.es_acceso_global(p_user_id, p_is_super_admin);
  v_emp    UUID    := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_fecha  DATE    := NULLIF(p_filtros->>'fecha','')::date;
  v_vet    UUID    := NULLIF(p_filtros->>'veterinario_id','')::uuid;
  v_data   JSONB;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'citas:listar');

  SELECT COALESCE(jsonb_agg(x ORDER BY x.created_at), '[]'::jsonb) INTO v_data
  FROM (
    SELECT le.id, le.desde, le.hasta, le.nota, le.created_at,
           le.mascota_id, m.nombre AS mascota, esp.nombre AS especie,
           le.cliente_id,
           trim(cl.nombres || ' ' || COALESCE(cl.apellido_paterno,'')) AS cliente,
           cl.telefono AS cliente_telefono,
           le.servicio_id, s.nombre AS servicio,
           le.veterinario_id,
           trim(u.nombres || ' ' || COALESCE(u.apellido_paterno,'')) AS veterinario,
           (CURRENT_DATE - le.created_at::date) AS dias_esperando
      FROM core.citas_lista_espera le
      JOIN core.mascotas m  ON m.id = le.mascota_id
      JOIN core.clientes cl ON cl.id = le.cliente_id
      JOIN core.especies esp ON esp.id = m.especie_id
      LEFT JOIN core.servicios s ON s.id = le.servicio_id
      LEFT JOIN core.users u ON u.id = le.veterinario_id
     WHERE le.atendido = false
       AND (v_global OR le.empresa_id = v_emp)
       -- Un cupo que se libera sólo le sirve a quien lo quería en esa fecha.
       AND (v_fecha IS NULL OR (v_fecha >= le.desde AND (le.hasta IS NULL OR v_fecha <= le.hasta)))
       AND (v_vet IS NULL OR le.veterinario_id IS NULL OR le.veterinario_id = v_vet)
  ) x;

  RETURN jsonb_build_object('ok', true, 'data', v_data);

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_mascota_historia(uuid, uuid, boolean, uuid, character varying, integer); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_mascota_historia(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_mascota_id uuid, p_tipo character varying DEFAULT NULL::character varying, p_limit integer DEFAULT 100) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_global BOOLEAN := internal.es_acceso_global(p_user_id, p_is_super_admin);
  v_emp    UUID    := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_data   JSONB;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'clinico:ver');

  -- Si el paciente no es de la empresa, se responde NOT_FOUND igual que en el
  -- resto del módulo. Devolver una lista vacía sugeriría que existe pero no
  -- tiene historia, que es otra cosa.
  IF NOT EXISTS (SELECT 1 FROM core.mascotas
                  WHERE id = p_mascota_id AND deleted_at IS NULL
                    AND (v_global OR empresa_id = v_emp)) THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Paciente no encontrado'));
  END IF;

  SELECT COALESCE(jsonb_agg(x ORDER BY x.fecha DESC), '[]'::jsonb) INTO v_data
  FROM (
    SELECT h.id, h.tipo_evento, h.fecha, h.titulo, h.resumen, h.entidad_id, h.cita_id,
           h.empresa_id, emp.nombre_comercial AS empresa,
           h.veterinario_id,
           trim(u.nombres || ' ' || COALESCE(u.apellido_paterno,'')) AS veterinario,
           u.colegiatura
    FROM core.historia_clinica h
    LEFT JOIN core.users u ON u.id = h.veterinario_id
    LEFT JOIN core.empresas emp ON emp.id = h.empresa_id
    WHERE h.mascota_id = p_mascota_id
      -- Cada empresa ve solo los eventos que registró: son negocios distintos.
      AND (v_global OR h.empresa_id = v_emp)
      AND (p_tipo IS NULL OR h.tipo_evento::text = p_tipo)
    ORDER BY h.fecha DESC
    LIMIT LEAST(COALESCE(p_limit, 100), 500)
  ) x;

  RETURN jsonb_build_object('ok', true, 'data', v_data);

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_mascota_listar(uuid, uuid, boolean, jsonb, integer, integer); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_mascota_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_filtros jsonb DEFAULT '{}'::jsonb, p_page integer DEFAULT 1, p_page_size integer DEFAULT 20) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_global  BOOLEAN := internal.es_acceso_global(p_user_id, p_is_super_admin);
  v_emp     UUID    := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_buscar  TEXT    := internal.normalizar(p_filtros->>'buscar');
  v_size    INT     := LEAST(GREATEST(COALESCE(p_page_size, 20), 1), 100);
  v_page    INT     := GREATEST(COALESCE(p_page, 1), 1);
  v_total   INT;
  v_data    JSONB;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'mascotas:listar');

  SELECT count(*) INTO v_total
  FROM core.mascotas m
  JOIN core.clientes c ON c.id = m.cliente_id
  WHERE m.deleted_at IS NULL
    AND (v_global OR m.empresa_id = v_emp)
    AND (p_filtros->>'estado'     IS NULL OR m.estado::text = p_filtros->>'estado')
    AND (p_filtros->>'especie_id' IS NULL OR m.especie_id = (p_filtros->>'especie_id')::uuid)
    AND (p_filtros->>'cliente_id' IS NULL OR m.cliente_id = (p_filtros->>'cliente_id')::uuid)
    AND (p_filtros->>'sexo'       IS NULL OR m.sexo::text = p_filtros->>'sexo')
    AND (v_buscar IS NULL OR v_buscar = '' OR
         internal.normalizar(m.nombre) LIKE '%' || v_buscar || '%' OR
         COALESCE(m.microchip,'') LIKE '%' || COALESCE(p_filtros->>'buscar','') || '%' OR
         COALESCE(m.codigo,'') LIKE '%' || upper(COALESCE(p_filtros->>'buscar','')) || '%' OR
         internal.normalizar(c.nombres || ' ' || COALESCE(c.apellido_paterno,''))
           LIKE '%' || v_buscar || '%');

  SELECT COALESCE(jsonb_agg(x), '[]'::jsonb) INTO v_data
  FROM (
    SELECT m.id, m.codigo, m.nombre, m.sexo, m.color, m.peso_kg, m.tamanio,
           m.fecha_nacimiento, m.esterilizado, m.microchip, m.foto_url,
           m.alergias, m.condiciones_cronicas, m.estado, m.created_at,
           internal.edad_mascota(m.fecha_nacimiento, m.edad_aproximada_meses) AS edad,
           m.especie_id, e.nombre AS especie, e.icono AS especie_icono,
           m.raza_id, r.nombre AS raza,
           m.cliente_id,
           trim(c.nombres || ' ' || COALESCE(c.apellido_paterno,'') || ' ' ||
                COALESCE(c.apellido_materno,'')) AS propietario,
           c.telefono AS propietario_telefono,
           (SELECT max(ci.fecha_hora) FROM core.citas ci
             WHERE ci.mascota_id = m.id AND ci.estado = 'completada'
               AND ci.deleted_at IS NULL
               AND (v_global OR ci.empresa_id = v_emp)) AS ultima_visita,
           (SELECT min(v.proximo_refuerzo) FROM core.vacunas v
             WHERE v.mascota_id = m.id AND v.proximo_refuerzo >= CURRENT_DATE) AS proxima_vacuna,
           (SELECT count(*) FROM core.consultas co
             WHERE co.mascota_id = m.id AND co.deleted_at IS NULL) AS total_consultas
    FROM core.mascotas m
    JOIN core.clientes c ON c.id = m.cliente_id
    JOIN core.especies e ON e.id = m.especie_id
    LEFT JOIN core.razas r ON r.id = m.raza_id
    WHERE m.deleted_at IS NULL
      AND (v_global OR m.empresa_id = v_emp)
      AND (p_filtros->>'estado'     IS NULL OR m.estado::text = p_filtros->>'estado')
      AND (p_filtros->>'especie_id' IS NULL OR m.especie_id = (p_filtros->>'especie_id')::uuid)
      AND (p_filtros->>'cliente_id' IS NULL OR m.cliente_id = (p_filtros->>'cliente_id')::uuid)
      AND (p_filtros->>'sexo'       IS NULL OR m.sexo::text = p_filtros->>'sexo')
      AND (v_buscar IS NULL OR v_buscar = '' OR
           internal.normalizar(m.nombre) LIKE '%' || v_buscar || '%' OR
           COALESCE(m.microchip,'') LIKE '%' || COALESCE(p_filtros->>'buscar','') || '%' OR
           COALESCE(m.codigo,'') LIKE '%' || upper(COALESCE(p_filtros->>'buscar','')) || '%' OR
           internal.normalizar(c.nombres || ' ' || COALESCE(c.apellido_paterno,''))
             LIKE '%' || v_buscar || '%')
    ORDER BY m.nombre
    LIMIT v_size OFFSET (v_page - 1) * v_size
  ) x;

  RETURN jsonb_build_object('ok', true, 'data', v_data, 'meta', jsonb_build_object(
    'total', v_total, 'page', v_page, 'pageSize', v_size,
    'pages', GREATEST(CEIL(v_total::numeric / v_size)::int, 1)));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_mascota_obtener(uuid, uuid, boolean, uuid); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_mascota_obtener(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_global BOOLEAN := internal.es_acceso_global(p_user_id, p_is_super_admin);
  v_emp    UUID    := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_data   JSONB;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'mascotas:listar');

  SELECT to_jsonb(x) INTO v_data FROM (
    SELECT m.id, m.codigo, m.nombre, m.sexo, m.color, m.senias_particulares,
           m.fecha_nacimiento, m.edad_aproximada_meses, m.peso_kg, m.tamanio,
           m.esterilizado, m.fecha_esterilizacion, m.microchip, m.num_placa,
           m.foto_url, m.alergias, m.condiciones_cronicas, m.observaciones,
           m.estado, m.fecha_fallecimiento, m.created_at,
           internal.edad_mascota(m.fecha_nacimiento, m.edad_aproximada_meses) AS edad,
           m.especie_id, e.nombre AS especie, e.icono AS especie_icono,
           m.raza_id, r.nombre AS raza,
           r.esperanza_vida,
           -- Propietario
           jsonb_build_object(
             'id', c.id, 'codigo', c.codigo,
             'nombre_completo', trim(c.nombres || ' ' || COALESCE(c.apellido_paterno,'') || ' ' ||
                                     COALESCE(c.apellido_materno,'')),
             'telefono', c.telefono, 'correo', c.correo,
             'numero_documento', c.numero_documento, 'direccion', c.direccion
           ) AS propietario,
           -- Vacunas
           (SELECT COALESCE(jsonb_agg(jsonb_build_object(
                     'id', v.id, 'nombre_vacuna', v.nombre_vacuna, 'laboratorio', v.laboratorio,
                     'lote', v.lote, 'fecha_aplicacion', v.fecha_aplicacion,
                     'proximo_refuerzo', v.proximo_refuerzo, 'dosis_numero', v.dosis_numero,
                     'vencida', (v.proximo_refuerzo IS NOT NULL AND v.proximo_refuerzo < CURRENT_DATE))
                   ORDER BY v.fecha_aplicacion DESC), '[]'::jsonb)
              FROM core.vacunas v WHERE v.mascota_id = m.id) AS vacunas,
           -- Tratamientos activos
           (SELECT COALESCE(jsonb_agg(jsonb_build_object(
                     'id', t.id, 'medicamento', t.medicamento, 'dosis', t.dosis,
                     'via', t.via, 'frecuencia_horas', t.frecuencia_horas,
                     'fecha_inicio', t.fecha_inicio, 'fecha_fin', t.fecha_fin,
                     'estado', t.estado)
                   ORDER BY t.fecha_inicio DESC), '[]'::jsonb)
              FROM core.tratamientos t
             WHERE t.mascota_id = m.id AND t.estado = 'activo') AS tratamientos_activos,
           -- Cirugías
           (SELECT COALESCE(jsonb_agg(jsonb_build_object(
                     'id', ci.id, 'nombre', ci.nombre, 'fecha_programada', ci.fecha_programada,
                     'fecha_inicio', ci.fecha_inicio, 'estado', ci.estado, 'resultado', ci.resultado)
                   ORDER BY COALESCE(ci.fecha_inicio, ci.fecha_programada) DESC), '[]'::jsonb)
              FROM core.cirugias ci WHERE ci.mascota_id = m.id) AS cirugias,
           -- Curva de peso: alimenta el gráfico de la ficha
           (SELECT COALESCE(jsonb_agg(jsonb_build_object(
                     'fecha', co.fecha, 'peso_kg', co.peso_kg) ORDER BY co.fecha), '[]'::jsonb)
              FROM core.consultas co
             WHERE co.mascota_id = m.id AND co.peso_kg IS NOT NULL
               AND co.deleted_at IS NULL) AS curva_peso,
           -- Próxima cita
           (SELECT jsonb_build_object('id', ci.id, 'fecha_hora', ci.fecha_hora,
                                      'motivo', ci.motivo, 'estado', ci.estado)
              FROM core.citas ci
             WHERE ci.mascota_id = m.id AND ci.deleted_at IS NULL
               AND ci.fecha_hora >= now()
               AND ci.estado IN ('programada','confirmada')
             ORDER BY ci.fecha_hora LIMIT 1) AS proxima_cita,
           -- Hospitalización en curso
           (SELECT jsonb_build_object('id', h.id, 'fecha_ingreso', h.fecha_ingreso,
                                      'motivo', h.motivo, 'jaula', h.jaula, 'estado', h.estado)
              FROM core.hospitalizaciones h
             WHERE h.mascota_id = m.id AND h.estado IN ('ingresado','en_observacion')
             ORDER BY h.fecha_ingreso DESC LIMIT 1) AS hospitalizacion_actual,
           (SELECT count(*) FROM core.consultas co
             WHERE co.mascota_id = m.id AND co.deleted_at IS NULL) AS total_consultas
    FROM core.mascotas m
    JOIN core.clientes c ON c.id = m.cliente_id
    JOIN core.especies e ON e.id = m.especie_id
    LEFT JOIN core.razas r ON r.id = m.raza_id
    WHERE m.id = p_id AND m.deleted_at IS NULL
      AND (v_global OR m.empresa_id = v_emp)
  ) x;

  IF v_data IS NULL THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Paciente no encontrado'));
  END IF;

  RETURN jsonb_build_object('ok', true, 'data', v_data);

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_mascotas_extraviadas_listar(uuid, uuid, boolean, boolean); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_mascotas_extraviadas_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_solo_activos boolean DEFAULT true) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_global BOOLEAN := internal.es_acceso_global(p_user_id, p_is_super_admin);
  v_emp    UUID    := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_data   JSONB;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'mascotas:listar');

  SELECT COALESCE(jsonb_agg(x ORDER BY x.fecha_extravio DESC), '[]'::jsonb) INTO v_data
  FROM (
    SELECT me.id, me.fecha_extravio, me.zona, me.descripcion, me.contacto,
           me.recompensa, me.encontrado, me.fecha_hallazgo,
           m.id AS mascota_id, m.nombre AS mascota, m.foto_url, m.microchip,
           e.nombre AS especie, r.nombre AS raza,
           trim(c.nombres || ' ' || COALESCE(c.apellido_paterno,'')) AS propietario,
           c.telefono AS propietario_telefono
    FROM core.mascotas_extraviadas me
    JOIN core.mascotas m ON m.id = me.mascota_id
    JOIN core.clientes c ON c.id = m.cliente_id
    JOIN core.especies e ON e.id = m.especie_id
    LEFT JOIN core.razas r ON r.id = m.raza_id
    WHERE (v_global OR me.empresa_id = v_emp)
      AND (p_solo_activos = false OR me.encontrado = false)
  ) x;

  RETURN jsonb_build_object('ok', true, 'data', v_data);

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_movimientos_listar(uuid, uuid, boolean, jsonb, integer, integer); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_movimientos_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_filtros jsonb DEFAULT '{}'::jsonb, p_page integer DEFAULT 1, p_page_size integer DEFAULT 50) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_global BOOLEAN := internal.es_acceso_global(p_user_id, p_is_super_admin);
  v_emp    UUID    := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_size   INT     := LEAST(GREATEST(COALESCE(p_page_size, 50), 1), 200);
  v_page   INT     := GREATEST(COALESCE(p_page, 1), 1);
  v_total  INT;
  v_data   JSONB;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'inventario:ver');

  SELECT count(*) INTO v_total
  FROM core.movimientos_inventario mv
  WHERE (v_global OR mv.empresa_id = v_emp)
    AND (p_filtros->>'producto_id' IS NULL OR mv.producto_id = (p_filtros->>'producto_id')::uuid)
    AND (p_filtros->>'tipo'   IS NULL OR mv.tipo::text = p_filtros->>'tipo')
    AND (p_filtros->>'motivo' IS NULL OR mv.motivo::text = p_filtros->>'motivo')
    AND (p_filtros->>'desde'  IS NULL OR mv.fecha >= (p_filtros->>'desde')::timestamptz)
    AND (p_filtros->>'hasta'  IS NULL OR mv.fecha <  (p_filtros->>'hasta')::timestamptz);

  SELECT COALESCE(jsonb_agg(x), '[]'::jsonb) INTO v_data
  FROM (
    SELECT mv.id, mv.tipo, mv.motivo, mv.cantidad, mv.costo_unitario,
           mv.saldo_despues, mv.fecha, mv.observaciones,
           mv.producto_id, pr.nombre AS producto, pr.codigo AS producto_codigo,
           pr.unidad_medida,
           al.nombre AS almacen,
           trim(u.nombres || ' ' || COALESCE(u.apellido_paterno,'')) AS usuario,
           m.nombre AS mascota,
           pv.razon_social AS proveedor
    FROM core.movimientos_inventario mv
    JOIN core.productos pr ON pr.id = mv.producto_id
    LEFT JOIN core.almacenes al ON al.id = mv.almacen_id
    LEFT JOIN core.users u ON u.id = mv.created_by
    LEFT JOIN core.mascotas m ON m.id = mv.mascota_id
    LEFT JOIN core.proveedores pv ON pv.id = mv.proveedor_id
    WHERE (v_global OR mv.empresa_id = v_emp)
      AND (p_filtros->>'producto_id' IS NULL OR mv.producto_id = (p_filtros->>'producto_id')::uuid)
      AND (p_filtros->>'tipo'   IS NULL OR mv.tipo::text = p_filtros->>'tipo')
      AND (p_filtros->>'motivo' IS NULL OR mv.motivo::text = p_filtros->>'motivo')
      AND (p_filtros->>'desde'  IS NULL OR mv.fecha >= (p_filtros->>'desde')::timestamptz)
      AND (p_filtros->>'hasta'  IS NULL OR mv.fecha <  (p_filtros->>'hasta')::timestamptz)
    ORDER BY mv.fecha DESC
    LIMIT v_size OFFSET (v_page - 1) * v_size
  ) x;

  RETURN jsonb_build_object('ok', true, 'data', v_data, 'meta', jsonb_build_object(
    'total', v_total, 'page', v_page, 'pageSize', v_size,
    'pages', GREATEST(CEIL(v_total::numeric / v_size)::int, 1)));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_notificaciones_listar(uuid, uuid, boolean, boolean, integer); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_notificaciones_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_solo_no_leidas boolean DEFAULT false, p_limit integer DEFAULT 30) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_data JSONB;
  v_no_leidas INT;
BEGIN
  SELECT COALESCE(jsonb_agg(x ORDER BY x.created_at DESC), '[]'::jsonb) INTO v_data
  FROM (
    SELECT n.id, n.canal, n.titulo, n.cuerpo, n.url, n.entidad, n.entidad_id,
           n.leida_at, n.created_at
    FROM core.notificaciones n
    WHERE n.user_id = p_user_id
      AND (NOT p_solo_no_leidas OR n.leida_at IS NULL)
    ORDER BY n.created_at DESC
    LIMIT LEAST(COALESCE(p_limit, 30), 100)
  ) x;

  SELECT count(*) INTO v_no_leidas FROM core.notificaciones
   WHERE user_id = p_user_id AND leida_at IS NULL;

  RETURN jsonb_build_object('ok', true, 'data', v_data,
    'meta', jsonb_build_object('no_leidas', v_no_leidas));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_ordenes_compra_listar(uuid, uuid, boolean, jsonb, integer, integer); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_ordenes_compra_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_filtros jsonb DEFAULT '{}'::jsonb, p_page integer DEFAULT 1, p_page_size integer DEFAULT 20) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_global BOOLEAN := internal.es_acceso_global(p_user_id, p_is_super_admin);
  v_emp    UUID    := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_size   INT     := LEAST(GREATEST(COALESCE(p_page_size, 20), 1), 100);
  v_page   INT     := GREATEST(COALESCE(p_page, 1), 1);
  v_total  INT;
  v_data   JSONB;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'compras:ver');

  SELECT count(*) INTO v_total
  FROM core.ordenes_compra oc
  WHERE oc.deleted_at IS NULL AND (v_global OR oc.empresa_id = v_emp)
    AND (p_filtros->>'estado'       IS NULL OR oc.estado::text = p_filtros->>'estado')
    AND (p_filtros->>'estado_pago'  IS NULL OR oc.estado_pago::text = p_filtros->>'estado_pago')
    AND (p_filtros->>'proveedor_id' IS NULL OR oc.proveedor_id = (p_filtros->>'proveedor_id')::uuid)
    AND (p_filtros->>'desde' IS NULL OR oc.fecha_emision >= (p_filtros->>'desde')::date)
    AND (p_filtros->>'hasta' IS NULL OR oc.fecha_emision <= (p_filtros->>'hasta')::date);

  SELECT COALESCE(jsonb_agg(x), '[]'::jsonb) INTO v_data
  FROM (
    SELECT oc.id, oc.numero, oc.fecha_emision, oc.fecha_estimada, oc.fecha_recepcion,
           oc.moneda, oc.subtotal, oc.igv, oc.total, oc.saldo_pendiente,
           oc.estado, oc.estado_pago, oc.observaciones,
           oc.proveedor_id, pv.razon_social AS proveedor, pv.numero_documento AS proveedor_doc,
           al.nombre AS almacen,
           (SELECT count(*) FROM core.orden_compra_items i WHERE i.orden_compra_id = oc.id) AS items,
           (SELECT COALESCE(jsonb_agg(jsonb_build_object(
                     'id', i.id, 'producto_id', i.producto_id, 'producto', pr.nombre,
                     'codigo', pr.codigo, 'cantidad', i.cantidad,
                     'cantidad_recibida', i.cantidad_recibida,
                     'precio_unitario', i.precio_unitario, 'descuento', i.descuento,
                     'subtotal', i.subtotal, 'numero_lote', i.numero_lote,
                     'fecha_vencimiento', i.fecha_vencimiento) ORDER BY i.orden), '[]'::jsonb)
              FROM core.orden_compra_items i
              JOIN core.productos pr ON pr.id = i.producto_id
             WHERE i.orden_compra_id = oc.id) AS detalle
    FROM core.ordenes_compra oc
    JOIN core.proveedores pv ON pv.id = oc.proveedor_id
    LEFT JOIN core.almacenes al ON al.id = oc.almacen_id
    WHERE oc.deleted_at IS NULL AND (v_global OR oc.empresa_id = v_emp)
      AND (p_filtros->>'estado'       IS NULL OR oc.estado::text = p_filtros->>'estado')
      AND (p_filtros->>'estado_pago'  IS NULL OR oc.estado_pago::text = p_filtros->>'estado_pago')
      AND (p_filtros->>'proveedor_id' IS NULL OR oc.proveedor_id = (p_filtros->>'proveedor_id')::uuid)
      AND (p_filtros->>'desde' IS NULL OR oc.fecha_emision >= (p_filtros->>'desde')::date)
      AND (p_filtros->>'hasta' IS NULL OR oc.fecha_emision <= (p_filtros->>'hasta')::date)
    ORDER BY oc.fecha_emision DESC, oc.numero DESC
    LIMIT v_size OFFSET (v_page - 1) * v_size
  ) x;

  RETURN jsonb_build_object('ok', true, 'data', v_data, 'meta', jsonb_build_object(
    'total', v_total, 'page', v_page, 'pageSize', v_size,
    'pages', GREATEST(CEIL(v_total::numeric / v_size)::int, 1)));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_pagos_listar(uuid, uuid, boolean, jsonb, integer, integer); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_pagos_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_filtros jsonb DEFAULT '{}'::jsonb, p_page integer DEFAULT 1, p_page_size integer DEFAULT 20) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_global BOOLEAN := internal.es_acceso_global(p_user_id, p_is_super_admin);
  v_emp    UUID    := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_size   INT     := LEAST(GREATEST(COALESCE(p_page_size, 20), 1), 100);
  v_page   INT     := GREATEST(COALESCE(p_page, 1), 1);
  v_total  INT;
  v_data   JSONB;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'pagos:ver');

  SELECT count(*) INTO v_total
  FROM core.pagos p
  WHERE (v_global OR p.empresa_id = v_emp)
    AND (p_filtros->>'cliente_id' IS NULL OR p.cliente_id = (p_filtros->>'cliente_id')::uuid)
    AND (p_filtros->>'metodo'     IS NULL OR p.metodo::text = p_filtros->>'metodo')
    AND (p_filtros->>'desde' IS NULL OR p.fecha_pago >= (p_filtros->>'desde')::timestamptz)
    AND (p_filtros->>'hasta' IS NULL OR p.fecha_pago <  (p_filtros->>'hasta')::timestamptz);

  SELECT COALESCE(jsonb_agg(x), '[]'::jsonb) INTO v_data
  FROM (
    SELECT p.id, p.numero, p.metodo, p.monto, p.moneda, p.referencia,
           p.fecha_pago, p.anulado_at, p.observaciones,
           p.cliente_id,
           trim(cl.nombres || ' ' || COALESCE(cl.apellido_paterno,'')) AS cliente,
           trim(u.nombres || ' ' || COALESCE(u.apellido_paterno,'')) AS cajero,
           (SELECT COALESCE(jsonb_agg(jsonb_build_object(
                     'comprobante_id', pa.comprobante_id,
                     'numero', c.numero_completo,
                     'monto_aplicado', pa.monto_aplicado)), '[]'::jsonb)
              FROM core.pago_aplicaciones pa
              JOIN core.comprobantes c ON c.id = pa.comprobante_id
             WHERE pa.pago_id = p.id) AS aplicaciones
    FROM core.pagos p
    JOIN core.clientes cl ON cl.id = p.cliente_id
    LEFT JOIN core.users u ON u.id = p.created_by
    WHERE (v_global OR p.empresa_id = v_emp)
      AND (p_filtros->>'cliente_id' IS NULL OR p.cliente_id = (p_filtros->>'cliente_id')::uuid)
      AND (p_filtros->>'metodo'     IS NULL OR p.metodo::text = p_filtros->>'metodo')
      AND (p_filtros->>'desde' IS NULL OR p.fecha_pago >= (p_filtros->>'desde')::timestamptz)
      AND (p_filtros->>'hasta' IS NULL OR p.fecha_pago <  (p_filtros->>'hasta')::timestamptz)
    ORDER BY p.fecha_pago DESC
    LIMIT v_size OFFSET (v_page - 1) * v_size
  ) x;

  RETURN jsonb_build_object('ok', true, 'data', v_data, 'meta', jsonb_build_object(
    'total', v_total, 'page', v_page, 'pageSize', v_size,
    'pages', GREATEST(CEIL(v_total::numeric / v_size)::int, 1)));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_pagos_proveedor_listar(uuid, uuid, boolean, jsonb); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_pagos_proveedor_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_filtros jsonb DEFAULT '{}'::jsonb) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_global BOOLEAN := internal.es_acceso_global(p_user_id, p_is_super_admin);
  v_emp    UUID    := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_data   JSONB;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'compras:ver');

  SELECT COALESCE(jsonb_agg(x ORDER BY x.fecha_pago DESC), '[]'::jsonb) INTO v_data
  FROM (
    SELECT pp.id, pp.numero, pp.metodo, pp.monto, pp.moneda, pp.referencia,
           pp.comprobante_url, pp.fecha_pago, pp.anulado_at, pp.observaciones,
           pv.razon_social AS proveedor, oc.numero AS orden_compra,
           trim(u.nombres || ' ' || COALESCE(u.apellido_paterno,'')) AS registrado_por
    FROM core.pagos_proveedor pp
    JOIN core.proveedores pv ON pv.id = pp.proveedor_id
    LEFT JOIN core.ordenes_compra oc ON oc.id = pp.orden_compra_id
    LEFT JOIN core.users u ON u.id = pp.created_by
    WHERE (v_global OR pp.empresa_id = v_emp)
      AND (p_filtros->>'proveedor_id' IS NULL OR pp.proveedor_id = (p_filtros->>'proveedor_id')::uuid)
      AND (p_filtros->>'desde' IS NULL OR pp.fecha_pago >= (p_filtros->>'desde')::timestamptz)
      AND (p_filtros->>'hasta' IS NULL OR pp.fecha_pago <  (p_filtros->>'hasta')::timestamptz)
  ) x;

  RETURN jsonb_build_object('ok', true, 'data', v_data);

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_pendiente_facturar(uuid, uuid, boolean, uuid); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_pendiente_facturar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_cliente_id uuid) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_emp   UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_serv  JSONB;
  v_ins   JSONB;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'facturacion:ver');

  IF NOT EXISTS (SELECT 1 FROM core.clientes c
                  WHERE c.id = p_cliente_id AND c.deleted_at IS NULL
                    AND internal.es_de_empresa(p_user_id, p_is_super_admin, v_emp, c.empresa_id)) THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Cliente no encontrado'));
  END IF;
  SELECT COALESCE(jsonb_agg(jsonb_build_object(
           'orden_servicio_id', os.id, 'tipo', 'servicio', 'tipo_item', 'servicio',
           'servicio_id', os.servicio_id, 'codigo', s.codigo,
           'descripcion', s.nombre || ' — ' || m.nombre,
           'cantidad', os.cantidad, 'precio_unitario', os.precio_unitario,
           'descuento', os.descuento, 'total', os.total,
           'afecto_igv', s.afecto_igv, 'fecha', os.fecha,
           'mascota', m.nombre) ORDER BY os.fecha), '[]'::jsonb) INTO v_serv
  FROM core.ordenes_servicio os
  JOIN core.servicios s ON s.id = os.servicio_id
  JOIN core.mascotas m ON m.id = os.mascota_id
  WHERE os.empresa_id = v_emp AND os.cliente_id = p_cliente_id
    AND os.facturado = false AND os.estado = 'completado';
  -- Nota: el filtro por os.empresa_id ya acota el resultado a la empresa; un
  -- cliente de otra empresa simplemente no tiene órdenes aquí.

  -- El insumo se imputa al propietario del paciente. Si el consumo no quedó
  -- atado a un paciente (venta de mostrador registrada como insumo), se busca
  -- por el acto clínico del que salió: lo que no se pueda imputar a un cliente
  -- no debe desaparecer de la cobranza sin dejar rastro.
  SELECT COALESCE(jsonb_agg(jsonb_build_object(
           'insumo_id', iu.id, 'tipo', 'producto', 'tipo_item', 'producto',
           'producto_id', iu.producto_id, 'codigo', pr.codigo,
           'descripcion', pr.nombre,
           'cantidad', iu.cantidad, 'precio_unitario', iu.precio_unitario,
           'total', round(iu.cantidad * iu.precio_unitario, 2),
           'afecto_igv', pr.afecto_igv, 'fecha', iu.fecha,
           'mascota', m.nombre) ORDER BY iu.fecha), '[]'::jsonb) INTO v_ins
  FROM core.insumos_utilizados iu
  JOIN core.productos pr ON pr.id = iu.producto_id
  LEFT JOIN core.mascotas m
         ON m.id = COALESCE(iu.mascota_id,
                            (SELECT c.mascota_id FROM core.consultas c WHERE c.id = iu.consulta_id),
                            (SELECT ci.mascota_id FROM core.cirugias ci WHERE ci.id = iu.cirugia_id),
                            (SELECT h.mascota_id FROM core.hospitalizaciones h WHERE h.id = iu.hospitalizacion_id))
  WHERE iu.empresa_id = v_emp AND iu.facturado = false
    AND m.cliente_id = p_cliente_id;

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object(
    'servicios', v_serv, 'insumos', v_ins));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_permisos_laborales_listar(uuid, uuid, boolean, jsonb); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_permisos_laborales_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_filtros jsonb DEFAULT '{}'::jsonb) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_emp   UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_data  JSONB;
  -- El motivo de un permiso —una cita médica, un duelo— es dato personal del
  -- compañero. Sin rrhh:gestionar, cada quien ve solo sus solicitudes.
  v_todos BOOLEAN := internal.tiene_permiso(p_user_id, 'rrhh:gestionar')
                     OR internal.es_acceso_global(p_user_id, p_is_super_admin);
  v_scope UUID;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'rrhh:ver');
  v_scope := CASE WHEN v_todos
                  THEN NULLIF(p_filtros->>'user_id','')::uuid
                  ELSE p_user_id END;

  SELECT COALESCE(jsonb_agg(x ORDER BY x.fecha_inicio DESC), '[]'::jsonb) INTO v_data
  FROM (
    SELECT pl.id, pl.tipo, pl.fecha_inicio, pl.fecha_fin, pl.hora_inicio, pl.hora_fin,
           pl.motivo, pl.estado, pl.aprobado_at, pl.comentario_aprobacion,
           (pl.fecha_fin - pl.fecha_inicio + 1) AS dias,
           pl.user_id, trim(u.nombres || ' ' || COALESCE(u.apellido_paterno,'')) AS solicitante,
           trim(ua.nombres || ' ' || COALESCE(ua.apellido_paterno,'')) AS aprobador
    FROM core.permisos_laborales pl
    JOIN core.users u ON u.id = pl.user_id
    LEFT JOIN core.users ua ON ua.id = pl.aprobado_por
    WHERE pl.empresa_id = v_emp
      AND (p_filtros->>'estado'  IS NULL OR pl.estado::text = p_filtros->>'estado')
      AND (v_scope IS NULL OR pl.user_id = v_scope)
  ) x;

  RETURN jsonb_build_object('ok', true, 'data', v_data);

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_permisos_listar(uuid, uuid, boolean); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_permisos_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_data JSONB;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'usuarios:asignar_rol');

  -- Agrupado por módulo: así la UI arma la matriz de permisos directamente.
  SELECT COALESCE(jsonb_agg(x ORDER BY x.modulo), '[]'::jsonb) INTO v_data
  FROM (
    SELECT p.modulo,
           jsonb_agg(jsonb_build_object(
             'id', p.id, 'codigo', p.codigo, 'accion', p.accion, 'descripcion', p.descripcion
           ) ORDER BY p.accion) AS permisos
    FROM core.permisos p
    GROUP BY p.modulo
  ) x;

  RETURN jsonb_build_object('ok', true, 'data', v_data);

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_plantillas_mensaje_listar(uuid, uuid, boolean); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_plantillas_mensaje_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_emp  UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_data JSONB;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'citas:listar');

  -- Se listan TODOS los tipos, tengan plantilla propia o no: la que no se
  -- editó muestra el texto por defecto, que es el que se va a mandar.
  SELECT COALESCE(jsonb_agg(jsonb_build_object(
           'tipo',        t.tipo,
           'nombre',      t.nombre,
           'texto',       COALESCE(p.texto, internal.plantilla_de(v_emp, t.tipo)),
           'texto_defecto', internal.plantilla_de(NULL, t.tipo),
           'personalizada', p.id IS NOT NULL,
           'id',          p.id,
           'estado',      COALESCE(p.estado, 'activo')) ORDER BY t.orden), '[]'::jsonb)
    INTO v_data
    FROM (VALUES
      ('vacuna',          'Refuerzo de vacuna',   1),
      ('desparasitacion', 'Desparasitación',      2),
      ('control',         'Control posterior',    3),
      ('cita',            'Recordatorio de cita', 4),
      ('cumpleanios',     'Cumpleaños',           5),
      ('deuda',           'Saldo pendiente',      6)
    ) AS t(tipo, nombre, orden)
    LEFT JOIN core.plantillas_mensaje p
      ON p.empresa_id = v_emp AND p.tipo = t.tipo AND p.canal = 'whatsapp';

  RETURN jsonb_build_object('ok', true, 'data', v_data);

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_portal_historial(uuid, uuid); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_portal_historial(p_cliente_id uuid, p_mascota_id uuid) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_data JSONB;
BEGIN
  IF NOT EXISTS (SELECT 1 FROM core.mascotas
                  WHERE id = p_mascota_id AND cliente_id = p_cliente_id AND deleted_at IS NULL) THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('FORBIDDEN','Esa mascota no está asociada a tu cuenta'));
  END IF;

  SELECT jsonb_build_object(
    'eventos', (
      SELECT COALESCE(jsonb_agg(jsonb_build_object(
        'tipo_evento', h.tipo_evento, 'fecha', h.fecha,
        'titulo', h.titulo, 'resumen', h.resumen,
        'veterinario', trim(u.nombres || ' ' || COALESCE(u.apellido_paterno,'')),
        'empresa', e.nombre_comercial) ORDER BY h.fecha DESC), '[]'::jsonb)
      FROM core.historia_clinica h
      LEFT JOIN core.users u ON u.id = h.veterinario_id
      LEFT JOIN core.empresas e ON e.id = h.empresa_id
      WHERE h.mascota_id = p_mascota_id
        AND h.tipo_evento <> 'nota'),   -- las notas internas no se exponen
    'vacunas', (
      SELECT COALESCE(jsonb_agg(jsonb_build_object(
        'nombre_vacuna', v.nombre_vacuna, 'fecha_aplicacion', v.fecha_aplicacion,
        'proximo_refuerzo', v.proximo_refuerzo, 'lote', v.lote,
        'vencida', (v.proximo_refuerzo IS NOT NULL AND v.proximo_refuerzo < CURRENT_DATE))
        ORDER BY v.fecha_aplicacion DESC), '[]'::jsonb)
      FROM core.vacunas v WHERE v.mascota_id = p_mascota_id),
    'tratamientos_activos', (
      SELECT COALESCE(jsonb_agg(jsonb_build_object(
        'medicamento', t.medicamento, 'dosis', t.dosis, 'via', t.via,
        'frecuencia_horas', t.frecuencia_horas, 'indicaciones', t.indicaciones,
        'fecha_inicio', t.fecha_inicio, 'fecha_fin', t.fecha_fin)), '[]'::jsonb)
      FROM core.tratamientos t
      WHERE t.mascota_id = p_mascota_id AND t.estado = 'activo'),
    'curva_peso', (
      SELECT COALESCE(jsonb_agg(jsonb_build_object(
        'fecha', c.fecha, 'peso_kg', c.peso_kg) ORDER BY c.fecha), '[]'::jsonb)
      FROM core.consultas c
      WHERE c.mascota_id = p_mascota_id AND c.peso_kg IS NOT NULL
        AND c.deleted_at IS NULL)
  ) INTO v_data;

  RETURN jsonb_build_object('ok', true, 'data', v_data);

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_portal_mis_citas(uuid, boolean); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_portal_mis_citas(p_cliente_id uuid, p_incluir_pasadas boolean DEFAULT true) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_data JSONB;
BEGIN
  SELECT COALESCE(jsonb_agg(x ORDER BY x.fecha_hora DESC), '[]'::jsonb) INTO v_data
  FROM (
    SELECT c.id, c.codigo, c.fecha_hora, c.duracion_min, c.motivo, c.estado,
           m.nombre AS mascota, m.foto_url AS mascota_foto,
           s.nombre AS servicio,
           trim(u.nombres || ' ' || COALESCE(u.apellido_paterno,'')) AS veterinario,
           e.nombre_comercial AS empresa, e.direccion_fiscal AS empresa_direccion,
           e.telefono AS empresa_telefono
    FROM core.citas c
    JOIN core.mascotas m ON m.id = c.mascota_id
    JOIN core.empresas e ON e.id = c.empresa_id
    LEFT JOIN core.servicios s ON s.id = c.servicio_id
    LEFT JOIN core.users u ON u.id = c.veterinario_id
    WHERE c.cliente_id = p_cliente_id AND c.deleted_at IS NULL
      AND (p_incluir_pasadas OR c.fecha_hora >= now())
    LIMIT 100
  ) x;

  RETURN jsonb_build_object('ok', true, 'data', v_data);

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_portal_mis_comprobantes(uuid); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_portal_mis_comprobantes(p_cliente_id uuid) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_data JSONB;
BEGIN
  SELECT COALESCE(jsonb_agg(x ORDER BY x.fecha_emision DESC), '[]'::jsonb) INTO v_data
  FROM (
    SELECT c.id, c.tipo, c.numero_completo, c.fecha_emision, c.fecha_vencimiento,
           c.total, c.saldo_pendiente, c.estado_pago, c.moneda, c.pdf_url,
           m.nombre AS mascota, e.nombre_comercial AS empresa
    FROM core.comprobantes c
    JOIN core.empresas e ON e.id = c.empresa_id
    LEFT JOIN core.mascotas m ON m.id = c.mascota_id
    WHERE c.cliente_id = p_cliente_id AND c.deleted_at IS NULL AND c.anulado_at IS NULL
    LIMIT 100
  ) x;

  RETURN jsonb_build_object('ok', true, 'data', v_data);

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_portal_mis_mascotas(uuid); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_portal_mis_mascotas(p_cliente_id uuid) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_data JSONB;
BEGIN
  SELECT COALESCE(jsonb_agg(x ORDER BY x.nombre), '[]'::jsonb) INTO v_data
  FROM (
    SELECT m.id, m.codigo, m.nombre, m.sexo, m.color, m.peso_kg, m.foto_url,
           m.esterilizado, m.microchip, m.estado, m.alergias,
           internal.edad_mascota(m.fecha_nacimiento, m.edad_aproximada_meses) AS edad,
           e.nombre AS especie, e.icono AS especie_icono,
           r.nombre AS raza,
           (SELECT jsonb_build_object('fecha_hora', c.fecha_hora, 'motivo', c.motivo,
                                      'estado', c.estado)
              FROM core.citas c
             WHERE c.mascota_id = m.id AND c.deleted_at IS NULL
               AND c.fecha_hora >= now() AND c.estado IN ('programada','confirmada')
             ORDER BY c.fecha_hora LIMIT 1) AS proxima_cita,
           (SELECT min(v.proximo_refuerzo) FROM core.vacunas v
             WHERE v.mascota_id = m.id AND v.proximo_refuerzo >= CURRENT_DATE) AS proxima_vacuna,
           (SELECT count(*) FROM core.vacunas v
             WHERE v.mascota_id = m.id AND v.proximo_refuerzo < CURRENT_DATE) AS vacunas_vencidas
    FROM core.mascotas m
    JOIN core.especies e ON e.id = m.especie_id
    LEFT JOIN core.razas r ON r.id = m.raza_id
    WHERE m.cliente_id = p_cliente_id AND m.deleted_at IS NULL
  ) x;

  RETURN jsonb_build_object('ok', true, 'data', v_data);

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_productos_listar(uuid, uuid, boolean, jsonb, integer, integer); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_productos_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_filtros jsonb DEFAULT '{}'::jsonb, p_page integer DEFAULT 1, p_page_size integer DEFAULT 20) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_global BOOLEAN := internal.es_acceso_global(p_user_id, p_is_super_admin);
  v_emp    UUID    := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_buscar TEXT    := internal.normalizar(p_filtros->>'buscar');
  v_raw    TEXT    := COALESCE(p_filtros->>'buscar','');
  v_size   INT     := LEAST(GREATEST(COALESCE(p_page_size, 20), 1), 100);
  v_page   INT     := GREATEST(COALESCE(p_page, 1), 1);
  v_solo_criticos BOOLEAN := COALESCE((p_filtros->>'solo_criticos')::boolean, false);
  v_total  INT;
  v_data   JSONB;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'inventario:ver');

  SELECT count(*) INTO v_total
  FROM core.productos p
  WHERE p.deleted_at IS NULL AND (v_global OR p.empresa_id = v_emp)
    AND (p_filtros->>'tipo'         IS NULL OR p.tipo::text = p_filtros->>'tipo')
    AND (p_filtros->>'estado'       IS NULL OR p.estado::text = p_filtros->>'estado')
    AND (p_filtros->>'categoria_id' IS NULL OR p.categoria_id = (p_filtros->>'categoria_id')::uuid)
    AND (NOT v_solo_criticos OR p.stock_actual <= p.stock_minimo)
    AND (v_buscar IS NULL OR v_buscar = '' OR
         internal.normalizar(p.nombre) LIKE '%' || v_buscar || '%' OR
         internal.normalizar(COALESCE(p.principio_activo,'')) LIKE '%' || v_buscar || '%' OR
         p.codigo LIKE '%' || v_raw || '%' OR
         COALESCE(p.codigo_barras,'') LIKE '%' || v_raw || '%');

  SELECT COALESCE(jsonb_agg(x), '[]'::jsonb) INTO v_data
  FROM (
    SELECT p.id, p.codigo, p.codigo_barras, p.nombre, p.descripcion, p.tipo,
           p.principio_activo, p.laboratorio, p.presentacion, p.unidad_medida,
           p.requiere_receta, p.controlado, p.refrigerado,
           p.precio_compra, p.precio_venta, p.margen_pct, p.afecto_igv,
           p.stock_actual, p.stock_minimo, p.stock_maximo, p.maneja_lotes,
           p.estado, p.categoria_id, p.empresa_id, cat.nombre AS categoria,
           CASE
             WHEN p.stock_actual <= 0 THEN 'agotado'
             WHEN p.stock_actual <= p.stock_minimo THEN 'critico'
             WHEN p.stock_maximo IS NOT NULL AND p.stock_actual >= p.stock_maximo THEN 'exceso'
             ELSE 'normal'
           END AS situacion_stock,
           (SELECT min(l.fecha_vencimiento) FROM core.lotes l
             WHERE l.producto_id = p.id AND l.cantidad > 0
               AND l.fecha_vencimiento IS NOT NULL) AS proximo_vencimiento,
           (SELECT COALESCE(SUM(l.cantidad), 0) FROM core.lotes l
             WHERE l.producto_id = p.id AND l.cantidad > 0
               AND l.fecha_vencimiento IS NOT NULL
               AND l.fecha_vencimiento <= CURRENT_DATE + 90) AS unidades_por_vencer
    FROM core.productos p
    LEFT JOIN core.categorias cat ON cat.id = p.categoria_id
    WHERE p.deleted_at IS NULL AND (v_global OR p.empresa_id = v_emp)
      AND (p_filtros->>'tipo'         IS NULL OR p.tipo::text = p_filtros->>'tipo')
      AND (p_filtros->>'estado'       IS NULL OR p.estado::text = p_filtros->>'estado')
      AND (p_filtros->>'categoria_id' IS NULL OR p.categoria_id = (p_filtros->>'categoria_id')::uuid)
      AND (NOT v_solo_criticos OR p.stock_actual <= p.stock_minimo)
      AND (v_buscar IS NULL OR v_buscar = '' OR
           internal.normalizar(p.nombre) LIKE '%' || v_buscar || '%' OR
           internal.normalizar(COALESCE(p.principio_activo,'')) LIKE '%' || v_buscar || '%' OR
           p.codigo LIKE '%' || v_raw || '%' OR
           COALESCE(p.codigo_barras,'') LIKE '%' || v_raw || '%')
    ORDER BY p.nombre
    LIMIT v_size OFFSET (v_page - 1) * v_size
  ) x;

  RETURN jsonb_build_object('ok', true, 'data', v_data, 'meta', jsonb_build_object(
    'total', v_total, 'page', v_page, 'pageSize', v_size,
    'pages', GREATEST(CEIL(v_total::numeric / v_size)::int, 1)));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_proveedores_listar(uuid, uuid, boolean, jsonb, integer, integer); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_proveedores_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_filtros jsonb DEFAULT '{}'::jsonb, p_page integer DEFAULT 1, p_page_size integer DEFAULT 20) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_global BOOLEAN := internal.es_acceso_global(p_user_id, p_is_super_admin);
  v_emp    UUID    := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_buscar TEXT    := internal.normalizar(p_filtros->>'buscar');
  v_raw    TEXT    := COALESCE(p_filtros->>'buscar','');
  v_size   INT     := LEAST(GREATEST(COALESCE(p_page_size, 20), 1), 100);
  v_page   INT     := GREATEST(COALESCE(p_page, 1), 1);
  v_total  INT;
  v_data   JSONB;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'compras:ver');

  SELECT count(*) INTO v_total
  FROM core.proveedores p
  WHERE p.deleted_at IS NULL AND (v_global OR p.empresa_id = v_emp)
    AND (p_filtros->>'estado'       IS NULL OR p.estado::text = p_filtros->>'estado')
    AND (p_filtros->>'categoria_id' IS NULL OR p.categoria_id = (p_filtros->>'categoria_id')::uuid)
    AND (v_buscar IS NULL OR v_buscar = '' OR
         internal.normalizar(p.razon_social) LIKE '%' || v_buscar || '%' OR
         p.numero_documento LIKE '%' || v_raw || '%');

  SELECT COALESCE(jsonb_agg(x), '[]'::jsonb) INTO v_data
  FROM (
    SELECT p.id, p.codigo, p.tipo_documento, p.numero_documento, p.razon_social,
           p.nombre_comercial, p.direccion, p.telefono, p.correo, p.web,
           p.dias_credito, p.cuenta_bancaria, p.banco, p.estado, p.observaciones,
           p.categoria_id, cat.nombre AS categoria, p.empresa_id,
           (SELECT count(*) FROM core.ordenes_compra oc
             WHERE oc.proveedor_id = p.id AND oc.deleted_at IS NULL) AS total_ordenes,
           (SELECT COALESCE(SUM(oc.saldo_pendiente), 0) FROM core.ordenes_compra oc
             WHERE oc.proveedor_id = p.id AND oc.deleted_at IS NULL
               AND oc.estado_pago <> 'pagado') AS deuda_pendiente,
           (SELECT max(oc.fecha_emision) FROM core.ordenes_compra oc
             WHERE oc.proveedor_id = p.id AND oc.deleted_at IS NULL) AS ultima_compra,
           (SELECT COALESCE(jsonb_agg(jsonb_build_object(
                     'id', c.id, 'nombres', c.nombres, 'cargo', c.cargo,
                     'telefono', c.telefono, 'correo', c.correo,
                     'es_principal', c.es_principal) ORDER BY c.es_principal DESC), '[]'::jsonb)
              FROM core.proveedor_contactos c WHERE c.proveedor_id = p.id) AS contactos
    FROM core.proveedores p
    LEFT JOIN core.categorias cat ON cat.id = p.categoria_id
    WHERE p.deleted_at IS NULL AND (v_global OR p.empresa_id = v_emp)
      AND (p_filtros->>'estado'       IS NULL OR p.estado::text = p_filtros->>'estado')
      AND (p_filtros->>'categoria_id' IS NULL OR p.categoria_id = (p_filtros->>'categoria_id')::uuid)
      AND (v_buscar IS NULL OR v_buscar = '' OR
           internal.normalizar(p.razon_social) LIKE '%' || v_buscar || '%' OR
           p.numero_documento LIKE '%' || v_raw || '%')
    ORDER BY p.razon_social
    LIMIT v_size OFFSET (v_page - 1) * v_size
  ) x;

  RETURN jsonb_build_object('ok', true, 'data', v_data, 'meta', jsonb_build_object(
    'total', v_total, 'page', v_page, 'pageSize', v_size,
    'pages', GREATEST(CEIL(v_total::numeric / v_size)::int, 1)));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_recordatorios_listar(uuid, uuid, boolean, integer); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_recordatorios_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_dias integer DEFAULT 7) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_emp  UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_data JSONB;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'citas:listar');

  SELECT COALESCE(jsonb_agg(x ORDER BY x.fecha_objetivo), '[]'::jsonb) INTO v_data
  FROM (
    SELECT r.id, r.tipo, r.titulo, r.mensaje, r.fecha_objetivo, r.canal,
           r.enviado_at, r.completado,
           (r.fecha_objetivo - CURRENT_DATE) AS dias_restantes,
           r.cliente_id,
           trim(cl.nombres || ' ' || COALESCE(cl.apellido_paterno,'')) AS cliente,
           cl.telefono AS cliente_telefono, cl.correo AS cliente_correo,
           r.mascota_id, m.nombre AS mascota, m.foto_url AS mascota_foto
    FROM core.recordatorios r
    JOIN core.clientes cl ON cl.id = r.cliente_id
    LEFT JOIN core.mascotas m ON m.id = r.mascota_id
    WHERE r.empresa_id = v_emp AND r.completado = false
      AND r.fecha_objetivo <= CURRENT_DATE + COALESCE(p_dias, 7)
  ) x;

  RETURN jsonb_build_object('ok', true, 'data', v_data);

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_reporte_clinico(uuid, uuid, boolean, date, date); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_reporte_clinico(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_desde date, p_hasta date) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_global BOOLEAN := internal.es_acceso_global(p_user_id, p_is_super_admin);
  v_emp    UUID    := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'reportes:ver');

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object(
    'periodo', jsonb_build_object('desde', p_desde, 'hasta', p_hasta),

    'resumen', jsonb_build_object(
      'consultas', (SELECT count(*) FROM core.consultas c
                     WHERE (v_global OR c.empresa_id = v_emp) AND c.deleted_at IS NULL
                       AND c.fecha::date BETWEEN p_desde AND p_hasta),
      'cirugias',  (SELECT count(*) FROM core.cirugias ci
                     WHERE (v_global OR ci.empresa_id = v_emp) AND ci.estado = 'realizada'
                       AND ci.fecha_inicio::date BETWEEN p_desde AND p_hasta),
      'vacunas',   (SELECT count(*) FROM core.vacunas v
                     WHERE (v_global OR v.empresa_id = v_emp)
                       AND v.fecha_aplicacion BETWEEN p_desde AND p_hasta),
      'desparasitaciones', (SELECT count(*) FROM core.desparasitaciones d
                             WHERE (v_global OR d.empresa_id = v_emp)
                               AND d.fecha_aplicacion BETWEEN p_desde AND p_hasta),
      'hospitalizaciones', (SELECT count(*) FROM core.hospitalizaciones h
                             WHERE (v_global OR h.empresa_id = v_emp)
                               AND h.fecha_ingreso::date BETWEEN p_desde AND p_hasta),
      'examenes',  (SELECT count(*) FROM core.examenes e
                     WHERE (v_global OR e.empresa_id = v_emp)
                       AND e.fecha_solicitud::date BETWEEN p_desde AND p_hasta)),

    -- Motivos de consulta más frecuentes: dice qué está entrando por la puerta
    'diagnosticos_frecuentes', (
      SELECT COALESCE(jsonb_agg(t), '[]'::jsonb) FROM (
        SELECT left(c.diagnostico, 80) AS diagnostico, count(*) AS casos
        FROM core.consultas c
        WHERE (v_global OR c.empresa_id = v_emp) AND c.deleted_at IS NULL
          AND c.fecha::date BETWEEN p_desde AND p_hasta
          AND COALESCE(trim(c.diagnostico), '') <> ''
        GROUP BY left(c.diagnostico, 80)
        ORDER BY casos DESC LIMIT 15) t),

    'por_especie', (
      SELECT COALESCE(jsonb_agg(t), '[]'::jsonb) FROM (
        SELECT e.nombre AS especie, count(*) AS atenciones
        FROM core.consultas c
        JOIN core.mascotas m ON m.id = c.mascota_id
        JOIN core.especies e ON e.id = m.especie_id
        WHERE (v_global OR c.empresa_id = v_emp) AND c.deleted_at IS NULL
          AND c.fecha::date BETWEEN p_desde AND p_hasta
        GROUP BY e.nombre ORDER BY atenciones DESC) t),

    'citas', (
      SELECT jsonb_build_object(
        'total',       count(*),
        'completadas', count(*) FILTER (WHERE c.estado = 'completada'),
        'canceladas',  count(*) FILTER (WHERE c.estado = 'cancelada'),
        'no_asistio',  count(*) FILTER (WHERE c.estado = 'no_asistio'),
        'tasa_asistencia', CASE WHEN count(*) > 0
          THEN round(100.0 * count(*) FILTER (WHERE c.estado = 'completada') / count(*), 1)
          ELSE 0 END)
      FROM core.citas c
      WHERE (v_global OR c.empresa_id = v_emp) AND c.deleted_at IS NULL
        AND c.fecha_hora::date BETWEEN p_desde AND p_hasta)
  ));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_reporte_ejecutivo(uuid, uuid, boolean, date, date); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_reporte_ejecutivo(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_desde date, p_hasta date) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_global BOOLEAN := internal.es_acceso_global(p_user_id, p_is_super_admin);
  v_emp    UUID    := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'reportes:ejecutivo');

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object(
    'periodo', jsonb_build_object('desde', p_desde, 'hasta', p_hasta),

    -- Comparativo entre empresas (solo aporta con acceso global)
    'por_empresa', (
      SELECT COALESCE(jsonb_agg(t), '[]'::jsonb) FROM (
        SELECT e.id, e.nombre_comercial AS empresa, e.razon_social,
               (SELECT count(*) FROM core.citas c
                 WHERE c.empresa_id = e.id AND c.deleted_at IS NULL
                   AND c.fecha_hora::date BETWEEN p_desde AND p_hasta) AS citas,
               (SELECT COALESCE(SUM(cp.total), 0) FROM core.comprobantes cp
                 WHERE cp.empresa_id = e.id AND cp.deleted_at IS NULL
                   AND cp.anulado_at IS NULL
                   AND cp.fecha_emision::date BETWEEN p_desde AND p_hasta) AS facturado,
               (SELECT COALESCE(SUM(cp.saldo_pendiente), 0) FROM core.comprobantes cp
                 WHERE cp.empresa_id = e.id AND cp.deleted_at IS NULL
                   AND cp.anulado_at IS NULL AND cp.saldo_pendiente > 0) AS por_cobrar,
               (SELECT count(*) FROM core.users u
                 WHERE u.empresa_id = e.id AND u.deleted_at IS NULL
                   AND u.estado = 'activo') AS personal
        FROM core.empresas e
        WHERE e.deleted_at IS NULL AND (v_global OR e.id = v_emp)
        ORDER BY facturado DESC) t),

    -- Clientes que más facturan
    'top_clientes', (
      SELECT COALESCE(jsonb_agg(t), '[]'::jsonb) FROM (
        SELECT trim(cl.nombres || ' ' || COALESCE(cl.apellido_paterno,'')) AS cliente,
               cl.numero_documento, count(*) AS documentos,
               COALESCE(SUM(c.total), 0) AS facturado,
               (SELECT count(*) FROM core.mascotas m
                 WHERE m.cliente_id = cl.id AND m.deleted_at IS NULL) AS mascotas
        FROM core.comprobantes c
        JOIN core.clientes cl ON cl.id = c.cliente_id
        WHERE (v_global OR c.empresa_id = v_emp)
          AND c.deleted_at IS NULL AND c.anulado_at IS NULL
          AND c.fecha_emision::date BETWEEN p_desde AND p_hasta
        GROUP BY cl.id, cl.nombres, cl.apellido_paterno, cl.numero_documento
        ORDER BY facturado DESC LIMIT 15) t),

    -- Rentabilidad aproximada: ingreso vs. costo de lo consumido
    'margen', (
      SELECT jsonb_build_object(
        'ingresos', COALESCE((SELECT SUM(c.total) FROM core.comprobantes c
                               WHERE (v_global OR c.empresa_id = v_emp)
                                 AND c.deleted_at IS NULL AND c.anulado_at IS NULL
                                 AND c.fecha_emision::date BETWEEN p_desde AND p_hasta), 0),
        'costo_insumos', COALESCE((SELECT SUM(mv.cantidad * mv.costo_unitario)
                                     FROM core.movimientos_inventario mv
                                    WHERE mv.empresa_id = v_emp AND mv.tipo = 'salida'
                                      AND mv.fecha::date BETWEEN p_desde AND p_hasta), 0),
        'compras', COALESCE((SELECT SUM(oc.total) FROM core.ordenes_compra oc
                              WHERE oc.empresa_id = v_emp AND oc.deleted_at IS NULL
                                AND oc.estado NOT IN ('borrador','cancelada')
                                AND oc.fecha_emision BETWEEN p_desde AND p_hasta), 0)))
  ));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_reporte_inventario(uuid, uuid, boolean, date, date); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_reporte_inventario(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_desde date DEFAULT NULL::date, p_hasta date DEFAULT NULL::date) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_emp   UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_desde DATE := COALESCE(p_desde, date_trunc('month', CURRENT_DATE)::date);
  v_hasta DATE := COALESCE(p_hasta, CURRENT_DATE);
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'reportes:ver');

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object(
    'periodo', jsonb_build_object('desde', v_desde, 'hasta', v_hasta),

    'valorizacion', (
      SELECT jsonb_build_object(
        'productos',      count(*),
        'unidades',       COALESCE(SUM(p.stock_actual), 0),
        'valor_compra',   COALESCE(SUM(p.stock_actual * p.precio_compra), 0),
        'valor_venta',    COALESCE(SUM(p.stock_actual * p.precio_venta), 0),
        'criticos',       count(*) FILTER (WHERE p.stock_actual <= p.stock_minimo),
        'agotados',       count(*) FILTER (WHERE p.stock_actual <= 0))
      FROM core.productos p
      WHERE p.empresa_id = v_emp AND p.deleted_at IS NULL AND p.estado = 'activo'),

    'por_tipo', (
      SELECT COALESCE(jsonb_agg(t), '[]'::jsonb) FROM (
        SELECT p.tipo, count(*) AS productos,
               COALESCE(SUM(p.stock_actual), 0) AS unidades,
               COALESCE(SUM(p.stock_actual * p.precio_compra), 0) AS valor
        FROM core.productos p
        WHERE p.empresa_id = v_emp AND p.deleted_at IS NULL AND p.estado = 'activo'
        GROUP BY p.tipo ORDER BY valor DESC) t),

    -- Más consumidos: lo que hay que tener siempre en stock
    'mas_consumidos', (
      SELECT COALESCE(jsonb_agg(t), '[]'::jsonb) FROM (
        SELECT p.nombre AS producto, p.codigo, p.unidad_medida,
               COALESCE(SUM(mv.cantidad), 0) AS salidas,
               p.stock_actual, p.stock_minimo
        FROM core.movimientos_inventario mv
        JOIN core.productos p ON p.id = mv.producto_id
        WHERE mv.empresa_id = v_emp
          AND mv.tipo = 'salida'
          AND mv.fecha::date BETWEEN v_desde AND v_hasta
        GROUP BY p.id, p.nombre, p.codigo, p.unidad_medida, p.stock_actual, p.stock_minimo
        ORDER BY salidas DESC LIMIT 20) t),

    'movimientos', (
      SELECT jsonb_build_object(
        'entradas', COALESCE(SUM(mv.cantidad) FILTER (WHERE mv.tipo = 'entrada'), 0),
        'salidas',  COALESCE(SUM(mv.cantidad) FILTER (WHERE mv.tipo = 'salida'), 0),
        'mermas',   COALESCE(SUM(mv.cantidad) FILTER (WHERE mv.tipo IN ('merma','vencimiento')), 0),
        'ajustes',  COALESCE(SUM(mv.cantidad) FILTER (
                      WHERE mv.tipo IN ('ajuste_positivo','ajuste_negativo')), 0))
      FROM core.movimientos_inventario mv
      WHERE mv.empresa_id = v_emp AND mv.fecha::date BETWEEN v_desde AND v_hasta)
  ));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_reporte_ventas(uuid, uuid, boolean, date, date); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_reporte_ventas(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_desde date, p_hasta date) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_global BOOLEAN := internal.es_acceso_global(p_user_id, p_is_super_admin);
  v_emp    UUID    := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'reportes:ver');

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object(
    'periodo', jsonb_build_object('desde', p_desde, 'hasta', p_hasta),

    'resumen', (
      SELECT jsonb_build_object(
        'facturado',  COALESCE(SUM(c.total), 0),
        'subtotal',   COALESCE(SUM(c.subtotal), 0),
        'igv',        COALESCE(SUM(c.igv), 0),
        'cobrado',    COALESCE(SUM(c.total - c.saldo_pendiente), 0),
        'pendiente',  COALESCE(SUM(c.saldo_pendiente), 0),
        'documentos', count(*),
        'ticket_promedio', CASE WHEN count(*) > 0
                           THEN round(COALESCE(SUM(c.total),0) / count(*), 2) ELSE 0 END)
      FROM core.comprobantes c
      WHERE (v_global OR c.empresa_id = v_emp)
        AND c.deleted_at IS NULL AND c.anulado_at IS NULL
        AND c.fecha_emision::date BETWEEN p_desde AND p_hasta),

    'por_tipo', (
      SELECT COALESCE(jsonb_agg(t), '[]'::jsonb) FROM (
        SELECT c.tipo, count(*) AS documentos, COALESCE(SUM(c.total), 0) AS total
        FROM core.comprobantes c
        WHERE (v_global OR c.empresa_id = v_emp)
          AND c.deleted_at IS NULL AND c.anulado_at IS NULL
          AND c.fecha_emision::date BETWEEN p_desde AND p_hasta
        GROUP BY c.tipo ORDER BY total DESC) t),

    'por_metodo_pago', (
      SELECT COALESCE(jsonb_agg(t), '[]'::jsonb) FROM (
        SELECT pg.metodo, count(*) AS operaciones, COALESCE(SUM(pg.monto), 0) AS total
        FROM core.pagos pg
        WHERE (v_global OR pg.empresa_id = v_emp) AND pg.anulado_at IS NULL
          AND pg.fecha_pago::date BETWEEN p_desde AND p_hasta
        GROUP BY pg.metodo ORDER BY total DESC) t),

    'por_servicio', (
      SELECT COALESCE(jsonb_agg(t), '[]'::jsonb) FROM (
        SELECT s.nombre AS servicio, s.tipo, count(*) AS veces,
               COALESCE(SUM(os.total), 0) AS ingresos
        FROM core.ordenes_servicio os
        JOIN core.servicios s ON s.id = os.servicio_id
        WHERE (v_global OR os.empresa_id = v_emp) AND os.estado <> 'anulado'
          AND os.fecha::date BETWEEN p_desde AND p_hasta
        GROUP BY s.nombre, s.tipo ORDER BY ingresos DESC) t),

    'por_veterinario', (
      SELECT COALESCE(jsonb_agg(t), '[]'::jsonb) FROM (
        SELECT trim(u.nombres || ' ' || COALESCE(u.apellido_paterno,'')) AS veterinario,
               count(*) AS atenciones, COALESCE(SUM(os.total), 0) AS ingresos
        FROM core.ordenes_servicio os
        JOIN core.users u ON u.id = os.veterinario_id
        WHERE (v_global OR os.empresa_id = v_emp) AND os.estado <> 'anulado'
          AND os.fecha::date BETWEEN p_desde AND p_hasta
        GROUP BY u.id, u.nombres, u.apellido_paterno
        ORDER BY ingresos DESC) t),

    'serie_diaria', (
      SELECT COALESCE(jsonb_agg(jsonb_build_object(
        'fecha', d::date,
        'facturado', (SELECT COALESCE(SUM(c.total), 0) FROM core.comprobantes c
                       WHERE (v_global OR c.empresa_id = v_emp)
                         AND c.deleted_at IS NULL AND c.anulado_at IS NULL
                         AND c.fecha_emision::date = d::date),
        'cobrado', (SELECT COALESCE(SUM(pg.monto), 0) FROM core.pagos pg
                     WHERE (v_global OR pg.empresa_id = v_emp) AND pg.anulado_at IS NULL
                       AND pg.fecha_pago::date = d::date)
      ) ORDER BY d), '[]'::jsonb)
      FROM generate_series(p_desde, p_hasta, '1 day'::interval) d)
  ));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_roles_listar(uuid, uuid, boolean); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_roles_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_data JSONB;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'usuarios:listar');

  SELECT COALESCE(jsonb_agg(x ORDER BY x.scope, x.nombre), '[]'::jsonb) INTO v_data
  FROM (
    SELECT r.id, r.codigo, r.nombre, r.descripcion, r.scope, r.is_sistema,
           (SELECT count(*) FROM core.users u WHERE u.rol_id = r.id AND u.deleted_at IS NULL) AS usuarios,
           (SELECT COALESCE(jsonb_agg(p.codigo ORDER BY p.codigo), '[]'::jsonb)
              FROM core.rol_permisos rp
              JOIN core.permisos p ON p.id = rp.permiso_id
             WHERE rp.rol_id = r.id) AS permisos
    FROM core.roles r
  ) x;

  RETURN jsonb_build_object('ok', true, 'data', v_data);

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_sala_espera(uuid, uuid, boolean, jsonb); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_sala_espera(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_filtros jsonb DEFAULT '{}'::jsonb) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_global BOOLEAN := internal.es_acceso_global(p_user_id, p_is_super_admin);
  v_emp    UUID    := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_vet    UUID    := NULLIF(p_filtros->>'veterinario_id','')::uuid;
  v_data   JSONB;
  v_resumen JSONB;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'citas:listar');

  SELECT COALESCE(jsonb_agg(x ORDER BY x.orden_triaje, x.llegada), '[]'::jsonb) INTO v_data
  FROM (
    SELECT c.id, c.codigo, c.estado, c.prioridad, c.motivo, c.origen,
           c.fecha_hora, c.duracion_min,
           COALESCE(c.hora_llegada, c.fecha_hora) AS llegada,
           c.hora_atencion,
           -- Gravedad primero: el orden clínico, no el de la fila.
           CASE c.prioridad
             WHEN 'emergencia' THEN 1
             WHEN 'urgencia'   THEN 2
             WHEN 'preferente' THEN 3
             ELSE 4 END AS orden_triaje,
           round(EXTRACT(EPOCH FROM (
             now() - COALESCE(c.hora_llegada, c.fecha_hora))) / 60.0)::int AS espera_min,
           m.id AS mascota_id, m.nombre AS mascota, m.foto_url AS mascota_foto,
           m.alergias, m.condiciones_cronicas,
           esp.nombre AS especie,
           internal.edad_mascota(m.fecha_nacimiento, m.edad_aproximada_meses) AS edad,
           cl.id AS cliente_id,
           trim(cl.nombres || ' ' || COALESCE(cl.apellido_paterno,'')) AS cliente,
           cl.telefono AS cliente_telefono,
           c.veterinario_id,
           trim(u.nombres || ' ' || COALESCE(u.apellido_paterno,'')) AS veterinario,
           u.color_agenda,
           s.nombre AS servicio,
           cons.id AS consultorio_id, cons.nombre AS consultorio,
           -- Si ya se abrió la consulta, el botón lleva ahí y no a crear otra.
           (SELECT co.id FROM core.consultas co
             WHERE co.cita_id = c.id AND co.deleted_at IS NULL
             ORDER BY co.created_at DESC LIMIT 1) AS consulta_id
      FROM core.citas c
      JOIN core.mascotas m  ON m.id = c.mascota_id
      JOIN core.clientes cl ON cl.id = c.cliente_id
      JOIN core.especies esp ON esp.id = m.especie_id
      LEFT JOIN core.users u ON u.id = c.veterinario_id
      LEFT JOIN core.servicios s ON s.id = c.servicio_id
      LEFT JOIN core.consultorios cons ON cons.id = c.consultorio_id
     WHERE c.deleted_at IS NULL
       AND c.estado IN ('en_espera','en_atencion')
       AND (v_global OR c.empresa_id = v_emp)
       AND (v_vet IS NULL OR c.veterinario_id = v_vet)
  ) x;

  SELECT jsonb_build_object(
    'en_espera',   count(*) FILTER (WHERE x->>'estado' = 'en_espera'),
    'en_atencion', count(*) FILTER (WHERE x->>'estado' = 'en_atencion'),
    'urgentes',    count(*) FILTER (WHERE x->>'prioridad' IN ('urgencia','emergencia')),
    'espera_max_min', COALESCE(max((x->>'espera_min')::int)
                               FILTER (WHERE x->>'estado' = 'en_espera'), 0),
    -- Los que aún no llegaron pero se les espera hoy: lo que viene.
    'agendados_hoy', (
      SELECT count(*) FROM core.citas c2
       WHERE c2.deleted_at IS NULL
         AND c2.estado IN ('programada','confirmada')
         AND (c2.fecha_hora AT TIME ZONE 'America/Lima')::date = CURRENT_DATE
         AND (v_global OR c2.empresa_id = v_emp)))
  INTO v_resumen
  FROM jsonb_array_elements(v_data) x;

  RETURN jsonb_build_object('ok', true, 'data', v_data, 'meta', v_resumen);

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_servicios_listar(uuid, uuid, boolean, jsonb); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_servicios_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_filtros jsonb DEFAULT '{}'::jsonb) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_global BOOLEAN := internal.es_acceso_global(p_user_id, p_is_super_admin);
  v_emp    UUID    := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_buscar TEXT    := internal.normalizar(p_filtros->>'buscar');
  v_data   JSONB;
BEGIN
  SELECT COALESCE(jsonb_agg(x ORDER BY x.tipo, x.nombre), '[]'::jsonb) INTO v_data
  FROM (
    SELECT s.id, s.codigo, s.nombre, s.descripcion, s.tipo, s.precio, s.costo_estimado,
           s.duracion_min, s.requiere_ayuno, s.requiere_cita, s.afecto_igv,
           s.categoria_id, s.estado, s.empresa_id,
           cat.nombre AS categoria,
           (SELECT count(*) FROM core.ordenes_servicio os
             WHERE os.servicio_id = s.id
               AND os.fecha >= date_trunc('month', CURRENT_DATE)) AS usos_mes
    FROM core.servicios s
    LEFT JOIN core.categorias cat ON cat.id = s.categoria_id
    WHERE s.deleted_at IS NULL
      AND (v_global OR s.empresa_id = v_emp)
      AND (p_filtros->>'tipo'   IS NULL OR s.tipo::text = p_filtros->>'tipo')
      AND (p_filtros->>'estado' IS NULL OR s.estado::text = p_filtros->>'estado')
      AND (p_filtros->>'categoria_id' IS NULL OR s.categoria_id = (p_filtros->>'categoria_id')::uuid)
      AND (v_buscar IS NULL OR v_buscar = '' OR
           internal.normalizar(s.nombre) LIKE '%' || v_buscar || '%' OR
           internal.normalizar(s.codigo) LIKE '%' || v_buscar || '%')
  ) x;

  RETURN jsonb_build_object('ok', true, 'data', v_data);

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_users_listar(uuid, uuid, boolean, jsonb, integer, integer); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_users_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_filtros jsonb DEFAULT '{}'::jsonb, p_page integer DEFAULT 1, p_page_size integer DEFAULT 20) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_global   BOOLEAN := internal.es_acceso_global(p_user_id, p_is_super_admin);
  v_emp      UUID    := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_buscar   TEXT    := internal.normalizar(p_filtros->>'buscar');
  v_size     INT     := LEAST(GREATEST(COALESCE(p_page_size, 20), 1), 100);
  v_page     INT     := GREATEST(COALESCE(p_page, 1), 1);
  v_total    INT;
  v_data     JSONB;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'usuarios:listar');

  SELECT count(*) INTO v_total
  FROM core.users u
  LEFT JOIN core.roles r ON r.id = u.rol_id
  WHERE u.deleted_at IS NULL
    AND (v_global OR u.empresa_id = v_emp)
    AND (p_filtros->>'estado' IS NULL OR u.estado::text = p_filtros->>'estado')
    AND (p_filtros->>'rol_id' IS NULL OR u.rol_id = (p_filtros->>'rol_id')::uuid)
    AND (p_filtros->>'solo_veterinarios' IS NULL
         OR (p_filtros->>'solo_veterinarios')::boolean = false
         OR u.es_veterinario = true)
    AND (v_buscar IS NULL OR v_buscar = '' OR
         internal.normalizar(u.nombres || ' ' || COALESCE(u.apellido_paterno,'') || ' ' ||
                             COALESCE(u.apellido_materno,'')) LIKE '%' || v_buscar || '%' OR
         internal.normalizar(u.email) LIKE '%' || v_buscar || '%' OR
         u.numero_documento LIKE '%' || COALESCE(p_filtros->>'buscar','') || '%');

  SELECT COALESCE(jsonb_agg(x), '[]'::jsonb) INTO v_data
  FROM (
    SELECT u.id, u.codigo, u.email, u.nombres, u.apellido_paterno, u.apellido_materno,
           u.tipo_documento, u.numero_documento, u.telefono, u.foto_url,
           u.empresa_id, u.is_super_admin, u.rol_id, u.estado, u.ultimo_login_at,
           u.es_veterinario, u.colegiatura, u.especializacion_id, u.color_agenda,
           u.created_at,
           r.nombre  AS rol_nombre,
           r.codigo  AS rol_codigo,
           r.scope   AS rol_scope,
           e.razon_social AS empresa_nombre,
           esp.nombre AS especializacion_nombre
    FROM core.users u
    LEFT JOIN core.roles r ON r.id = u.rol_id
    LEFT JOIN core.empresas e ON e.id = u.empresa_id
    LEFT JOIN core.especializaciones esp ON esp.id = u.especializacion_id
    WHERE u.deleted_at IS NULL
      AND (v_global OR u.empresa_id = v_emp)
      AND (p_filtros->>'estado' IS NULL OR u.estado::text = p_filtros->>'estado')
      AND (p_filtros->>'rol_id' IS NULL OR u.rol_id = (p_filtros->>'rol_id')::uuid)
      AND (p_filtros->>'solo_veterinarios' IS NULL
           OR (p_filtros->>'solo_veterinarios')::boolean = false
           OR u.es_veterinario = true)
      AND (v_buscar IS NULL OR v_buscar = '' OR
           internal.normalizar(u.nombres || ' ' || COALESCE(u.apellido_paterno,'') || ' ' ||
                               COALESCE(u.apellido_materno,'')) LIKE '%' || v_buscar || '%' OR
           internal.normalizar(u.email) LIKE '%' || v_buscar || '%' OR
           u.numero_documento LIKE '%' || COALESCE(p_filtros->>'buscar','') || '%')
    ORDER BY u.apellido_paterno NULLS LAST, u.nombres
    LIMIT v_size OFFSET (v_page - 1) * v_size
  ) x;

  RETURN jsonb_build_object('ok', true, 'data', v_data, 'meta', jsonb_build_object(
    'total', v_total, 'page', v_page, 'pageSize', v_size,
    'pages', GREATEST(CEIL(v_total::numeric / v_size)::int, 1)));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_users_obtener(uuid, uuid, boolean, uuid); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_users_obtener(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_global BOOLEAN := internal.es_acceso_global(p_user_id, p_is_super_admin);
  v_emp    UUID    := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_data   JSONB;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'usuarios:listar');

  SELECT to_jsonb(x) INTO v_data FROM (
    SELECT u.id, u.codigo, u.email, u.nombres, u.apellido_paterno, u.apellido_materno,
           u.tipo_documento, u.numero_documento, u.telefono, u.foto_url,
           u.empresa_id, u.is_super_admin, u.rol_id, u.estado, u.ultimo_login_at,
           u.es_veterinario, u.colegiatura, u.especializacion_id, u.color_agenda,
           u.must_change_password, u.created_at,
           r.nombre AS rol_nombre, r.codigo AS rol_codigo,
           e.razon_social AS empresa_nombre,
           (SELECT COALESCE(jsonb_agg(p.codigo ORDER BY p.codigo), '[]'::jsonb)
              FROM core.rol_permisos rp
              JOIN core.permisos p ON p.id = rp.permiso_id
             WHERE rp.rol_id = u.rol_id) AS permisos
    FROM core.users u
    LEFT JOIN core.roles r ON r.id = u.rol_id
    LEFT JOIN core.empresas e ON e.id = u.empresa_id
    WHERE u.id = p_id AND u.deleted_at IS NULL
      AND (v_global OR u.empresa_id = v_emp)
  ) x;

  IF v_data IS NULL THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Usuario no encontrado'));
  END IF;

  RETURN jsonb_build_object('ok', true, 'data', v_data);

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_vacunas_carne(uuid, uuid, boolean, uuid); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_vacunas_carne(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_mascota_id uuid) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_global BOOLEAN := internal.es_acceso_global(p_user_id, p_is_super_admin);
  v_emp    UUID    := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_data   JSONB;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'clinico:ver');

  IF NOT EXISTS (SELECT 1 FROM core.mascotas
                  WHERE id = p_mascota_id AND deleted_at IS NULL
                    AND (v_global OR empresa_id = v_emp)) THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Paciente no encontrado'));
  END IF;

  SELECT COALESCE(jsonb_agg(x ORDER BY x.fecha_aplicacion DESC), '[]'::jsonb) INTO v_data
  FROM (
    SELECT v.id, v.nombre_vacuna, v.laboratorio, v.lote, v.fecha_aplicacion,
           v.dosis_numero, v.proximo_refuerzo, v.via, v.reaccion_adversa,
           v.observaciones, emp.nombre_comercial AS empresa,
           trim(u.nombres || ' ' || COALESCE(u.apellido_paterno,'')) AS veterinario,
           u.colegiatura,
           CASE
             WHEN v.proximo_refuerzo IS NULL THEN 'sin_refuerzo'
             WHEN v.proximo_refuerzo < CURRENT_DATE THEN 'vencida'
             WHEN v.proximo_refuerzo <= CURRENT_DATE + 30 THEN 'por_vencer'
             ELSE 'vigente'
           END AS situacion
    FROM core.vacunas v
    LEFT JOIN core.users u ON u.id = v.veterinario_id
    LEFT JOIN core.empresas emp ON emp.id = v.empresa_id
    WHERE v.mascota_id = p_mascota_id
      AND (v_global OR v.empresa_id = v_emp)
  ) x;

  RETURN jsonb_build_object('ok', true, 'data', v_data);

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: fn_veterinarios_listar(uuid, uuid, boolean); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.fn_veterinarios_listar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_global BOOLEAN := internal.es_acceso_global(p_user_id, p_is_super_admin);
  v_emp    UUID    := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_data   JSONB;
BEGIN
  SELECT COALESCE(jsonb_agg(x ORDER BY x.apellido_paterno, x.nombres), '[]'::jsonb) INTO v_data
  FROM (
    SELECT u.id, u.nombres, u.apellido_paterno, u.apellido_materno,
           u.colegiatura, u.color_agenda, u.foto_url, u.empresa_id,
           esp.nombre AS especializacion,
           (SELECT count(*) FROM core.citas c
             WHERE c.veterinario_id = u.id AND c.deleted_at IS NULL
               AND c.fecha_hora::date = CURRENT_DATE
               AND c.estado NOT IN ('cancelada','no_asistio')) AS citas_hoy
    FROM core.users u
    LEFT JOIN core.especializaciones esp ON esp.id = u.especializacion_id
    WHERE u.es_veterinario = true AND u.deleted_at IS NULL AND u.estado = 'activo'
      AND (v_global OR u.empresa_id = v_emp)
  ) x;

  RETURN jsonb_build_object('ok', true, 'data', v_data);

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_asistencia_marcar(uuid, uuid, boolean, uuid); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_asistencia_marcar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_target_user_id uuid DEFAULT NULL::uuid) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_emp    UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_target UUID;
  v_reg    RECORD;
  v_estado core.estado_asistencia := 'puntual';
  v_limite TIME;
BEGIN
  -- Fichar es autoservicio; fichar por un compañero, no.
  v_target := internal.usuario_objetivo(p_user_id, p_target_user_id, v_emp);

  SELECT * INTO v_reg FROM core.asistencia
   WHERE user_id = v_target AND fecha = CURRENT_DATE;

  IF NOT FOUND THEN
    -- Tardanza: entra más de 10 min después del inicio del horario de la empresa
    SELECT min(hora_inicio) INTO v_limite FROM core.horarios_atencion
     WHERE empresa_id = v_emp AND activo = true
       AND dia_semana = EXTRACT(DOW FROM CURRENT_DATE)::int;

    IF v_limite IS NOT NULL AND CURRENT_TIME > v_limite + INTERVAL '10 minutes' THEN
      v_estado := 'tardanza';
    END IF;

    INSERT INTO core.asistencia (empresa_id, user_id, fecha, hora_entrada, estado)
    VALUES (v_emp, v_target, CURRENT_DATE, CURRENT_TIME, v_estado);

    RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object(
      'accion', 'entrada', 'hora', CURRENT_TIME, 'estado', v_estado));
  END IF;

  IF v_reg.hora_salida IS NOT NULL THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('BUSINESS_RULE','Ya se registró la salida de hoy'));
  END IF;

  UPDATE core.asistencia SET hora_salida = CURRENT_TIME
   WHERE id = v_reg.id;

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object(
    'accion', 'salida', 'hora', CURRENT_TIME));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_auth_cambiar_password(uuid, uuid, boolean, text, text); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_auth_cambiar_password(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_password_actual text, p_password_nuevo text) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_hash   TEXT;
  v_motivo TEXT;
BEGIN
  SELECT password_hash INTO v_hash FROM core.users WHERE id = p_user_id;
  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Usuario no encontrado'));
  END IF;

  IF v_hash IS DISTINCT FROM crypt(p_password_actual, v_hash) THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('FORBIDDEN','La contraseña actual es incorrecta','password_actual'));
  END IF;

  v_motivo := internal.password_invalida(
    p_password_nuevo, (SELECT email FROM core.users WHERE id = p_user_id));
  IF v_motivo IS NOT NULL THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('VALIDATION_ERROR', v_motivo, 'password_nuevo'));
  END IF;

  UPDATE core.users
     SET password_hash = crypt(p_password_nuevo, gen_salt('bf', 10)),
         must_change_password = false,
         password_reset_token = NULL, password_reset_expires = NULL,
         updated_at = now(), updated_by = p_user_id
   WHERE id = p_user_id;

  PERFORM internal.registrar_auditoria(
    p_user_id, p_empresa_id, 'cambio_password', 'users', p_user_id);

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('updated', true));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_auth_login(character varying, text); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_auth_login(p_email character varying, p_password text) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_user     RECORD;
  v_rol      JSONB;
  v_permisos JSONB;
  v_empresa  JSONB;
BEGIN
  SELECT u.* INTO v_user
  FROM core.users u
  WHERE lower(u.email) = lower(p_email) AND u.deleted_at IS NULL;

  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('UNAUTHORIZED','Credenciales inválidas'));
  END IF;

  -- Misma respuesta que para un correo que no existe: "la cuenta no está
  -- activa" confirmaba que ese correo SÍ es de alguien de la clínica, que es
  -- justo lo que busca quien está probando direcciones.
  IF v_user.estado <> 'activo' THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('UNAUTHORIZED','Credenciales inválidas'));
  END IF;

  IF v_user.bloqueado_hasta IS NOT NULL AND v_user.bloqueado_hasta > now() THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('FORBIDDEN',
        'Cuenta bloqueada temporalmente por intentos fallidos. Intenta en unos minutos.'));
  END IF;

  IF v_user.password_hash IS DISTINCT FROM crypt(p_password, v_user.password_hash) THEN
    UPDATE core.users
       SET intentos_fallidos = intentos_fallidos + 1,
           bloqueado_hasta = CASE
             WHEN intentos_fallidos + 1 >= 5 THEN now() + INTERVAL '15 minutes'
             ELSE bloqueado_hasta END,
           updated_at = now()
     WHERE id = v_user.id;
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('UNAUTHORIZED','Credenciales inválidas'));
  END IF;

  UPDATE core.users
     SET intentos_fallidos = 0, bloqueado_hasta = NULL,
         ultimo_login_at = now(), updated_at = now()
   WHERE id = v_user.id;

  SELECT to_jsonb(r) INTO v_rol FROM core.roles r WHERE r.id = v_user.rol_id;

  SELECT COALESCE(jsonb_agg(p.codigo ORDER BY p.codigo), '[]'::jsonb) INTO v_permisos
  FROM core.rol_permisos rp
  JOIN core.permisos p ON p.id = rp.permiso_id
  WHERE rp.rol_id = v_user.rol_id;

  IF v_user.empresa_id IS NOT NULL THEN
    SELECT to_jsonb(e) - 'pse_password_enc' INTO v_empresa
    FROM core.empresas e WHERE e.id = v_user.empresa_id;
  END IF;

  PERFORM internal.registrar_auditoria(
    v_user.id, v_user.empresa_id, 'login', 'users', v_user.id);

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object(
    'user', jsonb_build_object(
      'id',                   v_user.id,
      'codigo',               v_user.codigo,
      'email',                v_user.email,
      'nombres',              v_user.nombres,
      'apellido_paterno',     v_user.apellido_paterno,
      'apellido_materno',     v_user.apellido_materno,
      'telefono',             v_user.telefono,
      'foto_url',             v_user.foto_url,
      'is_super_admin',       v_user.is_super_admin,
      'empresa_id',           v_user.empresa_id,
      'es_veterinario',       v_user.es_veterinario,
      'colegiatura',          v_user.colegiatura,
      'must_change_password', v_user.must_change_password
    ),
    'rol',      v_rol,
    'permisos', v_permisos,
    'empresa',  v_empresa
  ));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_auth_reset_password(character varying, text); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_auth_reset_password(p_token character varying, p_password_nuevo text) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_user_id UUID;
  v_motivo  TEXT;
BEGIN
  v_motivo := internal.password_invalida(p_password_nuevo);
  IF v_motivo IS NOT NULL THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('VALIDATION_ERROR', v_motivo, 'password'));
  END IF;

  SELECT id INTO v_user_id FROM core.users
   WHERE password_reset_token = p_token
     AND password_reset_expires > now()
     AND deleted_at IS NULL;

  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('FORBIDDEN','El enlace es inválido o ya expiró'));
  END IF;

  UPDATE core.users
     SET password_hash = crypt(p_password_nuevo, gen_salt('bf', 10)),
         password_reset_token = NULL, password_reset_expires = NULL,
         must_change_password = false,
         intentos_fallidos = 0, bloqueado_hasta = NULL,
         updated_at = now()
   WHERE id = v_user_id;

  PERFORM internal.registrar_auditoria(v_user_id, NULL, 'reset_password', 'users', v_user_id);

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('updated', true));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_auth_solicitar_reset(character varying); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_auth_solicitar_reset(p_email character varying) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_user_id UUID;
  v_token   VARCHAR(64);
BEGIN
  SELECT id INTO v_user_id FROM core.users
   WHERE lower(email) = lower(p_email) AND deleted_at IS NULL AND estado = 'activo';

  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', true,
      'data', jsonb_build_object('enviado', true, 'token', NULL));
  END IF;

  v_token := encode(gen_random_bytes(24), 'hex');

  UPDATE core.users
     SET password_reset_token = v_token,
         password_reset_expires = now() + INTERVAL '1 hour',
         updated_at = now()
   WHERE id = v_user_id;

  -- El backend usa el token para armar el enlace y enviar el correo.
  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object(
    'enviado', true, 'token', v_token, 'user_id', v_user_id, 'email', p_email));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_caja_abrir(uuid, uuid, boolean, numeric, text); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_caja_abrir(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_monto_apertura numeric DEFAULT 0, p_observaciones text DEFAULT NULL::text) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_id  UUID;
  v_emp UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'caja:operar');

  IF EXISTS (SELECT 1 FROM core.cajas
              WHERE empresa_id = v_emp AND user_apertura_id = p_user_id AND estado = 'abierta') THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('CONFLICT','Ya tienes una caja abierta. Ciérrala antes de abrir otra.'));
  END IF;

  INSERT INTO core.cajas (
    empresa_id, numero, user_apertura_id, monto_apertura, observaciones)
  VALUES (
    v_emp, internal.siguiente_numero(v_emp, 'CAJA', 5), p_user_id,
    COALESCE(p_monto_apertura, 0), p_observaciones)
  RETURNING id INTO v_id;

  PERFORM internal.registrar_auditoria(p_user_id, v_emp, 'abrir', 'cajas', v_id);

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('id', v_id));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_caja_cerrar(uuid, uuid, boolean, uuid, numeric, text); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_caja_cerrar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid, p_monto_contado numeric, p_observaciones text DEFAULT NULL::text) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_caja      RECORD;
  v_ingresos  NUMERIC(14,2);
  v_egresos   NUMERIC(14,2);
  v_efectivo  NUMERIC(14,2);
  v_tarjeta   NUMERIC(14,2);
  v_digital   NUMERIC(14,2);
  v_esperado  NUMERIC(14,2);
  v_dif       NUMERIC(14,2);
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'caja:operar');

  SELECT * INTO v_caja FROM core.cajas
   WHERE id = p_id
     AND internal.es_de_empresa(p_user_id, p_is_super_admin,
           internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin), empresa_id);
  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Caja no encontrada'));
  END IF;

  IF v_caja.estado <> 'abierta' THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('BUSINESS_RULE','La caja ya fue cerrada'));
  END IF;

  SELECT
    COALESCE(SUM(monto) FILTER (WHERE tipo = 'ingreso'), 0),
    COALESCE(SUM(monto) FILTER (WHERE tipo = 'egreso'), 0),
    COALESCE(SUM(CASE WHEN tipo = 'ingreso' THEN monto ELSE -monto END)
             FILTER (WHERE metodo = 'efectivo'), 0),
    COALESCE(SUM(CASE WHEN tipo = 'ingreso' THEN monto ELSE -monto END)
             FILTER (WHERE metodo = 'tarjeta'), 0),
    COALESCE(SUM(CASE WHEN tipo = 'ingreso' THEN monto ELSE -monto END)
             FILTER (WHERE metodo IN ('yape','plin','transferencia','deposito')), 0)
  INTO v_ingresos, v_egresos, v_efectivo, v_tarjeta, v_digital
  FROM core.movimientos_caja WHERE caja_id = p_id;

  -- Solo el efectivo debe estar físicamente en la caja al cerrar.
  v_esperado := v_caja.monto_apertura + v_efectivo;
  v_dif      := COALESCE(p_monto_contado, 0) - v_esperado;

  UPDATE core.cajas SET
    user_cierre_id = p_user_id,
    fecha_cierre   = now(),
    total_ingresos = v_ingresos,
    total_egresos  = v_egresos,
    total_efectivo = v_efectivo,
    total_tarjeta  = v_tarjeta,
    total_digital  = v_digital,
    monto_esperado = v_esperado,
    monto_contado  = p_monto_contado,
    diferencia     = v_dif,
    estado         = CASE WHEN v_dif = 0 THEN 'cuadrada' ELSE 'cerrada' END::core.estado_caja,
    observaciones  = COALESCE(observaciones || ' | ', '') || COALESCE(p_observaciones, '')
  WHERE id = p_id;

  PERFORM internal.registrar_auditoria(
    p_user_id, v_caja.empresa_id, 'cerrar', 'cajas', p_id, NULL,
    jsonb_build_object('esperado', v_esperado, 'contado', p_monto_contado, 'diferencia', v_dif));

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object(
    'id', p_id, 'monto_esperado', v_esperado, 'monto_contado', p_monto_contado,
    'diferencia', v_dif, 'total_ingresos', v_ingresos, 'total_egresos', v_egresos,
    'total_efectivo', v_efectivo, 'total_tarjeta', v_tarjeta, 'total_digital', v_digital,
    'cuadrada', v_dif = 0));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_caja_movimiento(uuid, uuid, boolean, jsonb); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_caja_movimiento(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_id   UUID;
  v_emp  UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_caja UUID := NULLIF(p_payload->>'caja_id','')::uuid;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'caja:operar');
  PERFORM internal.validar_payload(p_payload, ARRAY['tipo','concepto','monto']);

  IF v_caja IS NOT NULL
     AND NOT EXISTS (SELECT 1 FROM core.cajas
                      WHERE id = v_caja
                        AND internal.es_de_empresa(p_user_id, p_is_super_admin, v_emp, empresa_id)) THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Caja no encontrada','caja_id'));
  END IF;

  IF v_caja IS NULL THEN
    SELECT id INTO v_caja FROM core.cajas
     WHERE empresa_id = v_emp AND user_apertura_id = p_user_id AND estado = 'abierta' LIMIT 1;
  END IF;

  IF v_caja IS NULL THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('BUSINESS_RULE','No hay una caja abierta para registrar el movimiento'));
  END IF;

  INSERT INTO core.movimientos_caja (
    empresa_id, caja_id, tipo, metodo, concepto, monto, created_by)
  VALUES (
    v_emp, v_caja,
    (p_payload->>'tipo')::core.tipo_movimiento_caja,
    COALESCE((p_payload->>'metodo')::core.metodo_pago, 'efectivo'),
    p_payload->>'concepto', (p_payload->>'monto')::numeric, p_user_id)
  RETURNING id INTO v_id;

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('id', v_id));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_categoria_guardar(uuid, uuid, boolean, jsonb); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_categoria_guardar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_id  UUID := NULLIF(p_payload->>'id','')::uuid;
  v_emp UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'catalogos:gestionar');

  IF v_id IS NULL THEN
    PERFORM internal.validar_payload(p_payload, ARRAY['ambito','nombre']);
    INSERT INTO core.categorias (empresa_id, ambito, codigo, nombre, descripcion, padre_id, orden, estado)
    VALUES (
      v_emp, p_payload->>'ambito',
      COALESCE(NULLIF(p_payload->>'codigo',''),
               upper(substr(regexp_replace(internal.normalizar(p_payload->>'nombre'), '[^a-z0-9]+', '', 'g'), 1, 12))
               || '-' || substr(gen_random_uuid()::text, 1, 4)),
      p_payload->>'nombre', p_payload->>'descripcion',
      NULLIF(p_payload->>'padre_id','')::uuid,
      COALESCE((p_payload->>'orden')::int, 0),
      COALESCE((p_payload->>'estado')::core.estado_generico, 'activo'))
    RETURNING id INTO v_id;
  ELSE
    IF NOT EXISTS (SELECT 1 FROM core.categorias
                    WHERE id = v_id
                      AND internal.es_de_empresa(p_user_id, p_is_super_admin, v_emp, empresa_id)) THEN
      RETURN jsonb_build_object('ok', false,
        'error', internal.error_jsonb('NOT_FOUND','Categoría no encontrada'));
    END IF;

    UPDATE core.categorias SET
      nombre      = COALESCE(p_payload->>'nombre', nombre),
      descripcion = COALESCE(p_payload->>'descripcion', descripcion),
      padre_id    = COALESCE(NULLIF(p_payload->>'padre_id','')::uuid, padre_id),
      orden       = COALESCE((p_payload->>'orden')::int, orden),
      estado      = COALESCE((p_payload->>'estado')::core.estado_generico, estado)
    WHERE id = v_id;
  END IF;

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('id', v_id));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_cirugia_programar(uuid, uuid, boolean, jsonb); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_cirugia_programar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_id      UUID;
  v_emp     UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_mascota UUID := (p_payload->>'mascota_id')::uuid;
  v_cliente UUID;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'clinico:registrar');
  PERFORM internal.validar_payload(p_payload, ARRAY['mascota_id','nombre']);

  SELECT cliente_id INTO v_cliente FROM core.mascotas
   WHERE id = v_mascota AND deleted_at IS NULL
     AND (internal.es_acceso_global(p_user_id, p_is_super_admin) OR empresa_id = v_emp);
  IF v_cliente IS NULL THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','El paciente indicado no existe','mascota_id'));
  END IF;

  INSERT INTO core.cirugias (
    empresa_id, codigo, mascota_id, cirujano_id, anestesista_id, consultorio_id,
    servicio_id, cita_id, nombre, descripcion, fecha_programada,
    anestesia_tipo, consentimiento_firmado, estado, created_by
  ) VALUES (
    v_emp, internal.siguiente_numero(v_emp, 'CIR', 5), v_mascota,
    COALESCE(NULLIF(p_payload->>'cirujano_id','')::uuid, p_user_id),
    NULLIF(p_payload->>'anestesista_id','')::uuid,
    NULLIF(p_payload->>'consultorio_id','')::uuid,
    NULLIF(p_payload->>'servicio_id','')::uuid,
    NULLIF(p_payload->>'cita_id','')::uuid,
    p_payload->>'nombre', p_payload->>'descripcion',
    NULLIF(p_payload->>'fecha_programada','')::timestamptz,
    p_payload->>'anestesia_tipo',
    COALESCE((p_payload->>'consentimiento_firmado')::boolean, false),
    'programada', p_user_id
  ) RETURNING id INTO v_id;

  PERFORM internal.registrar_evento_clinico(
    v_emp, v_mascota, v_cliente,
    COALESCE(NULLIF(p_payload->>'cirujano_id','')::uuid, p_user_id),
    'cirugia', 'Cirugía programada: ' || (p_payload->>'nombre'),
    p_payload->>'descripcion', v_id, NULLIF(p_payload->>'cita_id','')::uuid);

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('id', v_id));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_cirugia_registrar_resultado(uuid, uuid, boolean, uuid, jsonb); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_cirugia_registrar_resultado(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid, p_payload jsonb) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_cir RECORD;
  v_emp UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'clinico:registrar');

  SELECT * INTO v_cir FROM core.cirugias
   WHERE id = p_id
     AND internal.es_de_empresa(p_user_id, p_is_super_admin,
           internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin), empresa_id);
  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Cirugía no encontrada'));
  END IF;

  IF NOT v_cir.consentimiento_firmado
     AND COALESCE((p_payload->>'consentimiento_firmado')::boolean, false) = false THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('BUSINESS_RULE',
        'No se puede cerrar la cirugía sin el consentimiento informado firmado',
        'consentimiento_firmado'));
  END IF;

  UPDATE core.cirugias SET
    fecha_inicio    = COALESCE(NULLIF(p_payload->>'fecha_inicio','')::timestamptz, fecha_inicio, now()),
    fecha_fin       = COALESCE(NULLIF(p_payload->>'fecha_fin','')::timestamptz, fecha_fin, now()),
    anestesia_tipo  = COALESCE(p_payload->>'anestesia_tipo', anestesia_tipo),
    anestesia_dosis = COALESCE(p_payload->>'anestesia_dosis', anestesia_dosis),
    hallazgos       = COALESCE(p_payload->>'hallazgos', hallazgos),
    complicaciones  = COALESCE(p_payload->>'complicaciones', complicaciones),
    resultado       = COALESCE(p_payload->>'resultado', resultado),
    cuidados_post   = COALESCE(p_payload->>'cuidados_post', cuidados_post),
    consentimiento_firmado = COALESCE((p_payload->>'consentimiento_firmado')::boolean, consentimiento_firmado),
    estado          = COALESCE((p_payload->>'estado')::core.estado_cirugia, 'realizada'),
    updated_by      = p_user_id
  WHERE id = p_id;

  -- La cirugía realizada deja su cargo. Es idempotente por cirugía: corregir el
  -- parte quirúrgico no vuelve a cobrarla.
  IF COALESCE((p_payload->>'estado')::core.estado_cirugia, 'realizada') = 'realizada' THEN
    PERFORM internal.registrar_cargo_servicio(
      v_emp, COALESCE(NULLIF(p_payload->>'servicio_id','')::uuid, v_cir.servicio_id),
      v_cir.mascota_id, p_user_id, 1,
      jsonb_build_object(
        'cita_id', v_cir.cita_id,
        'veterinario_id', v_cir.cirujano_id,
        'descripcion', v_cir.nombre,
        'origen_tabla', 'cirugias', 'origen_id', p_id));
  END IF;

  PERFORM internal.registrar_auditoria(
    p_user_id, v_cir.empresa_id, 'registrar_resultado', 'cirugias', p_id, NULL, p_payload);

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('id', p_id));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_cita_cambiar_estado(uuid, uuid, boolean, uuid, character varying, text); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_cita_cambiar_estado(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid, p_estado character varying, p_motivo text DEFAULT NULL::text) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_cita   RECORD;
  v_nuevo  core.estado_cita := p_estado::core.estado_cita;
  v_accion core.accion_cita;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'citas:editar');

  SELECT * INTO v_cita FROM core.citas
   WHERE id = p_id AND deleted_at IS NULL AND internal.es_de_empresa(p_user_id, p_is_super_admin,
           internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin), empresa_id);
  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Cita no encontrada'));
  END IF;

  IF v_cita.estado = 'completada' AND v_nuevo <> 'completada' THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('BUSINESS_RULE',
        'Una cita completada ya no cambia de estado'));
  END IF;

  IF v_nuevo = 'cancelada' AND COALESCE(trim(p_motivo),'') = '' THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('VALIDATION_ERROR',
        'Indica el motivo de la cancelación','motivo'));
  END IF;

  UPDATE core.citas SET
    estado        = v_nuevo,
    hora_llegada  = CASE WHEN v_nuevo = 'en_espera'   AND hora_llegada  IS NULL THEN now() ELSE hora_llegada END,
    hora_atencion = CASE WHEN v_nuevo = 'en_atencion' AND hora_atencion IS NULL THEN now() ELSE hora_atencion END,
    hora_salida   = CASE WHEN v_nuevo = 'completada'  AND hora_salida   IS NULL THEN now() ELSE hora_salida END,
    motivo_cancelacion = CASE WHEN v_nuevo = 'cancelada' THEN p_motivo ELSE motivo_cancelacion END,
    updated_by    = p_user_id
  WHERE id = p_id;

  v_accion := CASE v_nuevo
    WHEN 'confirmada' THEN 'confirmada'::core.accion_cita
    WHEN 'cancelada'  THEN 'cancelada'::core.accion_cita
    WHEN 'completada' THEN 'atendida'::core.accion_cita
    WHEN 'no_asistio' THEN 'no_asistio'::core.accion_cita
    ELSE NULL END;

  IF v_accion IS NOT NULL THEN
    INSERT INTO core.citas_historial (cita_id, accion, fecha_hora_antes, motivo, user_id)
    VALUES (p_id, v_accion, v_cita.fecha_hora, p_motivo, p_user_id);
  END IF;

  PERFORM internal.registrar_auditoria(
    p_user_id, v_cita.empresa_id, 'cambiar_estado', 'citas', p_id,
    jsonb_build_object('estado', v_cita.estado),
    jsonb_build_object('estado', v_nuevo, 'motivo', p_motivo));

  RETURN jsonb_build_object('ok', true,
    'data', jsonb_build_object('id', p_id, 'estado', v_nuevo));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_cita_crear(uuid, uuid, boolean, jsonb); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_cita_crear(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_id      UUID;
  v_emp     UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_vet     UUID := NULLIF(p_payload->>'veterinario_id','')::uuid;
  v_fecha   TIMESTAMPTZ := (p_payload->>'fecha_hora')::timestamptz;
  v_dur     INT;
  v_cliente UUID;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'citas:crear');
  PERFORM internal.validar_payload(p_payload, ARRAY['mascota_id','fecha_hora']);

  -- El propietario se deriva de la mascota, y la mascota debe pertenecer a la
  -- empresa: así no se puede agendar un paciente de otra empresa pasando su id.
  SELECT cliente_id INTO v_cliente FROM core.mascotas
   WHERE id = (p_payload->>'mascota_id')::uuid AND deleted_at IS NULL
     AND (internal.es_acceso_global(p_user_id, p_is_super_admin) OR empresa_id = v_emp);

  IF v_cliente IS NULL THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','El paciente indicado no existe','mascota_id'));
  END IF;

  -- Duración: la del servicio, o la configurada por la empresa
  SELECT COALESCE(
    NULLIF(p_payload->>'duracion_min','')::int,
    (SELECT s.duracion_min FROM core.servicios s
      WHERE s.id = NULLIF(p_payload->>'servicio_id','')::uuid),
    (SELECT e.duracion_cita_min FROM core.empresas e WHERE e.id = v_emp),
    30) INTO v_dur;

  IF v_fecha < now() - INTERVAL '1 day' THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('VALIDATION_ERROR',
        'No se pueden agendar citas en el pasado','fecha_hora'));
  END IF;

  IF v_vet IS NOT NULL AND internal.hay_solapamiento_cita(v_emp, v_vet, v_fecha, v_dur) THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('CONFLICT',
        'El veterinario ya tiene una cita en ese horario','fecha_hora'));
  END IF;

  INSERT INTO core.citas (
    empresa_id, codigo, cliente_id, mascota_id, veterinario_id, servicio_id,
    consultorio_id, fecha_hora, duracion_min, motivo, prioridad, origen,
    estado, observaciones, created_by
  ) VALUES (
    v_emp,
    internal.siguiente_numero(v_emp, 'CIT', 6),
    v_cliente,
    (p_payload->>'mascota_id')::uuid,
    v_vet,
    NULLIF(p_payload->>'servicio_id','')::uuid,
    NULLIF(p_payload->>'consultorio_id','')::uuid,
    v_fecha, v_dur,
    p_payload->>'motivo',
    COALESCE((p_payload->>'prioridad')::core.prioridad_cita, 'normal'),
    COALESCE((p_payload->>'origen')::core.origen_cita, 'mostrador'),
    COALESCE((p_payload->>'estado')::core.estado_cita, 'programada'),
    p_payload->>'observaciones',
    p_user_id
  ) RETURNING id INTO v_id;

  INSERT INTO core.citas_historial (cita_id, accion, fecha_hora_despues, motivo, user_id)
  VALUES (v_id, 'creada', v_fecha, p_payload->>'motivo', p_user_id);

  PERFORM internal.registrar_auditoria(p_user_id, v_emp, 'crear', 'citas', v_id, NULL, p_payload);

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('id', v_id));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_cita_eliminar(uuid, uuid, boolean, uuid); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_cita_eliminar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_estado core.estado_cita;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'citas:eliminar');

  SELECT estado INTO v_estado FROM core.citas
   WHERE id = p_id AND deleted_at IS NULL AND internal.es_de_empresa(p_user_id, p_is_super_admin,
           internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin), empresa_id);
  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Cita no encontrada'));
  END IF;

  IF v_estado = 'completada' THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('BUSINESS_RULE',
        'Una cita completada no se elimina: forma parte del historial clínico'));
  END IF;

  UPDATE core.citas SET deleted_at = now(), updated_by = p_user_id WHERE id = p_id;
  PERFORM internal.registrar_auditoria(p_user_id, p_empresa_id, 'eliminar', 'citas', p_id);

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('id', p_id, 'eliminado', true));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_cita_registrar_llegada(uuid, uuid, boolean, jsonb); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_cita_registrar_llegada(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_emp     UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_cita    UUID := NULLIF(p_payload->>'cita_id','')::uuid;
  v_mascota UUID := NULLIF(p_payload->>'mascota_id','')::uuid;
  v_cliente UUID;
  v_prio    core.prioridad_cita := COALESCE((p_payload->>'prioridad')::core.prioridad_cita, 'normal');
  v_c       RECORD;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'citas:crear');

  -- Caso 1: tenía cita. Sólo se marca la llegada.
  IF v_cita IS NOT NULL THEN
    SELECT * INTO v_c FROM core.citas
     WHERE id = v_cita AND deleted_at IS NULL
       AND internal.es_de_empresa(p_user_id, p_is_super_admin, v_emp, empresa_id);
    IF NOT FOUND THEN
      RETURN jsonb_build_object('ok', false,
        'error', internal.error_jsonb('NOT_FOUND','Cita no encontrada'));
    END IF;

    IF v_c.estado IN ('completada','cancelada') THEN
      RETURN jsonb_build_object('ok', false,
        'error', internal.error_jsonb('BUSINESS_RULE',
          format('La cita está %s: registra una llegada sin cita', v_c.estado)));
    END IF;

    UPDATE core.citas SET
      estado       = 'en_espera',
      hora_llegada = COALESCE(hora_llegada, now()),
      -- El triaje del mostrador puede subir la prioridad con la que venía.
      prioridad    = internal.prioridad_mas_grave(prioridad, v_prio),
      updated_by   = p_user_id
    WHERE id = v_cita;

    RETURN jsonb_build_object('ok', true,
      'data', jsonb_build_object('id', v_cita, 'estado', 'en_espera', 'creada', false));
  END IF;

  -- Caso 2: llegó sin cita.
  PERFORM internal.validar_payload(p_payload, ARRAY['mascota_id']);

  SELECT cliente_id INTO v_cliente FROM core.mascotas
   WHERE id = v_mascota AND deleted_at IS NULL
     AND (internal.es_acceso_global(p_user_id, p_is_super_admin) OR empresa_id = v_emp);
  IF v_cliente IS NULL THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','El paciente indicado no existe','mascota_id'));
  END IF;

  INSERT INTO core.citas (
    empresa_id, codigo, cliente_id, mascota_id, veterinario_id, servicio_id,
    consultorio_id, fecha_hora, duracion_min, motivo, prioridad, origen,
    estado, hora_llegada, observaciones, created_by
  ) VALUES (
    v_emp, internal.siguiente_numero(v_emp, 'CIT', 6), v_cliente, v_mascota,
    NULLIF(p_payload->>'veterinario_id','')::uuid,
    NULLIF(p_payload->>'servicio_id','')::uuid,
    NULLIF(p_payload->>'consultorio_id','')::uuid,
    now(),
    COALESCE((p_payload->>'duracion_min')::int,
             (SELECT e.duracion_cita_min FROM core.empresas e WHERE e.id = v_emp), 30),
    COALESCE(NULLIF(p_payload->>'motivo',''), 'Atención sin cita'),
    v_prio, 'mostrador', 'en_espera', now(),
    p_payload->>'observaciones', p_user_id
  ) RETURNING id INTO v_cita;

  INSERT INTO core.citas_historial (cita_id, accion, fecha_hora_despues, motivo, user_id)
  VALUES (v_cita, 'creada', now(), 'Llegada sin cita previa', p_user_id);

  PERFORM internal.registrar_auditoria(
    p_user_id, v_emp, 'registrar_llegada', 'citas', v_cita, NULL, p_payload);

  RETURN jsonb_build_object('ok', true,
    'data', jsonb_build_object('id', v_cita, 'estado', 'en_espera', 'creada', true));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_cita_reprogramar(uuid, uuid, boolean, uuid, timestamp with time zone, text, uuid); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_cita_reprogramar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid, p_fecha_hora timestamp with time zone, p_motivo text DEFAULT NULL::text, p_veterinario_id uuid DEFAULT NULL::uuid) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_cita RECORD;
  v_vet  UUID;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'citas:editar');

  SELECT * INTO v_cita FROM core.citas
   WHERE id = p_id AND deleted_at IS NULL AND internal.es_de_empresa(p_user_id, p_is_super_admin,
           internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin), empresa_id);
  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Cita no encontrada'));
  END IF;

  IF v_cita.estado IN ('completada','cancelada') THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('BUSINESS_RULE',
        format('Una cita %s no se puede reprogramar', v_cita.estado)));
  END IF;

  v_vet := COALESCE(p_veterinario_id, v_cita.veterinario_id);

  IF v_vet IS NOT NULL AND
     internal.hay_solapamiento_cita(v_cita.empresa_id, v_vet, p_fecha_hora, v_cita.duracion_min, p_id) THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('CONFLICT',
        'El veterinario ya tiene una cita en ese horario','fecha_hora'));
  END IF;

  UPDATE core.citas
     SET fecha_hora = p_fecha_hora,
         veterinario_id = v_vet,
         estado = 'programada',
         updated_by = p_user_id
   WHERE id = p_id;

  INSERT INTO core.citas_historial (
    cita_id, accion, fecha_hora_antes, fecha_hora_despues, motivo, user_id)
  VALUES (p_id, 'reprogramada', v_cita.fecha_hora, p_fecha_hora, p_motivo, p_user_id);

  PERFORM internal.registrar_auditoria(
    p_user_id, v_cita.empresa_id, 'reprogramar', 'citas', p_id,
    jsonb_build_object('fecha_hora', v_cita.fecha_hora),
    jsonb_build_object('fecha_hora', p_fecha_hora));

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('id', p_id));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_clausula_guardar(uuid, uuid, boolean, jsonb); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_clausula_guardar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_id  UUID := NULLIF(p_payload->>'id','')::uuid;
  v_emp UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'catalogos:gestionar');

  IF v_id IS NULL THEN
    PERFORM internal.validar_payload(p_payload, ARRAY['titulo','contenido']);
    INSERT INTO core.clausulas (empresa_id, tipo, titulo, contenido, orden, estado)
    VALUES (v_emp, COALESCE(p_payload->>'tipo','consentimiento'),
            p_payload->>'titulo', p_payload->>'contenido',
            COALESCE((p_payload->>'orden')::int, 0),
            COALESCE((p_payload->>'estado')::core.estado_generico, 'activo'))
    RETURNING id INTO v_id;
  ELSE
    IF NOT EXISTS (SELECT 1 FROM core.clausulas
                    WHERE id = v_id
                      AND internal.es_de_empresa(p_user_id, p_is_super_admin, v_emp, empresa_id)) THEN
      RETURN jsonb_build_object('ok', false,
        'error', internal.error_jsonb('NOT_FOUND','Cláusula no encontrada'));
    END IF;

    UPDATE core.clausulas SET
      tipo      = COALESCE(p_payload->>'tipo', tipo),
      titulo    = COALESCE(p_payload->>'titulo', titulo),
      contenido = COALESCE(p_payload->>'contenido', contenido),
      orden     = COALESCE((p_payload->>'orden')::int, orden),
      estado    = COALESCE((p_payload->>'estado')::core.estado_generico, estado)
    WHERE id = v_id;
  END IF;

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('id', v_id));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_cliente_activar_portal(uuid, uuid, boolean, uuid, text); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_cliente_activar_portal(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid, p_password text) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_emp UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'clientes:editar');

  IF length(COALESCE(p_password,'')) < 8 THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('VALIDATION_ERROR',
        'La contraseña del portal debe tener al menos 8 caracteres','password'));
  END IF;

  UPDATE core.clientes
     SET portal_acceso = true,
         portal_password_hash = crypt(p_password, gen_salt('bf', 10)),
         updated_by = p_user_id
   WHERE id = p_id AND deleted_at IS NULL
     AND (internal.es_acceso_global(p_user_id, p_is_super_admin) OR empresa_id = v_emp);

  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Cliente no encontrado'));
  END IF;

  PERFORM internal.registrar_auditoria(
    p_user_id, v_emp, 'activar_portal', 'clientes', p_id);

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('id', p_id, 'portal_acceso', true));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_cliente_actualizar(uuid, uuid, boolean, uuid, jsonb); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_cliente_actualizar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid, p_payload jsonb) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_antes JSONB;
  v_emp   UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'clientes:editar');

  -- El filtro por empresa va en el SELECT: un cliente de otra empresa se
  -- comporta como inexistente, sin revelar que existe.
  SELECT to_jsonb(c) - 'portal_password_hash' INTO v_antes
  FROM core.clientes c
  WHERE c.id = p_id AND c.deleted_at IS NULL
    AND (internal.es_acceso_global(p_user_id, p_is_super_admin) OR c.empresa_id = v_emp);

  IF v_antes IS NULL THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Cliente no encontrado'));
  END IF;

  UPDATE core.clientes SET
    nombres          = COALESCE(p_payload->>'nombres', nombres),
    apellido_paterno = COALESCE(p_payload->>'apellido_paterno', apellido_paterno),
    apellido_materno = COALESCE(p_payload->>'apellido_materno', apellido_materno),
    razon_social     = COALESCE(p_payload->>'razon_social', razon_social),
    telefono         = COALESCE(p_payload->>'telefono', telefono),
    telefono_alterno = COALESCE(p_payload->>'telefono_alterno', telefono_alterno),
    correo           = COALESCE(lower(NULLIF(p_payload->>'correo','')), correo),
    direccion        = COALESCE(p_payload->>'direccion', direccion),
    ubigeo           = COALESCE(p_payload->>'ubigeo', ubigeo),
    fecha_nacimiento = COALESCE(NULLIF(p_payload->>'fecha_nacimiento','')::date, fecha_nacimiento),
    linea_credito    = COALESCE((p_payload->>'linea_credito')::numeric, linea_credito),
    dias_credito     = COALESCE((p_payload->>'dias_credito')::int, dias_credito),
    acepta_marketing = COALESCE((p_payload->>'acepta_marketing')::boolean, acepta_marketing),
    observaciones    = COALESCE(p_payload->>'observaciones', observaciones),
    estado           = COALESCE((p_payload->>'estado')::core.estado_cliente, estado),
    updated_by       = p_user_id
  WHERE id = p_id;

  PERFORM internal.registrar_auditoria(
    p_user_id, v_emp, 'actualizar', 'clientes', p_id, v_antes, p_payload);

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('id', p_id));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_cliente_crear(uuid, uuid, boolean, jsonb); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_cliente_crear(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_id       UUID;
  v_emp      UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_tipo_doc core.tipo_documento_identidad :=
    COALESCE((p_payload->>'tipo_documento')::core.tipo_documento_identidad, 'DNI');
  -- Se normaliza ANTES de validar y de buscar duplicados: si no, '12.345.678'
  -- se rechazaría por 'no son 8 dígitos' y esquivaría el chequeo de duplicado
  -- (los valores guardados sí están normalizados por trigger).
  v_doc      TEXT := internal.normalizar_documento(p_payload->>'numero_documento');
  v_existente UUID;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'clientes:crear');
  PERFORM internal.validar_payload(p_payload, ARRAY['numero_documento','nombres']);

  IF v_tipo_doc = 'DNI' AND NOT internal.validar_dni(v_doc) THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('VALIDATION_ERROR','El DNI debe tener 8 dígitos','numero_documento'));
  END IF;

  IF v_tipo_doc = 'RUC' AND NOT internal.validar_ruc(v_doc) THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('VALIDATION_ERROR','El RUC no es válido','numero_documento'));
  END IF;

  IF v_emp IS NULL THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('VALIDATION_ERROR',
        'No se pudo determinar la empresa del usuario','empresa_id'));
  END IF;

  -- El documento es único DENTRO de la empresa. Otra empresa puede tener a la
  -- misma persona en su cartera: son negocios independientes.
  SELECT id INTO v_existente FROM core.clientes
   WHERE empresa_id = v_emp
     AND tipo_documento = v_tipo_doc AND numero_documento = v_doc
     AND deleted_at IS NULL;

  IF v_existente IS NOT NULL THEN
    RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(
      'CONFLICT', 'Ya existe un cliente con ese documento', 'numero_documento')
      || jsonb_build_object('cliente_id', v_existente));
  END IF;

  INSERT INTO core.clientes (
    empresa_id, codigo, tipo_documento, numero_documento,
    nombres, apellido_paterno, apellido_materno,
    razon_social, telefono, telefono_alterno, correo, direccion, ubigeo,
    fecha_nacimiento, linea_credito, dias_credito,
    acepta_marketing, observaciones, created_by
  ) VALUES (
    v_emp,
    COALESCE(NULLIF(p_payload->>'codigo',''), internal.siguiente_numero(v_emp, 'CLI', 5)),
    v_tipo_doc, v_doc,
    p_payload->>'nombres',
    p_payload->>'apellido_paterno',
    p_payload->>'apellido_materno',
    p_payload->>'razon_social',
    p_payload->>'telefono',
    p_payload->>'telefono_alterno',
    lower(NULLIF(p_payload->>'correo','')),
    p_payload->>'direccion',
    p_payload->>'ubigeo',
    NULLIF(p_payload->>'fecha_nacimiento','')::date,
    COALESCE((p_payload->>'linea_credito')::numeric, 0),
    COALESCE((p_payload->>'dias_credito')::int, 0),
    COALESCE((p_payload->>'acepta_marketing')::boolean, true),
    p_payload->>'observaciones',
    p_user_id
  ) RETURNING id INTO v_id;

  PERFORM internal.registrar_auditoria(
    p_user_id, v_emp, 'crear', 'clientes', v_id, NULL, p_payload);

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('id', v_id));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_cliente_eliminar(uuid, uuid, boolean, uuid); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_cliente_eliminar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_citas INT;
  v_emp   UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'clientes:eliminar');

  IF NOT EXISTS (SELECT 1 FROM core.clientes
                  WHERE id = p_id AND deleted_at IS NULL
                    AND (internal.es_acceso_global(p_user_id, p_is_super_admin)
                         OR empresa_id = v_emp)) THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Cliente no encontrado'));
  END IF;

  SELECT count(*) INTO v_citas FROM core.citas WHERE cliente_id = p_id AND deleted_at IS NULL;

  IF v_citas > 0 THEN
    UPDATE core.clientes SET estado = 'inactivo', updated_by = p_user_id WHERE id = p_id;
    RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object(
      'id', p_id, 'desactivado', true,
      'mensaje', 'El cliente tiene historial de atenciones: se desactivó en lugar de eliminarse.'));
  END IF;

  UPDATE core.clientes SET deleted_at = now(), estado = 'inactivo', updated_by = p_user_id
   WHERE id = p_id AND deleted_at IS NULL;

  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Cliente no encontrado'));
  END IF;

  PERFORM internal.registrar_auditoria(p_user_id, p_empresa_id, 'eliminar', 'clientes', p_id);
  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('id', p_id, 'eliminado', true));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_comprobante_actualizar_sunat(uuid, uuid, boolean, uuid, jsonb); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_comprobante_actualizar_sunat(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid, p_payload jsonb) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'facturacion:sunat');

  UPDATE core.comprobantes SET
    estado        = COALESCE((p_payload->>'estado')::core.estado_comprobante, estado),
    hash_cpe      = COALESCE(p_payload->>'hash_cpe', hash_cpe),
    xml_url       = COALESCE(p_payload->>'xml_url', xml_url),
    pdf_url       = COALESCE(p_payload->>'pdf_url', pdf_url),
    cdr_url       = COALESCE(p_payload->>'cdr_url', cdr_url),
    sunat_codigo  = COALESCE(p_payload->>'sunat_codigo', sunat_codigo),
    sunat_mensaje = COALESCE(p_payload->>'sunat_mensaje', sunat_mensaje),
    updated_by    = p_user_id
  WHERE id = p_id AND deleted_at IS NULL
    AND internal.es_de_empresa(p_user_id, p_is_super_admin,
          internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin), empresa_id);

  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Comprobante no encontrado'));
  END IF;

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('id', p_id));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_comprobante_anular(uuid, uuid, boolean, uuid, text); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_comprobante_anular(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid, p_motivo text) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_c    RECORD;
  v_item RECORD;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'facturacion:anular');

  IF COALESCE(trim(p_motivo), '') = '' THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('VALIDATION_ERROR','Indica el motivo de la anulación','motivo'));
  END IF;

  SELECT * INTO v_c FROM core.comprobantes
   WHERE id = p_id AND deleted_at IS NULL
     AND internal.es_de_empresa(p_user_id, p_is_super_admin,
           internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin), empresa_id);
  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Comprobante no encontrado'));
  END IF;

  IF v_c.anulado_at IS NOT NULL THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('BUSINESS_RULE','El comprobante ya está anulado'));
  END IF;

  -- Una vez que el documento salió hacia SUNAT deja de ser nuestro: existe para
  -- la administración tributaria. Lo que corresponde es la nota de crédito (o
  -- la comunicación de baja, dentro del plazo), no borrarlo del sistema.
  IF v_c.estado IN ('enviado_sunat','aceptado_sunat','observado_sunat') THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('BUSINESS_RULE',
        'El comprobante ya fue enviado a SUNAT: corresponde emitir una nota de crédito'));
  END IF;

  -- Si ya se corrigió con una nota de crédito, anular encima devolvería el
  -- stock y el saldo por segunda vez. El documento ya tiene su corrección.
  IF EXISTS (SELECT 1 FROM core.comprobantes nc
              WHERE nc.documento_ref_id = p_id AND nc.anulado_at IS NULL
                AND nc.deleted_at IS NULL) THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('BUSINESS_RULE',
        'El comprobante ya tiene una nota de crédito: esa es su corrección'));
  END IF;

  IF EXISTS (SELECT 1 FROM core.pago_aplicaciones pa
              JOIN core.pagos pg ON pg.id = pa.pago_id AND pg.anulado_at IS NULL
             WHERE pa.comprobante_id = p_id) THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('BUSINESS_RULE',
        'El comprobante tiene cobros aplicados: anula primero los pagos o emite una nota de crédito'));
  END IF;

  UPDATE core.comprobantes
     SET estado = 'anulado', anulado_at = now(),
         motivo_nota = p_motivo, saldo_pendiente = 0,
         estado_pago = 'anulado', updated_by = p_user_id
   WHERE id = p_id;

  -- Devolver los ítems al pool de pendientes: lo que se anuló sigue prestado y
  -- sigue debiéndose.
  UPDATE core.ordenes_servicio SET facturado = false, comprobante_id = NULL
   WHERE comprobante_id = p_id;

  UPDATE core.insumos_utilizados SET facturado = false
   WHERE id IN (SELECT i.insumo_id FROM core.comprobante_items i
                 WHERE i.comprobante_id = p_id AND i.insumo_id IS NOT NULL);

  -- La venta de mostrador salió del almacén al emitir: al anular, vuelve. Los
  -- insumos no se reponen porque el producto ya se usó en el paciente.
  FOR v_item IN
    SELECT ci.producto_id, ci.cantidad
      FROM core.comprobante_items ci
     WHERE ci.comprobante_id = p_id
       AND ci.producto_id IS NOT NULL AND ci.insumo_id IS NULL
  LOOP
    PERFORM internal.mover_stock(
      v_c.empresa_id, v_item.producto_id, 'entrada', 'devolucion',
      v_item.cantidad, p_user_id, NULL,
      jsonb_build_object('cliente_id', v_c.cliente_id, 'comprobante_id', p_id,
                         'observaciones', 'Anulación de ' || v_c.numero_completo));
  END LOOP;

  PERFORM internal.registrar_auditoria(
    p_user_id, v_c.empresa_id, 'anular', 'comprobantes', p_id, NULL,
    jsonb_build_object('motivo', p_motivo));

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('id', p_id, 'anulado', true));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_comprobante_emitir(uuid, uuid, boolean, jsonb); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_comprobante_emitir(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_id       UUID;
  v_emp      UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_tipo     core.tipo_comprobante := COALESCE((p_payload->>'tipo')::core.tipo_comprobante, 'boleta');
  v_cliente  UUID := (p_payload->>'cliente_id')::uuid;
  v_serie    TEXT;
  v_numero   INT;
  v_tasa     NUMERIC(5,4);
  v_items    JSONB := COALESCE(p_payload->'items', '[]'::jsonb);
  v_item     JSONB;
  v_orden    INT := 0;
  v_base     NUMERIC(14,2);
  v_igv_item NUMERIC(14,2);
  v_cli      RECORD;
  v_electronico BOOLEAN;
  v_estado   core.estado_comprobante;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'facturacion:emitir');
  PERFORM internal.validar_payload(p_payload, ARRAY['cliente_id']);

  SELECT * INTO v_cli FROM core.clientes
   WHERE id = v_cliente AND deleted_at IS NULL
     AND (internal.es_acceso_global(p_user_id, p_is_super_admin) OR empresa_id = v_emp);
  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Cliente no encontrado','cliente_id'));
  END IF;

  -- Una factura exige RUC: si el cliente no lo tiene, corresponde boleta.
  IF v_tipo = 'factura' AND v_cli.tipo_documento <> 'RUC' THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('BUSINESS_RULE',
        'Para emitir factura el cliente debe tener RUC. Usa boleta o actualiza sus datos.','tipo'));
  END IF;

  SELECT igv_tasa,
         CASE v_tipo
           WHEN 'factura' THEN COALESCE(serie_factura_default, 'F001')
           WHEN 'boleta'  THEN COALESCE(serie_boleta_default, 'B001')
           ELSE COALESCE(serie_nota_venta_default, 'NV01')
         END,
         emite_electronico
    INTO v_tasa, v_serie, v_electronico
  FROM core.empresas WHERE id = v_emp;

  v_tasa  := COALESCE(v_tasa, 0.18);
  v_serie := COALESCE(NULLIF(p_payload->>'serie',''), v_serie);

  -- Si no vienen ítems, se toma todo lo pendiente del cliente en esta empresa.
  IF jsonb_array_length(v_items) = 0 THEN
    SELECT COALESCE(
      (SELECT jsonb_agg(jsonb_build_object(
         'tipo_item', 'servicio', 'orden_servicio_id', os.id, 'servicio_id', os.servicio_id,
         'codigo', s.codigo, 'descripcion', s.nombre || ' — ' || m.nombre,
         'cantidad', os.cantidad, 'precio_unitario', os.precio_unitario,
         'descuento', os.descuento, 'afecto_igv', s.afecto_igv))
         FROM core.ordenes_servicio os
         JOIN core.servicios s ON s.id = os.servicio_id
         JOIN core.mascotas m ON m.id = os.mascota_id
        WHERE os.empresa_id = v_emp AND os.cliente_id = v_cliente
          AND os.facturado = false AND os.estado = 'completado'), '[]'::jsonb)
      ||
      COALESCE(
      (SELECT jsonb_agg(jsonb_build_object(
         'tipo_item', 'producto', 'insumo_id', iu.id, 'producto_id', iu.producto_id,
         'codigo', pr.codigo, 'descripcion', pr.nombre,
         'cantidad', iu.cantidad, 'precio_unitario', iu.precio_unitario,
         'descuento', 0, 'afecto_igv', pr.afecto_igv))
         FROM core.insumos_utilizados iu
         JOIN core.productos pr ON pr.id = iu.producto_id
         JOIN core.mascotas m ON m.id = iu.mascota_id
        WHERE iu.empresa_id = v_emp AND iu.facturado = false
          AND m.cliente_id = v_cliente), '[]'::jsonb)
    INTO v_items;
  END IF;

  IF jsonb_array_length(v_items) = 0 THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('BUSINESS_RULE',
        'No hay servicios ni productos pendientes de facturar para este cliente','items'));
  END IF;

  -- Una factura o boleta de una empresa que emite electrónicamente nace
  -- pendiente de envío: está numerada y es cobrable, pero SUNAT todavía no la
  -- vio. La nota de venta es interna y no sale nunca.
  v_estado := CASE
    WHEN COALESCE(v_electronico, false) AND v_tipo IN ('factura','boleta')
    THEN 'pendiente_envio'::core.estado_comprobante
    ELSE 'emitido'::core.estado_comprobante END;

  v_numero := internal.siguiente_numero_documento(v_emp, v_tipo::text, v_serie);

  INSERT INTO core.comprobantes (
    empresa_id, tipo, serie, numero, cliente_id, mascota_id, cita_id, consulta_id,
    caja_id, fecha_emision, fecha_vencimiento, moneda, descuento_global,
    estado, observaciones, created_by
  ) VALUES (
    v_emp, v_tipo, v_serie, v_numero, v_cliente,
    NULLIF(p_payload->>'mascota_id','')::uuid,
    NULLIF(p_payload->>'cita_id','')::uuid,
    NULLIF(p_payload->>'consulta_id','')::uuid,
    NULLIF(p_payload->>'caja_id','')::uuid,
    COALESCE(NULLIF(p_payload->>'fecha_emision','')::timestamptz, now()),
    COALESCE(NULLIF(p_payload->>'fecha_vencimiento','')::date,
             CURRENT_DATE + COALESCE(v_cli.dias_credito, 0)),
    COALESCE((p_payload->>'moneda')::core.moneda_codigo, 'PEN'),
    COALESCE((p_payload->>'descuento_global')::numeric, 0),
    v_estado, p_payload->>'observaciones', p_user_id
  ) RETURNING id INTO v_id;

  FOR v_item IN SELECT * FROM jsonb_array_elements(v_items) LOOP
    v_orden := v_orden + 1;
    v_base := round(
      (v_item->>'cantidad')::numeric * (v_item->>'precio_unitario')::numeric
      - COALESCE((v_item->>'descuento')::numeric, 0), 2);

    -- El precio de lista ya incluye IGV: se desagrega para el comprobante.
    IF COALESCE((v_item->>'afecto_igv')::boolean, true) THEN
      v_igv_item := round(v_base - (v_base / (1 + v_tasa)), 2);
    ELSE
      v_igv_item := 0;
    END IF;

    INSERT INTO core.comprobante_items (
      comprobante_id, tipo_item, servicio_id, producto_id, orden_servicio_id,
      insumo_id, codigo, descripcion, cantidad, precio_unitario, descuento,
      afecto_igv, tipo_afectacion_igv, unidad_medida, subtotal, igv, total, orden
    ) VALUES (
      v_id,
      -- El tipo se deduce del origen antes que de lo que mande el cliente: un
      -- ítem con producto es producto aunque el payload diga otra cosa.
      COALESCE(
        NULLIF(v_item->>'tipo_item','')::core.tipo_item_comprobante,
        CASE WHEN NULLIF(v_item->>'producto_id','') IS NOT NULL
                  OR NULLIF(v_item->>'insumo_id','') IS NOT NULL THEN 'producto'
             WHEN NULLIF(v_item->>'servicio_id','') IS NOT NULL THEN 'servicio'
             ELSE 'otro' END::core.tipo_item_comprobante),
      NULLIF(v_item->>'servicio_id','')::uuid,
      NULLIF(v_item->>'producto_id','')::uuid,
      NULLIF(v_item->>'orden_servicio_id','')::uuid,
      NULLIF(v_item->>'insumo_id','')::uuid,
      v_item->>'codigo', v_item->>'descripcion',
      (v_item->>'cantidad')::numeric, (v_item->>'precio_unitario')::numeric,
      COALESCE((v_item->>'descuento')::numeric, 0),
      COALESCE((v_item->>'afecto_igv')::boolean, true),
      -- Catálogo SUNAT 07: 10 gravado, 20 exonerado. Un servicio veterinario
      -- exonerado (casos de campañas) no puede declarar base gravada.
      CASE WHEN COALESCE((v_item->>'afecto_igv')::boolean, true) THEN '10' ELSE '20' END,
      -- Catálogo SUNAT 03: un producto se mide en unidades (NIU); un servicio
      -- no tiene unidad física y va como ZZ.
      COALESCE(NULLIF(v_item->>'unidad_medida',''),
               CASE WHEN NULLIF(v_item->>'producto_id','') IS NOT NULL
                         OR NULLIF(v_item->>'insumo_id','') IS NOT NULL
                    THEN 'NIU' ELSE 'ZZ' END),
      v_base - v_igv_item, v_igv_item, v_base, v_orden);

    -- Marcar el origen como facturado para que no reaparezca en pendientes
    IF NULLIF(v_item->>'orden_servicio_id','') IS NOT NULL THEN
      UPDATE core.ordenes_servicio
         SET facturado = true, comprobante_id = v_id, updated_at = now()
       WHERE id = (v_item->>'orden_servicio_id')::uuid;
    END IF;

    IF NULLIF(v_item->>'insumo_id','') IS NOT NULL THEN
      UPDATE core.insumos_utilizados SET facturado = true
       WHERE id = (v_item->>'insumo_id')::uuid;
    END IF;

    -- Venta de mostrador: el producto sale del almacén aquí. Si viene de un
    -- insumo, el stock ya se descontó en la atención y volver a moverlo dejaría
    -- el kardex con el doble de salidas.
    IF NULLIF(v_item->>'insumo_id','') IS NULL
       AND NULLIF(v_item->>'producto_id','') IS NOT NULL THEN
      PERFORM internal.mover_stock(
        v_emp, (v_item->>'producto_id')::uuid, 'salida', 'venta',
        (v_item->>'cantidad')::numeric, p_user_id, NULL,
        jsonb_build_object('cliente_id', v_cliente, 'comprobante_id', v_id,
                           'observaciones', 'Venta ' || v_serie || '-' || v_numero));
    END IF;
  END LOOP;

  -- El trigger de items ya recalculó subtotal/igv/total/saldo de la cabecera.
  PERFORM internal.recalcular_saldo_comprobante(v_id);

  PERFORM internal.registrar_auditoria(
    p_user_id, v_emp, 'emitir', 'comprobantes', v_id, NULL,
    jsonb_build_object('tipo', v_tipo, 'serie', v_serie, 'numero', v_numero));

  RETURN jsonb_build_object('ok', true, 'data', (
    SELECT jsonb_build_object(
      'id', c.id, 'numero_completo', c.numero_completo, 'tipo', c.tipo,
      'subtotal', c.subtotal, 'igv', c.igv, 'total', c.total,
      'saldo_pendiente', c.saldo_pendiente)
    FROM core.comprobantes c WHERE c.id = v_id));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_comprobante_marcar_enviado(uuid, uuid, boolean, uuid, character varying, jsonb); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_comprobante_marcar_enviado(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid, p_request_id character varying, p_request jsonb) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_emp UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'facturacion:emitir');

  UPDATE core.comprobantes
     SET estado          = 'enviado_sunat',
         pse_request_id  = p_request_id,
         enviado_pse_at  = now(),
         updated_at = now(), updated_by = p_user_id
   WHERE id = p_id AND deleted_at IS NULL
     AND internal.es_de_empresa(p_user_id, p_is_super_admin, v_emp, empresa_id);

  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Comprobante no encontrado'));
  END IF;

  INSERT INTO core.comprobante_pse_log (comprobante_id, operacion, request, exito, mensaje, created_by)
  VALUES (p_id, 'enviar', p_request, true, 'Enviado al PSE', p_user_id);

  RETURN jsonb_build_object('ok', true,
    'data', jsonb_build_object('id', p_id, 'estado', 'enviado_sunat'));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_comprobante_pse_log(uuid, uuid, boolean, uuid, jsonb); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_comprobante_pse_log(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid, p_payload jsonb) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_intento INT;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'facturacion:emitir');

  SELECT COALESCE(MAX(intento), 0) + 1 INTO v_intento
    FROM core.comprobante_pse_log WHERE comprobante_id = p_id;

  INSERT INTO core.comprobante_pse_log (
    comprobante_id, intento, operacion, request, response, exito, mensaje, duracion_ms, created_by)
  VALUES (
    p_id, v_intento,
    COALESCE(p_payload->>'operacion', 'enviar'),
    p_payload->'request', p_payload->'response',
    COALESCE((p_payload->>'exito')::boolean, false),
    p_payload->>'mensaje',
    NULLIF(p_payload->>'duracion_ms','')::int,
    p_user_id);

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('intento', v_intento));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_comprobante_recibir_respuesta(uuid, uuid, boolean, uuid, jsonb); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_comprobante_recibir_respuesta(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid, p_payload jsonb) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_emp    UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_estado core.estado_comprobante := (p_payload->>'estado')::core.estado_comprobante;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'facturacion:emitir');

  UPDATE core.comprobantes SET
    pse_response      = COALESCE(p_payload->'response', pse_response),
    xml_url           = COALESCE(NULLIF(p_payload->>'xml_url',''), xml_url),
    pdf_url           = COALESCE(NULLIF(p_payload->>'pdf_url',''), pdf_url),
    cdr_url           = COALESCE(NULLIF(p_payload->>'cdr_url',''), cdr_url),
    hash_cpe          = COALESCE(NULLIF(p_payload->>'hash_cpe',''), hash_cpe),
    sunat_codigo      = COALESCE(NULLIF(p_payload->>'sunat_codigo',''), sunat_codigo),
    sunat_mensaje     = COALESCE(NULLIF(p_payload->>'sunat_mensaje',''), sunat_mensaje),
    estado            = COALESCE(v_estado, estado),
    aceptado_sunat_at = CASE WHEN v_estado = 'aceptado_sunat'
                             THEN COALESCE(aceptado_sunat_at, now()) ELSE aceptado_sunat_at END,
    updated_at = now(), updated_by = p_user_id
  WHERE id = p_id AND deleted_at IS NULL
    AND internal.es_de_empresa(p_user_id, p_is_super_admin, v_emp, empresa_id);

  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Comprobante no encontrado'));
  END IF;

  PERFORM internal.registrar_auditoria(
    p_user_id, v_emp, 'respuesta_sunat', 'comprobantes', p_id, NULL,
    jsonb_build_object('estado', v_estado, 'codigo', p_payload->>'sunat_codigo'));

  RETURN jsonb_build_object('ok', true,
    'data', jsonb_build_object('id', p_id, 'estado', COALESCE(v_estado::text, 'sin_cambio')));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_comunicacion_registrar(uuid, uuid, boolean, jsonb); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_comunicacion_registrar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_id  UUID;
  v_emp UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'clientes:editar');

  PERFORM internal.validar_payload(p_payload, ARRAY['cliente_id','mensaje']);

  INSERT INTO core.comunicaciones (
    empresa_id, cliente_id, mascota_id, user_id, tipo, asunto, mensaje,
    requiere_seguimiento, fecha_seguimiento, created_by
  ) VALUES (
    v_emp,
    (p_payload->>'cliente_id')::uuid,
    NULLIF(p_payload->>'mascota_id','')::uuid,
    p_user_id,
    COALESCE((p_payload->>'tipo')::core.tipo_comunicacion, 'llamada'),
    p_payload->>'asunto',
    p_payload->>'mensaje',
    COALESCE((p_payload->>'requiere_seguimiento')::boolean, false),
    NULLIF(p_payload->>'fecha_seguimiento','')::date,
    p_user_id
  ) RETURNING id INTO v_id;

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('id', v_id));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_consulta_actualizar(uuid, uuid, boolean, uuid, jsonb); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_consulta_actualizar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid, p_payload jsonb) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_estado core.estado_consulta;
  v_antes  JSONB;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'clinico:registrar');

  SELECT estado, to_jsonb(c) INTO v_estado, v_antes
    FROM core.consultas c
   WHERE c.id = p_id AND c.deleted_at IS NULL
     AND internal.es_de_empresa(p_user_id, p_is_super_admin,
           internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin), c.empresa_id);

  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Consulta no encontrada'));
  END IF;

  -- Una consulta cerrada es un documento clínico firmado: no se reescribe.
  IF v_estado = 'cerrada' THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('BUSINESS_RULE',
        'La consulta está cerrada. Registra una nota médica o una nueva consulta.'));
  END IF;

  UPDATE core.consultas SET
    motivo                  = COALESCE(p_payload->>'motivo', motivo),
    anamnesis               = COALESCE(p_payload->>'anamnesis', anamnesis),
    peso_kg                 = COALESCE(NULLIF(p_payload->>'peso_kg','')::numeric, peso_kg),
    temperatura_c           = COALESCE(NULLIF(p_payload->>'temperatura_c','')::numeric, temperatura_c),
    frecuencia_cardiaca     = COALESCE(NULLIF(p_payload->>'frecuencia_cardiaca','')::int, frecuencia_cardiaca),
    frecuencia_respiratoria = COALESCE(NULLIF(p_payload->>'frecuencia_respiratoria','')::int, frecuencia_respiratoria),
    mucosas                 = COALESCE(p_payload->>'mucosas', mucosas),
    tllc_seg                = COALESCE(NULLIF(p_payload->>'tllc_seg','')::numeric, tllc_seg),
    condicion_corporal      = COALESCE(NULLIF(p_payload->>'condicion_corporal','')::int, condicion_corporal),
    examen_fisico           = COALESCE(p_payload->>'examen_fisico', examen_fisico),
    diagnostico             = COALESCE(p_payload->>'diagnostico', diagnostico),
    diagnostico_diferencial = COALESCE(p_payload->>'diagnostico_diferencial', diagnostico_diferencial),
    pronostico              = COALESCE(p_payload->>'pronostico', pronostico),
    plan_terapeutico        = COALESCE(p_payload->>'plan_terapeutico', plan_terapeutico),
    prescripcion            = COALESCE(p_payload->>'prescripcion', prescripcion),
    indicaciones_casa       = COALESCE(p_payload->>'indicaciones_casa', indicaciones_casa),
    proxima_visita          = COALESCE(NULLIF(p_payload->>'proxima_visita','')::date, proxima_visita),
    updated_by              = p_user_id
  WHERE id = p_id;

  PERFORM internal.registrar_auditoria(
    p_user_id, p_empresa_id, 'actualizar', 'consultas', p_id, v_antes, p_payload);

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('id', p_id));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_consulta_cerrar(uuid, uuid, boolean, uuid); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_consulta_cerrar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_consulta RECORD;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'clinico:registrar');

  SELECT * INTO v_consulta FROM core.consultas
   WHERE id = p_id AND deleted_at IS NULL
     AND internal.es_de_empresa(p_user_id, p_is_super_admin,
           internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin), empresa_id);
  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Consulta no encontrada'));
  END IF;

  IF COALESCE(trim(v_consulta.diagnostico), '') = '' THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('VALIDATION_ERROR',
        'No se puede cerrar una consulta sin diagnóstico','diagnostico'));
  END IF;

  UPDATE core.consultas SET estado = 'cerrada', updated_by = p_user_id WHERE id = p_id;

  IF v_consulta.cita_id IS NOT NULL THEN
    UPDATE core.citas
       SET estado = 'completada',
           hora_salida = COALESCE(hora_salida, now()),
           updated_by = p_user_id
     WHERE id = v_consulta.cita_id;

    INSERT INTO core.citas_historial (cita_id, accion, motivo, user_id)
    VALUES (v_consulta.cita_id, 'atendida', 'Consulta cerrada', p_user_id);
  END IF;

  PERFORM internal.registrar_auditoria(
    p_user_id, v_consulta.empresa_id, 'cerrar', 'consultas', p_id);

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('id', p_id, 'estado', 'cerrada'));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_consulta_crear(uuid, uuid, boolean, jsonb); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_consulta_crear(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_id      UUID;
  v_emp     UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_cliente UUID;
  v_vet     UUID := COALESCE(NULLIF(p_payload->>'veterinario_id','')::uuid, p_user_id);
  v_cita    UUID := NULLIF(p_payload->>'cita_id','')::uuid;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'clinico:registrar');
  PERFORM internal.validar_payload(p_payload, ARRAY['mascota_id','motivo']);

  -- El paciente debe ser de la empresa: un id de otra empresa se comporta
  -- como inexistente.
  SELECT cliente_id INTO v_cliente FROM core.mascotas
   WHERE id = (p_payload->>'mascota_id')::uuid AND deleted_at IS NULL
     AND (internal.es_acceso_global(p_user_id, p_is_super_admin) OR empresa_id = v_emp);

  IF v_cliente IS NULL THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','El paciente indicado no existe','mascota_id'));
  END IF;

  -- Solo un veterinario colegiado firma una consulta.
  IF NOT EXISTS (SELECT 1 FROM core.users
                  WHERE id = v_vet AND es_veterinario = true AND deleted_at IS NULL) THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('BUSINESS_RULE',
        'La consulta debe estar firmada por un veterinario colegiado','veterinario_id'));
  END IF;

  INSERT INTO core.consultas (
    empresa_id, codigo, mascota_id, cliente_id, veterinario_id, cita_id, fecha,
    motivo, anamnesis, peso_kg, temperatura_c, frecuencia_cardiaca,
    frecuencia_respiratoria, mucosas, tllc_seg, condicion_corporal, examen_fisico,
    diagnostico, diagnostico_diferencial, pronostico, plan_terapeutico,
    prescripcion, indicaciones_casa, proxima_visita, estado, created_by
  ) VALUES (
    v_emp,
    internal.siguiente_numero(v_emp, 'CON', 6),
    (p_payload->>'mascota_id')::uuid, v_cliente, v_vet, v_cita,
    COALESCE(NULLIF(p_payload->>'fecha','')::timestamptz, now()),
    p_payload->>'motivo',
    p_payload->>'anamnesis',
    NULLIF(p_payload->>'peso_kg','')::numeric,
    NULLIF(p_payload->>'temperatura_c','')::numeric,
    NULLIF(p_payload->>'frecuencia_cardiaca','')::int,
    NULLIF(p_payload->>'frecuencia_respiratoria','')::int,
    p_payload->>'mucosas',
    NULLIF(p_payload->>'tllc_seg','')::numeric,
    NULLIF(p_payload->>'condicion_corporal','')::int,
    p_payload->>'examen_fisico',
    p_payload->>'diagnostico',
    p_payload->>'diagnostico_diferencial',
    p_payload->>'pronostico',
    p_payload->>'plan_terapeutico',
    p_payload->>'prescripcion',
    p_payload->>'indicaciones_casa',
    NULLIF(p_payload->>'proxima_visita','')::date,
    COALESCE((p_payload->>'estado')::core.estado_consulta, 'borrador'),
    p_user_id
  ) RETURNING id INTO v_id;

  PERFORM internal.registrar_evento_clinico(
    v_emp, (p_payload->>'mascota_id')::uuid, v_cliente, v_vet, 'consulta',
    'Consulta: ' || left(p_payload->>'motivo', 120),
    p_payload->>'diagnostico', v_id, v_cita);

  -- Atender desde la agenda cierra la cita sin un paso manual extra.
  IF v_cita IS NOT NULL THEN
    UPDATE core.citas
       SET estado = 'en_atencion',
           hora_atencion = COALESCE(hora_atencion, now()),
           updated_by = p_user_id
     WHERE id = v_cita AND estado NOT IN ('completada','cancelada');
  END IF;

  -- Recordatorio de control si el veterinario fijó próxima visita
  IF NULLIF(p_payload->>'proxima_visita','') IS NOT NULL THEN
    INSERT INTO core.recordatorios (
      empresa_id, cliente_id, mascota_id, tipo, titulo, mensaje,
      fecha_objetivo, entidad_ref, entidad_id)
    VALUES (
      v_emp, v_cliente, (p_payload->>'mascota_id')::uuid, 'control',
      'Control post-consulta',
      'Recordar al propietario la visita de control indicada en la consulta.',
      (p_payload->>'proxima_visita')::date, 'consultas', v_id);
  END IF;

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('id', v_id));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_consultorio_guardar(uuid, uuid, boolean, jsonb); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_consultorio_guardar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_id  UUID := NULLIF(p_payload->>'id','')::uuid;
  v_emp UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'catalogos:gestionar');

  IF v_id IS NULL THEN
    PERFORM internal.validar_payload(p_payload, ARRAY['nombre']);
    INSERT INTO core.consultorios (empresa_id, nombre, tipo, capacidad, estado)
    VALUES (v_emp, p_payload->>'nombre', COALESCE(p_payload->>'tipo','consulta'),
            COALESCE((p_payload->>'capacidad')::int, 1),
            COALESCE((p_payload->>'estado')::core.estado_generico, 'activo'))
    RETURNING id INTO v_id;
  ELSE
    IF NOT EXISTS (SELECT 1 FROM core.consultorios
                    WHERE id = v_id
                      AND internal.es_de_empresa(p_user_id, p_is_super_admin, v_emp, empresa_id)) THEN
      RETURN jsonb_build_object('ok', false,
        'error', internal.error_jsonb('NOT_FOUND','Consultorio no encontrado'));
    END IF;

    UPDATE core.consultorios SET
      nombre    = COALESCE(p_payload->>'nombre', nombre),
      tipo      = COALESCE(p_payload->>'tipo', tipo),
      capacidad = COALESCE((p_payload->>'capacidad')::int, capacidad),
      estado    = COALESCE((p_payload->>'estado')::core.estado_generico, estado)
    WHERE id = v_id;
  END IF;

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('id', v_id));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_contrato_personal_guardar(uuid, uuid, boolean, jsonb); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_contrato_personal_guardar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_id  UUID := NULLIF(p_payload->>'id','')::uuid;
  v_emp UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'rrhh:gestionar');

  IF v_id IS NULL THEN
    PERFORM internal.validar_payload(p_payload, ARRAY['user_id','fecha_inicio']);

    -- Un solo contrato vigente por persona: el nuevo cierra el anterior.
    UPDATE core.contratos_personal SET vigente = false
     WHERE user_id = (p_payload->>'user_id')::uuid AND vigente = true;

    INSERT INTO core.contratos_personal (
      empresa_id, user_id, tipo, cargo, fecha_inicio, fecha_fin,
      salario, moneda, documento_url, vigente)
    VALUES (
      v_emp, (p_payload->>'user_id')::uuid,
      COALESCE((p_payload->>'tipo')::core.tipo_contrato_empleado, 'plazo_fijo'),
      p_payload->>'cargo',
      (p_payload->>'fecha_inicio')::date,
      NULLIF(p_payload->>'fecha_fin','')::date,
      NULLIF(p_payload->>'salario','')::numeric,
      COALESCE((p_payload->>'moneda')::core.moneda_codigo, 'PEN'),
      p_payload->>'documento_url', true)
    RETURNING id INTO v_id;
  ELSE
    IF NOT EXISTS (SELECT 1 FROM core.contratos_personal
                    WHERE id = v_id
                      AND internal.es_de_empresa(p_user_id, p_is_super_admin, v_emp, empresa_id)) THEN
      RETURN jsonb_build_object('ok', false,
        'error', internal.error_jsonb('NOT_FOUND','Contrato no encontrado'));
    END IF;

    UPDATE core.contratos_personal SET
      tipo          = COALESCE((p_payload->>'tipo')::core.tipo_contrato_empleado, tipo),
      cargo         = COALESCE(p_payload->>'cargo', cargo),
      fecha_inicio  = COALESCE(NULLIF(p_payload->>'fecha_inicio','')::date, fecha_inicio),
      fecha_fin     = COALESCE(NULLIF(p_payload->>'fecha_fin','')::date, fecha_fin),
      salario       = COALESCE(NULLIF(p_payload->>'salario','')::numeric, salario),
      documento_url = COALESCE(p_payload->>'documento_url', documento_url),
      vigente       = COALESCE((p_payload->>'vigente')::boolean, vigente)
    WHERE id = v_id;
  END IF;

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('id', v_id));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_desparasitacion_registrar(uuid, uuid, boolean, jsonb); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_desparasitacion_registrar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_id      UUID;
  v_emp     UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_mascota UUID := (p_payload->>'mascota_id')::uuid;
  v_cliente UUID;
  v_proxima DATE := NULLIF(p_payload->>'proxima_dosis','')::date;
  v_fecha   DATE := COALESCE(NULLIF(p_payload->>'fecha_aplicacion','')::date, CURRENT_DATE);
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'clinico:registrar');
  PERFORM internal.validar_payload(p_payload, ARRAY['mascota_id','producto_nombre']);

  SELECT cliente_id INTO v_cliente FROM core.mascotas
   WHERE id = v_mascota AND deleted_at IS NULL
     AND (internal.es_acceso_global(p_user_id, p_is_super_admin) OR empresa_id = v_emp);

  INSERT INTO core.desparasitaciones (
    empresa_id, mascota_id, veterinario_id, consulta_id, producto_id,
    producto_nombre, tipo, dosis, fecha_aplicacion, proxima_dosis, observaciones, created_by
  ) VALUES (
    v_emp, v_mascota,
    COALESCE(NULLIF(p_payload->>'veterinario_id','')::uuid, p_user_id),
    NULLIF(p_payload->>'consulta_id','')::uuid,
    NULLIF(p_payload->>'producto_id','')::uuid,
    p_payload->>'producto_nombre',
    COALESCE(p_payload->>'tipo','interna'),
    p_payload->>'dosis',
    v_fecha, v_proxima,
    p_payload->>'observaciones',
    p_user_id
  ) RETURNING id INTO v_id;

  -- El antiparasitario entregado se descuenta y se cobra, igual que la vacuna.
  IF NULLIF(p_payload->>'producto_id','') IS NOT NULL THEN
    PERFORM internal.consumir_producto_clinico(
      v_emp, (p_payload->>'producto_id')::uuid,
      COALESCE((p_payload->>'cantidad')::numeric, 1), p_user_id,
      jsonb_build_object('mascota_id', v_mascota,
                         'consulta_id', NULLIF(p_payload->>'consulta_id','')::uuid,
                         'observaciones', 'Desparasitación: ' || (p_payload->>'producto_nombre')));
  END IF;

  PERFORM internal.registrar_cargo_servicio(
    v_emp, NULLIF(p_payload->>'servicio_id','')::uuid, v_mascota, p_user_id, 1,
    jsonb_build_object(
      'consulta_id', NULLIF(p_payload->>'consulta_id','')::uuid,
      'veterinario_id', NULLIF(p_payload->>'veterinario_id','')::uuid,
      'descripcion', 'Desparasitación ' || COALESCE(p_payload->>'tipo','interna'),
      'origen_tabla', 'desparasitaciones', 'origen_id', v_id));

  PERFORM internal.registrar_evento_clinico(
    v_emp, v_mascota, v_cliente, p_user_id, 'desparasitacion',
    'Desparasitación ' || COALESCE(p_payload->>'tipo','interna'),
    p_payload->>'producto_nombre', v_id, NULL, v_fecha::timestamptz);

  IF v_proxima IS NOT NULL THEN
    INSERT INTO core.recordatorios (
      empresa_id, cliente_id, mascota_id, tipo, titulo, mensaje,
      fecha_objetivo, entidad_ref, entidad_id)
    VALUES (v_emp, v_cliente, v_mascota, 'desparasitacion',
            'Próxima desparasitación',
            'Corresponde la siguiente dosis de desparasitación.',
            v_proxima, 'desparasitaciones', v_id);
  END IF;

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('id', v_id));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_disponibilidad_eliminar(uuid, uuid, boolean, uuid); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_disponibilidad_eliminar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'rrhh:gestionar');
  DELETE FROM core.disponibilidad
   WHERE id = p_id
     AND internal.es_de_empresa(p_user_id, p_is_super_admin,
           internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin), empresa_id);
  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('eliminado', true));
EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_disponibilidad_guardar(uuid, uuid, boolean, jsonb); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_disponibilidad_guardar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_id  UUID := NULLIF(p_payload->>'id','')::uuid;
  v_emp UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'rrhh:gestionar');

  IF v_id IS NULL THEN
    PERFORM internal.validar_payload(p_payload, ARRAY['user_id','fecha','hora_inicio','hora_fin']);
    INSERT INTO core.disponibilidad (
      empresa_id, user_id, fecha, hora_inicio, hora_fin, tipo, consultorio_id, nota)
    VALUES (
      v_emp, (p_payload->>'user_id')::uuid, (p_payload->>'fecha')::date,
      (p_payload->>'hora_inicio')::time, (p_payload->>'hora_fin')::time,
      COALESCE((p_payload->>'tipo')::core.tipo_disponibilidad, 'laboral'),
      NULLIF(p_payload->>'consultorio_id','')::uuid, p_payload->>'nota')
    RETURNING id INTO v_id;
  ELSE
    IF NOT EXISTS (SELECT 1 FROM core.disponibilidad
                    WHERE id = v_id
                      AND internal.es_de_empresa(p_user_id, p_is_super_admin, v_emp, empresa_id)) THEN
      RETURN jsonb_build_object('ok', false,
        'error', internal.error_jsonb('NOT_FOUND','Turno no encontrado'));
    END IF;

    UPDATE core.disponibilidad SET
      fecha       = COALESCE(NULLIF(p_payload->>'fecha','')::date, fecha),
      hora_inicio = COALESCE(NULLIF(p_payload->>'hora_inicio','')::time, hora_inicio),
      hora_fin    = COALESCE(NULLIF(p_payload->>'hora_fin','')::time, hora_fin),
      tipo        = COALESCE((p_payload->>'tipo')::core.tipo_disponibilidad, tipo),
      consultorio_id = COALESCE(NULLIF(p_payload->>'consultorio_id','')::uuid, consultorio_id),
      nota        = COALESCE(p_payload->>'nota', nota)
    WHERE id = v_id;
  END IF;

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('id', v_id));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_documento_medico_registrar(uuid, uuid, boolean, jsonb); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_documento_medico_registrar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_id      UUID;
  v_emp     UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_mascota UUID := (p_payload->>'mascota_id')::uuid;
  v_cliente UUID;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'clinico:registrar');

  PERFORM internal.validar_payload(p_payload, ARRAY['mascota_id','titulo','storage_key']);

  SELECT cliente_id INTO v_cliente FROM core.mascotas
   WHERE id = v_mascota AND deleted_at IS NULL
     AND (internal.es_acceso_global(p_user_id, p_is_super_admin) OR empresa_id = v_emp);

  INSERT INTO core.documentos_medicos (
    empresa_id, mascota_id, consulta_id, tipo, titulo, descripcion,
    storage_key, mime_type, tamanio_bytes, created_by
  ) VALUES (
    v_emp, v_mascota,
    NULLIF(p_payload->>'consulta_id','')::uuid,
    COALESCE(p_payload->>'tipo','otro'),
    p_payload->>'titulo', p_payload->>'descripcion',
    p_payload->>'storage_key', p_payload->>'mime_type',
    NULLIF(p_payload->>'tamanio_bytes','')::bigint,
    p_user_id
  ) RETURNING id INTO v_id;

  PERFORM internal.registrar_evento_clinico(
    v_emp, v_mascota, v_cliente, p_user_id, 'documento',
    'Documento: ' || (p_payload->>'titulo'), p_payload->>'descripcion', v_id);

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('id', v_id));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_empresa_actualizar(uuid, uuid, boolean, uuid, jsonb); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_empresa_actualizar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid, p_payload jsonb) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_antes JSONB;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'empresa:configurar');

  PERFORM internal.assert_acceso_empresa(p_user_id, p_id, p_is_super_admin);

  SELECT to_jsonb(e) - 'pse_password_enc' INTO v_antes
  FROM core.empresas e WHERE e.id = p_id AND e.deleted_at IS NULL;

  IF v_antes IS NULL THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Empresa no encontrada'));
  END IF;

  UPDATE core.empresas SET
    razon_social      = COALESCE(p_payload->>'razon_social', razon_social),
    nombre_comercial  = COALESCE(p_payload->>'nombre_comercial', nombre_comercial),
    direccion_fiscal  = COALESCE(p_payload->>'direccion_fiscal', direccion_fiscal),
    ubigeo            = COALESCE(p_payload->>'ubigeo', ubigeo),
    telefono          = COALESCE(p_payload->>'telefono', telefono),
    correo            = COALESCE(p_payload->>'correo', correo),
    logo_url          = COALESCE(p_payload->>'logo_url', logo_url),
    serie_factura_default = COALESCE(p_payload->>'serie_factura_default', serie_factura_default),
    serie_boleta_default  = COALESCE(p_payload->>'serie_boleta_default', serie_boleta_default),
    serie_nota_venta_default = COALESCE(p_payload->>'serie_nota_venta_default', serie_nota_venta_default),
    igv_tasa          = COALESCE((p_payload->>'igv_tasa')::numeric, igv_tasa),
    aforo_consultorios = COALESCE((p_payload->>'aforo_consultorios')::int, aforo_consultorios),
    duracion_cita_min = COALESCE((p_payload->>'duracion_cita_min')::int, duracion_cita_min),
    serie_nota_credito_default = COALESCE(p_payload->>'serie_nota_credito_default', serie_nota_credito_default),
    -- Datos fiscales que SUNAT exige del emisor. Se guardan por separado del
    -- domicilio porque el proveedor los pide como nodos, y recortados a 30
    -- caracteres: más largo y SUNAT rechaza el comprobante (error 113).
    urbanizacion      = COALESCE(p_payload->>'urbanizacion', urbanizacion),
    distrito          = COALESCE(p_payload->>'distrito', distrito),
    provincia         = COALESCE(p_payload->>'provincia', provincia),
    departamento      = COALESCE(p_payload->>'departamento', departamento),
    emite_electronico = COALESCE((p_payload->>'emite_electronico')::boolean, emite_electronico),
    pse_proveedor     = COALESCE(p_payload->>'pse_proveedor', pse_proveedor),
    pse_ruc           = COALESCE(p_payload->>'pse_ruc', pse_ruc),
    pse_endpoint      = COALESCE(p_payload->>'pse_endpoint', pse_endpoint),
    pse_usuario       = COALESCE(p_payload->>'pse_usuario', pse_usuario),
    pse_password_enc  = COALESCE(p_payload->>'pse_password_enc', pse_password_enc),
    estado            = COALESCE((p_payload->>'estado')::core.estado_empresa, estado),
    updated_by        = p_user_id
  WHERE id = p_id;

  -- La clave del PSE no entra a la bitácora: el blob cifrado en la auditoría es
  -- una copia más del secreto, en una tabla que lee más gente.
  PERFORM internal.registrar_auditoria(
    p_user_id, p_id, 'actualizar', 'empresas', p_id, v_antes,
    p_payload - 'pse_password_enc' - 'pse_password');

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('id', p_id));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_empresa_crear(uuid, uuid, boolean, jsonb); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_empresa_crear(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_id  UUID;
  v_ruc TEXT := internal.normalizar_documento(p_payload->>'ruc');
BEGIN
  IF NOT p_is_super_admin THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('FORBIDDEN','Solo un super administrador puede crear empresas'));
  END IF;

  PERFORM internal.validar_payload(p_payload, ARRAY['ruc','razon_social']);

  IF NOT internal.validar_ruc(v_ruc) THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('VALIDATION_ERROR','El RUC no es válido','ruc'));
  END IF;

  IF EXISTS (SELECT 1 FROM core.empresas WHERE ruc = v_ruc AND deleted_at IS NULL) THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('CONFLICT','Ya existe una empresa con ese RUC','ruc'));
  END IF;

  INSERT INTO core.empresas (
    ruc, razon_social, nombre_comercial, direccion_fiscal, ubigeo,
    telefono, correo, logo_url, serie_factura_default, serie_boleta_default,
    serie_nota_venta_default, aforo_consultorios, duracion_cita_min, created_by
  ) VALUES (
    v_ruc,
    p_payload->>'razon_social',
    p_payload->>'nombre_comercial',
    p_payload->>'direccion_fiscal',
    p_payload->>'ubigeo',
    p_payload->>'telefono',
    p_payload->>'correo',
    p_payload->>'logo_url',
    COALESCE(p_payload->>'serie_factura_default','F001'),
    COALESCE(p_payload->>'serie_boleta_default','B001'),
    COALESCE(p_payload->>'serie_nota_venta_default','NV01'),
    COALESCE((p_payload->>'aforo_consultorios')::int, 1),
    COALESCE((p_payload->>'duracion_cita_min')::int, 30),
    p_user_id
  ) RETURNING id INTO v_id;

  -- Almacén principal: sin él, ningún movimiento de inventario tiene destino.
  INSERT INTO core.almacenes (empresa_id, codigo, nombre, es_principal)
  VALUES (v_id, 'ALM-01', 'Almacén principal', true);

  -- Un consultorio para que la agenda funcione desde el día uno.
  INSERT INTO core.consultorios (empresa_id, nombre, tipo)
  VALUES (v_id, 'Consultorio 1', 'consulta');

  PERFORM internal.registrar_auditoria(
    p_user_id, v_id, 'crear', 'empresas', v_id, NULL, p_payload);

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('id', v_id));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_especializacion_guardar(uuid, uuid, boolean, jsonb); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_especializacion_guardar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_id UUID := NULLIF(p_payload->>'id','')::uuid;
BEGIN
  IF NOT p_is_super_admin THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('FORBIDDEN',
        'La taxonomía (especies, razas y especialidades) la mantiene el operador del ERP: '
        'es compartida por todas las empresas'));
  END IF;
  PERFORM internal.assert_permiso(p_user_id, 'catalogos:gestionar');

  IF v_id IS NULL THEN
    PERFORM internal.validar_payload(p_payload, ARRAY['nombre']);
    INSERT INTO core.especializaciones (codigo, nombre, descripcion, estado)
    VALUES (
      COALESCE(NULLIF(p_payload->>'codigo',''),
               upper(regexp_replace(internal.normalizar(p_payload->>'nombre'), '[^a-z0-9]+', '_', 'g'))),
      p_payload->>'nombre', p_payload->>'descripcion',
      COALESCE((p_payload->>'estado')::core.estado_generico, 'activo'))
    RETURNING id INTO v_id;
  ELSE
    UPDATE core.especializaciones SET
      nombre      = COALESCE(p_payload->>'nombre', nombre),
      descripcion = COALESCE(p_payload->>'descripcion', descripcion),
      estado      = COALESCE((p_payload->>'estado')::core.estado_generico, estado)
    WHERE id = v_id;
  END IF;

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('id', v_id));

EXCEPTION
  WHEN unique_violation THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('CONFLICT','Ya existe una especialidad con ese código','codigo'));
  WHEN OTHERS THEN
    RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_especie_guardar(uuid, uuid, boolean, jsonb); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_especie_guardar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_id UUID := NULLIF(p_payload->>'id','')::uuid;
BEGIN
  IF NOT p_is_super_admin THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('FORBIDDEN',
        'La taxonomía (especies, razas y especialidades) la mantiene el operador del ERP: '
        'es compartida por todas las empresas'));
  END IF;
  PERFORM internal.assert_permiso(p_user_id, 'catalogos:gestionar');
  PERFORM internal.validar_payload(p_payload, ARRAY['nombre']);

  IF v_id IS NULL THEN
    INSERT INTO core.especies (codigo, nombre, nombre_cria, icono, estado)
    VALUES (
      COALESCE(NULLIF(p_payload->>'codigo',''),
               upper(regexp_replace(internal.normalizar(p_payload->>'nombre'), '[^a-z0-9]+', '_', 'g'))),
      p_payload->>'nombre', p_payload->>'nombre_cria',
      COALESCE(NULLIF(p_payload->>'icono',''), 'PawPrint'),
      COALESCE((p_payload->>'estado')::core.estado_generico, 'activo'))
    RETURNING id INTO v_id;
  ELSE
    UPDATE core.especies SET
      nombre      = COALESCE(p_payload->>'nombre', nombre),
      nombre_cria = COALESCE(p_payload->>'nombre_cria', nombre_cria),
      icono       = COALESCE(NULLIF(p_payload->>'icono',''), icono),
      estado      = COALESCE((p_payload->>'estado')::core.estado_generico, estado)
    WHERE id = v_id;
  END IF;

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('id', v_id));

EXCEPTION
  WHEN unique_violation THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('CONFLICT','Ya existe una especie con ese código','codigo'));
  WHEN OTHERS THEN
    RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_esquema_vacunacion_guardar(uuid, uuid, boolean, jsonb); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_esquema_vacunacion_guardar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_id  UUID := NULLIF(p_payload->>'id','')::uuid;
  v_emp UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'catalogos:gestionar');

  IF v_id IS NULL THEN
    PERFORM internal.validar_payload(p_payload, ARRAY['especie_id','nombre']);
    INSERT INTO core.esquemas_vacunacion (
      empresa_id, especie_id, nombre, descripcion, obligatoria,
      edad_inicio_semanas, intervalo_dias, dosis_totales, revacunacion_meses, estado
    ) VALUES (
      v_emp, (p_payload->>'especie_id')::uuid, p_payload->>'nombre', p_payload->>'descripcion',
      COALESCE((p_payload->>'obligatoria')::boolean, false),
      NULLIF(p_payload->>'edad_inicio_semanas','')::int,
      NULLIF(p_payload->>'intervalo_dias','')::int,
      COALESCE((p_payload->>'dosis_totales')::int, 1),
      NULLIF(p_payload->>'revacunacion_meses','')::int,
      COALESCE((p_payload->>'estado')::core.estado_generico, 'activo'))
    RETURNING id INTO v_id;
  ELSE
    IF NOT EXISTS (SELECT 1 FROM core.esquemas_vacunacion
                    WHERE id = v_id
                      AND internal.es_de_empresa(p_user_id, p_is_super_admin, v_emp, empresa_id)) THEN
      RETURN jsonb_build_object('ok', false,
        'error', internal.error_jsonb('NOT_FOUND','Protocolo no encontrado'));
    END IF;

    UPDATE core.esquemas_vacunacion SET
      nombre              = COALESCE(p_payload->>'nombre', nombre),
      descripcion         = COALESCE(p_payload->>'descripcion', descripcion),
      obligatoria         = COALESCE((p_payload->>'obligatoria')::boolean, obligatoria),
      edad_inicio_semanas = COALESCE(NULLIF(p_payload->>'edad_inicio_semanas','')::int, edad_inicio_semanas),
      intervalo_dias      = COALESCE(NULLIF(p_payload->>'intervalo_dias','')::int, intervalo_dias),
      dosis_totales       = COALESCE((p_payload->>'dosis_totales')::int, dosis_totales),
      revacunacion_meses  = COALESCE(NULLIF(p_payload->>'revacunacion_meses','')::int, revacunacion_meses),
      estado              = COALESCE((p_payload->>'estado')::core.estado_generico, estado)
    WHERE id = v_id;
  END IF;

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('id', v_id));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_evaluacion_registrar(uuid, uuid, boolean, jsonb); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_evaluacion_registrar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_id  UUID;
  v_emp UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'rrhh:gestionar');
  PERFORM internal.validar_payload(p_payload, ARRAY['user_id','periodo']);

  INSERT INTO core.evaluaciones_personal (
    empresa_id, user_id, evaluador_id, periodo, fecha,
    puntualidad, eficiencia, calidad_atencion, trabajo_equipo, observaciones)
  VALUES (
    v_emp, (p_payload->>'user_id')::uuid, p_user_id, p_payload->>'periodo',
    COALESCE(NULLIF(p_payload->>'fecha','')::date, CURRENT_DATE),
    NULLIF(p_payload->>'puntualidad','')::int,
    NULLIF(p_payload->>'eficiencia','')::int,
    NULLIF(p_payload->>'calidad_atencion','')::int,
    NULLIF(p_payload->>'trabajo_equipo','')::int,
    p_payload->>'observaciones')
  RETURNING id INTO v_id;

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('id', v_id));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_examen_registrar(uuid, uuid, boolean, jsonb); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_examen_registrar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_id      UUID;
  v_emp     UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_mascota UUID := (p_payload->>'mascota_id')::uuid;
  v_cliente UUID;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'clinico:registrar');
  PERFORM internal.validar_payload(p_payload, ARRAY['mascota_id','tipo','nombre']);

  SELECT cliente_id INTO v_cliente FROM core.mascotas
   WHERE id = v_mascota AND deleted_at IS NULL
     AND (internal.es_acceso_global(p_user_id, p_is_super_admin) OR empresa_id = v_emp);

  INSERT INTO core.examenes (
    empresa_id, mascota_id, consulta_id, servicio_id, veterinario_id,
    tipo, nombre, fecha_solicitud, fecha_resultado, resultado, valores,
    interpretacion, archivo_url, created_by
  ) VALUES (
    v_emp, v_mascota,
    NULLIF(p_payload->>'consulta_id','')::uuid,
    NULLIF(p_payload->>'servicio_id','')::uuid,
    COALESCE(NULLIF(p_payload->>'veterinario_id','')::uuid, p_user_id),
    p_payload->>'tipo', p_payload->>'nombre',
    COALESCE(NULLIF(p_payload->>'fecha_solicitud','')::timestamptz, now()),
    NULLIF(p_payload->>'fecha_resultado','')::timestamptz,
    p_payload->>'resultado',
    CASE WHEN p_payload ? 'valores' THEN p_payload->'valores' END,
    p_payload->>'interpretacion',
    p_payload->>'archivo_url',
    p_user_id
  ) RETURNING id INTO v_id;

  PERFORM internal.registrar_evento_clinico(
    v_emp, v_mascota, v_cliente, p_user_id, 'examen',
    (p_payload->>'tipo') || ': ' || (p_payload->>'nombre'),
    p_payload->>'interpretacion', v_id);

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('id', v_id));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_horarios_atencion_guardar(uuid, uuid, boolean, jsonb); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_horarios_atencion_guardar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_horarios jsonb) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_emp  UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_item JSONB;
  v_n    INT := 0;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'catalogos:gestionar');

  DELETE FROM core.horarios_atencion WHERE empresa_id = v_emp;

  FOR v_item IN SELECT * FROM jsonb_array_elements(p_horarios) LOOP
    INSERT INTO core.horarios_atencion (empresa_id, dia_semana, hora_inicio, hora_fin, activo, es_guardia)
    VALUES (
      v_emp,
      (v_item->>'dia_semana')::int,
      (v_item->>'hora_inicio')::time,
      (v_item->>'hora_fin')::time,
      COALESCE((v_item->>'activo')::boolean, true),
      COALESCE((v_item->>'es_guardia')::boolean, false));
    v_n := v_n + 1;
  END LOOP;

  PERFORM internal.registrar_auditoria(
    p_user_id, v_emp, 'guardar', 'horarios_atencion', NULL, NULL, p_horarios);

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('guardados', v_n));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_hospitalizacion_alta(uuid, uuid, boolean, uuid, jsonb); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_hospitalizacion_alta(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid, p_payload jsonb DEFAULT '{}'::jsonb) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_h    RECORD;
  v_emp  UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_alta TIMESTAMPTZ;
  v_dias INT;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'clinico:registrar');

  SELECT * INTO v_h FROM core.hospitalizaciones
   WHERE id = p_id
     AND internal.es_de_empresa(p_user_id, p_is_super_admin,
           internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin), empresa_id);
  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Hospitalización no encontrada'));
  END IF;

  v_alta := COALESCE(NULLIF(p_payload->>'fecha_alta','')::timestamptz, now());

  UPDATE core.hospitalizaciones SET
    fecha_alta        = v_alta,
    indicaciones_alta = COALESCE(p_payload->>'indicaciones_alta', indicaciones_alta),
    estado            = COALESCE((p_payload->>'estado')::core.estado_hospitalizacion, 'alta')
  WHERE id = p_id;

  -- Días de internamiento. Se cobra el día de ingreso y cada día iniciado
  -- después: así es como lo cobra una clínica, y así cuadra con lo que el
  -- propietario ve en la factura.
  v_dias := GREATEST(1, CEIL(EXTRACT(EPOCH FROM (v_alta - v_h.fecha_ingreso)) / 86400.0)::int);

  PERFORM internal.registrar_cargo_servicio(
    v_emp, NULLIF(p_payload->>'servicio_id','')::uuid, v_h.mascota_id, p_user_id, v_dias,
    jsonb_build_object(
      'veterinario_id', v_h.veterinario_id,
      'descripcion', 'Hospitalización · ' || v_dias || ' día(s)',
      'origen_tabla', 'hospitalizaciones', 'origen_id', p_id));

  PERFORM internal.registrar_auditoria(
    p_user_id, v_h.empresa_id, 'alta', 'hospitalizaciones', p_id, NULL,
    jsonb_build_object('dias', v_dias, 'fecha_alta', v_alta));

  RETURN jsonb_build_object('ok', true,
    'data', jsonb_build_object('id', p_id, 'dias', v_dias));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_hospitalizacion_evolucion(uuid, uuid, boolean, jsonb); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_hospitalizacion_evolucion(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_id UUID;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'clinico:registrar');
  PERFORM internal.validar_payload(p_payload, ARRAY['hospitalizacion_id']);

  IF NOT EXISTS (
      SELECT 1 FROM core.hospitalizaciones h
       WHERE h.id = (p_payload->>'hospitalizacion_id')::uuid
         AND internal.es_de_empresa(p_user_id, p_is_super_admin,
               internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin), h.empresa_id)) THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Hospitalización no encontrada','hospitalizacion_id'));
  END IF;

  INSERT INTO core.hospitalizacion_evoluciones (
    hospitalizacion_id, user_id, fecha_hora, temperatura_c,
    frecuencia_cardiaca, frecuencia_respiratoria, come, orina, defeca, nota
  ) VALUES (
    (p_payload->>'hospitalizacion_id')::uuid, p_user_id,
    COALESCE(NULLIF(p_payload->>'fecha_hora','')::timestamptz, now()),
    NULLIF(p_payload->>'temperatura_c','')::numeric,
    NULLIF(p_payload->>'frecuencia_cardiaca','')::int,
    NULLIF(p_payload->>'frecuencia_respiratoria','')::int,
    NULLIF(p_payload->>'come','')::boolean,
    NULLIF(p_payload->>'orina','')::boolean,
    NULLIF(p_payload->>'defeca','')::boolean,
    p_payload->>'nota'
  ) RETURNING id INTO v_id;

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('id', v_id));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_hospitalizacion_ingresar(uuid, uuid, boolean, jsonb); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_hospitalizacion_ingresar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_id      UUID;
  v_emp     UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_mascota UUID := (p_payload->>'mascota_id')::uuid;
  v_cliente UUID;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'clinico:registrar');
  PERFORM internal.validar_payload(p_payload, ARRAY['mascota_id','motivo']);

  IF EXISTS (SELECT 1 FROM core.hospitalizaciones
              WHERE mascota_id = v_mascota AND estado IN ('ingresado','en_observacion')) THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('CONFLICT','El paciente ya está hospitalizado'));
  END IF;

  SELECT cliente_id INTO v_cliente FROM core.mascotas
   WHERE id = v_mascota AND deleted_at IS NULL
     AND (internal.es_acceso_global(p_user_id, p_is_super_admin) OR empresa_id = v_emp);

  INSERT INTO core.hospitalizaciones (
    empresa_id, codigo, mascota_id, veterinario_id, consultorio_id, jaula,
    motivo, diagnostico, fecha_ingreso, estado, created_by
  ) VALUES (
    v_emp, internal.siguiente_numero(v_emp, 'HOSP', 5), v_mascota,
    COALESCE(NULLIF(p_payload->>'veterinario_id','')::uuid, p_user_id),
    NULLIF(p_payload->>'consultorio_id','')::uuid,
    p_payload->>'jaula', p_payload->>'motivo', p_payload->>'diagnostico',
    COALESCE(NULLIF(p_payload->>'fecha_ingreso','')::timestamptz, now()),
    'ingresado', p_user_id
  ) RETURNING id INTO v_id;

  PERFORM internal.registrar_evento_clinico(
    v_emp, v_mascota, v_cliente, p_user_id, 'hospitalizacion',
    'Ingreso a hospitalización', p_payload->>'motivo', v_id);

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('id', v_id));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_insumo_consumir(uuid, uuid, boolean, jsonb); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_insumo_consumir(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_id      UUID;
  v_emp     UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_prod    UUID := (p_payload->>'producto_id')::uuid;
  v_cant    NUMERIC := (p_payload->>'cantidad')::numeric;
  v_precio  NUMERIC(12,2);
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'clinico:registrar');
  PERFORM internal.validar_payload(p_payload, ARRAY['producto_id','cantidad']);

  SELECT COALESCE(NULLIF(p_payload->>'precio_unitario','')::numeric, precio_venta)
    INTO v_precio FROM core.productos
   WHERE id = v_prod AND deleted_at IS NULL
     AND internal.es_de_empresa(p_user_id, p_is_super_admin, v_emp, empresa_id);

  IF v_precio IS NULL THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Producto no encontrado','producto_id'));
  END IF;

  -- Descuenta del inventario (por lote, FEFO) y deja el consumo pendiente de
  -- cobro. El paciente se deriva del acto si no vino en el payload: sin eso, el
  -- insumo salía del almacén y no llegaba nunca a la cuenta del propietario.
  v_id := internal.consumir_producto_clinico(
    v_emp, v_prod, v_cant, p_user_id,
    p_payload || jsonb_build_object('precio_unitario', v_precio));

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('id', v_id));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_inventario_movimiento(uuid, uuid, boolean, jsonb); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_inventario_movimiento(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_id  UUID;
  v_emp UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'inventario:mover');
  PERFORM internal.validar_payload(p_payload, ARRAY['producto_id','tipo','motivo','cantidad']);

  IF NOT EXISTS (SELECT 1 FROM core.productos
                  WHERE id = (p_payload->>'producto_id')::uuid AND deleted_at IS NULL
                    AND internal.es_de_empresa(p_user_id, p_is_super_admin, v_emp, empresa_id)) THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Producto no encontrado','producto_id'));
  END IF;

  v_id := internal.mover_stock(
    v_emp,
    (p_payload->>'producto_id')::uuid,
    (p_payload->>'tipo')::core.tipo_movimiento_inventario,
    (p_payload->>'motivo')::core.motivo_movimiento,
    (p_payload->>'cantidad')::numeric,
    p_user_id,
    NULLIF(p_payload->>'almacen_id','')::uuid,
    jsonb_build_object(
      'costo_unitario',      p_payload->>'costo_unitario',
      'almacen_destino_id',  p_payload->>'almacen_destino_id',
      'lote_id',             p_payload->>'lote_id',
      'proveedor_id',        p_payload->>'proveedor_id',
      'cliente_id',          p_payload->>'cliente_id',
      'mascota_id',          p_payload->>'mascota_id',
      'observaciones',       p_payload->>'observaciones'));

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('id', v_id));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_lista_espera_anotar(uuid, uuid, boolean, jsonb); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_lista_espera_anotar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_id      UUID;
  v_emp     UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_mascota UUID := (p_payload->>'mascota_id')::uuid;
  v_cliente UUID;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'citas:crear');
  PERFORM internal.validar_payload(p_payload, ARRAY['mascota_id','desde']);

  -- El propietario se deriva del paciente, igual que al agendar: así no se
  -- puede anotar a un paciente de otra empresa pasando su id.
  SELECT cliente_id INTO v_cliente FROM core.mascotas
   WHERE id = v_mascota AND deleted_at IS NULL
     AND (internal.es_acceso_global(p_user_id, p_is_super_admin) OR empresa_id = v_emp);
  IF v_cliente IS NULL THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','El paciente indicado no existe','mascota_id'));
  END IF;

  INSERT INTO core.citas_lista_espera (
    empresa_id, cliente_id, mascota_id, servicio_id, veterinario_id, desde, hasta, nota)
  VALUES (
    v_emp, v_cliente, v_mascota,
    NULLIF(p_payload->>'servicio_id','')::uuid,
    NULLIF(p_payload->>'veterinario_id','')::uuid,
    (p_payload->>'desde')::date,
    NULLIF(p_payload->>'hasta','')::date,
    p_payload->>'nota')
  RETURNING id INTO v_id;

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('id', v_id));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_lista_espera_resolver(uuid, uuid, boolean, uuid); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_lista_espera_resolver(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_emp UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'citas:editar');

  UPDATE core.citas_lista_espera SET atendido = true
   WHERE id = p_id
     AND internal.es_de_empresa(p_user_id, p_is_super_admin, v_emp, empresa_id);

  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Anotación no encontrada'));
  END IF;

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('id', p_id, 'atendido', true));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_lote_registrar(uuid, uuid, boolean, jsonb); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_lote_registrar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_id  UUID;
  v_emp UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'inventario:gestionar');
  PERFORM internal.validar_payload(p_payload, ARRAY['producto_id','numero_lote','cantidad']);

  IF NOT EXISTS (SELECT 1 FROM core.productos
                  WHERE id = (p_payload->>'producto_id')::uuid AND deleted_at IS NULL
                    AND internal.es_de_empresa(p_user_id, p_is_super_admin, v_emp, empresa_id)) THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Producto no encontrado','producto_id'));
  END IF;

  INSERT INTO core.lotes (empresa_id, producto_id, numero_lote, fecha_vencimiento, cantidad, costo_unitario)
  VALUES (v_emp, (p_payload->>'producto_id')::uuid, p_payload->>'numero_lote',
          NULLIF(p_payload->>'fecha_vencimiento','')::date,
          0,  -- el movimiento de entrada es el que suma; así no se duplica
          COALESCE((p_payload->>'costo_unitario')::numeric, 0))
  ON CONFLICT (producto_id, numero_lote) DO UPDATE
    SET fecha_vencimiento = COALESCE(EXCLUDED.fecha_vencimiento, core.lotes.fecha_vencimiento),
        costo_unitario    = COALESCE(NULLIF(EXCLUDED.costo_unitario, 0), core.lotes.costo_unitario),
        updated_at = now()
  RETURNING id INTO v_id;

  PERFORM internal.mover_stock(
    v_emp, (p_payload->>'producto_id')::uuid, 'entrada', 'compra',
    (p_payload->>'cantidad')::numeric, p_user_id,
    NULLIF(p_payload->>'almacen_id','')::uuid,
    jsonb_build_object('lote_id', v_id,
                       'costo_unitario', p_payload->>'costo_unitario',
                       'proveedor_id', p_payload->>'proveedor_id',
                       'observaciones', 'Ingreso de lote ' || (p_payload->>'numero_lote')));

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('id', v_id));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_mascota_actualizar(uuid, uuid, boolean, uuid, jsonb); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_mascota_actualizar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid, p_payload jsonb) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_antes JSONB;
  v_emp   UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_chip  TEXT := NULLIF(p_payload->>'microchip','');
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'mascotas:editar');

  SELECT to_jsonb(m) INTO v_antes FROM core.mascotas m
   WHERE m.id = p_id AND m.deleted_at IS NULL
     AND (internal.es_acceso_global(p_user_id, p_is_super_admin) OR m.empresa_id = v_emp);

  IF v_antes IS NULL THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Paciente no encontrado'));
  END IF;

  IF v_chip IS NOT NULL AND EXISTS (
      SELECT 1 FROM core.mascotas
       WHERE empresa_id = (v_antes->>'empresa_id')::uuid
         AND microchip = v_chip AND id <> p_id AND deleted_at IS NULL) THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('CONFLICT','Ese microchip ya está registrado en otro paciente','microchip'));
  END IF;

  UPDATE core.mascotas SET
    nombre               = COALESCE(p_payload->>'nombre', nombre),
    especie_id           = COALESCE(NULLIF(p_payload->>'especie_id','')::uuid, especie_id),
    raza_id              = COALESCE(NULLIF(p_payload->>'raza_id','')::uuid, raza_id),
    sexo                 = COALESCE((p_payload->>'sexo')::core.sexo_mascota, sexo),
    color                = COALESCE(p_payload->>'color', color),
    senias_particulares  = COALESCE(p_payload->>'senias_particulares', senias_particulares),
    fecha_nacimiento     = COALESCE(NULLIF(p_payload->>'fecha_nacimiento','')::date, fecha_nacimiento),
    edad_aproximada_meses = COALESCE(NULLIF(p_payload->>'edad_aproximada_meses','')::int, edad_aproximada_meses),
    peso_kg              = COALESCE(NULLIF(p_payload->>'peso_kg','')::numeric, peso_kg),
    tamanio              = COALESCE(NULLIF(p_payload->>'tamanio','')::core.tamanio_mascota, tamanio),
    esterilizado         = COALESCE((p_payload->>'esterilizado')::boolean, esterilizado),
    fecha_esterilizacion = COALESCE(NULLIF(p_payload->>'fecha_esterilizacion','')::date, fecha_esterilizacion),
    microchip            = COALESCE(v_chip, microchip),
    num_placa            = COALESCE(NULLIF(p_payload->>'num_placa',''), num_placa),
    foto_url             = COALESCE(p_payload->>'foto_url', foto_url),
    alergias             = COALESCE(p_payload->>'alergias', alergias),
    condiciones_cronicas = COALESCE(p_payload->>'condiciones_cronicas', condiciones_cronicas),
    observaciones        = COALESCE(p_payload->>'observaciones', observaciones),
    estado               = COALESCE((p_payload->>'estado')::core.estado_mascota, estado),
    fecha_fallecimiento  = COALESCE(NULLIF(p_payload->>'fecha_fallecimiento','')::date, fecha_fallecimiento),
    updated_by           = p_user_id
  WHERE id = p_id;

  PERFORM internal.registrar_auditoria(
    p_user_id, v_emp, 'actualizar', 'mascotas', p_id, v_antes, p_payload);

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('id', p_id));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_mascota_crear(uuid, uuid, boolean, jsonb); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_mascota_crear(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_id   UUID;
  v_emp  UUID;   -- se hereda del propietario, ver abajo
  v_chip TEXT := NULLIF(p_payload->>'microchip','');
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'mascotas:crear');
  PERFORM internal.validar_payload(p_payload, ARRAY['cliente_id','nombre','especie_id']);

  -- La empresa la manda el propietario, no el payload: así una mascota nunca
  -- queda en una empresa distinta a la de su dueño.
  SELECT empresa_id INTO v_emp FROM core.clientes
   WHERE id = (p_payload->>'cliente_id')::uuid AND deleted_at IS NULL
     AND (internal.es_acceso_global(p_user_id, p_is_super_admin)
          OR empresa_id = internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin));

  IF v_emp IS NULL THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','El propietario indicado no existe','cliente_id'));
  END IF;

  IF v_chip IS NOT NULL AND EXISTS (
      SELECT 1 FROM core.mascotas
       WHERE empresa_id = v_emp AND microchip = v_chip AND deleted_at IS NULL) THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('CONFLICT','Ese microchip ya está registrado en otro paciente','microchip'));
  END IF;

  INSERT INTO core.mascotas (
    empresa_id, codigo, cliente_id, nombre, especie_id, raza_id, sexo, color,
    senias_particulares, fecha_nacimiento, edad_aproximada_meses, peso_kg, tamanio,
    esterilizado, fecha_esterilizacion, microchip, num_placa, foto_url,
    alergias, condiciones_cronicas, observaciones, created_by
  ) VALUES (
    v_emp,
    COALESCE(NULLIF(p_payload->>'codigo',''), internal.siguiente_numero(v_emp, 'HC', 6)),
    (p_payload->>'cliente_id')::uuid,
    p_payload->>'nombre',
    (p_payload->>'especie_id')::uuid,
    NULLIF(p_payload->>'raza_id','')::uuid,
    COALESCE((p_payload->>'sexo')::core.sexo_mascota, 'desconocido'),
    p_payload->>'color',
    p_payload->>'senias_particulares',
    NULLIF(p_payload->>'fecha_nacimiento','')::date,
    NULLIF(p_payload->>'edad_aproximada_meses','')::int,
    NULLIF(p_payload->>'peso_kg','')::numeric,
    NULLIF(p_payload->>'tamanio','')::core.tamanio_mascota,
    COALESCE((p_payload->>'esterilizado')::boolean, false),
    NULLIF(p_payload->>'fecha_esterilizacion','')::date,
    v_chip,
    NULLIF(p_payload->>'num_placa',''),
    p_payload->>'foto_url',
    p_payload->>'alergias',
    p_payload->>'condiciones_cronicas',
    p_payload->>'observaciones',
    p_user_id
  ) RETURNING id INTO v_id;

  PERFORM internal.registrar_auditoria(p_user_id, v_emp, 'crear', 'mascotas', v_id, NULL, p_payload);

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('id', v_id));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_mascota_eliminar(uuid, uuid, boolean, uuid); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_mascota_eliminar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_eventos INT;
  v_emp     UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'mascotas:eliminar');

  IF NOT EXISTS (SELECT 1 FROM core.mascotas
                  WHERE id = p_id AND deleted_at IS NULL
                    AND (internal.es_acceso_global(p_user_id, p_is_super_admin)
                         OR empresa_id = v_emp)) THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Paciente no encontrado'));
  END IF;

  SELECT count(*) INTO v_eventos FROM core.historia_clinica WHERE mascota_id = p_id;

  IF v_eventos > 0 THEN
    UPDATE core.mascotas SET estado = 'inactivo', updated_by = p_user_id
     WHERE id = p_id AND deleted_at IS NULL;
    RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object(
      'id', p_id, 'desactivado', true,
      'mensaje', 'El paciente tiene historia clínica: se marcó como inactivo. La historia se conserva.'));
  END IF;

  UPDATE core.mascotas SET deleted_at = now(), estado = 'inactivo', updated_by = p_user_id
   WHERE id = p_id AND deleted_at IS NULL;

  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Paciente no encontrado'));
  END IF;

  PERFORM internal.registrar_auditoria(p_user_id, p_empresa_id, 'eliminar', 'mascotas', p_id);
  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('id', p_id, 'eliminado', true));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_mascota_marcar_encontrada(uuid, uuid, boolean, uuid); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_mascota_marcar_encontrada(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_mascota UUID;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'mascotas:editar');

  UPDATE core.mascotas_extraviadas
     SET encontrado = true, fecha_hallazgo = CURRENT_DATE
   WHERE id = p_id
     AND (internal.es_acceso_global(p_user_id, p_is_super_admin)
          OR empresa_id = internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin))
   RETURNING mascota_id INTO v_mascota;

  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Reporte no encontrado'));
  END IF;

  UPDATE core.mascotas SET estado = 'activo', updated_by = p_user_id WHERE id = v_mascota;

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('id', p_id, 'encontrado', true));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_mascota_reportar_extravio(uuid, uuid, boolean, jsonb); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_mascota_reportar_extravio(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_id  UUID;
  v_emp UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'mascotas:editar');

  PERFORM internal.validar_payload(p_payload, ARRAY['mascota_id','fecha_extravio']);

  IF NOT EXISTS (SELECT 1 FROM core.mascotas
                  WHERE id = (p_payload->>'mascota_id')::uuid AND deleted_at IS NULL
                    AND (internal.es_acceso_global(p_user_id, p_is_super_admin)
                         OR empresa_id = v_emp)) THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Paciente no encontrado','mascota_id'));
  END IF;

  INSERT INTO core.mascotas_extraviadas (
    empresa_id, mascota_id, fecha_extravio, zona, descripcion, contacto, recompensa, created_by
  ) VALUES (
    v_emp,
    (p_payload->>'mascota_id')::uuid,
    (p_payload->>'fecha_extravio')::date,
    p_payload->>'zona',
    p_payload->>'descripcion',
    p_payload->>'contacto',
    NULLIF(p_payload->>'recompensa','')::numeric,
    p_user_id
  ) RETURNING id INTO v_id;

  UPDATE core.mascotas SET estado = 'extraviado', updated_by = p_user_id
   WHERE id = (p_payload->>'mascota_id')::uuid;

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('id', v_id));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_nota_credito_emitir(uuid, uuid, boolean, jsonb); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_nota_credito_emitir(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_id      UUID;
  v_emp     UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_ref     RECORD;
  v_serie   TEXT;
  v_numero  INT;
  v_motivo  TEXT := NULLIF(trim(p_payload->>'motivo'), '');
  v_items   JSONB := COALESCE(p_payload->'items', '[]'::jsonb);
  v_item    JSONB;
  v_orden   INT := 0;
  v_ci      RECORD;
  v_cant    NUMERIC(12,2);
  v_total   NUMERIC(14,2) := 0;
  v_acred   NUMERIC(12,2);
  v_repone  BOOLEAN := COALESCE((p_payload->>'repone_stock')::boolean, true);
  v_electronico BOOLEAN;
  -- Catálogo SUNAT 09. El motivo es dato del documento, no un default oculto:
  -- SUNAT valida que el código corresponda a lo que dice la nota.
  v_cod_nota TEXT := COALESCE(NULLIF(p_payload->>'codigo_tipo_nota',''), '01');
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'facturacion:emitir');
  PERFORM internal.validar_payload(p_payload, ARRAY['comprobante_id']);

  IF v_motivo IS NULL THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('VALIDATION_ERROR',
        'Indica el motivo de la nota de crédito','motivo'));
  END IF;

  SELECT * INTO v_ref FROM core.comprobantes
   WHERE id = (p_payload->>'comprobante_id')::uuid AND deleted_at IS NULL
     AND internal.es_de_empresa(p_user_id, p_is_super_admin, v_emp, empresa_id);
  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Comprobante no encontrado','comprobante_id'));
  END IF;

  IF v_ref.tipo IN ('nota_credito','nota_debito') THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('BUSINESS_RULE',
        'Una nota de crédito no se emite sobre otra nota'));
  END IF;

  IF v_ref.anulado_at IS NOT NULL THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('BUSINESS_RULE',
        'El comprobante está anulado: no hay nada que acreditar'));
  END IF;

  SELECT emite_electronico,
         COALESCE(NULLIF(p_payload->>'serie',''), serie_nota_credito_default,
                  CASE WHEN v_ref.tipo = 'factura' THEN 'FC01' ELSE 'BC01' END)
    INTO v_electronico, v_serie
    FROM core.empresas WHERE id = v_emp;
  v_numero := internal.siguiente_numero_documento(v_emp, 'nota_credito', v_serie);

  INSERT INTO core.comprobantes (
    empresa_id, tipo, serie, numero, cliente_id, mascota_id, consulta_id,
    fecha_emision, moneda, tipo_cambio, estado, estado_pago,
    documento_ref_id, motivo_nota, codigo_tipo_nota, observaciones, created_by
  ) VALUES (
    v_emp, 'nota_credito', v_serie, v_numero, v_ref.cliente_id, v_ref.mascota_id,
    v_ref.consulta_id, now(), v_ref.moneda, v_ref.tipo_cambio,
    CASE WHEN COALESCE(v_electronico, false) THEN 'pendiente_envio'::core.estado_comprobante
         ELSE 'emitido'::core.estado_comprobante END,
    'pagado', v_ref.id, v_motivo, v_cod_nota, p_payload->>'observaciones', p_user_id
  ) RETURNING id INTO v_id;

  -- Sin detalle: la nota cubre lo que aún no se ha acreditado del comprobante.
  IF jsonb_array_length(v_items) = 0 THEN
    SELECT COALESCE(jsonb_agg(jsonb_build_object('comprobante_item_id', ci.id)), '[]'::jsonb)
      INTO v_items
      FROM core.comprobante_items ci WHERE ci.comprobante_id = v_ref.id;
  END IF;

  FOR v_item IN SELECT * FROM jsonb_array_elements(v_items) LOOP
    SELECT * INTO v_ci FROM core.comprobante_items
     WHERE id = (v_item->>'comprobante_item_id')::uuid AND comprobante_id = v_ref.id;
    IF NOT FOUND THEN
      RAISE EXCEPTION 'El ítem indicado no pertenece al comprobante' USING ERRCODE = 'P0001';
    END IF;

    -- Lo ya acreditado de este ítem en notas anteriores. No se puede devolver
    -- más de lo que se cobró, ni sumando varias notas parciales.
    SELECT COALESCE(SUM(nci.cantidad), 0) INTO v_acred
      FROM core.comprobante_items nci
      JOIN core.comprobantes nc ON nc.id = nci.comprobante_id
     WHERE nci.item_ref_id = v_ci.id
       AND nc.tipo = 'nota_credito' AND nc.anulado_at IS NULL AND nc.deleted_at IS NULL;

    v_cant := COALESCE((v_item->>'cantidad')::numeric, v_ci.cantidad - v_acred);

    IF v_cant > v_ci.cantidad - v_acred THEN
      RAISE EXCEPTION
        'Del ítem "%" ya se acreditaron % de %: no se puede acreditar % más',
        v_ci.descripcion, v_acred, v_ci.cantidad, v_cant USING ERRCODE = 'P0001';
    END IF;

    IF v_cant <= 0 THEN CONTINUE; END IF;

    v_orden := v_orden + 1;
    INSERT INTO core.comprobante_items (
      comprobante_id, tipo_item, servicio_id, producto_id, orden_servicio_id,
      insumo_id, item_ref_id, codigo, descripcion, cantidad, precio_unitario, descuento,
      afecto_igv, tipo_afectacion_igv, unidad_medida, subtotal, igv, total, orden
    ) VALUES (
      v_id, v_ci.tipo_item, v_ci.servicio_id, v_ci.producto_id, v_ci.orden_servicio_id,
      v_ci.insumo_id, v_ci.id, v_ci.codigo, v_ci.descripcion, v_cant, v_ci.precio_unitario, 0,
      v_ci.afecto_igv, v_ci.tipo_afectacion_igv, v_ci.unidad_medida,
      round(v_ci.subtotal * v_cant / v_ci.cantidad, 2),
      round(v_ci.igv      * v_cant / v_ci.cantidad, 2),
      round(v_ci.total    * v_cant / v_ci.cantidad, 2),
      v_orden);

    v_total := v_total + round(v_ci.total * v_cant / v_ci.cantidad, 2);

    -- Devolución de producto vendido en mostrador: vuelve al almacén.
    IF v_repone AND v_ci.producto_id IS NOT NULL AND v_ci.insumo_id IS NULL THEN
      PERFORM internal.mover_stock(
        v_emp, v_ci.producto_id, 'entrada', 'devolucion', v_cant, p_user_id, NULL,
        jsonb_build_object('cliente_id', v_ref.cliente_id, 'comprobante_id', v_id,
                           'observaciones', 'Nota de crédito ' || v_serie || '-' || v_numero));
    END IF;
  END LOOP;

  IF v_orden = 0 THEN
    RAISE EXCEPTION 'La nota de crédito no tiene ítems' USING ERRCODE = 'P0001';
  END IF;

  -- La nota baja la deuda del comprobante que corrige. Si lo cubre entero, ese
  -- comprobante queda sin saldo y deja de aparecer en cobranzas.
  UPDATE core.comprobantes
     SET saldo_pendiente = GREATEST(saldo_pendiente - v_total, 0),
         estado_pago = CASE WHEN GREATEST(saldo_pendiente - v_total, 0) <= 0
                            THEN 'pagado'::core.estado_pago ELSE estado_pago END,
         updated_at = now(), updated_by = p_user_id
   WHERE id = v_ref.id;

  -- Lo acreditado deja de estar cobrado: si fue un error de facturación, vuelve
  -- a pendiente; si fue una devolución, ya no se le debe cobrar a nadie.
  IF COALESCE((p_payload->>'devolver_a_pendientes')::boolean, false) THEN
    UPDATE core.ordenes_servicio SET facturado = false, comprobante_id = NULL
     WHERE id IN (SELECT ci.orden_servicio_id FROM core.comprobante_items ci
                   WHERE ci.comprobante_id = v_id AND ci.orden_servicio_id IS NOT NULL);
    UPDATE core.insumos_utilizados SET facturado = false
     WHERE id IN (SELECT ci.insumo_id FROM core.comprobante_items ci
                   WHERE ci.comprobante_id = v_id AND ci.insumo_id IS NOT NULL);
  END IF;

  PERFORM internal.registrar_auditoria(
    p_user_id, v_emp, 'emitir_nota_credito', 'comprobantes', v_id, NULL,
    jsonb_build_object('ref', v_ref.numero_completo, 'motivo', v_motivo, 'total', v_total));

  RETURN jsonb_build_object('ok', true, 'data', (
    SELECT jsonb_build_object(
      'id', c.id, 'numero_completo', c.numero_completo, 'tipo', c.tipo,
      'subtotal', c.subtotal, 'igv', c.igv, 'total', c.total,
      'documento_ref', v_ref.numero_completo)
    FROM core.comprobantes c WHERE c.id = v_id));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_nota_medica_crear(uuid, uuid, boolean, jsonb); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_nota_medica_crear(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_id      UUID;
  v_emp     UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_mascota UUID := (p_payload->>'mascota_id')::uuid;
  v_cliente UUID;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'clinico:registrar');

  PERFORM internal.validar_payload(p_payload, ARRAY['mascota_id','nota']);

  SELECT cliente_id INTO v_cliente FROM core.mascotas
   WHERE id = v_mascota AND deleted_at IS NULL
     AND (internal.es_acceso_global(p_user_id, p_is_super_admin) OR empresa_id = v_emp);

  INSERT INTO core.notas_medicas (empresa_id, mascota_id, user_id, nota, destacada)
  VALUES (v_emp, v_mascota, p_user_id, p_payload->>'nota',
          COALESCE((p_payload->>'destacada')::boolean, false))
  RETURNING id INTO v_id;

  PERFORM internal.registrar_evento_clinico(
    v_emp, v_mascota, v_cliente, p_user_id, 'nota',
    'Nota médica', left(p_payload->>'nota', 200), v_id);

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('id', v_id));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_notificacion_marcar_leida(uuid, uuid, boolean, uuid); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_notificacion_marcar_leida(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid DEFAULT NULL::uuid) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_n INT;
BEGIN
  -- Sin id: marca todas las del usuario (botón "marcar todo como leído")
  UPDATE core.notificaciones SET leida_at = now()
   WHERE user_id = p_user_id AND leida_at IS NULL
     AND (p_id IS NULL OR id = p_id);

  GET DIAGNOSTICS v_n = ROW_COUNT;

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('marcadas', v_n));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_orden_compra_cambiar_estado(uuid, uuid, boolean, uuid, character varying); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_orden_compra_cambiar_estado(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid, p_estado character varying) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_actual core.estado_orden_compra;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'compras:gestionar');

  SELECT estado INTO v_actual FROM core.ordenes_compra
   WHERE id = p_id AND deleted_at IS NULL
     AND internal.es_de_empresa(p_user_id, p_is_super_admin,
           internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin), empresa_id);
  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Orden de compra no encontrada'));
  END IF;

  IF v_actual IN ('recibida','recibida_parcial') AND p_estado = 'cancelada' THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('BUSINESS_RULE',
        'No se cancela una orden con mercadería ya recibida: registra la devolución en inventario'));
  END IF;

  UPDATE core.ordenes_compra
     SET estado = p_estado::core.estado_orden_compra, updated_by = p_user_id
   WHERE id = p_id;

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('id', p_id, 'estado', p_estado));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_orden_compra_crear(uuid, uuid, boolean, jsonb); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_orden_compra_crear(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_id       UUID;
  v_emp      UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_item     JSONB;
  v_subtotal NUMERIC(14,2) := 0;
  v_igv      NUMERIC(14,2) := 0;
  v_tasa     NUMERIC(5,4);
  v_sub_item NUMERIC(14,2);
  v_orden    INT := 0;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'compras:gestionar');
  PERFORM internal.validar_payload(p_payload, ARRAY['proveedor_id','items']);

  IF NOT EXISTS (SELECT 1 FROM core.proveedores
                  WHERE id = (p_payload->>'proveedor_id')::uuid AND deleted_at IS NULL
                    AND internal.es_de_empresa(p_user_id, p_is_super_admin, v_emp, empresa_id)) THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Proveedor no encontrado','proveedor_id'));
  END IF;

  IF jsonb_array_length(p_payload->'items') = 0 THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('VALIDATION_ERROR','La orden necesita al menos un ítem','items'));
  END IF;

  SELECT igv_tasa INTO v_tasa FROM core.empresas WHERE id = v_emp;
  v_tasa := COALESCE(v_tasa, 0.18);

  INSERT INTO core.ordenes_compra (
    empresa_id, numero, proveedor_id, almacen_id, fecha_emision, fecha_estimada,
    moneda, estado, observaciones, created_by
  ) VALUES (
    v_emp, internal.siguiente_numero(v_emp, 'OC', 6),
    (p_payload->>'proveedor_id')::uuid,
    COALESCE(NULLIF(p_payload->>'almacen_id','')::uuid,
             (SELECT id FROM core.almacenes WHERE empresa_id = v_emp AND es_principal LIMIT 1)),
    COALESCE(NULLIF(p_payload->>'fecha_emision','')::date, CURRENT_DATE),
    NULLIF(p_payload->>'fecha_estimada','')::date,
    COALESCE((p_payload->>'moneda')::core.moneda_codigo, 'PEN'),
    COALESCE((p_payload->>'estado')::core.estado_orden_compra, 'borrador'),
    p_payload->>'observaciones', p_user_id
  ) RETURNING id INTO v_id;

  FOR v_item IN SELECT * FROM jsonb_array_elements(p_payload->'items') LOOP
    v_orden := v_orden + 1;
    v_sub_item := round(
      (v_item->>'cantidad')::numeric * (v_item->>'precio_unitario')::numeric
      - COALESCE((v_item->>'descuento')::numeric, 0), 2);

    INSERT INTO core.orden_compra_items (
      orden_compra_id, producto_id, descripcion, cantidad, precio_unitario,
      descuento, subtotal, numero_lote, fecha_vencimiento, orden
    ) VALUES (
      v_id, (v_item->>'producto_id')::uuid, v_item->>'descripcion',
      (v_item->>'cantidad')::numeric, (v_item->>'precio_unitario')::numeric,
      COALESCE((v_item->>'descuento')::numeric, 0), v_sub_item,
      NULLIF(v_item->>'numero_lote',''),
      NULLIF(v_item->>'fecha_vencimiento','')::date, v_orden);

    v_subtotal := v_subtotal + v_sub_item;
  END LOOP;

  v_igv := internal.calcular_igv(v_subtotal, v_tasa);

  UPDATE core.ordenes_compra
     SET subtotal = v_subtotal, igv = v_igv,
         total = v_subtotal + v_igv, saldo_pendiente = v_subtotal + v_igv
   WHERE id = v_id;

  PERFORM internal.registrar_auditoria(
    p_user_id, v_emp, 'crear', 'ordenes_compra', v_id, NULL, p_payload);

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object(
    'id', v_id, 'subtotal', v_subtotal, 'igv', v_igv, 'total', v_subtotal + v_igv));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_orden_compra_recibir(uuid, uuid, boolean, uuid, jsonb); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_orden_compra_recibir(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid, p_recepcion jsonb DEFAULT NULL::jsonb) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_oc      RECORD;
  v_item    RECORD;
  v_recibir NUMERIC;
  v_saldo   NUMERIC;
  v_lote    UUID;
  v_pend    INT;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'compras:recibir');

  SELECT * INTO v_oc FROM core.ordenes_compra
   WHERE id = p_id AND deleted_at IS NULL
     AND internal.es_de_empresa(p_user_id, p_is_super_admin,
           internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin), empresa_id);
  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Orden de compra no encontrada'));
  END IF;

  IF v_oc.estado IN ('recibida','cancelada') THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('BUSINESS_RULE',
        format('La orden ya está %s', v_oc.estado)));
  END IF;

  FOR v_item IN
    SELECT i.*, pr.maneja_lotes, pr.nombre AS producto_nombre
      FROM core.orden_compra_items i
      JOIN core.productos pr ON pr.id = i.producto_id
     WHERE i.orden_compra_id = p_id
  LOOP
    -- Recepción parcial: si viene detalle, se usa; si no, se recibe todo.
    v_recibir := COALESCE(
      (SELECT (e->>'cantidad')::numeric
         FROM jsonb_array_elements(COALESCE(p_recepcion, '[]'::jsonb)) e
        WHERE (e->>'item_id')::uuid = v_item.id),
      v_item.cantidad - v_item.cantidad_recibida);

    CONTINUE WHEN v_recibir IS NULL OR v_recibir <= 0;

    -- No se puede recibir más de lo pedido: si llegó de más, corresponde otra
    -- orden, no inflar ésta. Sin este tope, un dedo de más en la recepción
    -- mete stock que nadie compró y descuadra la valorización.
    v_saldo := v_item.cantidad - v_item.cantidad_recibida;
    IF v_recibir > v_saldo THEN
      RETURN jsonb_build_object('ok', false,
        'error', internal.error_jsonb('BUSINESS_RULE',
          format('De "%s" quedan %s por recibir y se intentó recibir %s',
                 v_item.producto_nombre, v_saldo, v_recibir), 'cantidad'));
    END IF;

    -- Un producto que maneja lotes sin número de lote deja el stock total y la
    -- suma de sus lotes en desacuerdo, y el control de vencimientos deja de
    -- servir justo en lo que importa: vacunas y medicamentos.
    IF v_item.maneja_lotes AND COALESCE(v_item.numero_lote,'') = '' THEN
      RETURN jsonb_build_object('ok', false,
        'error', internal.error_jsonb('VALIDATION_ERROR',
          format('"%s" se controla por lotes: indica número de lote y vencimiento antes de recibirlo',
                 v_item.producto_nombre), 'numero_lote'));
    END IF;

    v_lote := NULL;
    IF v_item.numero_lote IS NOT NULL THEN
      INSERT INTO core.lotes (empresa_id, producto_id, numero_lote, fecha_vencimiento, cantidad, costo_unitario)
      VALUES (v_oc.empresa_id, v_item.producto_id, v_item.numero_lote,
              v_item.fecha_vencimiento, 0, v_item.precio_unitario)
      ON CONFLICT (producto_id, numero_lote) DO UPDATE
        SET fecha_vencimiento = COALESCE(EXCLUDED.fecha_vencimiento, core.lotes.fecha_vencimiento),
            updated_at = now()
      RETURNING id INTO v_lote;
    END IF;

    PERFORM internal.mover_stock(
      v_oc.empresa_id, v_item.producto_id, 'entrada', 'compra', v_recibir, p_user_id,
      v_oc.almacen_id,
      jsonb_build_object('lote_id', v_lote,
                         'costo_unitario', v_item.precio_unitario,
                         'proveedor_id', v_oc.proveedor_id,
                         'orden_compra_id', p_id,
                         'observaciones', 'Recepción de ' || v_oc.numero));

    UPDATE core.orden_compra_items
       SET cantidad_recibida = cantidad_recibida + v_recibir
     WHERE id = v_item.id;

    -- El precio de compra del producto se refresca con la última compra real.
    UPDATE core.productos
       SET precio_compra = v_item.precio_unitario,
           margen_pct = CASE WHEN v_item.precio_unitario > 0
                        THEN round((precio_venta - v_item.precio_unitario) / v_item.precio_unitario * 100, 2) END,
           updated_at = now()
     WHERE id = v_item.producto_id;
  END LOOP;

  SELECT count(*) INTO v_pend FROM core.orden_compra_items
   WHERE orden_compra_id = p_id AND cantidad_recibida < cantidad;

  UPDATE core.ordenes_compra
     SET estado = CASE WHEN v_pend = 0 THEN 'recibida' ELSE 'recibida_parcial' END::core.estado_orden_compra,
         fecha_recepcion = CASE WHEN v_pend = 0 THEN CURRENT_DATE ELSE fecha_recepcion END,
         updated_by = p_user_id
   WHERE id = p_id;

  PERFORM internal.registrar_auditoria(
    p_user_id, v_oc.empresa_id, 'recibir', 'ordenes_compra', p_id);

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object(
    'id', p_id, 'items_pendientes', v_pend,
    'estado', CASE WHEN v_pend = 0 THEN 'recibida' ELSE 'recibida_parcial' END));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_orden_servicio_crear(uuid, uuid, boolean, jsonb); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_orden_servicio_crear(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_id       UUID;
  v_emp      UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_mascota  UUID := (p_payload->>'mascota_id')::uuid;
  v_cliente  UUID;
  v_precio   NUMERIC(12,2);
  v_cant     NUMERIC(10,2) := COALESCE((p_payload->>'cantidad')::numeric, 1);
  v_desc     NUMERIC(12,2) := COALESCE((p_payload->>'descuento')::numeric, 0);
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'clinico:registrar');
  PERFORM internal.validar_payload(p_payload, ARRAY['mascota_id','servicio_id']);

  SELECT cliente_id INTO v_cliente FROM core.mascotas
   WHERE id = v_mascota AND deleted_at IS NULL
     AND (internal.es_acceso_global(p_user_id, p_is_super_admin) OR empresa_id = v_emp);

  SELECT COALESCE(NULLIF(p_payload->>'precio_unitario','')::numeric, s.precio) INTO v_precio
    FROM core.servicios s
   WHERE s.id = (p_payload->>'servicio_id')::uuid AND s.deleted_at IS NULL
     AND internal.es_de_empresa(p_user_id, p_is_super_admin, v_emp, s.empresa_id);

  IF v_precio IS NULL THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Servicio no encontrado','servicio_id'));
  END IF;

  INSERT INTO core.ordenes_servicio (
    empresa_id, codigo, mascota_id, cliente_id, servicio_id, veterinario_id,
    cita_id, consulta_id, cantidad, precio_unitario, descuento, total,
    descripcion, estado, created_by
  ) VALUES (
    v_emp, internal.siguiente_numero(v_emp, 'OS', 6), v_mascota, v_cliente,
    (p_payload->>'servicio_id')::uuid,
    COALESCE(NULLIF(p_payload->>'veterinario_id','')::uuid, p_user_id),
    NULLIF(p_payload->>'cita_id','')::uuid,
    NULLIF(p_payload->>'consulta_id','')::uuid,
    v_cant, v_precio, v_desc, round(v_cant * v_precio - v_desc, 2),
    p_payload->>'descripcion',
    COALESCE((p_payload->>'estado')::core.estado_orden_servicio, 'completado'),
    p_user_id
  ) RETURNING id INTO v_id;

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('id', v_id));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_pago_anular(uuid, uuid, boolean, uuid, text); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_pago_anular(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid, p_motivo text) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_pago RECORD;
  v_comp UUID;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'pagos:anular');

  SELECT * INTO v_pago FROM core.pagos
   WHERE id = p_id
     AND internal.es_de_empresa(p_user_id, p_is_super_admin,
           internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin), empresa_id);
  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Pago no encontrado'));
  END IF;

  IF v_pago.anulado_at IS NOT NULL THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('BUSINESS_RULE','El pago ya está anulado'));
  END IF;

  UPDATE core.pagos
     SET anulado_at = now(),
         observaciones = COALESCE(observaciones || ' | ', '') || 'ANULADO: ' || COALESCE(p_motivo,'')
   WHERE id = p_id;

  -- Los saldos de los comprobantes vuelven a subir
  FOR v_comp IN SELECT comprobante_id FROM core.pago_aplicaciones WHERE pago_id = p_id LOOP
    PERFORM internal.recalcular_saldo_comprobante(v_comp);
  END LOOP;

  IF v_pago.caja_id IS NOT NULL THEN
    INSERT INTO core.movimientos_caja (
      empresa_id, caja_id, tipo, metodo, concepto, monto, pago_id, created_by)
    VALUES (v_pago.empresa_id, v_pago.caja_id, 'egreso', v_pago.metodo,
            'Anulación de cobro ' || COALESCE(v_pago.numero,''), v_pago.monto, p_id, p_user_id);
  END IF;

  PERFORM internal.registrar_auditoria(
    p_user_id, v_pago.empresa_id, 'anular', 'pagos', p_id, NULL,
    jsonb_build_object('motivo', p_motivo));

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('id', p_id, 'anulado', true));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_pago_proveedor_registrar(uuid, uuid, boolean, jsonb); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_pago_proveedor_registrar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_id     UUID;
  v_emp    UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_oc     UUID := NULLIF(p_payload->>'orden_compra_id','')::uuid;
  v_monto  NUMERIC(14,2) := (p_payload->>'monto')::numeric;
  v_saldo  NUMERIC(14,2);
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'compras:pagar');
  PERFORM internal.validar_payload(p_payload, ARRAY['proveedor_id','monto']);

  IF NOT EXISTS (SELECT 1 FROM core.proveedores
                  WHERE id = (p_payload->>'proveedor_id')::uuid AND deleted_at IS NULL
                    AND internal.es_de_empresa(p_user_id, p_is_super_admin, v_emp, empresa_id)) THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Proveedor no encontrado','proveedor_id'));
  END IF;

  IF v_monto <= 0 THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('VALIDATION_ERROR','El monto debe ser mayor a cero','monto'));
  END IF;

  IF v_oc IS NOT NULL THEN
    SELECT saldo_pendiente INTO v_saldo FROM core.ordenes_compra
     WHERE id = v_oc AND deleted_at IS NULL
       AND internal.es_de_empresa(p_user_id, p_is_super_admin, v_emp, empresa_id);
    IF v_saldo IS NULL THEN
      RETURN jsonb_build_object('ok', false,
        'error', internal.error_jsonb('NOT_FOUND','Orden de compra no encontrada','orden_compra_id'));
    END IF;
    IF v_monto > v_saldo THEN
      RETURN jsonb_build_object('ok', false,
        'error', internal.error_jsonb('BUSINESS_RULE',
          format('El pago (%s) excede el saldo pendiente de la orden (%s)', v_monto, v_saldo), 'monto'));
    END IF;
  END IF;

  INSERT INTO core.pagos_proveedor (
    empresa_id, proveedor_id, orden_compra_id, numero, metodo, monto, moneda,
    referencia, comprobante_url, fecha_pago, observaciones, created_by
  ) VALUES (
    v_emp, (p_payload->>'proveedor_id')::uuid, v_oc,
    internal.siguiente_numero(v_emp, 'PGP', 6),
    COALESCE((p_payload->>'metodo')::core.metodo_pago, 'transferencia'),
    v_monto,
    COALESCE((p_payload->>'moneda')::core.moneda_codigo, 'PEN'),
    p_payload->>'referencia', p_payload->>'comprobante_url',
    COALESCE(NULLIF(p_payload->>'fecha_pago','')::timestamptz, now()),
    p_payload->>'observaciones', p_user_id
  ) RETURNING id INTO v_id;

  IF v_oc IS NOT NULL THEN
    UPDATE core.ordenes_compra
       SET saldo_pendiente = saldo_pendiente - v_monto,
           estado_pago = CASE
             WHEN saldo_pendiente - v_monto <= 0 THEN 'pagado'::core.estado_pago
             ELSE 'parcial'::core.estado_pago END,
           updated_at = now()
     WHERE id = v_oc;
  END IF;

  PERFORM internal.registrar_auditoria(
    p_user_id, v_emp, 'registrar_pago', 'pagos_proveedor', v_id, NULL, p_payload);

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('id', v_id));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_pago_registrar(uuid, uuid, boolean, jsonb); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_pago_registrar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_id        UUID;
  v_emp       UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_monto     NUMERIC(14,2) := (p_payload->>'monto')::numeric;
  v_caja      UUID;
  v_aplic     JSONB := COALESCE(p_payload->'aplicaciones', '[]'::jsonb);
  v_item      JSONB;
  v_suma      NUMERIC(14,2) := 0;
  v_saldo     NUMERIC(14,2);
  v_restante  NUMERIC(14,2);
  v_comp      RECORD;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'pagos:registrar');
  PERFORM internal.validar_payload(p_payload, ARRAY['cliente_id','monto']);

  IF NOT EXISTS (SELECT 1 FROM core.clientes
                  WHERE id = (p_payload->>'cliente_id')::uuid AND deleted_at IS NULL
                    AND internal.es_de_empresa(p_user_id, p_is_super_admin, v_emp, empresa_id)) THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Cliente no encontrado','cliente_id'));
  END IF;

  IF v_monto <= 0 THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('VALIDATION_ERROR','El monto debe ser mayor a cero','monto'));
  END IF;

  -- Caja abierta del usuario (si la hay): el cobro entra al arqueo del turno
  SELECT id INTO v_caja FROM core.cajas
   WHERE empresa_id = v_emp AND user_apertura_id = p_user_id AND estado = 'abierta'
   LIMIT 1;
  -- Una caja de otra empresa no sirve: se ignora si no es de la nuestra.
  IF NULLIF(p_payload->>'caja_id','') IS NOT NULL
     AND EXISTS (SELECT 1 FROM core.cajas
                  WHERE id = (p_payload->>'caja_id')::uuid
                    AND internal.es_de_empresa(p_user_id, p_is_super_admin, v_emp, empresa_id)) THEN
    v_caja := (p_payload->>'caja_id')::uuid;
  END IF;

  -- El efectivo SÍ exige caja abierta. Un cobro en efectivo sin caja no genera
  -- movimiento y por tanto no aparece en ningún arqueo: el billete entra al
  -- cajón y no hay nada contra qué cuadrarlo. Los medios que van al banco
  -- (tarjeta, transferencia, yape…) no necesitan caja.
  IF COALESCE((p_payload->>'metodo')::core.metodo_pago, 'efectivo') = 'efectivo'
     AND v_caja IS NULL THEN
    RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(
      'BUSINESS_RULE',
      'Para cobrar en efectivo necesitas una caja abierta', 'caja_id'));
  END IF;

  INSERT INTO core.pagos (
    empresa_id, cliente_id, caja_id, numero, metodo, monto, moneda,
    referencia, fecha_pago, observaciones, created_by
  ) VALUES (
    v_emp, (p_payload->>'cliente_id')::uuid, v_caja,
    internal.siguiente_numero(v_emp, 'PAG', 6),
    COALESCE((p_payload->>'metodo')::core.metodo_pago, 'efectivo'),
    v_monto,
    COALESCE((p_payload->>'moneda')::core.moneda_codigo, 'PEN'),
    p_payload->>'referencia',
    COALESCE(NULLIF(p_payload->>'fecha_pago','')::timestamptz, now()),
    p_payload->>'observaciones', p_user_id
  ) RETURNING id INTO v_id;

  -- Aplicaciones explícitas
  IF jsonb_array_length(v_aplic) > 0 THEN
    FOR v_item IN SELECT * FROM jsonb_array_elements(v_aplic) LOOP
      SELECT saldo_pendiente INTO v_saldo FROM core.comprobantes
       WHERE id = (v_item->>'comprobante_id')::uuid AND deleted_at IS NULL
         AND internal.es_de_empresa(p_user_id, p_is_super_admin, v_emp, empresa_id);

      IF v_saldo IS NULL THEN
        RAISE EXCEPTION 'Comprobante no encontrado' USING ERRCODE = 'P0001';
      END IF;

      IF (v_item->>'monto')::numeric > v_saldo THEN
        RAISE EXCEPTION 'El monto aplicado (%) supera el saldo del comprobante (%)',
          (v_item->>'monto')::numeric, v_saldo USING ERRCODE = 'P0001';
      END IF;

      INSERT INTO core.pago_aplicaciones (pago_id, comprobante_id, monto_aplicado)
      VALUES (v_id, (v_item->>'comprobante_id')::uuid, (v_item->>'monto')::numeric);

      PERFORM internal.recalcular_saldo_comprobante((v_item->>'comprobante_id')::uuid);
      v_suma := v_suma + (v_item->>'monto')::numeric;
    END LOOP;

    IF v_suma > v_monto THEN
      RAISE EXCEPTION 'Las aplicaciones (%) superan el monto del pago (%)', v_suma, v_monto
        USING ERRCODE = 'P0001';
    END IF;
  ELSE
    -- Sin detalle: se imputa a los comprobantes más antiguos hasta agotarlo.
    v_restante := v_monto;
    FOR v_comp IN
      SELECT id, saldo_pendiente FROM core.comprobantes
       WHERE empresa_id = v_emp AND cliente_id = (p_payload->>'cliente_id')::uuid
         AND deleted_at IS NULL AND anulado_at IS NULL AND saldo_pendiente > 0
       ORDER BY fecha_emision
    LOOP
      EXIT WHEN v_restante <= 0;
      INSERT INTO core.pago_aplicaciones (pago_id, comprobante_id, monto_aplicado)
      VALUES (v_id, v_comp.id, LEAST(v_restante, v_comp.saldo_pendiente));

      PERFORM internal.recalcular_saldo_comprobante(v_comp.id);
      v_restante := v_restante - LEAST(v_restante, v_comp.saldo_pendiente);
    END LOOP;
  END IF;

  IF v_caja IS NOT NULL THEN
    INSERT INTO core.movimientos_caja (
      empresa_id, caja_id, tipo, metodo, concepto, monto, pago_id, created_by)
    VALUES (
      v_emp, v_caja, 'ingreso',
      COALESCE((p_payload->>'metodo')::core.metodo_pago, 'efectivo'),
      'Cobro a cliente', v_monto, v_id, p_user_id);
  END IF;

  PERFORM internal.registrar_auditoria(
    p_user_id, v_emp, 'registrar_pago', 'pagos', v_id, NULL, p_payload);

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object(
    'id', v_id, 'monto', v_monto, 'caja_id', v_caja));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_permiso_resolver(uuid, uuid, boolean, uuid, character varying, text); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_permiso_resolver(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid, p_estado character varying, p_comentario text DEFAULT NULL::text) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_p RECORD;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'rrhh:aprobar');

  SELECT * INTO v_p FROM core.permisos_laborales
   WHERE id = p_id
     AND internal.es_de_empresa(p_user_id, p_is_super_admin,
           internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin), empresa_id);
  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Solicitud no encontrada'));
  END IF;

  IF v_p.user_id = p_user_id THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('BUSINESS_RULE','No puedes aprobar tu propia solicitud'));
  END IF;

  IF v_p.estado = p_estado::core.estado_solicitud THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('BUSINESS_RULE',
        format('La solicitud ya está en estado "%s"', p_estado)));
  END IF;

  UPDATE core.permisos_laborales SET
    estado = p_estado::core.estado_solicitud,
    aprobado_por = p_user_id, aprobado_at = now(),
    comentario_aprobacion = p_comentario
  WHERE id = p_id;

  -- El bloqueo de agenda sigue a la decisión en los dos sentidos: se pone al
  -- aprobar y se retira si después se rechaza o se cancela. Sin lo segundo, un
  -- permiso revertido dejaba al veterinario sin agenda para siempre.
  DELETE FROM core.disponibilidad WHERE permiso_id = p_id;

  IF p_estado = 'aprobado' THEN
    INSERT INTO core.disponibilidad (
      empresa_id, user_id, fecha, hora_inicio, hora_fin, tipo, nota, permiso_id)
    SELECT v_p.empresa_id, v_p.user_id, d::date,
           COALESCE(v_p.hora_inicio, '00:00'::time),
           COALESCE(v_p.hora_fin, '23:59'::time),
           CASE v_p.tipo WHEN 'vacaciones' THEN 'vacaciones' ELSE 'permiso' END::core.tipo_disponibilidad,
           'Permiso aprobado: ' || COALESCE(v_p.motivo, v_p.tipo::text),
           p_id
      FROM generate_series(v_p.fecha_inicio, v_p.fecha_fin, '1 day'::interval) d;
  END IF;

  PERFORM internal.registrar_auditoria(
    p_user_id, v_p.empresa_id, 'resolver', 'permisos_laborales', p_id, NULL,
    jsonb_build_object('estado', p_estado, 'comentario', p_comentario));

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('id', p_id, 'estado', p_estado));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_permiso_solicitar(uuid, uuid, boolean, jsonb); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_permiso_solicitar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_id     UUID;
  v_emp    UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_target UUID;
BEGIN
  PERFORM internal.validar_payload(p_payload, ARRAY['fecha_inicio','fecha_fin']);

  -- Un permiso aprobado bloquea la agenda del veterinario: pedirlo a nombre de
  -- otro es una acción de RRHH, no de autoservicio.
  v_target := internal.usuario_objetivo(
    p_user_id, NULLIF(p_payload->>'user_id','')::uuid, v_emp);

  INSERT INTO core.permisos_laborales (
    empresa_id, user_id, tipo, fecha_inicio, fecha_fin, hora_inicio, hora_fin, motivo)
  VALUES (
    v_emp,
    v_target,
    COALESCE((p_payload->>'tipo')::core.tipo_permiso_laboral, 'personal'),
    (p_payload->>'fecha_inicio')::date, (p_payload->>'fecha_fin')::date,
    NULLIF(p_payload->>'hora_inicio','')::time,
    NULLIF(p_payload->>'hora_fin','')::time,
    p_payload->>'motivo')
  RETURNING id INTO v_id;

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('id', v_id));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_plantilla_mensaje_guardar(uuid, uuid, boolean, jsonb); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_plantilla_mensaje_guardar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_id  UUID;
  v_emp UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'catalogos:editar');
  PERFORM internal.validar_payload(p_payload, ARRAY['tipo','texto']);

  INSERT INTO core.plantillas_mensaje (empresa_id, tipo, canal, nombre, texto, estado)
  VALUES (
    v_emp, p_payload->>'tipo', 'whatsapp',
    COALESCE(NULLIF(p_payload->>'nombre',''), p_payload->>'tipo'),
    p_payload->>'texto',
    COALESCE((p_payload->>'estado')::core.estado_generico, 'activo'))
  ON CONFLICT (empresa_id, tipo, canal) DO UPDATE
    SET texto = EXCLUDED.texto,
        nombre = EXCLUDED.nombre,
        estado = EXCLUDED.estado,
        updated_at = now()
  RETURNING id INTO v_id;

  PERFORM internal.registrar_auditoria(
    p_user_id, v_emp, 'guardar', 'plantillas_mensaje', v_id, NULL, p_payload);

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('id', v_id));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_portal_cambiar_password(uuid, text, text); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_portal_cambiar_password(p_cliente_id uuid, p_password_actual text, p_password_nuevo text) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_hash TEXT;
BEGIN
  SELECT portal_password_hash INTO v_hash FROM core.clientes WHERE id = p_cliente_id;

  IF v_hash IS NULL OR v_hash IS DISTINCT FROM crypt(p_password_actual, v_hash) THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('FORBIDDEN','La contraseña actual es incorrecta','password_actual'));
  END IF;

  IF length(p_password_nuevo) < 8 THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('VALIDATION_ERROR',
        'La contraseña nueva debe tener al menos 8 caracteres','password_nuevo'));
  END IF;

  UPDATE core.clientes
     SET portal_password_hash = crypt(p_password_nuevo, gen_salt('bf', 10)), updated_at = now()
   WHERE id = p_cliente_id;

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('updated', true));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_portal_login(character varying, text); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_portal_login(p_documento character varying, p_password text) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_cli RECORD;
BEGIN
  -- El documento es único por empresa, así que la misma persona puede existir
  -- en varias. Se toma la primera cuyo password coincida más abajo; en la
  -- práctica solo una empresa le habilita el portal.
  SELECT c.* INTO v_cli FROM core.clientes c
   WHERE (c.numero_documento = p_documento OR lower(c.correo) = lower(p_documento))
     AND c.portal_acceso = true
     AND c.deleted_at IS NULL
   ORDER BY c.portal_ultimo_login_at DESC NULLS LAST, c.created_at
   LIMIT 1;

  IF NOT FOUND OR v_cli.portal_acceso = false OR v_cli.portal_password_hash IS NULL THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('UNAUTHORIZED','Credenciales inválidas'));
  END IF;

  IF v_cli.estado <> 'activo' THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('FORBIDDEN','El acceso al portal está deshabilitado'));
  END IF;

  IF v_cli.portal_password_hash IS DISTINCT FROM crypt(p_password, v_cli.portal_password_hash) THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('UNAUTHORIZED','Credenciales inválidas'));
  END IF;

  UPDATE core.clientes SET portal_ultimo_login_at = now() WHERE id = v_cli.id;

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object(
    'cliente', jsonb_build_object(
      'id', v_cli.id, 'codigo', v_cli.codigo,
      'nombres', v_cli.nombres, 'apellido_paterno', v_cli.apellido_paterno,
      'correo', v_cli.correo, 'telefono', v_cli.telefono,
      -- El propietario pertenece a UNA empresa: el portal solo le muestra
      -- lo de esa empresa y solo puede pedir cita ahí.
      'empresa_id', v_cli.empresa_id
    )
  ));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_portal_solicitar_cita(uuid, jsonb); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_portal_solicitar_cita(p_cliente_id uuid, p_payload jsonb) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_id      UUID;
  v_mascota UUID := (p_payload->>'mascota_id')::uuid;
  v_emp     UUID;
  v_fecha   TIMESTAMPTZ := (p_payload->>'fecha_hora')::timestamptz;
  v_dur     INT;
BEGIN
  PERFORM internal.validar_payload(p_payload, ARRAY['mascota_id','fecha_hora']);

  IF NOT EXISTS (SELECT 1 FROM core.mascotas
                  WHERE id = v_mascota AND cliente_id = p_cliente_id AND deleted_at IS NULL) THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('FORBIDDEN','Esa mascota no está asociada a tu cuenta'));
  END IF;

  -- La empresa NO viene del payload: es la del propietario. Así no puede pedir
  -- cita en una empresa que no es la suya aunque manipule la petición.
  SELECT empresa_id INTO v_emp FROM core.clientes WHERE id = p_cliente_id;

  IF v_emp IS NULL THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Cuenta sin empresa asociada'));
  END IF;

  IF v_fecha < now() THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('VALIDATION_ERROR','La fecha solicitada ya pasó','fecha_hora'));
  END IF;

  -- La clínica tiene que estar abierta a esa hora. Sin esto el propietario
  -- podía pedir hora un domingo a las 3 de la mañana, y recepción descubría la
  -- solicitud imposible al día siguiente.
  IF EXISTS (SELECT 1 FROM core.horarios_atencion h
              WHERE h.empresa_id = v_emp AND h.activo = true)
     AND NOT EXISTS (
       SELECT 1 FROM core.horarios_atencion h
        WHERE h.empresa_id = v_emp AND h.activo = true
          AND h.dia_semana = EXTRACT(DOW FROM (v_fecha AT TIME ZONE 'America/Lima'))::int
          AND (v_fecha AT TIME ZONE 'America/Lima')::time >= h.hora_inicio
          AND (v_fecha AT TIME ZONE 'America/Lima')::time <  h.hora_fin)
  THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('BUSINESS_RULE',
        'La clínica no atiende en ese horario. Elige otro momento.', 'fecha_hora'));
  END IF;

  -- Tope de solicitudes sin confirmar. El portal es público: sin un límite,
  -- una cuenta puede llenar la agenda de pedidos que nadie pidió.
  IF (SELECT count(*) FROM core.citas c
       WHERE c.cliente_id = p_cliente_id AND c.deleted_at IS NULL
         AND c.origen = 'portal' AND c.estado = 'programada'
         AND c.fecha_hora >= now()) >= 5 THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('BUSINESS_RULE',
        'Tienes varias solicitudes sin confirmar. Espera a que la clínica las responda.'));
  END IF;

  -- Una misma mascota no puede tener dos pedidos a la misma hora.
  IF EXISTS (SELECT 1 FROM core.citas c
              WHERE c.mascota_id = v_mascota AND c.deleted_at IS NULL
                AND c.estado IN ('programada','confirmada')
                AND c.fecha_hora = v_fecha) THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('CONFLICT',
        'Ya tienes una cita solicitada para ese horario', 'fecha_hora'));
  END IF;

  SELECT COALESCE(
    (SELECT s.duracion_min FROM core.servicios s WHERE s.id = NULLIF(p_payload->>'servicio_id','')::uuid),
    (SELECT e.duracion_cita_min FROM core.empresas e WHERE e.id = v_emp),
    30) INTO v_dur;

  INSERT INTO core.citas (
    empresa_id, codigo, cliente_id, mascota_id, servicio_id, fecha_hora,
    duracion_min, motivo, origen, estado)
  VALUES (
    v_emp, internal.siguiente_numero(v_emp, 'CIT', 6), p_cliente_id, v_mascota,
    NULLIF(p_payload->>'servicio_id','')::uuid, v_fecha, v_dur,
    p_payload->>'motivo', 'portal', 'programada')
  RETURNING id INTO v_id;

  INSERT INTO core.citas_historial (cita_id, accion, fecha_hora_despues, motivo)
  VALUES (v_id, 'creada', v_fecha, 'Solicitada desde el portal del propietario');

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object(
    'id', v_id, 'estado', 'programada',
    'mensaje', 'Tu solicitud fue registrada. La clínica confirmará el horario.'));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_producto_eliminar(uuid, uuid, boolean, uuid); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_producto_eliminar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_movs INT;
  v_emp  UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'inventario:gestionar');

  IF NOT EXISTS (SELECT 1 FROM core.productos
                  WHERE id = p_id AND deleted_at IS NULL
                    AND internal.es_de_empresa(p_user_id, p_is_super_admin, v_emp, empresa_id)) THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Producto no encontrado'));
  END IF;

  SELECT count(*) INTO v_movs FROM core.movimientos_inventario WHERE producto_id = p_id;
  IF v_movs > 0 THEN
    UPDATE core.productos SET estado = 'inactivo', updated_by = p_user_id WHERE id = p_id;
    RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object(
      'id', p_id, 'desactivado', true,
      'mensaje', 'El producto tiene movimientos de inventario: se desactivó para preservar el kardex.'));
  END IF;

  UPDATE core.productos SET deleted_at = now(), estado = 'inactivo', updated_by = p_user_id
   WHERE id = p_id AND deleted_at IS NULL;

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('id', p_id, 'eliminado', true));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_producto_guardar(uuid, uuid, boolean, jsonb); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_producto_guardar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_id  UUID := NULLIF(p_payload->>'id','')::uuid;
  v_emp UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_compra NUMERIC := NULLIF(p_payload->>'precio_compra','')::numeric;
  v_venta  NUMERIC := NULLIF(p_payload->>'precio_venta','')::numeric;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'inventario:gestionar');

  IF v_id IS NULL THEN
    PERFORM internal.validar_payload(p_payload, ARRAY['nombre','precio_venta']);
    INSERT INTO core.productos (
      empresa_id, codigo, codigo_barras, nombre, descripcion, tipo, categoria_id,
      principio_activo, laboratorio, presentacion, unidad_medida,
      requiere_receta, controlado, refrigerado,
      precio_compra, precio_venta, margen_pct, afecto_igv,
      stock_minimo, stock_maximo, maneja_lotes, estado, created_by
    ) VALUES (
      v_emp,
      COALESCE(NULLIF(p_payload->>'codigo',''), internal.siguiente_numero(v_emp, 'PRD', 5)),
      NULLIF(p_payload->>'codigo_barras',''),
      p_payload->>'nombre', p_payload->>'descripcion',
      COALESCE((p_payload->>'tipo')::core.tipo_producto, 'insumo'),
      NULLIF(p_payload->>'categoria_id','')::uuid,
      p_payload->>'principio_activo', p_payload->>'laboratorio',
      p_payload->>'presentacion',
      COALESCE(NULLIF(p_payload->>'unidad_medida',''), 'UND'),
      COALESCE((p_payload->>'requiere_receta')::boolean, false),
      COALESCE((p_payload->>'controlado')::boolean, false),
      COALESCE((p_payload->>'refrigerado')::boolean, false),
      COALESCE(v_compra, 0), v_venta,
      CASE WHEN COALESCE(v_compra,0) > 0
           THEN round((v_venta - v_compra) / v_compra * 100, 2) END,
      COALESCE((p_payload->>'afecto_igv')::boolean, true),
      COALESCE((p_payload->>'stock_minimo')::numeric, 0),
      NULLIF(p_payload->>'stock_maximo','')::numeric,
      COALESCE((p_payload->>'maneja_lotes')::boolean, false),
      COALESCE((p_payload->>'estado')::core.estado_generico, 'activo'),
      p_user_id
    ) RETURNING id INTO v_id;

    -- Stock inicial opcional: entra como movimiento para dejar rastro
    IF COALESCE((p_payload->>'stock_inicial')::numeric, 0) > 0 THEN
      PERFORM internal.mover_stock(
        v_emp, v_id, 'entrada', 'ajuste_inventario',
        (p_payload->>'stock_inicial')::numeric, p_user_id, NULL,
        jsonb_build_object('costo_unitario', COALESCE(v_compra, 0),
                           'observaciones', 'Stock inicial al crear el producto'));
    END IF;
  ELSE
    IF NOT EXISTS (SELECT 1 FROM core.productos
                    WHERE id = v_id AND deleted_at IS NULL
                      AND internal.es_de_empresa(p_user_id, p_is_super_admin, v_emp, empresa_id)) THEN
      RETURN jsonb_build_object('ok', false,
        'error', internal.error_jsonb('NOT_FOUND','Producto no encontrado'));
    END IF;

    UPDATE core.productos SET
      codigo_barras    = COALESCE(NULLIF(p_payload->>'codigo_barras',''), codigo_barras),
      nombre           = COALESCE(p_payload->>'nombre', nombre),
      descripcion      = COALESCE(p_payload->>'descripcion', descripcion),
      tipo             = COALESCE((p_payload->>'tipo')::core.tipo_producto, tipo),
      categoria_id     = COALESCE(NULLIF(p_payload->>'categoria_id','')::uuid, categoria_id),
      principio_activo = COALESCE(p_payload->>'principio_activo', principio_activo),
      laboratorio      = COALESCE(p_payload->>'laboratorio', laboratorio),
      presentacion     = COALESCE(p_payload->>'presentacion', presentacion),
      unidad_medida    = COALESCE(NULLIF(p_payload->>'unidad_medida',''), unidad_medida),
      requiere_receta  = COALESCE((p_payload->>'requiere_receta')::boolean, requiere_receta),
      controlado       = COALESCE((p_payload->>'controlado')::boolean, controlado),
      refrigerado      = COALESCE((p_payload->>'refrigerado')::boolean, refrigerado),
      precio_compra    = COALESCE(v_compra, precio_compra),
      precio_venta     = COALESCE(v_venta, precio_venta),
      margen_pct       = CASE WHEN COALESCE(v_compra, precio_compra) > 0
                         THEN round((COALESCE(v_venta, precio_venta) - COALESCE(v_compra, precio_compra))
                                    / COALESCE(v_compra, precio_compra) * 100, 2)
                         ELSE margen_pct END,
      afecto_igv       = COALESCE((p_payload->>'afecto_igv')::boolean, afecto_igv),
      stock_minimo     = COALESCE((p_payload->>'stock_minimo')::numeric, stock_minimo),
      stock_maximo     = COALESCE(NULLIF(p_payload->>'stock_maximo','')::numeric, stock_maximo),
      maneja_lotes     = COALESCE((p_payload->>'maneja_lotes')::boolean, maneja_lotes),
      estado           = COALESCE((p_payload->>'estado')::core.estado_generico, estado),
      updated_by       = p_user_id
    WHERE id = v_id AND deleted_at IS NULL;
  END IF;

  PERFORM internal.registrar_auditoria(p_user_id, v_emp, 'guardar', 'productos', v_id, NULL, p_payload);
  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('id', v_id));

EXCEPTION
  WHEN unique_violation THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('CONFLICT','Ya existe un producto con ese código','codigo'));
  WHEN OTHERS THEN
    RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_proveedor_contacto_guardar(uuid, uuid, boolean, jsonb); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_proveedor_contacto_guardar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_id UUID := NULLIF(p_payload->>'id','')::uuid;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'compras:gestionar');

  -- El contacto cuelga del proveedor: basta con validar que el proveedor
  -- (nuevo contacto) o el contacto existente sean de la empresa.
  IF v_id IS NULL THEN
    PERFORM internal.validar_payload(p_payload, ARRAY['proveedor_id','nombres']);
    IF NOT EXISTS (SELECT 1 FROM core.proveedores pv
                    WHERE pv.id = (p_payload->>'proveedor_id')::uuid AND pv.deleted_at IS NULL
                      AND internal.es_de_empresa(p_user_id, p_is_super_admin,
                            internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin),
                            pv.empresa_id)) THEN
      RETURN jsonb_build_object('ok', false,
        'error', internal.error_jsonb('NOT_FOUND','Proveedor no encontrado','proveedor_id'));
    END IF;
    INSERT INTO core.proveedor_contactos (proveedor_id, nombres, cargo, telefono, correo, es_principal)
    VALUES ((p_payload->>'proveedor_id')::uuid, p_payload->>'nombres', p_payload->>'cargo',
            p_payload->>'telefono', lower(NULLIF(p_payload->>'correo','')),
            COALESCE((p_payload->>'es_principal')::boolean, false))
    RETURNING id INTO v_id;
  ELSE
    IF NOT EXISTS (SELECT 1 FROM core.proveedor_contactos c
                    JOIN core.proveedores pv ON pv.id = c.proveedor_id
                    WHERE c.id = v_id
                      AND internal.es_de_empresa(p_user_id, p_is_super_admin,
                            internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin),
                            pv.empresa_id)) THEN
      RETURN jsonb_build_object('ok', false,
        'error', internal.error_jsonb('NOT_FOUND','Contacto no encontrado'));
    END IF;

    UPDATE core.proveedor_contactos SET
      nombres      = COALESCE(p_payload->>'nombres', nombres),
      cargo        = COALESCE(p_payload->>'cargo', cargo),
      telefono     = COALESCE(p_payload->>'telefono', telefono),
      correo       = COALESCE(lower(NULLIF(p_payload->>'correo','')), correo),
      es_principal = COALESCE((p_payload->>'es_principal')::boolean, es_principal)
    WHERE id = v_id;
  END IF;

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('id', v_id));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_proveedor_eliminar(uuid, uuid, boolean, uuid); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_proveedor_eliminar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_ordenes INT;
  v_emp     UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'compras:gestionar');

  IF NOT EXISTS (SELECT 1 FROM core.proveedores
                  WHERE id = p_id AND deleted_at IS NULL
                    AND internal.es_de_empresa(p_user_id, p_is_super_admin, v_emp, empresa_id)) THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Proveedor no encontrado'));
  END IF;

  SELECT count(*) INTO v_ordenes FROM core.ordenes_compra
   WHERE proveedor_id = p_id AND deleted_at IS NULL;

  IF v_ordenes > 0 THEN
    UPDATE core.proveedores SET estado = 'inactivo', updated_by = p_user_id WHERE id = p_id;
    RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object(
      'id', p_id, 'desactivado', true,
      'mensaje', 'El proveedor tiene órdenes de compra: se desactivó en lugar de eliminarse.'));
  END IF;

  UPDATE core.proveedores SET deleted_at = now(), estado = 'inactivo', updated_by = p_user_id
   WHERE id = p_id AND deleted_at IS NULL;

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('id', p_id, 'eliminado', true));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_proveedor_guardar(uuid, uuid, boolean, jsonb); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_proveedor_guardar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_id  UUID := NULLIF(p_payload->>'id','')::uuid;
  v_emp UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_doc TEXT := internal.normalizar_documento(p_payload->>'numero_documento');
  v_tipo core.tipo_documento_identidad :=
    COALESCE((p_payload->>'tipo_documento')::core.tipo_documento_identidad, 'RUC');
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'compras:gestionar');

  IF v_id IS NULL THEN
    PERFORM internal.validar_payload(p_payload, ARRAY['numero_documento','razon_social']);

    IF v_tipo = 'RUC' AND NOT internal.validar_ruc(v_doc) THEN
      RETURN jsonb_build_object('ok', false,
        'error', internal.error_jsonb('VALIDATION_ERROR','El RUC no es válido','numero_documento'));
    END IF;

    INSERT INTO core.proveedores (
      empresa_id, codigo, tipo_documento, numero_documento, razon_social,
      nombre_comercial, categoria_id, direccion, telefono, correo, web,
      dias_credito, cuenta_bancaria, banco, estado, observaciones, created_by
    ) VALUES (
      v_emp,
      COALESCE(NULLIF(p_payload->>'codigo',''), internal.siguiente_numero(v_emp, 'PRV', 4)),
      v_tipo, v_doc, p_payload->>'razon_social', p_payload->>'nombre_comercial',
      NULLIF(p_payload->>'categoria_id','')::uuid,
      p_payload->>'direccion', p_payload->>'telefono',
      lower(NULLIF(p_payload->>'correo','')), p_payload->>'web',
      COALESCE((p_payload->>'dias_credito')::int, 0),
      p_payload->>'cuenta_bancaria', p_payload->>'banco',
      COALESCE((p_payload->>'estado')::core.estado_proveedor, 'activo'),
      p_payload->>'observaciones', p_user_id
    ) RETURNING id INTO v_id;
  ELSE
    IF NOT EXISTS (SELECT 1 FROM core.proveedores
                    WHERE id = v_id AND deleted_at IS NULL
                      AND internal.es_de_empresa(p_user_id, p_is_super_admin, v_emp, empresa_id)) THEN
      RETURN jsonb_build_object('ok', false,
        'error', internal.error_jsonb('NOT_FOUND','Proveedor no encontrado'));
    END IF;

    UPDATE core.proveedores SET
      razon_social     = COALESCE(p_payload->>'razon_social', razon_social),
      nombre_comercial = COALESCE(p_payload->>'nombre_comercial', nombre_comercial),
      categoria_id     = COALESCE(NULLIF(p_payload->>'categoria_id','')::uuid, categoria_id),
      direccion        = COALESCE(p_payload->>'direccion', direccion),
      telefono         = COALESCE(p_payload->>'telefono', telefono),
      correo           = COALESCE(lower(NULLIF(p_payload->>'correo','')), correo),
      web              = COALESCE(p_payload->>'web', web),
      dias_credito     = COALESCE((p_payload->>'dias_credito')::int, dias_credito),
      cuenta_bancaria  = COALESCE(p_payload->>'cuenta_bancaria', cuenta_bancaria),
      banco            = COALESCE(p_payload->>'banco', banco),
      estado           = COALESCE((p_payload->>'estado')::core.estado_proveedor, estado),
      observaciones    = COALESCE(p_payload->>'observaciones', observaciones),
      updated_by       = p_user_id
    WHERE id = v_id AND deleted_at IS NULL;
  END IF;

  PERFORM internal.registrar_auditoria(p_user_id, v_emp, 'guardar', 'proveedores', v_id, NULL, p_payload);
  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('id', v_id));

EXCEPTION
  WHEN unique_violation THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('CONFLICT','Ya existe un proveedor con ese documento','numero_documento'));
  WHEN OTHERS THEN
    RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_raza_guardar(uuid, uuid, boolean, jsonb); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_raza_guardar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_id  UUID := NULLIF(p_payload->>'id','')::uuid;
  v_emp UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'catalogos:gestionar');

  -- Una raza sin empresa es taxonomía global y solo la toca el operador del ERP.
  -- Cualquier empresa puede crear las SUYAS, que solo ella ve: así no necesita un
  -- campo de texto libre en la ficha del paciente para las razas fuera de catálogo.
  IF v_id IS NULL THEN
    PERFORM internal.validar_payload(p_payload, ARRAY['especie_id','nombre']);
    INSERT INTO core.razas (
      especie_id, empresa_id, nombre, tamanio_referencia, peso_min_kg, peso_max_kg,
      esperanza_vida, estado
    ) VALUES (
      (p_payload->>'especie_id')::uuid,
      CASE WHEN p_is_super_admin AND COALESCE((p_payload->>'global')::boolean, false)
           THEN NULL ELSE v_emp END,
      p_payload->>'nombre',
      NULLIF(p_payload->>'tamanio_referencia','')::core.tamanio_mascota,
      NULLIF(p_payload->>'peso_min_kg','')::numeric,
      NULLIF(p_payload->>'peso_max_kg','')::numeric,
      NULLIF(p_payload->>'esperanza_vida','')::int,
      COALESCE((p_payload->>'estado')::core.estado_generico, 'activo'))
    RETURNING id INTO v_id;
  ELSE
    -- Editar: la global solo el super admin; la propia, su empresa.
    IF NOT EXISTS (SELECT 1 FROM core.razas
                    WHERE id = v_id
                      AND ((empresa_id IS NULL AND p_is_super_admin)
                           OR internal.es_de_empresa(p_user_id, p_is_super_admin, v_emp, empresa_id))) THEN
      RETURN jsonb_build_object('ok', false,
        'error', internal.error_jsonb('FORBIDDEN',
          'Las razas del catálogo global las mantiene el operador del ERP'));
    END IF;

    UPDATE core.razas SET
      nombre             = COALESCE(p_payload->>'nombre', nombre),
      tamanio_referencia = COALESCE(NULLIF(p_payload->>'tamanio_referencia','')::core.tamanio_mascota, tamanio_referencia),
      peso_min_kg        = COALESCE(NULLIF(p_payload->>'peso_min_kg','')::numeric, peso_min_kg),
      peso_max_kg        = COALESCE(NULLIF(p_payload->>'peso_max_kg','')::numeric, peso_max_kg),
      esperanza_vida     = COALESCE(NULLIF(p_payload->>'esperanza_vida','')::int, esperanza_vida),
      estado             = COALESCE((p_payload->>'estado')::core.estado_generico, estado)
    WHERE id = v_id;
  END IF;

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('id', v_id));

EXCEPTION
  WHEN unique_violation THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('CONFLICT','Esa raza ya existe para la especie','nombre'));
  WHEN OTHERS THEN
    RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_recordatorio_completar(uuid, uuid, boolean, uuid); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_recordatorio_completar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'citas:editar');

  UPDATE core.recordatorios SET completado = true, enviado_at = COALESCE(enviado_at, now())
   WHERE id = p_id
     AND internal.es_de_empresa(p_user_id, p_is_super_admin,
           internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin), empresa_id);

  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Recordatorio no encontrado'));
  END IF;

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('id', p_id, 'completado', true));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_recordatorio_contactar(uuid, uuid, boolean, uuid, jsonb); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_recordatorio_contactar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid, p_payload jsonb DEFAULT '{}'::jsonb) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_emp UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_r   RECORD;
BEGIN
  SELECT * INTO v_r FROM core.recordatorios
   WHERE id = p_id
     AND internal.es_de_empresa(p_user_id, p_is_super_admin, v_emp, empresa_id);
  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Recordatorio no encontrado'));
  END IF;

  UPDATE core.recordatorios
     SET enviado_at = COALESCE(enviado_at, now()),
         completado = COALESCE((p_payload->>'completar')::boolean, completado)
   WHERE id = p_id;

  INSERT INTO core.comunicaciones (
    empresa_id, cliente_id, mascota_id, user_id, tipo, asunto, mensaje, fecha, created_by)
  VALUES (
    v_r.empresa_id, v_r.cliente_id, v_r.mascota_id, p_user_id,
    COALESCE((p_payload->>'canal')::core.tipo_comunicacion, 'whatsapp'),
    v_r.titulo,
    COALESCE(NULLIF(p_payload->>'mensaje',''), v_r.mensaje, v_r.titulo),
    now(), p_user_id);

  RETURN jsonb_build_object('ok', true,
    'data', jsonb_build_object('id', p_id, 'enviado', true));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_recordatorios_generar_citas(uuid, uuid, boolean, integer); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_recordatorios_generar_citas(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_dias integer DEFAULT 1) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_emp   UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_c     RECORD;
  v_n     INT := 0;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'citas:editar');

  FOR v_c IN
    SELECT c.id, c.empresa_id, c.cliente_id, c.mascota_id, c.fecha_hora,
           m.nombre AS mascota
      FROM core.citas c
      JOIN core.mascotas m ON m.id = c.mascota_id
     WHERE c.deleted_at IS NULL
       AND c.empresa_id = v_emp
       AND c.estado IN ('programada','confirmada')
       AND c.recordatorio_enviado_at IS NULL
       AND (c.fecha_hora AT TIME ZONE 'America/Lima')::date
           BETWEEN CURRENT_DATE AND CURRENT_DATE + COALESCE(p_dias, 1)
  LOOP
    INSERT INTO core.recordatorios (
      empresa_id, cliente_id, mascota_id, tipo, titulo, mensaje,
      fecha_objetivo, canal, entidad_ref, entidad_id)
    VALUES (
      v_c.empresa_id, v_c.cliente_id, v_c.mascota_id, 'cita',
      'Cita de ' || v_c.mascota,
      'Cita programada para el ' ||
        to_char(v_c.fecha_hora AT TIME ZONE 'America/Lima', 'DD/MM/YYYY a las HH24:MI') || '.',
      (v_c.fecha_hora AT TIME ZONE 'America/Lima')::date, 'whatsapp', 'citas', v_c.id);

    UPDATE core.citas SET recordatorio_enviado_at = now() WHERE id = v_c.id;
    v_n := v_n + 1;
  END LOOP;

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('generados', v_n));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_rol_crear(uuid, uuid, boolean, jsonb); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_rol_crear(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_id UUID;
BEGIN
  IF NOT p_is_super_admin THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('FORBIDDEN','Solo un super administrador gestiona roles'));
  END IF;

  PERFORM internal.validar_payload(p_payload, ARRAY['codigo','nombre']);

  INSERT INTO core.roles (codigo, nombre, descripcion, scope)
  VALUES (p_payload->>'codigo', p_payload->>'nombre', p_payload->>'descripcion',
          COALESCE((p_payload->>'scope')::core.scope_rol, 'empresa'))
  RETURNING id INTO v_id;

  PERFORM internal.registrar_auditoria(p_user_id, NULL, 'crear', 'roles', v_id, NULL, p_payload);
  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('id', v_id));

EXCEPTION
  WHEN unique_violation THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('CONFLICT','Ya existe un rol con ese código','codigo'));
  WHEN OTHERS THEN
    RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_rol_eliminar(uuid, uuid, boolean, uuid); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_rol_eliminar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_rol_id uuid) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_usuarios INT;
  v_sistema  BOOLEAN;
BEGIN
  IF NOT p_is_super_admin THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('FORBIDDEN','Solo un super administrador gestiona roles'));
  END IF;

  SELECT is_sistema INTO v_sistema FROM core.roles WHERE id = p_rol_id;
  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Rol no encontrado'));
  END IF;

  IF v_sistema THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('BUSINESS_RULE','Los roles del sistema no se pueden eliminar'));
  END IF;

  SELECT count(*) INTO v_usuarios FROM core.users WHERE rol_id = p_rol_id AND deleted_at IS NULL;
  IF v_usuarios > 0 THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('BUSINESS_RULE',
        format('El rol tiene %s usuario(s) asignado(s). Reasígnalos antes de eliminarlo.', v_usuarios)));
  END IF;

  DELETE FROM core.roles WHERE id = p_rol_id;
  PERFORM internal.registrar_auditoria(p_user_id, NULL, 'eliminar', 'roles', p_rol_id);

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('eliminado', true));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_rol_set_permisos(uuid, uuid, boolean, uuid, jsonb); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_rol_set_permisos(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_rol_id uuid, p_codigos jsonb) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_is_sistema BOOLEAN;
  v_total      INT;
BEGIN
  IF NOT p_is_super_admin THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('FORBIDDEN','Solo un super administrador gestiona permisos'));
  END IF;

  SELECT is_sistema INTO v_is_sistema FROM core.roles WHERE id = p_rol_id;
  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Rol no encontrado'));
  END IF;

  DELETE FROM core.rol_permisos WHERE rol_id = p_rol_id;

  INSERT INTO core.rol_permisos (rol_id, permiso_id)
  SELECT p_rol_id, p.id
  FROM core.permisos p
  WHERE p.codigo IN (SELECT jsonb_array_elements_text(p_codigos));

  GET DIAGNOSTICS v_total = ROW_COUNT;

  PERFORM internal.registrar_auditoria(
    p_user_id, NULL, 'set_permisos', 'roles', p_rol_id, NULL,
    jsonb_build_object('permisos', p_codigos));

  RETURN jsonb_build_object('ok', true,
    'data', jsonb_build_object('rol_id', p_rol_id, 'permisos_asignados', v_total));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_servicio_eliminar(uuid, uuid, boolean, uuid); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_servicio_eliminar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_usos INT;
  v_emp  UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'servicios:gestionar');

  IF NOT EXISTS (SELECT 1 FROM core.servicios
                  WHERE id = p_id AND deleted_at IS NULL
                    AND internal.es_de_empresa(p_user_id, p_is_super_admin, v_emp, empresa_id)) THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Servicio no encontrado'));
  END IF;

  SELECT count(*) INTO v_usos FROM core.ordenes_servicio WHERE servicio_id = p_id;
  IF v_usos > 0 THEN
    UPDATE core.servicios SET estado = 'inactivo', updated_by = p_user_id WHERE id = p_id;
    RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object(
      'id', p_id, 'desactivado', true,
      'mensaje', 'El servicio ya fue prestado a pacientes: se desactivó para no romper el histórico.'));
  END IF;

  UPDATE core.servicios SET deleted_at = now(), estado = 'inactivo', updated_by = p_user_id
   WHERE id = p_id AND deleted_at IS NULL;

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('id', p_id, 'eliminado', true));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_servicio_guardar(uuid, uuid, boolean, jsonb); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_servicio_guardar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_id  UUID := NULLIF(p_payload->>'id','')::uuid;
  v_emp UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'servicios:gestionar');

  IF v_id IS NULL THEN
    PERFORM internal.validar_payload(p_payload, ARRAY['nombre','precio']);
    INSERT INTO core.servicios (
      empresa_id, codigo, nombre, descripcion, tipo, categoria_id, precio,
      costo_estimado, duracion_min, requiere_ayuno, requiere_cita, afecto_igv,
      producto_id, estado, created_by
    ) VALUES (
      v_emp,
      COALESCE(NULLIF(p_payload->>'codigo',''), internal.siguiente_numero(v_emp, 'SRV', 4)),
      p_payload->>'nombre', p_payload->>'descripcion',
      COALESCE((p_payload->>'tipo')::core.tipo_servicio, 'consulta'),
      NULLIF(p_payload->>'categoria_id','')::uuid,
      (p_payload->>'precio')::numeric,
      COALESCE((p_payload->>'costo_estimado')::numeric, 0),
      COALESCE((p_payload->>'duracion_min')::int, 30),
      COALESCE((p_payload->>'requiere_ayuno')::boolean, false),
      COALESCE((p_payload->>'requiere_cita')::boolean, true),
      COALESCE((p_payload->>'afecto_igv')::boolean, true),
      NULLIF(p_payload->>'producto_id','')::uuid,
      COALESCE((p_payload->>'estado')::core.estado_generico, 'activo'),
      p_user_id
    ) RETURNING id INTO v_id;
  ELSE
    -- Editar exige que el servicio sea de la empresa: con solo el UUID, otra
    -- empresa podría reescribir el catálogo ajeno.
    IF NOT EXISTS (SELECT 1 FROM core.servicios
                    WHERE id = v_id AND deleted_at IS NULL
                      AND internal.es_de_empresa(p_user_id, p_is_super_admin, v_emp, empresa_id)) THEN
      RETURN jsonb_build_object('ok', false,
        'error', internal.error_jsonb('NOT_FOUND','Servicio no encontrado'));
    END IF;

    UPDATE core.servicios SET
      nombre         = COALESCE(p_payload->>'nombre', nombre),
      descripcion    = COALESCE(p_payload->>'descripcion', descripcion),
      tipo           = COALESCE((p_payload->>'tipo')::core.tipo_servicio, tipo),
      categoria_id   = COALESCE(NULLIF(p_payload->>'categoria_id','')::uuid, categoria_id),
      precio         = COALESCE((p_payload->>'precio')::numeric, precio),
      costo_estimado = COALESCE((p_payload->>'costo_estimado')::numeric, costo_estimado),
      duracion_min   = COALESCE((p_payload->>'duracion_min')::int, duracion_min),
      requiere_ayuno = COALESCE((p_payload->>'requiere_ayuno')::boolean, requiere_ayuno),
      requiere_cita  = COALESCE((p_payload->>'requiere_cita')::boolean, requiere_cita),
      afecto_igv     = COALESCE((p_payload->>'afecto_igv')::boolean, afecto_igv),
      producto_id    = COALESCE(NULLIF(p_payload->>'producto_id','')::uuid, producto_id),
      estado         = COALESCE((p_payload->>'estado')::core.estado_generico, estado),
      updated_by     = p_user_id
    WHERE id = v_id AND deleted_at IS NULL;
  END IF;

  PERFORM internal.registrar_auditoria(p_user_id, v_emp, 'guardar', 'servicios', v_id, NULL, p_payload);
  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('id', v_id));

EXCEPTION
  WHEN unique_violation THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('CONFLICT','Ya existe un servicio con ese código','codigo'));
  WHEN OTHERS THEN
    RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_tratamiento_cambiar_estado(uuid, uuid, boolean, uuid, character varying); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_tratamiento_cambiar_estado(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid, p_estado character varying) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'clinico:registrar');

  UPDATE core.tratamientos
     SET estado = p_estado::core.estado_tratamiento,
         fecha_fin = CASE WHEN p_estado <> 'activo' THEN COALESCE(fecha_fin, CURRENT_DATE) ELSE fecha_fin END
   WHERE id = p_id
     AND internal.es_de_empresa(p_user_id, p_is_super_admin,
           internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin), empresa_id);

  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Tratamiento no encontrado'));
  END IF;

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('id', p_id, 'estado', p_estado));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_tratamiento_registrar(uuid, uuid, boolean, jsonb); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_tratamiento_registrar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_id      UUID;
  v_emp     UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_mascota UUID := (p_payload->>'mascota_id')::uuid;
  v_cliente UUID;
  v_inicio  DATE := COALESCE(NULLIF(p_payload->>'fecha_inicio','')::date, CURRENT_DATE);
  v_dias    INT  := NULLIF(p_payload->>'duracion_dias','')::int;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'clinico:registrar');
  PERFORM internal.validar_payload(p_payload, ARRAY['mascota_id','medicamento','dosis']);

  SELECT cliente_id INTO v_cliente FROM core.mascotas
   WHERE id = v_mascota AND deleted_at IS NULL
     AND (internal.es_acceso_global(p_user_id, p_is_super_admin) OR empresa_id = v_emp);

  INSERT INTO core.tratamientos (
    empresa_id, mascota_id, consulta_id, veterinario_id, producto_id,
    medicamento, principio_activo, dosis, via, frecuencia_horas, duracion_dias,
    fecha_inicio, fecha_fin, indicaciones, estado, created_by
  ) VALUES (
    v_emp, v_mascota,
    NULLIF(p_payload->>'consulta_id','')::uuid,
    COALESCE(NULLIF(p_payload->>'veterinario_id','')::uuid, p_user_id),
    NULLIF(p_payload->>'producto_id','')::uuid,
    p_payload->>'medicamento',
    p_payload->>'principio_activo',
    p_payload->>'dosis',
    COALESCE((p_payload->>'via')::core.via_administracion, 'oral'),
    NULLIF(p_payload->>'frecuencia_horas','')::int,
    v_dias, v_inicio,
    COALESCE(NULLIF(p_payload->>'fecha_fin','')::date,
             CASE WHEN v_dias IS NOT NULL THEN v_inicio + v_dias END),
    p_payload->>'indicaciones',
    COALESCE((p_payload->>'estado')::core.estado_tratamiento, 'activo'),
    p_user_id
  ) RETURNING id INTO v_id;

  PERFORM internal.registrar_evento_clinico(
    v_emp, v_mascota, v_cliente, p_user_id, 'tratamiento',
    'Tratamiento: ' || (p_payload->>'medicamento'),
    (p_payload->>'dosis') || ' · ' || COALESCE(p_payload->>'via','oral'),
    v_id, NULL, v_inicio::timestamptz);

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('id', v_id));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_users_actualizar(uuid, uuid, boolean, uuid, jsonb); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_users_actualizar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid, p_payload jsonb) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_antes JSONB;
  v_emp   UUID;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'usuarios:editar');

  SELECT to_jsonb(u) - 'password_hash' - 'password_reset_token', u.empresa_id
    INTO v_antes, v_emp
  FROM core.users u WHERE u.id = p_id AND u.deleted_at IS NULL;

  IF v_antes IS NULL THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Usuario no encontrado'));
  END IF;

  IF v_emp IS NOT NULL THEN
    PERFORM internal.assert_acceso_empresa(p_user_id, v_emp, p_is_super_admin);
  END IF;

  UPDATE core.users SET
    nombres            = COALESCE(p_payload->>'nombres', nombres),
    apellido_paterno   = COALESCE(p_payload->>'apellido_paterno', apellido_paterno),
    apellido_materno   = COALESCE(p_payload->>'apellido_materno', apellido_materno),
    telefono           = COALESCE(p_payload->>'telefono', telefono),
    foto_url           = COALESCE(p_payload->>'foto_url', foto_url),
    tipo_documento     = COALESCE((p_payload->>'tipo_documento')::core.tipo_documento_identidad, tipo_documento),
    numero_documento   = COALESCE(p_payload->>'numero_documento', numero_documento),
    es_veterinario     = COALESCE((p_payload->>'es_veterinario')::boolean, es_veterinario),
    colegiatura        = COALESCE(NULLIF(p_payload->>'colegiatura',''), colegiatura),
    especializacion_id = COALESCE(NULLIF(p_payload->>'especializacion_id','')::uuid, especializacion_id),
    color_agenda       = COALESCE(NULLIF(p_payload->>'color_agenda',''), color_agenda),
    updated_by         = p_user_id
  WHERE id = p_id;

  PERFORM internal.registrar_auditoria(
    p_user_id, v_emp, 'actualizar', 'users', p_id, v_antes, p_payload);

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('id', p_id));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_users_cambiar_estado(uuid, uuid, boolean, uuid, character varying); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_users_cambiar_estado(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid, p_estado character varying) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_emp UUID;
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'usuarios:editar');

  IF p_id = p_user_id THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('BUSINESS_RULE','No puedes cambiar el estado de tu propia cuenta'));
  END IF;

  -- El usuario destino debe ser de la misma empresa. Un administrador lo es de SU
  -- empresa: sin esta comprobación podría tomar la cuenta de otra con solo el UUID.
  IF NOT EXISTS (
      SELECT 1 FROM core.users u
       WHERE u.id = p_id AND u.deleted_at IS NULL
         AND (p_is_super_admin
              OR (u.empresa_id IS NOT NULL
                  AND u.empresa_id = internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin)))) THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Usuario no encontrado'));
  END IF;

  SELECT empresa_id INTO v_emp FROM core.users WHERE id = p_id AND deleted_at IS NULL;

  UPDATE core.users
     SET estado = p_estado::core.estado_user,
         intentos_fallidos = 0, bloqueado_hasta = NULL,
         updated_by = p_user_id
   WHERE id = p_id;

  -- Revocar sesiones activas al desactivar
  IF p_estado <> 'activo' THEN
    UPDATE core.sesiones SET revocado_at = now()
     WHERE user_id = p_id AND revocado_at IS NULL;
  END IF;

  PERFORM internal.registrar_auditoria(
    p_user_id, v_emp, 'cambiar_estado', 'users', p_id, NULL,
    jsonb_build_object('estado', p_estado));

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('id', p_id, 'estado', p_estado));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_users_cambiar_rol(uuid, uuid, boolean, uuid, uuid, uuid); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_users_cambiar_rol(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid, p_rol_id uuid, p_empresa_destino uuid DEFAULT NULL::uuid) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_scope core.scope_rol;
  v_emp   UUID;
BEGIN
  IF NOT p_is_super_admin THEN
    PERFORM internal.assert_permiso(p_user_id, 'usuarios:asignar_rol');
  END IF;

  -- Nadie cambia su propio rol: sería auto-concederse permisos.
  IF p_id = p_user_id THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('BUSINESS_RULE','No puedes cambiar tu propio rol'));
  END IF;

  SELECT scope INTO v_scope FROM core.roles WHERE id = p_rol_id;
  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Rol no encontrado','rol_id'));
  END IF;

  -- Conceder alcance global es entregar toda la instalación: solo el super admin.
  IF v_scope IN ('global','global_restricted') AND NOT p_is_super_admin THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('FORBIDDEN',
        'Solo un super administrador puede asignar roles de alcance global','rol_id'));
  END IF;

  -- El usuario destino debe ser de la empresa de quien opera.
  IF NOT EXISTS (
      SELECT 1 FROM core.users u
       WHERE u.id = p_id AND u.deleted_at IS NULL
         AND (p_is_super_admin
              OR (u.empresa_id IS NOT NULL
                  AND u.empresa_id = internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin)))) THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Usuario no encontrado'));
  END IF;

  IF v_scope IN ('global','global_restricted') THEN
    v_emp := NULL;
  ELSE
    SELECT COALESCE(p_empresa_destino, empresa_id,
                    internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin))
      INTO v_emp
    FROM core.users WHERE id = p_id;

    IF v_emp IS NULL THEN
      RETURN jsonb_build_object('ok', false,
        'error', internal.error_jsonb('VALIDATION_ERROR',
          'Este rol opera en una empresa: indica cuál','empresa_id'));
    END IF;
  END IF;

  UPDATE core.users
     SET rol_id = p_rol_id, empresa_id = v_emp, updated_by = p_user_id
   WHERE id = p_id AND deleted_at IS NULL;

  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Usuario no encontrado'));
  END IF;

  PERFORM internal.registrar_auditoria(
    p_user_id, v_emp, 'cambiar_rol', 'users', p_id, NULL,
    jsonb_build_object('rol_id', p_rol_id, 'empresa_id', v_emp));

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('id', p_id));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_users_crear(uuid, uuid, boolean, jsonb); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_users_crear(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_id        UUID;
  v_emp       UUID;
  v_scope     core.scope_rol;
  v_rol_id    UUID := NULLIF(p_payload->>'rol_id','')::uuid;
  v_email     TEXT := internal.normalizar_correo(p_payload->>'email');
  -- Normalizado antes de validar y de comparar contra lo ya guardado.
  v_doc       TEXT := internal.normalizar_documento(p_payload->>'numero_documento');
  v_tipo_doc  core.tipo_documento_identidad := COALESCE((p_payload->>'tipo_documento')::core.tipo_documento_identidad, 'DNI');
  v_es_vet    BOOLEAN := COALESCE((p_payload->>'es_veterinario')::boolean, false);
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'usuarios:crear');
  PERFORM internal.validar_payload(p_payload,
    ARRAY['email','password','nombres','apellido_paterno','numero_documento']);

  IF internal.password_invalida(p_payload->>'password', v_email) IS NOT NULL THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('VALIDATION_ERROR',
        internal.password_invalida(p_payload->>'password', v_email), 'password'));
  END IF;

  IF v_tipo_doc = 'DNI' AND NOT internal.validar_dni(v_doc) THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('VALIDATION_ERROR','El DNI debe tener 8 dígitos','numero_documento'));
  END IF;

  IF EXISTS (SELECT 1 FROM core.users WHERE lower(email) = v_email AND deleted_at IS NULL) THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('CONFLICT','Ya existe un usuario con ese correo','email'));
  END IF;

  IF EXISTS (SELECT 1 FROM core.users
              WHERE tipo_documento = v_tipo_doc AND numero_documento = v_doc AND deleted_at IS NULL) THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('CONFLICT','Ya existe un usuario con ese documento','numero_documento'));
  END IF;

  IF v_es_vet AND COALESCE(p_payload->>'colegiatura','') = '' THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('VALIDATION_ERROR',
        'Un veterinario necesita número de colegiatura para firmar la historia clínica','colegiatura'));
  END IF;

  -- La empresa se deriva del scope del rol: global ⇒ NULL, empresa ⇒ obligatoria.
  SELECT scope INTO v_scope FROM core.roles WHERE id = v_rol_id;

  -- Un rol de alcance global da acceso a TODAS las empresas. Solo un super admin
  -- puede concederlo: sin esto, el administrador de una empresa se crearía un
  -- usuario super_admin y se llevaría la instalación entera.
  IF v_scope IN ('global','global_restricted') AND NOT p_is_super_admin THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('FORBIDDEN',
        'Solo un super administrador puede crear usuarios con alcance global','rol_id'));
  END IF;

  IF v_scope IN ('global','global_restricted') THEN
    v_emp := NULL;
  ELSE
    v_emp := COALESCE(NULLIF(p_payload->>'empresa_id','')::uuid,
                      internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin));
    IF v_emp IS NULL THEN
      RETURN jsonb_build_object('ok', false,
        'error', internal.error_jsonb('VALIDATION_ERROR','Debes indicar la empresa del usuario','empresa_id'));
    END IF;
    PERFORM internal.assert_acceso_empresa(p_user_id, v_emp, p_is_super_admin);
  END IF;

  INSERT INTO core.users (
    codigo, email, password_hash, nombres, apellido_paterno, apellido_materno,
    tipo_documento, numero_documento, telefono, foto_url, empresa_id, rol_id,
    es_veterinario, colegiatura, especializacion_id, color_agenda,
    estado, must_change_password, created_by
  ) VALUES (
    COALESCE(NULLIF(p_payload->>'codigo',''),
             internal.siguiente_numero(COALESCE(v_emp, '00000000-0000-0000-0000-000000000000'::uuid), 'USR', 4)),
    v_email,
    crypt(p_payload->>'password', gen_salt('bf', 10)),
    p_payload->>'nombres',
    p_payload->>'apellido_paterno',
    p_payload->>'apellido_materno',
    v_tipo_doc, v_doc,
    p_payload->>'telefono',
    p_payload->>'foto_url',
    v_emp, v_rol_id,
    v_es_vet,
    NULLIF(p_payload->>'colegiatura',''),
    NULLIF(p_payload->>'especializacion_id','')::uuid,
    COALESCE(NULLIF(p_payload->>'color_agenda',''), '#07B162'),
    COALESCE((p_payload->>'estado')::core.estado_user, 'activo'),
    COALESCE((p_payload->>'must_change_password')::boolean, true),
    p_user_id
  ) RETURNING id INTO v_id;

  PERFORM internal.registrar_auditoria(
    p_user_id, v_emp, 'crear', 'users', v_id, NULL, p_payload - 'password');

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('id', v_id));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_users_eliminar(uuid, uuid, boolean, uuid); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_users_eliminar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'usuarios:eliminar');

  IF p_id = p_user_id THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('BUSINESS_RULE','No puedes eliminar tu propia cuenta'));
  END IF;

  -- El usuario destino debe ser de la misma empresa. Un administrador lo es de SU
  -- empresa: sin esta comprobación podría tomar la cuenta de otra con solo el UUID.
  IF NOT EXISTS (
      SELECT 1 FROM core.users u
       WHERE u.id = p_id AND u.deleted_at IS NULL
         AND (p_is_super_admin
              OR (u.empresa_id IS NOT NULL
                  AND u.empresa_id = internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin)))) THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Usuario no encontrado'));
  END IF;


  -- Un veterinario con historia clínica firmada no se borra: se desactiva,
  -- o la trazabilidad del acto médico queda huérfana.
  IF EXISTS (SELECT 1 FROM core.consultas WHERE veterinario_id = p_id LIMIT 1) THEN
    UPDATE core.users SET estado = 'inactivo', updated_by = p_user_id WHERE id = p_id;
    RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object(
      'id', p_id, 'desactivado', true,
      'mensaje', 'El usuario tiene historia clínica firmada: se desactivó en lugar de eliminarse.'));
  END IF;

  UPDATE core.users
     SET deleted_at = now(), estado = 'inactivo', updated_by = p_user_id
   WHERE id = p_id AND deleted_at IS NULL;

  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Usuario no encontrado'));
  END IF;

  PERFORM internal.registrar_auditoria(p_user_id, p_empresa_id, 'eliminar', 'users', p_id);

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('id', p_id, 'eliminado', true));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_users_reset_password(uuid, uuid, boolean, uuid, text); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_users_reset_password(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_id uuid, p_password_temp text) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'usuarios:editar');

  -- El usuario destino debe ser de la misma empresa. Un administrador lo es de SU
  -- empresa: sin esta comprobación podría tomar la cuenta de otra con solo el UUID.
  IF NOT EXISTS (
      SELECT 1 FROM core.users u
       WHERE u.id = p_id AND u.deleted_at IS NULL
         AND (p_is_super_admin
              OR (u.empresa_id IS NOT NULL
                  AND u.empresa_id = internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin)))) THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Usuario no encontrado'));
  END IF;

  IF internal.password_invalida(p_password_temp) IS NOT NULL THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('VALIDATION_ERROR',
        internal.password_invalida(p_password_temp), 'password_temp'));
  END IF;

  UPDATE core.users
     SET password_hash = crypt(p_password_temp, gen_salt('bf', 10)),
         must_change_password = true,
         intentos_fallidos = 0, bloqueado_hasta = NULL,
         updated_by = p_user_id
   WHERE id = p_id AND deleted_at IS NULL;

  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','Usuario no encontrado'));
  END IF;

  UPDATE core.sesiones SET revocado_at = now()
   WHERE user_id = p_id AND revocado_at IS NULL;

  PERFORM internal.registrar_auditoria(
    p_user_id, p_empresa_id, 'reset_password_admin', 'users', p_id);

  RETURN jsonb_build_object('ok', true, 'data', jsonb_build_object('id', p_id));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: sp_vacuna_aplicar(uuid, uuid, boolean, jsonb); Type: FUNCTION; Schema: app; Owner: -
--

CREATE FUNCTION app.sp_vacuna_aplicar(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean, p_payload jsonb) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'app', 'internal', 'public'
    AS $$
DECLARE
  v_id       UUID;
  v_emp      UUID := internal.empresa_efectiva(p_user_id, p_empresa_id, p_is_super_admin);
  v_cliente  UUID;
  v_mascota  UUID := (p_payload->>'mascota_id')::uuid;
  v_producto UUID := NULLIF(p_payload->>'producto_id','')::uuid;
  v_refuerzo DATE := NULLIF(p_payload->>'proximo_refuerzo','')::date;
  v_esquema  UUID := NULLIF(p_payload->>'esquema_id','')::uuid;
  v_fecha    DATE := COALESCE(NULLIF(p_payload->>'fecha_aplicacion','')::date, CURRENT_DATE);
BEGIN
  PERFORM internal.assert_permiso(p_user_id, 'clinico:registrar');
  PERFORM internal.validar_payload(p_payload, ARRAY['mascota_id','nombre_vacuna']);

  SELECT cliente_id INTO v_cliente FROM core.mascotas
   WHERE id = v_mascota AND deleted_at IS NULL
     AND (internal.es_acceso_global(p_user_id, p_is_super_admin) OR empresa_id = v_emp);
  IF v_cliente IS NULL THEN
    RETURN jsonb_build_object('ok', false,
      'error', internal.error_jsonb('NOT_FOUND','El paciente indicado no existe','mascota_id'));
  END IF;

  -- Si no llega refuerzo explícito pero hay esquema, se calcula del protocolo.
  IF v_refuerzo IS NULL AND v_esquema IS NOT NULL THEN
    SELECT v_fecha + COALESCE(ev.intervalo_dias, ev.revacunacion_meses * 30, 365)
      INTO v_refuerzo
    FROM core.esquemas_vacunacion ev WHERE ev.id = v_esquema;
  END IF;

  INSERT INTO core.vacunas (
    empresa_id, mascota_id, veterinario_id, consulta_id, esquema_id, producto_id,
    nombre_vacuna, laboratorio, lote, fecha_aplicacion, dosis_numero,
    proximo_refuerzo, via, reaccion_adversa, observaciones, created_by
  ) VALUES (
    v_emp, v_mascota,
    COALESCE(NULLIF(p_payload->>'veterinario_id','')::uuid, p_user_id),
    NULLIF(p_payload->>'consulta_id','')::uuid,
    v_esquema, v_producto,
    p_payload->>'nombre_vacuna',
    p_payload->>'laboratorio',
    p_payload->>'lote',
    v_fecha,
    COALESCE((p_payload->>'dosis_numero')::int, 1),
    v_refuerzo,
    COALESCE((p_payload->>'via')::core.via_administracion, 'subcutanea'),
    p_payload->>'reaccion_adversa',
    p_payload->>'observaciones',
    p_user_id
  ) RETURNING id INTO v_id;

  -- La dosis sale del inventario si se indicó el producto, y queda pendiente de
  -- cobro: una vacuna aplicada es producto entregado, no una merma.
  IF v_producto IS NOT NULL THEN
    PERFORM internal.consumir_producto_clinico(
      v_emp, v_producto, COALESCE((p_payload->>'dosis_cantidad')::numeric, 1), p_user_id,
      jsonb_build_object('mascota_id', v_mascota,
                         'consulta_id', NULLIF(p_payload->>'consulta_id','')::uuid,
                         'observaciones', 'Vacuna aplicada: ' || (p_payload->>'nombre_vacuna')));
  END IF;

  -- El acto de vacunar tiene tarifa propia (aplicación, carné): si se indicó el
  -- servicio, se cobra junto con la dosis.
  PERFORM internal.registrar_cargo_servicio(
    v_emp, NULLIF(p_payload->>'servicio_id','')::uuid, v_mascota, p_user_id, 1,
    jsonb_build_object(
      'consulta_id', NULLIF(p_payload->>'consulta_id','')::uuid,
      'cita_id', NULLIF(p_payload->>'cita_id','')::uuid,
      'veterinario_id', NULLIF(p_payload->>'veterinario_id','')::uuid,
      'descripcion', 'Aplicación de ' || (p_payload->>'nombre_vacuna'),
      'origen_tabla', 'vacunas', 'origen_id', v_id));

  PERFORM internal.registrar_evento_clinico(
    v_emp, v_mascota, v_cliente,
    COALESCE(NULLIF(p_payload->>'veterinario_id','')::uuid, p_user_id),
    'vacuna', 'Vacuna: ' || (p_payload->>'nombre_vacuna'),
    CASE WHEN v_refuerzo IS NOT NULL
         THEN 'Próximo refuerzo: ' || to_char(v_refuerzo, 'DD/MM/YYYY') END,
    v_id, NULLIF(p_payload->>'cita_id','')::uuid, v_fecha::timestamptz);

  -- Recordatorio del refuerzo para que recepción lo contacte a tiempo.
  IF v_refuerzo IS NOT NULL THEN
    INSERT INTO core.recordatorios (
      empresa_id, cliente_id, mascota_id, tipo, titulo, mensaje,
      fecha_objetivo, entidad_ref, entidad_id)
    VALUES (
      v_emp, v_cliente, v_mascota, 'vacuna',
      'Refuerzo de ' || (p_payload->>'nombre_vacuna'),
      'Corresponde el refuerzo de la vacuna aplicada el ' || to_char(v_fecha, 'DD/MM/YYYY') || '.',
      v_refuerzo, 'vacunas', v_id);
  END IF;

  RETURN jsonb_build_object('ok', true,
    'data', jsonb_build_object('id', v_id, 'proximo_refuerzo', v_refuerzo));

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', internal.error_jsonb(SQLSTATE, SQLERRM));
END;
$$;


--
-- Name: trg_asistencia_horas(); Type: FUNCTION; Schema: core; Owner: -
--

CREATE FUNCTION core.trg_asistencia_horas() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NEW.hora_entrada IS NOT NULL AND NEW.hora_salida IS NOT NULL THEN
    NEW.horas_trabajadas := round(
      EXTRACT(EPOCH FROM (NEW.hora_salida - NEW.hora_entrada)) / 3600.0, 2);
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: trg_comprobante_recalcular(); Type: FUNCTION; Schema: core; Owner: -
--

CREATE FUNCTION core.trg_comprobante_recalcular() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  v_comprobante UUID := COALESCE(NEW.comprobante_id, OLD.comprobante_id);
BEGIN
  UPDATE core.comprobantes c
     SET subtotal = COALESCE(t.subtotal, 0),
         igv      = COALESCE(t.igv, 0),
         total    = COALESCE(t.total, 0) - c.descuento_global,
         saldo_pendiente = (COALESCE(t.total, 0) - c.descuento_global) - COALESCE((
           SELECT SUM(pa.monto_aplicado) FROM core.pago_aplicaciones pa
            WHERE pa.comprobante_id = c.id), 0),
         updated_at = now()
    FROM (
      SELECT SUM(subtotal) AS subtotal, SUM(igv) AS igv, SUM(total) AS total
        FROM core.comprobante_items WHERE comprobante_id = v_comprobante
    ) t
   WHERE c.id = v_comprobante;

  RETURN NULL;
END;
$$;


--
-- Name: trg_consulta_sync_peso(); Type: FUNCTION; Schema: core; Owner: -
--

CREATE FUNCTION core.trg_consulta_sync_peso() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NEW.peso_kg IS NOT NULL AND NEW.peso_kg > 0 THEN
    UPDATE core.mascotas
       SET peso_kg = NEW.peso_kg, updated_at = now()
     WHERE id = NEW.mascota_id;
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: trg_evaluacion_promedio(); Type: FUNCTION; Schema: core; Owner: -
--

CREATE FUNCTION core.trg_evaluacion_promedio() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.promedio := round((
    COALESCE(NEW.puntualidad,0) + COALESCE(NEW.eficiencia,0) +
    COALESCE(NEW.calidad_atencion,0) + COALESCE(NEW.trabajo_equipo,0)
  )::numeric / NULLIF((
    (NEW.puntualidad IS NOT NULL)::int + (NEW.eficiencia IS NOT NULL)::int +
    (NEW.calidad_atencion IS NOT NULL)::int + (NEW.trabajo_equipo IS NOT NULL)::int
  ), 0), 2);
  RETURN NEW;
END;
$$;


--
-- Name: trg_mascota_fallecida(); Type: FUNCTION; Schema: core; Owner: -
--

CREATE FUNCTION core.trg_mascota_fallecida() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NEW.estado = 'fallecido' AND OLD.estado <> 'fallecido' THEN
    UPDATE core.tratamientos SET estado = 'suspendido', updated_at = now()
     WHERE mascota_id = NEW.id AND estado = 'activo';
    UPDATE core.citas SET estado = 'cancelada',
           motivo_cancelacion = 'Paciente fallecido', updated_at = now()
     WHERE mascota_id = NEW.id
       AND estado IN ('programada','confirmada')
       AND fecha_hora > now();
    UPDATE core.recordatorios SET completado = true
     WHERE mascota_id = NEW.id AND completado = false;
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: trg_movimiento_aplicar_stock(); Type: FUNCTION; Schema: core; Owner: -
--

CREATE FUNCTION core.trg_movimiento_aplicar_stock() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  v_delta   NUMERIC(12,2);
  v_almacen UUID;
BEGIN
  v_delta := CASE NEW.tipo
    WHEN 'entrada'          THEN  NEW.cantidad
    WHEN 'ajuste_positivo'  THEN  NEW.cantidad
    WHEN 'salida'           THEN -NEW.cantidad
    WHEN 'ajuste_negativo'  THEN -NEW.cantidad
    WHEN 'merma'            THEN -NEW.cantidad
    WHEN 'vencimiento'      THEN -NEW.cantidad
    WHEN 'transferencia'    THEN -NEW.cantidad
  END;

  v_almacen := COALESCE(NEW.almacen_id, (
    SELECT id FROM core.almacenes
     WHERE empresa_id = NEW.empresa_id AND es_principal = true
     LIMIT 1));

  IF v_almacen IS NOT NULL THEN
    INSERT INTO core.stock (empresa_id, producto_id, almacen_id, cantidad)
    VALUES (NEW.empresa_id, NEW.producto_id, v_almacen, v_delta)
    ON CONFLICT (producto_id, almacen_id)
    DO UPDATE SET cantidad = core.stock.cantidad + v_delta, updated_at = now();

    -- El destino de una transferencia recibe la cantidad completa
    IF NEW.tipo = 'transferencia' AND NEW.almacen_destino_id IS NOT NULL THEN
      INSERT INTO core.stock (empresa_id, producto_id, almacen_id, cantidad)
      VALUES (NEW.empresa_id, NEW.producto_id, NEW.almacen_destino_id, NEW.cantidad)
      ON CONFLICT (producto_id, almacen_id)
      DO UPDATE SET cantidad = core.stock.cantidad + NEW.cantidad, updated_at = now();
    END IF;
  END IF;

  -- Lote: mismo delta (salvo transferencia, que no cambia el total del lote)
  IF NEW.lote_id IS NOT NULL AND NEW.tipo <> 'transferencia' THEN
    UPDATE core.lotes SET cantidad = cantidad + v_delta, updated_at = now()
     WHERE id = NEW.lote_id;
  END IF;

  -- Denormalizado del producto: suma de todos sus almacenes
  UPDATE core.productos p
     SET stock_actual = COALESCE((
           SELECT SUM(s.cantidad) FROM core.stock s WHERE s.producto_id = p.id
         ), 0),
         updated_at = now()
   WHERE p.id = NEW.producto_id;

  NEW.saldo_despues := (SELECT stock_actual FROM core.productos WHERE id = NEW.producto_id);
  RETURN NEW;
END;
$$;


--
-- Name: trg_normalizar_cliente(); Type: FUNCTION; Schema: core; Owner: -
--

CREATE FUNCTION core.trg_normalizar_cliente() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'core', 'internal', 'public'
    AS $$
BEGIN
  NEW.numero_documento := internal.normalizar_documento(NEW.numero_documento);
  NEW.nombres          := internal.normalizar_nombre(NEW.nombres);
  NEW.apellido_paterno := internal.normalizar_nombre(NEW.apellido_paterno);
  NEW.apellido_materno := internal.normalizar_nombre(NEW.apellido_materno);
  -- La razón social se recorta pero NO se capitaliza: "SAC", "E.I.R.L." y las
  -- siglas de la marca son parte del nombre legal.
  NEW.razon_social     := internal.normalizar_texto(NEW.razon_social);
  NEW.telefono         := internal.normalizar_telefono(NEW.telefono);
  NEW.telefono_alterno := internal.normalizar_telefono(NEW.telefono_alterno);
  NEW.correo           := internal.normalizar_correo(NEW.correo);
  NEW.direccion        := internal.normalizar_texto(NEW.direccion);
  NEW.ubigeo           := internal.normalizar_codigo(NEW.ubigeo);
  NEW.codigo           := internal.normalizar_codigo(NEW.codigo);
  NEW.observaciones    := internal.normalizar_texto(NEW.observaciones);
  RETURN NEW;
END;
$$;


--
-- Name: trg_normalizar_contacto(); Type: FUNCTION; Schema: core; Owner: -
--

CREATE FUNCTION core.trg_normalizar_contacto() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'core', 'internal', 'public'
    AS $$
BEGIN
  NEW.nombres  := internal.normalizar_nombre(NEW.nombres);
  NEW.cargo    := internal.normalizar_texto(NEW.cargo);
  NEW.telefono := internal.normalizar_telefono(NEW.telefono);
  NEW.correo   := internal.normalizar_correo(NEW.correo);
  RETURN NEW;
END;
$$;


--
-- Name: trg_normalizar_empresa(); Type: FUNCTION; Schema: core; Owner: -
--

CREATE FUNCTION core.trg_normalizar_empresa() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'core', 'internal', 'public'
    AS $$
BEGIN
  NEW.ruc              := internal.normalizar_documento(NEW.ruc);
  NEW.razon_social     := internal.normalizar_texto(NEW.razon_social);
  NEW.nombre_comercial := internal.normalizar_texto(NEW.nombre_comercial);
  NEW.direccion_fiscal := internal.normalizar_texto(NEW.direccion_fiscal);
  NEW.telefono         := internal.normalizar_telefono(NEW.telefono);
  NEW.correo           := internal.normalizar_correo(NEW.correo);
  NEW.ubigeo           := internal.normalizar_codigo(NEW.ubigeo);
  NEW.serie_factura_default    := internal.normalizar_codigo(NEW.serie_factura_default);
  NEW.serie_boleta_default     := internal.normalizar_codigo(NEW.serie_boleta_default);
  NEW.serie_nota_venta_default := internal.normalizar_codigo(NEW.serie_nota_venta_default);
  RETURN NEW;
END;
$$;


--
-- Name: trg_normalizar_mascota(); Type: FUNCTION; Schema: core; Owner: -
--

CREATE FUNCTION core.trg_normalizar_mascota() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'core', 'internal', 'public'
    AS $$
BEGIN
  NEW.nombre              := internal.normalizar_nombre(NEW.nombre);
  NEW.color               := internal.normalizar_texto(NEW.color);
  NEW.microchip           := internal.normalizar_documento(NEW.microchip);
  NEW.num_placa           := internal.normalizar_codigo(NEW.num_placa);
  NEW.codigo              := internal.normalizar_codigo(NEW.codigo);
  NEW.alergias            := internal.normalizar_texto(NEW.alergias);
  NEW.condiciones_cronicas := internal.normalizar_texto(NEW.condiciones_cronicas);
  NEW.senias_particulares := internal.normalizar_texto(NEW.senias_particulares);
  NEW.observaciones       := internal.normalizar_texto(NEW.observaciones);
  RETURN NEW;
END;
$$;


--
-- Name: trg_normalizar_producto(); Type: FUNCTION; Schema: core; Owner: -
--

CREATE FUNCTION core.trg_normalizar_producto() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'core', 'internal', 'public'
    AS $$
BEGIN
  NEW.codigo           := internal.normalizar_codigo(NEW.codigo);
  NEW.codigo_barras    := internal.normalizar_documento(NEW.codigo_barras);
  NEW.nombre           := internal.normalizar_texto(NEW.nombre);
  NEW.principio_activo := internal.normalizar_texto(NEW.principio_activo);
  NEW.laboratorio      := internal.normalizar_texto(NEW.laboratorio);
  NEW.presentacion     := internal.normalizar_texto(NEW.presentacion);
  NEW.unidad_medida    := internal.normalizar_codigo(NEW.unidad_medida);
  NEW.descripcion      := internal.normalizar_texto(NEW.descripcion);
  RETURN NEW;
END;
$$;


--
-- Name: trg_normalizar_proveedor(); Type: FUNCTION; Schema: core; Owner: -
--

CREATE FUNCTION core.trg_normalizar_proveedor() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'core', 'internal', 'public'
    AS $$
BEGIN
  NEW.numero_documento := internal.normalizar_documento(NEW.numero_documento);
  NEW.razon_social     := internal.normalizar_texto(NEW.razon_social);
  NEW.nombre_comercial := internal.normalizar_texto(NEW.nombre_comercial);
  NEW.telefono         := internal.normalizar_telefono(NEW.telefono);
  NEW.correo           := internal.normalizar_correo(NEW.correo);
  NEW.direccion        := internal.normalizar_texto(NEW.direccion);
  NEW.codigo           := internal.normalizar_codigo(NEW.codigo);
  NEW.cuenta_bancaria  := internal.normalizar_documento(NEW.cuenta_bancaria);
  NEW.banco            := internal.normalizar_texto(NEW.banco);
  RETURN NEW;
END;
$$;


--
-- Name: trg_normalizar_servicio(); Type: FUNCTION; Schema: core; Owner: -
--

CREATE FUNCTION core.trg_normalizar_servicio() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'core', 'internal', 'public'
    AS $$
BEGIN
  NEW.codigo      := internal.normalizar_codigo(NEW.codigo);
  NEW.nombre      := internal.normalizar_texto(NEW.nombre);
  NEW.descripcion := internal.normalizar_texto(NEW.descripcion);
  RETURN NEW;
END;
$$;


--
-- Name: trg_normalizar_taxonomia(); Type: FUNCTION; Schema: core; Owner: -
--

CREATE FUNCTION core.trg_normalizar_taxonomia() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'core', 'internal', 'public'
    AS $$
BEGIN
  NEW.nombre := internal.normalizar_texto(NEW.nombre);
  IF TG_TABLE_NAME = 'especies' THEN
    NEW.codigo := internal.normalizar_codigo(NEW.codigo);
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: trg_normalizar_user(); Type: FUNCTION; Schema: core; Owner: -
--

CREATE FUNCTION core.trg_normalizar_user() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'core', 'internal', 'public'
    AS $$
BEGIN
  NEW.email            := internal.normalizar_correo(NEW.email);
  NEW.numero_documento := internal.normalizar_documento(NEW.numero_documento);
  NEW.nombres          := internal.normalizar_nombre(NEW.nombres);
  NEW.apellido_paterno := internal.normalizar_nombre(NEW.apellido_paterno);
  NEW.apellido_materno := internal.normalizar_nombre(NEW.apellido_materno);
  NEW.telefono         := internal.normalizar_telefono(NEW.telefono);
  NEW.codigo           := internal.normalizar_codigo(NEW.codigo);
  NEW.colegiatura      := internal.normalizar_codigo(NEW.colegiatura);
  RETURN NEW;
END;
$$;


--
-- Name: trg_touch_updated_at(); Type: FUNCTION; Schema: core; Owner: -
--

CREATE FUNCTION core.trg_touch_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at := now();
  RETURN NEW;
END;
$$;


--
-- Name: trg_users_validate_rol_scope(); Type: FUNCTION; Schema: core; Owner: -
--

CREATE FUNCTION core.trg_users_validate_rol_scope() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  v_scope core.scope_rol;
BEGIN
  IF NEW.rol_id IS NULL THEN
    RETURN NEW;
  END IF;

  SELECT scope INTO v_scope FROM core.roles WHERE id = NEW.rol_id;

  IF v_scope IN ('global','global_restricted') AND NEW.empresa_id IS NOT NULL THEN
    RAISE EXCEPTION 'Un rol con alcance % no puede estar asignado a una empresa concreta', v_scope
      USING ERRCODE = 'P0001';
  END IF;

  IF v_scope = 'empresa' AND NEW.empresa_id IS NULL THEN
    RAISE EXCEPTION 'Un rol con alcance de empresa requiere empresa_id'
      USING ERRCODE = 'P0001';
  END IF;

  RETURN NEW;
END;
$$;


--
-- Name: assert_acceso_empresa(uuid, uuid, boolean); Type: FUNCTION; Schema: internal; Owner: -
--

CREATE FUNCTION internal.assert_acceso_empresa(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'internal', 'public'
    AS $$
DECLARE
  v_empresa_user UUID;
BEGIN
  IF internal.es_acceso_global(p_user_id, p_is_super_admin) THEN RETURN; END IF;

  IF p_user_id IS NULL THEN
    RAISE EXCEPTION 'Usuario no autenticado' USING ERRCODE = '42501';
  END IF;

  SELECT empresa_id INTO v_empresa_user
  FROM core.users WHERE id = p_user_id AND deleted_at IS NULL;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Usuario no existe' USING ERRCODE = '42501';
  END IF;

  IF v_empresa_user IS NULL OR v_empresa_user <> p_empresa_id THEN
    RAISE EXCEPTION 'Sin acceso a la empresa indicada' USING ERRCODE = '42501';
  END IF;
END;
$$;


--
-- Name: assert_permiso(uuid, character varying); Type: FUNCTION; Schema: internal; Owner: -
--

CREATE FUNCTION internal.assert_permiso(p_user_id uuid, p_codigo_permiso character varying) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'internal', 'public'
    AS $$
DECLARE
  v_is_super BOOLEAN;
  v_rol_id   UUID;
  v_existe   INT;
BEGIN
  -- El token vive 15 minutos. Si en ese rato al usuario se le dio de baja o se
  -- le desactivó la cuenta, el token sigue firmado y válido: la comprobación
  -- del permiso es el único punto donde eso se puede notar.
  SELECT is_super_admin, rol_id INTO v_is_super, v_rol_id
  FROM core.users
  WHERE id = p_user_id AND deleted_at IS NULL AND estado = 'activo';

  IF NOT FOUND THEN
    RAISE EXCEPTION 'La cuenta no está activa' USING ERRCODE = '42501';
  END IF;

  IF v_is_super = true THEN RETURN; END IF;

  IF v_rol_id IS NULL THEN
    RAISE EXCEPTION 'Usuario sin rol asignado' USING ERRCODE = '42501';
  END IF;

  SELECT 1 INTO v_existe
  FROM core.rol_permisos rp
  JOIN core.permisos p ON p.id = rp.permiso_id
  WHERE rp.rol_id = v_rol_id AND p.codigo = p_codigo_permiso
  LIMIT 1;

  IF v_existe IS NULL THEN
    RAISE EXCEPTION 'Permiso requerido: %', p_codigo_permiso USING ERRCODE = '42501';
  END IF;
END;
$$;


--
-- Name: calcular_igv(numeric, numeric); Type: FUNCTION; Schema: internal; Owner: -
--

CREATE FUNCTION internal.calcular_igv(p_base numeric, p_tasa numeric DEFAULT 0.18) RETURNS numeric
    LANGUAGE sql IMMUTABLE
    AS $$
  SELECT round(COALESCE(p_base,0) * COALESCE(p_tasa, 0.18), 2);
$$;


--
-- Name: consumir_producto_clinico(uuid, uuid, numeric, uuid, jsonb); Type: FUNCTION; Schema: internal; Owner: -
--

CREATE FUNCTION internal.consumir_producto_clinico(p_empresa_id uuid, p_producto_id uuid, p_cantidad numeric, p_user_id uuid, p_refs jsonb DEFAULT '{}'::jsonb) RETURNS uuid
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'internal', 'public'
    AS $$
DECLARE
  v_id      UUID;
  v_mascota UUID := NULLIF(p_refs->>'mascota_id','')::uuid;
  v_consulta UUID := NULLIF(p_refs->>'consulta_id','')::uuid;
  v_cirugia  UUID := NULLIF(p_refs->>'cirugia_id','')::uuid;
  v_hosp     UUID := NULLIF(p_refs->>'hospitalizacion_id','')::uuid;
  v_precio  NUMERIC(12,2);
BEGIN
  -- El paciente se hereda del acto clínico si no vino explícito.
  IF v_mascota IS NULL THEN
    v_mascota := COALESCE(
      (SELECT mascota_id FROM core.consultas         WHERE id = v_consulta),
      (SELECT mascota_id FROM core.cirugias          WHERE id = v_cirugia),
      (SELECT mascota_id FROM core.hospitalizaciones WHERE id = v_hosp));
  END IF;

  SELECT COALESCE(NULLIF(p_refs->>'precio_unitario','')::numeric, precio_venta)
    INTO v_precio
    FROM core.productos WHERE id = p_producto_id AND empresa_id = p_empresa_id;

  IF v_precio IS NULL THEN
    RAISE EXCEPTION 'Producto no encontrado' USING ERRCODE = 'P0002';
  END IF;

  PERFORM internal.mover_stock(
    p_empresa_id, p_producto_id, 'salida', 'uso_clinico', p_cantidad, p_user_id,
    NULLIF(p_refs->>'almacen_id','')::uuid,
    jsonb_build_object(
      'mascota_id', v_mascota,
      'consulta_id', v_consulta,
      'observaciones', COALESCE(p_refs->>'observaciones', 'Insumo usado en atención clínica')));

  INSERT INTO core.insumos_utilizados (
    empresa_id, producto_id, mascota_id, consulta_id, cirugia_id,
    hospitalizacion_id, orden_servicio_id, cantidad, precio_unitario, created_by
  ) VALUES (
    p_empresa_id, p_producto_id, v_mascota, v_consulta, v_cirugia, v_hosp,
    NULLIF(p_refs->>'orden_servicio_id','')::uuid,
    p_cantidad, v_precio, p_user_id
  ) RETURNING id INTO v_id;

  RETURN v_id;
END;
$$;


--
-- Name: edad_mascota(date, integer); Type: FUNCTION; Schema: internal; Owner: -
--

CREATE FUNCTION internal.edad_mascota(p_fecha_nacimiento date, p_edad_aprox_meses integer DEFAULT NULL::integer) RETURNS jsonb
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
  v_meses INT;
  v_anios INT;
  v_resto INT;
BEGIN
  IF p_fecha_nacimiento IS NOT NULL THEN
    v_meses := (EXTRACT(YEAR FROM age(CURRENT_DATE, p_fecha_nacimiento)) * 12
              + EXTRACT(MONTH FROM age(CURRENT_DATE, p_fecha_nacimiento)))::int;
  ELSIF p_edad_aprox_meses IS NOT NULL THEN
    v_meses := p_edad_aprox_meses;
  ELSE
    RETURN jsonb_build_object('meses', NULL, 'texto', 'Edad desconocida');
  END IF;

  v_anios := v_meses / 12;
  v_resto := v_meses % 12;

  RETURN jsonb_build_object(
    'meses', v_meses,
    'anios', v_anios,
    'texto', CASE
      WHEN v_anios = 0 THEN v_resto || ' ' || CASE WHEN v_resto = 1 THEN 'mes' ELSE 'meses' END
      WHEN v_resto = 0 THEN v_anios || ' ' || CASE WHEN v_anios = 1 THEN 'año' ELSE 'años' END
      ELSE v_anios || ' ' || CASE WHEN v_anios = 1 THEN 'año' ELSE 'años' END
           || ' ' || v_resto || ' ' || CASE WHEN v_resto = 1 THEN 'mes' ELSE 'meses' END
    END
  );
END;
$$;


--
-- Name: empresa_efectiva(uuid, uuid, boolean); Type: FUNCTION; Schema: internal; Owner: -
--

CREATE FUNCTION internal.empresa_efectiva(p_user_id uuid, p_empresa_id uuid, p_is_super_admin boolean DEFAULT false) RETURNS uuid
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'internal', 'public'
    AS $$
DECLARE
  v_emp UUID;
BEGIN
  IF p_empresa_id IS NOT NULL THEN RETURN p_empresa_id; END IF;

  SELECT empresa_id INTO v_emp FROM core.users WHERE id = p_user_id;
  IF v_emp IS NOT NULL THEN RETURN v_emp; END IF;

  IF internal.es_acceso_global(p_user_id, p_is_super_admin) THEN
    SELECT id INTO v_emp FROM core.empresas
     WHERE estado = 'activa' AND deleted_at IS NULL
     ORDER BY created_at LIMIT 1;
  END IF;

  RETURN v_emp;
END;
$$;


--
-- Name: error_jsonb(text, text, text); Type: FUNCTION; Schema: internal; Owner: -
--

CREATE FUNCTION internal.error_jsonb(p_code text, p_message text, p_field text DEFAULT NULL::text) RETURNS jsonb
    LANGUAGE sql IMMUTABLE
    AS $$
  SELECT jsonb_strip_nulls(jsonb_build_object(
    'code', p_code, 'message', p_message, 'field', p_field
  ));
$$;


--
-- Name: es_acceso_global(uuid, boolean); Type: FUNCTION; Schema: internal; Owner: -
--

CREATE FUNCTION internal.es_acceso_global(p_user_id uuid, p_is_super_admin boolean DEFAULT false) RETURNS boolean
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'internal', 'public'
    AS $$
DECLARE
  v_scope core.scope_rol;
  v_super BOOLEAN;
BEGIN
  IF p_is_super_admin = true THEN RETURN true; END IF;
  IF p_user_id IS NULL THEN RETURN false; END IF;

  SELECT u.is_super_admin, r.scope INTO v_super, v_scope
  FROM core.users u
  LEFT JOIN core.roles r ON r.id = u.rol_id
  WHERE u.id = p_user_id AND u.deleted_at IS NULL;

  IF v_super = true THEN RETURN true; END IF;
  RETURN COALESCE(v_scope IN ('global','global_restricted'), false);
END;
$$;


--
-- Name: es_de_empresa(uuid, boolean, uuid, uuid); Type: FUNCTION; Schema: internal; Owner: -
--

CREATE FUNCTION internal.es_de_empresa(p_user_id uuid, p_is_super_admin boolean, p_empresa_contexto uuid, p_empresa_registro uuid) RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'internal', 'public'
    AS $$
  SELECT p_empresa_registro IS NOT NULL
     AND (internal.es_acceso_global(p_user_id, p_is_super_admin)
          OR p_empresa_registro = p_empresa_contexto);
$$;


--
-- Name: ficha_paciente(uuid); Type: FUNCTION; Schema: internal; Owner: -
--

CREATE FUNCTION internal.ficha_paciente(p_mascota_id uuid) RETURNS jsonb
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'internal', 'public'
    AS $$
  SELECT jsonb_build_object(
    'paciente', jsonb_build_object(
      'id',            m.id,
      'codigo',        m.codigo,
      'nombre',        m.nombre,
      'especie',       esp.nombre,
      'raza',          COALESCE(r.nombre, 'Mestizo'),
      'sexo',          m.sexo,
      'color',         m.color,
      'senias',        m.senias_particulares,
      'fecha_nacimiento', m.fecha_nacimiento,
      'edad',          internal.edad_mascota(m.fecha_nacimiento, m.edad_aproximada_meses),
      'peso_kg',       m.peso_kg,
      'microchip',     m.microchip,
      'esterilizado',  m.esterilizado,
      'alergias',      m.alergias,
      'condiciones_cronicas', m.condiciones_cronicas),
    'propietario', jsonb_build_object(
      'id',            cl.id,
      'nombre',        COALESCE(NULLIF(cl.razon_social,''),
                                trim(cl.nombres || ' ' || COALESCE(cl.apellido_paterno,'') || ' ' ||
                                     COALESCE(cl.apellido_materno,''))),
      'tipo_documento',   cl.tipo_documento,
      'numero_documento', cl.numero_documento,
      'direccion',     cl.direccion,
      'telefono',      cl.telefono,
      'correo',        cl.correo))
  FROM core.mascotas m
  JOIN core.clientes cl ON cl.id = m.cliente_id
  JOIN core.especies esp ON esp.id = m.especie_id
  LEFT JOIN core.razas r ON r.id = m.raza_id
  WHERE m.id = p_mascota_id;
$$;


--
-- Name: firma_profesional(uuid); Type: FUNCTION; Schema: internal; Owner: -
--

CREATE FUNCTION internal.firma_profesional(p_user_id uuid) RETURNS jsonb
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'internal', 'public'
    AS $$
  SELECT jsonb_build_object(
    'nombre', trim(u.nombres || ' ' || COALESCE(u.apellido_paterno,'') || ' ' ||
                   COALESCE(u.apellido_materno,'')),
    'colegiatura', u.colegiatura,
    'es_veterinario', u.es_veterinario,
    'especializacion', esp.nombre)
  FROM core.users u
  LEFT JOIN core.especializaciones esp ON esp.id = u.especializacion_id
  WHERE u.id = p_user_id;
$$;


--
-- Name: hay_solapamiento_cita(uuid, uuid, timestamp with time zone, integer, uuid); Type: FUNCTION; Schema: internal; Owner: -
--

CREATE FUNCTION internal.hay_solapamiento_cita(p_empresa_id uuid, p_veterinario_id uuid, p_inicio timestamp with time zone, p_duracion_min integer, p_excluir_cita uuid DEFAULT NULL::uuid) RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'internal', 'public'
    AS $$
  SELECT EXISTS (
    SELECT 1 FROM core.citas c
    WHERE c.empresa_id = p_empresa_id
      AND c.veterinario_id = p_veterinario_id
      AND c.deleted_at IS NULL
      AND c.estado NOT IN ('cancelada','no_asistio')
      AND (p_excluir_cita IS NULL OR c.id <> p_excluir_cita)
      AND tstzrange(c.fecha_hora, c.fecha_hora + (c.duracion_min || ' minutes')::interval)
          && tstzrange(p_inicio, p_inicio + (p_duracion_min || ' minutes')::interval)
  );
$$;


--
-- Name: lotes_a_consumir(uuid, numeric, boolean); Type: FUNCTION; Schema: internal; Owner: -
--

CREATE FUNCTION internal.lotes_a_consumir(p_producto_id uuid, p_cantidad numeric, p_incluir_vencidos boolean DEFAULT false) RETURNS TABLE(lote_id uuid, cantidad numeric, costo_unitario numeric)
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'internal', 'public'
    AS $$
DECLARE
  v_resta NUMERIC := p_cantidad;
  v_lote  RECORD;
BEGIN
  FOR v_lote IN
    SELECT l.id, l.cantidad AS disponible, l.costo_unitario
      FROM core.lotes l
     WHERE l.producto_id = p_producto_id
       AND l.cantidad > 0
       AND (p_incluir_vencidos
            OR l.fecha_vencimiento IS NULL
            OR l.fecha_vencimiento >= CURRENT_DATE)
     ORDER BY l.fecha_vencimiento NULLS LAST, l.created_at
  LOOP
    EXIT WHEN v_resta <= 0;
    lote_id        := v_lote.id;
    cantidad       := LEAST(v_resta, v_lote.disponible);
    costo_unitario := v_lote.costo_unitario;
    v_resta        := v_resta - cantidad;
    RETURN NEXT;
  END LOOP;
END;
$$;


--
-- Name: membrete_empresa(uuid); Type: FUNCTION; Schema: internal; Owner: -
--

CREATE FUNCTION internal.membrete_empresa(p_empresa_id uuid) RETURNS jsonb
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'internal', 'public'
    AS $$
  SELECT jsonb_build_object(
    'razon_social',     e.razon_social,
    'nombre_comercial', COALESCE(e.nombre_comercial, e.razon_social),
    'ruc',              e.ruc,
    'direccion',        e.direccion_fiscal,
    'distrito',         e.distrito,
    'telefono',         e.telefono,
    'correo',           e.correo,
    'logo_url',         e.logo_url)
  FROM core.empresas e WHERE e.id = p_empresa_id;
$$;


--
-- Name: mover_stock(uuid, uuid, core.tipo_movimiento_inventario, core.motivo_movimiento, numeric, uuid, uuid, jsonb); Type: FUNCTION; Schema: internal; Owner: -
--

CREATE FUNCTION internal.mover_stock(p_empresa_id uuid, p_producto_id uuid, p_tipo core.tipo_movimiento_inventario, p_motivo core.motivo_movimiento, p_cantidad numeric, p_user_id uuid, p_almacen_id uuid DEFAULT NULL::uuid, p_refs jsonb DEFAULT '{}'::jsonb) RETURNS uuid
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'internal', 'public'
    AS $$
DECLARE
  v_id       UUID;
  v_stock    NUMERIC;
  v_almacen  UUID;
  v_es_salida BOOLEAN;
  v_lotes    BOOLEAN;
  v_lote_ref UUID := NULLIF(p_refs->>'lote_id','')::uuid;
  v_saca_vencidos BOOLEAN;
  v_repartido NUMERIC := 0;
  v_tramo    RECORD;
BEGIN
  IF p_cantidad IS NULL OR p_cantidad <= 0 THEN
    RAISE EXCEPTION 'La cantidad del movimiento debe ser mayor a cero' USING ERRCODE = 'P0001';
  END IF;

  v_almacen := COALESCE(p_almacen_id, (
    SELECT id FROM core.almacenes
     WHERE empresa_id = p_empresa_id AND es_principal = true LIMIT 1));

  v_es_salida := p_tipo IN ('salida','ajuste_negativo','merma','vencimiento','transferencia');

  -- Una salida no puede dejar el stock en negativo
  IF v_es_salida THEN
    SELECT COALESCE(SUM(cantidad), 0) INTO v_stock
      FROM core.stock WHERE producto_id = p_producto_id
       AND (v_almacen IS NULL OR almacen_id = v_almacen);
    IF v_stock < p_cantidad THEN
      RAISE EXCEPTION 'Stock insuficiente: disponible %, solicitado %', v_stock, p_cantidad
        USING ERRCODE = 'P0001';
    END IF;
  END IF;

  SELECT maneja_lotes INTO v_lotes FROM core.productos WHERE id = p_producto_id;

  -- Salida de un producto con lotes y sin lote indicado: se reparte por FEFO.
  IF v_es_salida AND COALESCE(v_lotes, false) AND v_lote_ref IS NULL
     AND p_tipo <> 'transferencia'
     AND EXISTS (SELECT 1 FROM core.lotes WHERE producto_id = p_producto_id AND cantidad > 0)
  THEN
    -- Los movimientos que existen para retirar producto vencido sí lo alcanzan;
    -- una salida clínica o una venta, no.
    v_saca_vencidos := p_tipo IN ('merma','vencimiento','ajuste_negativo');

    FOR v_tramo IN
      SELECT * FROM internal.lotes_a_consumir(p_producto_id, p_cantidad, v_saca_vencidos)
    LOOP
      v_id := internal.registrar_kardex(
        p_empresa_id, p_producto_id, v_almacen, p_tipo, p_motivo,
        v_tramo.cantidad, p_user_id,
        p_refs || jsonb_build_object(
          'lote_id', v_tramo.lote_id,
          'costo_unitario', COALESCE((p_refs->>'costo_unitario')::numeric, v_tramo.costo_unitario)));
      v_repartido := v_repartido + v_tramo.cantidad;
    END LOOP;

    IF v_repartido < p_cantidad THEN
      RAISE EXCEPTION
        'Stock insuficiente en lotes vigentes: disponible %, solicitado %. Revisa vencimientos.',
        v_repartido, p_cantidad USING ERRCODE = 'P0001';
    END IF;

    RETURN v_id;
  END IF;

  RETURN internal.registrar_kardex(
    p_empresa_id, p_producto_id, v_almacen, p_tipo, p_motivo,
    p_cantidad, p_user_id, p_refs);
END;
$$;


--
-- Name: normalizar(text); Type: FUNCTION; Schema: internal; Owner: -
--

CREATE FUNCTION internal.normalizar(p_texto text) RETURNS text
    LANGUAGE sql IMMUTABLE
    AS $$
  SELECT lower(unaccent(coalesce(p_texto, '')));
$$;


--
-- Name: normalizar_codigo(text); Type: FUNCTION; Schema: internal; Owner: -
--

CREATE FUNCTION internal.normalizar_codigo(p_valor text) RETURNS text
    LANGUAGE sql IMMUTABLE
    AS $$
  SELECT NULLIF(upper(btrim(coalesce(p_valor, ''))), '');
$$;


--
-- Name: normalizar_correo(text); Type: FUNCTION; Schema: internal; Owner: -
--

CREATE FUNCTION internal.normalizar_correo(p_valor text) RETURNS text
    LANGUAGE sql IMMUTABLE
    AS $$
  SELECT NULLIF(lower(btrim(coalesce(p_valor, ''))), '');
$$;


--
-- Name: normalizar_documento(text); Type: FUNCTION; Schema: internal; Owner: -
--

CREATE FUNCTION internal.normalizar_documento(p_valor text) RETURNS text
    LANGUAGE sql IMMUTABLE
    AS $$
  SELECT NULLIF(upper(regexp_replace(coalesce(p_valor, ''), '[^A-Za-z0-9]', '', 'g')), '');
$$;


--
-- Name: normalizar_nombre(text); Type: FUNCTION; Schema: internal; Owner: -
--

CREATE FUNCTION internal.normalizar_nombre(p_valor text) RETURNS text
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
  v_particulas TEXT[] := ARRAY['de','del','la','las','los','y','e','da','do','van','von','di'];
  v_palabras   TEXT[];
  v_salida     TEXT[] := '{}';
  v_p          TEXT;
  i            INT := 0;
BEGIN
  IF internal.normalizar_texto(p_valor) IS NULL THEN RETURN NULL; END IF;

  v_palabras := regexp_split_to_array(lower(internal.normalizar_texto(p_valor)), ' ');
  FOREACH v_p IN ARRAY v_palabras LOOP
    i := i + 1;
    IF i > 1 AND v_p = ANY (v_particulas) THEN
      v_salida := v_salida || v_p;
    ELSE
      -- initcap por palabra: respeta guiones ("Ana-María") y apóstrofes.
      v_salida := v_salida || initcap(v_p);
    END IF;
  END LOOP;

  RETURN array_to_string(v_salida, ' ');
END;
$$;


--
-- Name: normalizar_telefono(text); Type: FUNCTION; Schema: internal; Owner: -
--

CREATE FUNCTION internal.normalizar_telefono(p_valor text) RETURNS text
    LANGUAGE sql IMMUTABLE
    AS $$
  SELECT NULLIF(
    CASE WHEN btrim(coalesce(p_valor, '')) LIKE '+%' THEN '+' ELSE '' END
      || regexp_replace(coalesce(p_valor, ''), '[^0-9]', '', 'g'),
    '');
$$;


--
-- Name: normalizar_texto(text); Type: FUNCTION; Schema: internal; Owner: -
--

CREATE FUNCTION internal.normalizar_texto(p_valor text) RETURNS text
    LANGUAGE sql IMMUTABLE
    AS $$
  SELECT NULLIF(regexp_replace(btrim(coalesce(p_valor, '')), '\s+', ' ', 'g'), '');
$$;


--
-- Name: password_invalida(text, text); Type: FUNCTION; Schema: internal; Owner: -
--

CREATE FUNCTION internal.password_invalida(p_password text, p_email text DEFAULT NULL::text) RETURNS text
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
  v_local TEXT;
BEGIN
  IF p_password IS NULL OR length(p_password) < 8 THEN
    RETURN 'La contraseña debe tener al menos 8 caracteres';
  END IF;
  IF p_password !~ '[A-Za-zÁÉÍÓÚáéíóúÑñ]' THEN
    RETURN 'La contraseña debe incluir al menos una letra';
  END IF;
  IF p_password !~ '[0-9]' THEN
    RETURN 'La contraseña debe incluir al menos un número';
  END IF;
  IF lower(p_password) IN (
       '12345678','123456789','contrasena','password','qwertyui','abc12345',
       'clinica1','veterinaria1','admin123','11111111') THEN
    RETURN 'Esa contraseña es demasiado común, elige otra';
  END IF;
  IF p_email IS NOT NULL THEN
    v_local := split_part(lower(p_email), '@', 1);
    IF length(v_local) >= 4 AND position(v_local IN lower(p_password)) > 0 THEN
      RETURN 'La contraseña no puede contener tu correo';
    END IF;
  END IF;
  RETURN NULL;
END;
$$;


--
-- Name: plantilla_de(uuid, text); Type: FUNCTION; Schema: internal; Owner: -
--

CREATE FUNCTION internal.plantilla_de(p_empresa_id uuid, p_tipo text) RETURNS text
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'internal', 'public'
    AS $$
DECLARE
  v_texto TEXT;
BEGIN
  SELECT texto INTO v_texto FROM core.plantillas_mensaje
   WHERE empresa_id = p_empresa_id AND tipo = p_tipo
     AND canal = 'whatsapp' AND estado = 'activo';

  IF v_texto IS NOT NULL THEN RETURN v_texto; END IF;

  RETURN CASE p_tipo
    WHEN 'vacuna' THEN
      'Hola {{propietario}}, te escribimos de {{clinica}}. A {{paciente}} le toca el refuerzo de su vacuna el {{fecha}}. ¿Coordinamos una cita?'
    WHEN 'desparasitacion' THEN
      'Hola {{propietario}}, te escribimos de {{clinica}}. A {{paciente}} le corresponde su desparasitación el {{fecha}}. ¿Te reservamos un horario?'
    WHEN 'control' THEN
      'Hola {{propietario}}, te escribimos de {{clinica}}. El control de {{paciente}} está previsto para el {{fecha}}. ¿Confirmamos la cita?'
    WHEN 'cita' THEN
      'Hola {{propietario}}, te recordamos la cita de {{paciente}} en {{clinica}} el {{fecha}}. Si no puedes asistir, avísanos y la reprogramamos.'
    WHEN 'cumpleanios' THEN
      '¡Hola {{propietario}}! Hoy {{paciente}} está de cumpleaños. Le mandamos un saludo de todo el equipo de {{clinica}}. 🎉'
    WHEN 'deuda' THEN
      'Hola {{propietario}}, te escribimos de {{clinica}} por el saldo pendiente de la atención de {{paciente}}. Cualquier duda, con gusto la vemos.'
    ELSE
      'Hola {{propietario}}, te escribimos de {{clinica}} por {{titulo}}.'
  END;
END;
$$;


--
-- Name: prioridad_mas_grave(core.prioridad_cita, core.prioridad_cita); Type: FUNCTION; Schema: internal; Owner: -
--

CREATE FUNCTION internal.prioridad_mas_grave(a core.prioridad_cita, b core.prioridad_cita) RETURNS core.prioridad_cita
    LANGUAGE sql IMMUTABLE
    AS $$
  SELECT CASE
    WHEN 'emergencia' IN (a::text, b::text) THEN 'emergencia'
    WHEN 'urgencia'   IN (a::text, b::text) THEN 'urgencia'
    WHEN 'preferente' IN (a::text, b::text) THEN 'preferente'
    ELSE 'normal'
  END::core.prioridad_cita;
$$;


--
-- Name: recalcular_saldo_comprobante(uuid); Type: FUNCTION; Schema: internal; Owner: -
--

CREATE FUNCTION internal.recalcular_saldo_comprobante(p_comprobante_id uuid) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'internal', 'public'
    AS $$
DECLARE
  v_total    NUMERIC(14,2);
  v_aplicado NUMERIC(14,2);
  v_saldo    NUMERIC(14,2);
BEGIN
  SELECT total INTO v_total FROM core.comprobantes WHERE id = p_comprobante_id;
  IF v_total IS NULL THEN RETURN; END IF;

  SELECT COALESCE(SUM(pa.monto_aplicado), 0) INTO v_aplicado
  FROM core.pago_aplicaciones pa
  JOIN core.pagos p ON p.id = pa.pago_id AND p.anulado_at IS NULL
  WHERE pa.comprobante_id = p_comprobante_id;

  v_saldo := v_total - v_aplicado;

  UPDATE core.comprobantes
     SET saldo_pendiente = v_saldo,
         estado_pago = CASE
           WHEN v_saldo <= 0   THEN 'pagado'::core.estado_pago
           WHEN v_aplicado > 0 THEN 'parcial'::core.estado_pago
           ELSE 'pendiente'::core.estado_pago
         END,
         updated_at = now()
   WHERE id = p_comprobante_id;
END;
$$;


--
-- Name: registrar_auditoria(uuid, uuid, character varying, character varying, uuid, jsonb, jsonb); Type: FUNCTION; Schema: internal; Owner: -
--

CREATE FUNCTION internal.registrar_auditoria(p_user_id uuid, p_empresa_id uuid, p_accion character varying, p_entidad character varying, p_entidad_id uuid, p_antes jsonb DEFAULT NULL::jsonb, p_despues jsonb DEFAULT NULL::jsonb) RETURNS uuid
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'internal', 'public'
    AS $$
DECLARE
  v_id   UUID;
  v_diff JSONB := '{}'::jsonb;
  v_key  TEXT;
BEGIN
  IF p_antes IS NOT NULL AND p_despues IS NOT NULL THEN
    FOR v_key IN
      SELECT k FROM jsonb_object_keys(p_antes) AS k
      UNION
      SELECT k FROM jsonb_object_keys(p_despues) AS k
    LOOP
      IF (p_antes->v_key) IS DISTINCT FROM (p_despues->v_key) THEN
        v_diff := v_diff || jsonb_build_object(
          v_key, jsonb_build_object('antes', p_antes->v_key, 'despues', p_despues->v_key));
      END IF;
    END LOOP;
  ELSIF p_despues IS NOT NULL THEN
    v_diff := jsonb_build_object('_creado', p_despues);
  ELSIF p_antes IS NOT NULL THEN
    v_diff := jsonb_build_object('_eliminado', p_antes);
  END IF;

  -- La IP y el agente los deja el backend como ajustes de sesión antes de
  -- llamar al SP (`app.client_ip`, `app.user_agent`). El segundo argumento de
  -- current_setting evita que reviente cuando no están: hay SPs que se llaman
  -- desde psql o desde un cron, y ahí simplemente no hay petición HTTP.
  INSERT INTO core.audit_log (
    user_id, empresa_id, accion, entidad, entidad_id, datos_antes, datos_despues, diff,
    ip, user_agent
  ) VALUES (
    p_user_id, p_empresa_id, p_accion, p_entidad, p_entidad_id, p_antes, p_despues, v_diff,
    NULLIF(current_setting('app.client_ip', true), ''),
    NULLIF(current_setting('app.user_agent', true), '')
  ) RETURNING id INTO v_id;

  RETURN v_id;
END;
$$;


--
-- Name: registrar_cargo_servicio(uuid, uuid, uuid, uuid, numeric, jsonb); Type: FUNCTION; Schema: internal; Owner: -
--

CREATE FUNCTION internal.registrar_cargo_servicio(p_empresa_id uuid, p_servicio_id uuid, p_mascota_id uuid, p_user_id uuid, p_cantidad numeric DEFAULT 1, p_refs jsonb DEFAULT '{}'::jsonb) RETURNS uuid
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'internal', 'public'
    AS $$
DECLARE
  v_id      UUID;
  v_cliente UUID;
  v_precio  NUMERIC(12,2);
  v_tabla   TEXT := NULLIF(p_refs->>'origen_tabla','');
  v_origen  UUID := NULLIF(p_refs->>'origen_id','')::uuid;
BEGIN
  IF p_servicio_id IS NULL OR p_mascota_id IS NULL THEN
    RETURN NULL;
  END IF;

  SELECT cliente_id INTO v_cliente FROM core.mascotas WHERE id = p_mascota_id;
  IF v_cliente IS NULL THEN RETURN NULL; END IF;

  SELECT COALESCE(NULLIF(p_refs->>'precio_unitario','')::numeric, s.precio)
    INTO v_precio
    FROM core.servicios s
   WHERE s.id = p_servicio_id AND s.empresa_id = p_empresa_id AND s.deleted_at IS NULL;

  IF v_precio IS NULL THEN RETURN NULL; END IF;

  -- Idempotencia: el mismo acto no se cobra dos veces aunque se reabra.
  IF v_tabla IS NOT NULL AND v_origen IS NOT NULL THEN
    SELECT id INTO v_id FROM core.ordenes_servicio
     WHERE empresa_id = p_empresa_id AND origen_tabla = v_tabla AND origen_id = v_origen
       AND estado <> 'anulado';
    IF v_id IS NOT NULL THEN RETURN v_id; END IF;
  END IF;

  INSERT INTO core.ordenes_servicio (
    empresa_id, codigo, mascota_id, cliente_id, servicio_id, veterinario_id,
    cita_id, consulta_id, cantidad, precio_unitario, descuento, total,
    descripcion, origen_tabla, origen_id, estado, created_by
  ) VALUES (
    p_empresa_id, internal.siguiente_numero(p_empresa_id, 'OS', 6),
    p_mascota_id, v_cliente, p_servicio_id,
    COALESCE(NULLIF(p_refs->>'veterinario_id','')::uuid, p_user_id),
    NULLIF(p_refs->>'cita_id','')::uuid,
    NULLIF(p_refs->>'consulta_id','')::uuid,
    p_cantidad, v_precio, 0, round(p_cantidad * v_precio, 2),
    p_refs->>'descripcion', v_tabla, v_origen,
    'completado', p_user_id
  ) RETURNING id INTO v_id;

  RETURN v_id;
END;
$$;


--
-- Name: registrar_evento_clinico(uuid, uuid, uuid, uuid, core.tipo_evento_clinico, character varying, text, uuid, uuid, timestamp with time zone); Type: FUNCTION; Schema: internal; Owner: -
--

CREATE FUNCTION internal.registrar_evento_clinico(p_empresa_id uuid, p_mascota_id uuid, p_cliente_id uuid, p_veterinario_id uuid, p_tipo core.tipo_evento_clinico, p_titulo character varying, p_resumen text DEFAULT NULL::text, p_entidad_id uuid DEFAULT NULL::uuid, p_cita_id uuid DEFAULT NULL::uuid, p_fecha timestamp with time zone DEFAULT NULL::timestamp with time zone) RETURNS uuid
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'internal', 'public'
    AS $$
DECLARE
  v_id UUID;
BEGIN
  INSERT INTO core.historia_clinica (
    empresa_id, mascota_id, cliente_id, veterinario_id, cita_id,
    tipo_evento, fecha, titulo, resumen, entidad_id, created_by
  ) VALUES (
    p_empresa_id, p_mascota_id, p_cliente_id, p_veterinario_id, p_cita_id,
    p_tipo, COALESCE(p_fecha, now()), p_titulo, p_resumen, p_entidad_id, p_veterinario_id
  ) RETURNING id INTO v_id;
  RETURN v_id;
END;
$$;


--
-- Name: registrar_kardex(uuid, uuid, uuid, core.tipo_movimiento_inventario, core.motivo_movimiento, numeric, uuid, jsonb); Type: FUNCTION; Schema: internal; Owner: -
--

CREATE FUNCTION internal.registrar_kardex(p_empresa_id uuid, p_producto_id uuid, p_almacen_id uuid, p_tipo core.tipo_movimiento_inventario, p_motivo core.motivo_movimiento, p_cantidad numeric, p_user_id uuid, p_refs jsonb DEFAULT '{}'::jsonb) RETURNS uuid
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'internal', 'public'
    AS $$
DECLARE
  v_id UUID;
BEGIN
  INSERT INTO core.movimientos_inventario (
    empresa_id, producto_id, almacen_id, almacen_destino_id, lote_id,
    tipo, motivo, cantidad, costo_unitario,
    cliente_id, proveedor_id, mascota_id, consulta_id, comprobante_id, orden_compra_id,
    observaciones, created_by
  ) VALUES (
    p_empresa_id, p_producto_id, p_almacen_id,
    NULLIF(p_refs->>'almacen_destino_id','')::uuid,
    NULLIF(p_refs->>'lote_id','')::uuid,
    p_tipo, p_motivo, p_cantidad,
    COALESCE((p_refs->>'costo_unitario')::numeric, 0),
    NULLIF(p_refs->>'cliente_id','')::uuid,
    NULLIF(p_refs->>'proveedor_id','')::uuid,
    NULLIF(p_refs->>'mascota_id','')::uuid,
    NULLIF(p_refs->>'consulta_id','')::uuid,
    NULLIF(p_refs->>'comprobante_id','')::uuid,
    NULLIF(p_refs->>'orden_compra_id','')::uuid,
    p_refs->>'observaciones', p_user_id
  ) RETURNING id INTO v_id;

  RETURN v_id;
END;
$$;


--
-- Name: render_plantilla(text, jsonb); Type: FUNCTION; Schema: internal; Owner: -
--

CREATE FUNCTION internal.render_plantilla(p_texto text, p_vars jsonb) RETURNS text
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
  v_out TEXT := COALESCE(p_texto, '');
  v_k   TEXT;
BEGIN
  FOR v_k IN SELECT jsonb_object_keys(COALESCE(p_vars, '{}'::jsonb)) LOOP
    v_out := replace(v_out, '{{' || v_k || '}}', COALESCE(p_vars->>v_k, ''));
  END LOOP;
  -- Lo que quedó sin reemplazar se borra: es preferible una frase corta a
  -- mandarle al propietario un "{{fecha}}" en el mensaje.
  RETURN btrim(regexp_replace(v_out, '\{\{[a-z_]+\}\}', '', 'g'));
END;
$$;


--
-- Name: siguiente_numero(uuid, character varying, integer); Type: FUNCTION; Schema: internal; Owner: -
--

CREATE FUNCTION internal.siguiente_numero(p_empresa_id uuid, p_prefijo character varying, p_ancho integer DEFAULT 6) RETURNS character varying
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'internal', 'public'
    AS $$
DECLARE
  v_numero INT;
BEGIN
  v_numero := internal.siguiente_numero_documento(p_empresa_id, p_prefijo, '0001');
  RETURN p_prefijo || '-' || lpad(v_numero::text, p_ancho, '0');
END;
$$;


--
-- Name: siguiente_numero_documento(uuid, character varying, character varying); Type: FUNCTION; Schema: internal; Owner: -
--

CREATE FUNCTION internal.siguiente_numero_documento(p_empresa_id uuid, p_tipo_documento character varying, p_serie character varying) RETURNS integer
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'internal', 'public'
    AS $$
DECLARE
  v_numero INT;
BEGIN
  INSERT INTO core.correlativos (empresa_id, tipo_documento, serie, ultimo_numero)
  VALUES (p_empresa_id, p_tipo_documento, p_serie, 0)
  ON CONFLICT DO NOTHING;

  UPDATE core.correlativos
     SET ultimo_numero = ultimo_numero + 1, updated_at = now()
   WHERE empresa_id = p_empresa_id
     AND tipo_documento = p_tipo_documento
     AND serie = p_serie
   RETURNING ultimo_numero INTO v_numero;

  RETURN v_numero;
END;
$$;


--
-- Name: telefono_whatsapp(text); Type: FUNCTION; Schema: internal; Owner: -
--

CREATE FUNCTION internal.telefono_whatsapp(p_telefono text) RETURNS text
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
  v TEXT := regexp_replace(COALESCE(p_telefono, ''), '[^0-9]', '', 'g');
BEGIN
  IF v = '' THEN RETURN NULL; END IF;

  -- Ya viene con código de país.
  IF length(v) = 11 AND left(v, 2) = '51' AND substr(v, 3, 1) = '9' THEN
    RETURN v;
  END IF;

  -- Celular peruano: 9 dígitos que empiezan en 9.
  IF length(v) = 9 AND left(v, 1) = '9' THEN
    RETURN '51' || v;
  END IF;

  -- Número extranjero ya internacionalizado (se guardó con "+").
  IF btrim(COALESCE(p_telefono, '')) LIKE '+%' AND length(v) BETWEEN 10 AND 15 THEN
    RETURN v;
  END IF;

  -- Fijo u otro formato: no hay WhatsApp al que escribir.
  RETURN NULL;
END;
$$;


--
-- Name: tiene_permiso(uuid, character varying); Type: FUNCTION; Schema: internal; Owner: -
--

CREATE FUNCTION internal.tiene_permiso(p_user_id uuid, p_codigo_permiso character varying) RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'core', 'internal', 'public'
    AS $$
  SELECT COALESCE(
    (SELECT u.is_super_admin FROM core.users u
      WHERE u.id = p_user_id AND u.deleted_at IS NULL AND u.estado = 'activo'),
    false)
  OR EXISTS (
    SELECT 1
    FROM core.users u
    JOIN core.rol_permisos rp ON rp.rol_id = u.rol_id
    JOIN core.permisos p ON p.id = rp.permiso_id
    WHERE u.id = p_user_id AND u.deleted_at IS NULL AND u.estado = 'activo'
      AND p.codigo = p_codigo_permiso);
$$;


--
-- Name: usuario_objetivo(uuid, uuid, uuid, character varying); Type: FUNCTION; Schema: internal; Owner: -
--

CREATE FUNCTION internal.usuario_objetivo(p_actor uuid, p_target uuid, p_empresa uuid, p_permiso character varying DEFAULT 'rrhh:gestionar'::character varying) RETURNS uuid
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'core', 'internal', 'public'
    AS $$
DECLARE
  v_emp_target UUID;
BEGIN
  IF p_target IS NULL OR p_target = p_actor THEN RETURN p_actor; END IF;

  PERFORM internal.assert_permiso(p_actor, p_permiso);

  SELECT empresa_id INTO v_emp_target
  FROM core.users WHERE id = p_target AND deleted_at IS NULL;

  IF NOT FOUND
     OR (v_emp_target IS DISTINCT FROM p_empresa
         AND NOT internal.es_acceso_global(p_actor, false)) THEN
    RAISE EXCEPTION 'Sin acceso al legajo de ese usuario' USING ERRCODE = '42501';
  END IF;

  RETURN p_target;
END;
$$;


--
-- Name: validar_dni(character varying); Type: FUNCTION; Schema: internal; Owner: -
--

CREATE FUNCTION internal.validar_dni(p_dni character varying) RETURNS boolean
    LANGUAGE sql IMMUTABLE
    AS $_$
  SELECT p_dni IS NOT NULL AND length(p_dni) = 8 AND p_dni ~ '^[0-9]{8}$';
$_$;


--
-- Name: validar_payload(jsonb, text[]); Type: FUNCTION; Schema: internal; Owner: -
--

CREATE FUNCTION internal.validar_payload(p_payload jsonb, p_claves text[]) RETURNS void
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
  v_clave TEXT;
BEGIN
  IF p_payload IS NULL THEN
    RAISE EXCEPTION 'Payload requerido' USING ERRCODE = 'P0001';
  END IF;
  FOREACH v_clave IN ARRAY p_claves LOOP
    IF NOT (p_payload ? v_clave) OR (p_payload->>v_clave) IS NULL THEN
      RAISE EXCEPTION 'Campo obligatorio faltante: %', v_clave USING ERRCODE = 'P0001';
    END IF;
  END LOOP;
END;
$$;


--
-- Name: validar_ruc(character varying); Type: FUNCTION; Schema: internal; Owner: -
--

CREATE FUNCTION internal.validar_ruc(p_ruc character varying) RETURNS boolean
    LANGUAGE plpgsql IMMUTABLE
    AS $_$
DECLARE
  v_pesos INT[] := ARRAY[5,4,3,2,7,6,5,4,3,2];
  v_suma  INT := 0;
  v_dv    INT;
  v_calc  INT;
  i       INT;
BEGIN
  IF p_ruc IS NULL OR length(p_ruc) <> 11 OR p_ruc !~ '^[0-9]{11}$' THEN
    RETURN false;
  END IF;
  IF substring(p_ruc,1,2) NOT IN ('10','15','16','17','20') THEN RETURN false; END IF;

  FOR i IN 1..10 LOOP
    v_suma := v_suma + (substring(p_ruc, i, 1)::int * v_pesos[i]);
  END LOOP;

  v_calc := 11 - (v_suma % 11);
  v_calc := CASE v_calc WHEN 11 THEN 1 WHEN 10 THEN 0 ELSE v_calc END;
  v_dv   := substring(p_ruc, 11, 1)::int;

  RETURN v_calc = v_dv;
END;
$_$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: almacenes; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.almacenes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id uuid NOT NULL,
    codigo character varying(30) NOT NULL,
    nombre character varying(120) NOT NULL,
    ubicacion character varying(255),
    es_principal boolean DEFAULT false NOT NULL,
    estado core.estado_generico DEFAULT 'activo'::core.estado_generico NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: asistencia; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.asistencia (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id uuid NOT NULL,
    user_id uuid NOT NULL,
    fecha date NOT NULL,
    hora_entrada time without time zone,
    hora_salida time without time zone,
    horas_trabajadas numeric(5,2),
    estado core.estado_asistencia DEFAULT 'puntual'::core.estado_asistencia NOT NULL,
    observaciones text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: audit_log; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.audit_log (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    empresa_id uuid,
    accion character varying(60) NOT NULL,
    entidad character varying(80) NOT NULL,
    entidad_id uuid,
    datos_antes jsonb,
    datos_despues jsonb,
    diff jsonb,
    ip character varying(45),
    user_agent text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: cajas; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.cajas (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id uuid NOT NULL,
    numero character varying(30),
    user_apertura_id uuid NOT NULL,
    user_cierre_id uuid,
    fecha_apertura timestamp with time zone DEFAULT now() NOT NULL,
    fecha_cierre timestamp with time zone,
    monto_apertura numeric(14,2) DEFAULT 0 NOT NULL,
    total_ingresos numeric(14,2) DEFAULT 0 NOT NULL,
    total_egresos numeric(14,2) DEFAULT 0 NOT NULL,
    total_efectivo numeric(14,2) DEFAULT 0 NOT NULL,
    total_tarjeta numeric(14,2) DEFAULT 0 NOT NULL,
    total_digital numeric(14,2) DEFAULT 0 NOT NULL,
    monto_esperado numeric(14,2) DEFAULT 0 NOT NULL,
    monto_contado numeric(14,2),
    diferencia numeric(14,2),
    estado core.estado_caja DEFAULT 'abierta'::core.estado_caja NOT NULL,
    observaciones text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: categorias; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.categorias (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id uuid NOT NULL,
    ambito character varying(20) NOT NULL,
    codigo character varying(40) NOT NULL,
    nombre character varying(120) NOT NULL,
    descripcion text,
    padre_id uuid,
    orden integer DEFAULT 0 NOT NULL,
    estado core.estado_generico DEFAULT 'activo'::core.estado_generico NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT categorias_ambito_check CHECK (((ambito)::text = ANY ((ARRAY['servicio'::character varying, 'producto'::character varying, 'proveedor'::character varying])::text[])))
);


--
-- Name: cirugias; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.cirugias (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id uuid NOT NULL,
    codigo character varying(20),
    mascota_id uuid NOT NULL,
    cirujano_id uuid,
    anestesista_id uuid,
    consultorio_id uuid,
    servicio_id uuid,
    cita_id uuid,
    nombre character varying(200) NOT NULL,
    descripcion text,
    fecha_programada timestamp with time zone,
    fecha_inicio timestamp with time zone,
    fecha_fin timestamp with time zone,
    anestesia_tipo character varying(120),
    anestesia_dosis character varying(120),
    hallazgos text,
    complicaciones text,
    resultado text,
    cuidados_post text,
    consentimiento_firmado boolean DEFAULT false NOT NULL,
    estado core.estado_cirugia DEFAULT 'programada'::core.estado_cirugia NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    updated_by uuid
);


--
-- Name: citas; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.citas (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id uuid NOT NULL,
    codigo character varying(20),
    cliente_id uuid NOT NULL,
    mascota_id uuid NOT NULL,
    veterinario_id uuid,
    servicio_id uuid,
    consultorio_id uuid,
    fecha_hora timestamp with time zone NOT NULL,
    duracion_min integer DEFAULT 30 NOT NULL,
    motivo text,
    prioridad core.prioridad_cita DEFAULT 'normal'::core.prioridad_cita NOT NULL,
    origen core.origen_cita DEFAULT 'mostrador'::core.origen_cita NOT NULL,
    estado core.estado_cita DEFAULT 'programada'::core.estado_cita NOT NULL,
    hora_llegada timestamp with time zone,
    hora_atencion timestamp with time zone,
    hora_salida timestamp with time zone,
    recordatorio_enviado_at timestamp with time zone,
    motivo_cancelacion text,
    observaciones text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    created_by uuid,
    updated_by uuid
);


--
-- Name: citas_historial; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.citas_historial (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    cita_id uuid NOT NULL,
    accion core.accion_cita NOT NULL,
    fecha_hora_antes timestamp with time zone,
    fecha_hora_despues timestamp with time zone,
    motivo text,
    user_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: citas_lista_espera; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.citas_lista_espera (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id uuid NOT NULL,
    cliente_id uuid NOT NULL,
    mascota_id uuid NOT NULL,
    servicio_id uuid,
    veterinario_id uuid,
    desde date NOT NULL,
    hasta date,
    nota text,
    atendido boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: clausulas; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.clausulas (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id uuid NOT NULL,
    tipo character varying(40) DEFAULT 'consentimiento'::character varying NOT NULL,
    titulo character varying(255) NOT NULL,
    contenido text NOT NULL,
    orden integer DEFAULT 0 NOT NULL,
    estado core.estado_generico DEFAULT 'activo'::core.estado_generico NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: clientes; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.clientes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id uuid NOT NULL,
    codigo character varying(20),
    tipo_documento core.tipo_documento_identidad DEFAULT 'DNI'::core.tipo_documento_identidad NOT NULL,
    numero_documento character varying(20) NOT NULL,
    nombres character varying(150) NOT NULL,
    apellido_paterno character varying(100),
    apellido_materno character varying(100),
    razon_social character varying(255),
    telefono character varying(30),
    telefono_alterno character varying(30),
    correo character varying(150),
    direccion text,
    ubigeo character varying(6),
    fecha_nacimiento date,
    linea_credito numeric(14,2) DEFAULT 0 NOT NULL,
    dias_credito integer DEFAULT 0 NOT NULL,
    acepta_marketing boolean DEFAULT true NOT NULL,
    portal_acceso boolean DEFAULT false NOT NULL,
    portal_password_hash text,
    portal_ultimo_login_at timestamp with time zone,
    estado core.estado_cliente DEFAULT 'activo'::core.estado_cliente NOT NULL,
    observaciones text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    created_by uuid,
    updated_by uuid
);


--
-- Name: TABLE clientes; Type: COMMENT; Schema: core; Owner: -
--

COMMENT ON TABLE core.clientes IS 'Propietarios de mascotas. Cartera privada de cada empresa.';


--
-- Name: comprobante_items; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.comprobante_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    comprobante_id uuid NOT NULL,
    tipo_item core.tipo_item_comprobante DEFAULT 'servicio'::core.tipo_item_comprobante NOT NULL,
    servicio_id uuid,
    producto_id uuid,
    orden_servicio_id uuid,
    codigo character varying(40),
    descripcion character varying(500) NOT NULL,
    cantidad numeric(12,2) DEFAULT 1 NOT NULL,
    precio_unitario numeric(12,4) DEFAULT 0 NOT NULL,
    descuento numeric(12,2) DEFAULT 0 NOT NULL,
    afecto_igv boolean DEFAULT true NOT NULL,
    subtotal numeric(14,2) DEFAULT 0 NOT NULL,
    igv numeric(14,2) DEFAULT 0 NOT NULL,
    total numeric(14,2) DEFAULT 0 NOT NULL,
    orden integer DEFAULT 0 NOT NULL,
    insumo_id uuid,
    tipo_afectacion_igv character varying(4) DEFAULT '10'::character varying NOT NULL,
    unidad_medida character varying(10) DEFAULT 'NIU'::character varying NOT NULL,
    item_ref_id uuid
);


--
-- Name: comprobante_pse_log; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.comprobante_pse_log (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    comprobante_id uuid NOT NULL,
    intento integer DEFAULT 1 NOT NULL,
    operacion character varying(30) DEFAULT 'enviar'::character varying NOT NULL,
    request jsonb,
    response jsonb,
    exito boolean DEFAULT false NOT NULL,
    mensaje text,
    duracion_ms integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid
);


--
-- Name: comprobantes; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.comprobantes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id uuid NOT NULL,
    tipo core.tipo_comprobante DEFAULT 'boleta'::core.tipo_comprobante NOT NULL,
    serie character varying(10) NOT NULL,
    numero integer NOT NULL,
    numero_completo character varying(30) GENERATED ALWAYS AS ((((serie)::text || '-'::text) || lpad((numero)::text, 8, '0'::text))) STORED,
    cliente_id uuid NOT NULL,
    mascota_id uuid,
    cita_id uuid,
    consulta_id uuid,
    caja_id uuid,
    fecha_emision timestamp with time zone DEFAULT now() NOT NULL,
    fecha_vencimiento date,
    moneda core.moneda_codigo DEFAULT 'PEN'::core.moneda_codigo NOT NULL,
    tipo_cambio numeric(8,4),
    subtotal numeric(14,2) DEFAULT 0 NOT NULL,
    descuento_global numeric(14,2) DEFAULT 0 NOT NULL,
    igv numeric(14,2) DEFAULT 0 NOT NULL,
    total numeric(14,2) DEFAULT 0 NOT NULL,
    saldo_pendiente numeric(14,2) DEFAULT 0 NOT NULL,
    estado core.estado_comprobante DEFAULT 'borrador'::core.estado_comprobante NOT NULL,
    estado_pago core.estado_pago DEFAULT 'pendiente'::core.estado_pago NOT NULL,
    hash_cpe character varying(255),
    xml_url text,
    pdf_url text,
    cdr_url text,
    sunat_codigo character varying(20),
    sunat_mensaje text,
    documento_ref_id uuid,
    motivo_nota text,
    observaciones text,
    anulado_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    created_by uuid,
    updated_by uuid,
    pse_request_id character varying(100),
    pse_response jsonb,
    enviado_pse_at timestamp with time zone,
    aceptado_sunat_at timestamp with time zone,
    codigo_tipo_nota character varying(4)
);


--
-- Name: COLUMN comprobantes.pse_request_id; Type: COMMENT; Schema: core; Owner: -
--

COMMENT ON COLUMN core.comprobantes.pse_request_id IS 'Identificador del documento en el PSE: RUC-CodTipo-Serie-Correlativo.';


--
-- Name: comunicaciones; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.comunicaciones (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id uuid NOT NULL,
    cliente_id uuid NOT NULL,
    mascota_id uuid,
    user_id uuid,
    tipo core.tipo_comunicacion DEFAULT 'llamada'::core.tipo_comunicacion NOT NULL,
    asunto character varying(255),
    mensaje text NOT NULL,
    requiere_seguimiento boolean DEFAULT false NOT NULL,
    fecha_seguimiento date,
    fecha timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid
);


--
-- Name: consultas; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.consultas (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id uuid NOT NULL,
    codigo character varying(20),
    mascota_id uuid NOT NULL,
    cliente_id uuid NOT NULL,
    veterinario_id uuid NOT NULL,
    cita_id uuid,
    fecha timestamp with time zone DEFAULT now() NOT NULL,
    motivo text NOT NULL,
    anamnesis text,
    peso_kg numeric(6,2),
    temperatura_c numeric(4,1),
    frecuencia_cardiaca integer,
    frecuencia_respiratoria integer,
    mucosas character varying(60),
    tllc_seg numeric(3,1),
    condicion_corporal integer,
    examen_fisico text,
    diagnostico text,
    diagnostico_diferencial text,
    pronostico character varying(60),
    plan_terapeutico text,
    prescripcion text,
    indicaciones_casa text,
    proxima_visita date,
    estado core.estado_consulta DEFAULT 'borrador'::core.estado_consulta NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    created_by uuid,
    updated_by uuid,
    CONSTRAINT consultas_condicion_corporal_check CHECK (((condicion_corporal >= 1) AND (condicion_corporal <= 9)))
);


--
-- Name: consultorios; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.consultorios (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id uuid NOT NULL,
    nombre character varying(80) NOT NULL,
    tipo character varying(40) DEFAULT 'consulta'::character varying NOT NULL,
    capacidad integer DEFAULT 1 NOT NULL,
    estado core.estado_generico DEFAULT 'activo'::core.estado_generico NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: contratos_personal; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.contratos_personal (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id uuid NOT NULL,
    user_id uuid NOT NULL,
    tipo core.tipo_contrato_empleado DEFAULT 'plazo_fijo'::core.tipo_contrato_empleado NOT NULL,
    cargo character varying(120),
    fecha_inicio date NOT NULL,
    fecha_fin date,
    salario numeric(12,2),
    moneda core.moneda_codigo DEFAULT 'PEN'::core.moneda_codigo NOT NULL,
    documento_url text,
    vigente boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: correlativos; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.correlativos (
    empresa_id uuid NOT NULL,
    tipo_documento character varying(40) NOT NULL,
    serie character varying(10) NOT NULL,
    ultimo_numero integer DEFAULT 0 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: desparasitaciones; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.desparasitaciones (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id uuid NOT NULL,
    mascota_id uuid NOT NULL,
    veterinario_id uuid,
    consulta_id uuid,
    producto_id uuid,
    producto_nombre character varying(150) NOT NULL,
    tipo character varying(20) DEFAULT 'interna'::character varying NOT NULL,
    dosis character varying(80),
    fecha_aplicacion date NOT NULL,
    proxima_dosis date,
    observaciones text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid
);


--
-- Name: disponibilidad; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.disponibilidad (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id uuid NOT NULL,
    user_id uuid NOT NULL,
    fecha date NOT NULL,
    hora_inicio time without time zone NOT NULL,
    hora_fin time without time zone NOT NULL,
    tipo core.tipo_disponibilidad DEFAULT 'laboral'::core.tipo_disponibilidad NOT NULL,
    consultorio_id uuid,
    nota text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    permiso_id uuid,
    CONSTRAINT ck_disponibilidad_rango CHECK ((hora_fin > hora_inicio))
);


--
-- Name: documentos_medicos; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.documentos_medicos (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id uuid NOT NULL,
    mascota_id uuid NOT NULL,
    consulta_id uuid,
    tipo character varying(60) DEFAULT 'otro'::character varying NOT NULL,
    titulo character varying(255) NOT NULL,
    descripcion text,
    storage_key text NOT NULL,
    mime_type character varying(120),
    tamanio_bytes bigint,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid
);


--
-- Name: empresas; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.empresas (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    ruc character varying(11) NOT NULL,
    razon_social character varying(255) NOT NULL,
    nombre_comercial character varying(255),
    direccion_fiscal text,
    ubigeo character varying(6),
    telefono character varying(30),
    correo character varying(150),
    logo_url text,
    pse_endpoint text,
    pse_usuario character varying(150),
    pse_password_enc text,
    serie_factura_default character varying(10),
    serie_boleta_default character varying(10),
    serie_nota_venta_default character varying(10),
    igv_tasa numeric(5,4) DEFAULT 0.1800 NOT NULL,
    moneda_default core.moneda_codigo DEFAULT 'PEN'::core.moneda_codigo NOT NULL,
    aforo_consultorios integer DEFAULT 1 NOT NULL,
    duracion_cita_min integer DEFAULT 30 NOT NULL,
    estado core.estado_empresa DEFAULT 'activa'::core.estado_empresa NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    created_by uuid,
    updated_by uuid,
    emite_electronico boolean DEFAULT false NOT NULL,
    pse_proveedor character varying(40) DEFAULT 'the_factory_hka'::character varying NOT NULL,
    pse_ruc character varying(11),
    urbanizacion character varying(120),
    distrito character varying(60),
    provincia character varying(60),
    departamento character varying(60),
    serie_nota_credito_default character varying(10)
);


--
-- Name: TABLE empresas; Type: COMMENT; Schema: core; Owner: -
--

COMMENT ON TABLE core.empresas IS 'Empresas del ERP. Cada una es un negocio independiente; el multi-tenancy se resuelve por empresa_id.';


--
-- Name: COLUMN empresas.emite_electronico; Type: COMMENT; Schema: core; Owner: -
--

COMMENT ON COLUMN core.empresas.emite_electronico IS 'false = la empresa registra sus comprobantes en el ERP pero los emite fuera. No se envían al PSE.';


--
-- Name: COLUMN empresas.pse_ruc; Type: COMMENT; Schema: core; Owner: -
--

COMMENT ON COLUMN core.empresas.pse_ruc IS 'RUC con el que se emite electrónicamente. Puede diferir del operativo en homologación.';


--
-- Name: especializaciones; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.especializaciones (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    codigo character varying(50) NOT NULL,
    nombre character varying(150) NOT NULL,
    descripcion text,
    estado core.estado_generico DEFAULT 'activo'::core.estado_generico NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: especies; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.especies (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    codigo character varying(30) NOT NULL,
    nombre character varying(80) NOT NULL,
    nombre_cria character varying(80),
    icono character varying(40),
    estado core.estado_generico DEFAULT 'activo'::core.estado_generico NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: esquemas_vacunacion; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.esquemas_vacunacion (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id uuid NOT NULL,
    especie_id uuid NOT NULL,
    nombre character varying(150) NOT NULL,
    descripcion text,
    obligatoria boolean DEFAULT false NOT NULL,
    edad_inicio_semanas integer,
    intervalo_dias integer,
    dosis_totales integer DEFAULT 1 NOT NULL,
    revacunacion_meses integer,
    estado core.estado_generico DEFAULT 'activo'::core.estado_generico NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: evaluaciones_personal; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.evaluaciones_personal (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id uuid NOT NULL,
    user_id uuid NOT NULL,
    evaluador_id uuid,
    periodo character varying(20) NOT NULL,
    fecha date DEFAULT CURRENT_DATE NOT NULL,
    puntualidad integer,
    eficiencia integer,
    calidad_atencion integer,
    trabajo_equipo integer,
    promedio numeric(3,2),
    observaciones text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT evaluaciones_personal_calidad_atencion_check CHECK (((calidad_atencion >= 1) AND (calidad_atencion <= 5))),
    CONSTRAINT evaluaciones_personal_eficiencia_check CHECK (((eficiencia >= 1) AND (eficiencia <= 5))),
    CONSTRAINT evaluaciones_personal_puntualidad_check CHECK (((puntualidad >= 1) AND (puntualidad <= 5))),
    CONSTRAINT evaluaciones_personal_trabajo_equipo_check CHECK (((trabajo_equipo >= 1) AND (trabajo_equipo <= 5)))
);


--
-- Name: examenes; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.examenes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id uuid NOT NULL,
    mascota_id uuid NOT NULL,
    consulta_id uuid,
    servicio_id uuid,
    veterinario_id uuid,
    tipo character varying(60) NOT NULL,
    nombre character varying(200) NOT NULL,
    fecha_solicitud timestamp with time zone DEFAULT now() NOT NULL,
    fecha_resultado timestamp with time zone,
    resultado text,
    valores jsonb,
    interpretacion text,
    archivo_url text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid
);


--
-- Name: historia_clinica; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.historia_clinica (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id uuid NOT NULL,
    mascota_id uuid NOT NULL,
    cliente_id uuid NOT NULL,
    veterinario_id uuid,
    cita_id uuid,
    tipo_evento core.tipo_evento_clinico NOT NULL,
    fecha timestamp with time zone DEFAULT now() NOT NULL,
    titulo character varying(255) NOT NULL,
    resumen text,
    entidad_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid
);


--
-- Name: TABLE historia_clinica; Type: COMMENT; Schema: core; Owner: -
--

COMMENT ON TABLE core.historia_clinica IS 'Línea de tiempo unificada del paciente. Cada tabla clínica registra aquí su evento.';


--
-- Name: horarios_atencion; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.horarios_atencion (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id uuid NOT NULL,
    dia_semana integer NOT NULL,
    hora_inicio time without time zone NOT NULL,
    hora_fin time without time zone NOT NULL,
    activo boolean DEFAULT true NOT NULL,
    es_guardia boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_horarios_rango CHECK ((hora_fin > hora_inicio)),
    CONSTRAINT horarios_atencion_dia_semana_check CHECK (((dia_semana >= 0) AND (dia_semana <= 6)))
);


--
-- Name: hospitalizacion_evoluciones; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.hospitalizacion_evoluciones (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    hospitalizacion_id uuid NOT NULL,
    user_id uuid,
    fecha_hora timestamp with time zone DEFAULT now() NOT NULL,
    temperatura_c numeric(4,1),
    frecuencia_cardiaca integer,
    frecuencia_respiratoria integer,
    come boolean,
    orina boolean,
    defeca boolean,
    nota text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: hospitalizaciones; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.hospitalizaciones (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id uuid NOT NULL,
    codigo character varying(20),
    mascota_id uuid NOT NULL,
    veterinario_id uuid,
    consultorio_id uuid,
    jaula character varying(40),
    motivo text NOT NULL,
    diagnostico text,
    fecha_ingreso timestamp with time zone DEFAULT now() NOT NULL,
    fecha_alta timestamp with time zone,
    indicaciones_alta text,
    estado core.estado_hospitalizacion DEFAULT 'ingresado'::core.estado_hospitalizacion NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid
);


--
-- Name: insumos_utilizados; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.insumos_utilizados (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id uuid NOT NULL,
    producto_id uuid NOT NULL,
    mascota_id uuid,
    consulta_id uuid,
    cirugia_id uuid,
    hospitalizacion_id uuid,
    orden_servicio_id uuid,
    cantidad numeric(12,2) NOT NULL,
    precio_unitario numeric(12,2) DEFAULT 0 NOT NULL,
    facturado boolean DEFAULT false NOT NULL,
    fecha timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid
);


--
-- Name: lotes; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.lotes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id uuid NOT NULL,
    producto_id uuid NOT NULL,
    numero_lote character varying(60) NOT NULL,
    fecha_vencimiento date,
    cantidad numeric(12,2) DEFAULT 0 NOT NULL,
    costo_unitario numeric(12,2) DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: mascotas; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.mascotas (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id uuid NOT NULL,
    codigo character varying(20),
    cliente_id uuid NOT NULL,
    nombre character varying(100) NOT NULL,
    especie_id uuid NOT NULL,
    raza_id uuid,
    sexo core.sexo_mascota DEFAULT 'desconocido'::core.sexo_mascota NOT NULL,
    color character varying(80),
    senias_particulares text,
    fecha_nacimiento date,
    edad_aproximada_meses integer,
    peso_kg numeric(6,2),
    tamanio core.tamanio_mascota,
    esterilizado boolean DEFAULT false NOT NULL,
    fecha_esterilizacion date,
    microchip character varying(40),
    num_placa character varying(40),
    foto_url text,
    alergias text,
    condiciones_cronicas text,
    observaciones text,
    estado core.estado_mascota DEFAULT 'activo'::core.estado_mascota NOT NULL,
    fecha_fallecimiento date,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    created_by uuid,
    updated_by uuid,
    CONSTRAINT ck_mascotas_microchip_unico CHECK (((microchip IS NULL) OR (length((microchip)::text) >= 8)))
);


--
-- Name: TABLE mascotas; Type: COMMENT; Schema: core; Owner: -
--

COMMENT ON TABLE core.mascotas IS 'Pacientes. Pertenecen a una empresa a través de su propietario.';


--
-- Name: mascotas_extraviadas; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.mascotas_extraviadas (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id uuid NOT NULL,
    mascota_id uuid NOT NULL,
    fecha_extravio date NOT NULL,
    zona character varying(255),
    descripcion text,
    contacto character varying(150),
    recompensa numeric(12,2),
    encontrado boolean DEFAULT false NOT NULL,
    fecha_hallazgo date,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid
);


--
-- Name: movimientos_caja; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.movimientos_caja (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id uuid NOT NULL,
    caja_id uuid NOT NULL,
    tipo core.tipo_movimiento_caja NOT NULL,
    metodo core.metodo_pago DEFAULT 'efectivo'::core.metodo_pago NOT NULL,
    concepto character varying(255) NOT NULL,
    monto numeric(14,2) NOT NULL,
    pago_id uuid,
    comprobante_id uuid,
    fecha timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    CONSTRAINT ck_mov_caja_monto CHECK ((monto > (0)::numeric))
);


--
-- Name: movimientos_inventario; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.movimientos_inventario (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id uuid NOT NULL,
    producto_id uuid NOT NULL,
    almacen_id uuid,
    almacen_destino_id uuid,
    lote_id uuid,
    tipo core.tipo_movimiento_inventario NOT NULL,
    motivo core.motivo_movimiento NOT NULL,
    cantidad numeric(12,2) NOT NULL,
    costo_unitario numeric(12,2) DEFAULT 0 NOT NULL,
    saldo_despues numeric(12,2),
    cliente_id uuid,
    proveedor_id uuid,
    mascota_id uuid,
    consulta_id uuid,
    comprobante_id uuid,
    orden_compra_id uuid,
    observaciones text,
    fecha timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    CONSTRAINT ck_movimientos_cantidad CHECK ((cantidad > (0)::numeric))
);


--
-- Name: notas_medicas; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.notas_medicas (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id uuid NOT NULL,
    mascota_id uuid NOT NULL,
    user_id uuid,
    nota text NOT NULL,
    destacada boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: notificaciones; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.notificaciones (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    empresa_id uuid,
    canal core.canal_notificacion DEFAULT 'sistema'::core.canal_notificacion NOT NULL,
    titulo character varying(200) NOT NULL,
    cuerpo text,
    url text,
    entidad character varying(80),
    entidad_id uuid,
    leida_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: orden_compra_items; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.orden_compra_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    orden_compra_id uuid NOT NULL,
    producto_id uuid NOT NULL,
    descripcion character varying(255),
    cantidad numeric(12,2) NOT NULL,
    cantidad_recibida numeric(12,2) DEFAULT 0 NOT NULL,
    precio_unitario numeric(12,2) NOT NULL,
    descuento numeric(12,2) DEFAULT 0 NOT NULL,
    subtotal numeric(14,2) DEFAULT 0 NOT NULL,
    numero_lote character varying(60),
    fecha_vencimiento date,
    orden integer DEFAULT 0 NOT NULL
);


--
-- Name: ordenes_compra; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.ordenes_compra (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id uuid NOT NULL,
    numero character varying(30) NOT NULL,
    proveedor_id uuid NOT NULL,
    almacen_id uuid,
    fecha_emision date DEFAULT CURRENT_DATE NOT NULL,
    fecha_estimada date,
    fecha_recepcion date,
    moneda core.moneda_codigo DEFAULT 'PEN'::core.moneda_codigo NOT NULL,
    subtotal numeric(14,2) DEFAULT 0 NOT NULL,
    igv numeric(14,2) DEFAULT 0 NOT NULL,
    total numeric(14,2) DEFAULT 0 NOT NULL,
    saldo_pendiente numeric(14,2) DEFAULT 0 NOT NULL,
    estado core.estado_orden_compra DEFAULT 'borrador'::core.estado_orden_compra NOT NULL,
    estado_pago core.estado_pago DEFAULT 'pendiente'::core.estado_pago NOT NULL,
    observaciones text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    created_by uuid,
    updated_by uuid
);


--
-- Name: ordenes_servicio; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.ordenes_servicio (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id uuid NOT NULL,
    codigo character varying(20),
    mascota_id uuid NOT NULL,
    cliente_id uuid NOT NULL,
    servicio_id uuid NOT NULL,
    veterinario_id uuid,
    cita_id uuid,
    consulta_id uuid,
    cantidad numeric(10,2) DEFAULT 1 NOT NULL,
    precio_unitario numeric(12,2) DEFAULT 0 NOT NULL,
    descuento numeric(12,2) DEFAULT 0 NOT NULL,
    total numeric(12,2) DEFAULT 0 NOT NULL,
    descripcion text,
    estado core.estado_orden_servicio DEFAULT 'pendiente'::core.estado_orden_servicio NOT NULL,
    facturado boolean DEFAULT false NOT NULL,
    comprobante_id uuid,
    fecha timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    origen_tabla character varying(40),
    origen_id uuid
);


--
-- Name: pago_aplicaciones; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.pago_aplicaciones (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    pago_id uuid NOT NULL,
    comprobante_id uuid NOT NULL,
    monto_aplicado numeric(14,2) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_aplicacion_monto CHECK ((monto_aplicado > (0)::numeric))
);


--
-- Name: pagos; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.pagos (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id uuid NOT NULL,
    cliente_id uuid NOT NULL,
    caja_id uuid,
    numero character varying(30),
    metodo core.metodo_pago DEFAULT 'efectivo'::core.metodo_pago NOT NULL,
    monto numeric(14,2) NOT NULL,
    moneda core.moneda_codigo DEFAULT 'PEN'::core.moneda_codigo NOT NULL,
    referencia character varying(120),
    fecha_pago timestamp with time zone DEFAULT now() NOT NULL,
    anulado_at timestamp with time zone,
    observaciones text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    CONSTRAINT ck_pagos_monto CHECK ((monto > (0)::numeric))
);


--
-- Name: pagos_proveedor; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.pagos_proveedor (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id uuid NOT NULL,
    proveedor_id uuid NOT NULL,
    orden_compra_id uuid,
    numero character varying(30),
    metodo core.metodo_pago DEFAULT 'transferencia'::core.metodo_pago NOT NULL,
    monto numeric(14,2) NOT NULL,
    moneda core.moneda_codigo DEFAULT 'PEN'::core.moneda_codigo NOT NULL,
    referencia character varying(120),
    comprobante_url text,
    fecha_pago timestamp with time zone DEFAULT now() NOT NULL,
    anulado_at timestamp with time zone,
    observaciones text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid
);


--
-- Name: permisos; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.permisos (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    codigo character varying(100) NOT NULL,
    modulo character varying(50) NOT NULL,
    accion character varying(50) NOT NULL,
    descripcion text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: permisos_laborales; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.permisos_laborales (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id uuid NOT NULL,
    user_id uuid NOT NULL,
    tipo core.tipo_permiso_laboral DEFAULT 'personal'::core.tipo_permiso_laboral NOT NULL,
    fecha_inicio date NOT NULL,
    fecha_fin date NOT NULL,
    hora_inicio time without time zone,
    hora_fin time without time zone,
    motivo text,
    estado core.estado_solicitud DEFAULT 'pendiente'::core.estado_solicitud NOT NULL,
    aprobado_por uuid,
    aprobado_at timestamp with time zone,
    comentario_aprobacion text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_permisos_rango CHECK ((fecha_fin >= fecha_inicio))
);


--
-- Name: plantillas_mensaje; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.plantillas_mensaje (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id uuid NOT NULL,
    tipo character varying(40) NOT NULL,
    canal core.canal_notificacion DEFAULT 'whatsapp'::core.canal_notificacion NOT NULL,
    nombre character varying(120) NOT NULL,
    texto text NOT NULL,
    estado core.estado_generico DEFAULT 'activo'::core.estado_generico NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE plantillas_mensaje; Type: COMMENT; Schema: core; Owner: -
--

COMMENT ON TABLE core.plantillas_mensaje IS 'Texto con el que cada clínica contacta a sus propietarios. Variables: {{propietario}}, {{paciente}}, {{clinica}}, {{fecha}}, {{titulo}}, {{telefono_clinica}}.';


--
-- Name: productos; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.productos (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id uuid NOT NULL,
    codigo character varying(40) NOT NULL,
    codigo_barras character varying(60),
    nombre character varying(200) NOT NULL,
    descripcion text,
    tipo core.tipo_producto DEFAULT 'insumo'::core.tipo_producto NOT NULL,
    categoria_id uuid,
    principio_activo character varying(200),
    laboratorio character varying(120),
    presentacion character varying(120),
    unidad_medida character varying(20) DEFAULT 'UND'::character varying NOT NULL,
    requiere_receta boolean DEFAULT false NOT NULL,
    controlado boolean DEFAULT false NOT NULL,
    refrigerado boolean DEFAULT false NOT NULL,
    precio_compra numeric(12,2) DEFAULT 0 NOT NULL,
    precio_venta numeric(12,2) DEFAULT 0 NOT NULL,
    margen_pct numeric(6,2),
    afecto_igv boolean DEFAULT true NOT NULL,
    stock_actual numeric(12,2) DEFAULT 0 NOT NULL,
    stock_minimo numeric(12,2) DEFAULT 0 NOT NULL,
    stock_maximo numeric(12,2),
    maneja_lotes boolean DEFAULT false NOT NULL,
    estado core.estado_generico DEFAULT 'activo'::core.estado_generico NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    created_by uuid,
    updated_by uuid
);


--
-- Name: proveedor_contactos; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.proveedor_contactos (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    proveedor_id uuid NOT NULL,
    nombres character varying(150) NOT NULL,
    cargo character varying(100),
    telefono character varying(30),
    correo character varying(150),
    es_principal boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: proveedores; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.proveedores (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id uuid NOT NULL,
    codigo character varying(30),
    tipo_documento core.tipo_documento_identidad DEFAULT 'RUC'::core.tipo_documento_identidad NOT NULL,
    numero_documento character varying(20) NOT NULL,
    razon_social character varying(255) NOT NULL,
    nombre_comercial character varying(255),
    categoria_id uuid,
    direccion text,
    telefono character varying(30),
    correo character varying(150),
    web character varying(200),
    dias_credito integer DEFAULT 0 NOT NULL,
    cuenta_bancaria character varying(60),
    banco character varying(80),
    estado core.estado_proveedor DEFAULT 'activo'::core.estado_proveedor NOT NULL,
    observaciones text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    created_by uuid,
    updated_by uuid
);


--
-- Name: razas; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.razas (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    especie_id uuid NOT NULL,
    empresa_id uuid,
    nombre character varying(120) NOT NULL,
    tamanio_referencia core.tamanio_mascota,
    peso_min_kg numeric(6,2),
    peso_max_kg numeric(6,2),
    esperanza_vida integer,
    estado core.estado_generico DEFAULT 'activo'::core.estado_generico NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: recordatorios; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.recordatorios (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id uuid NOT NULL,
    cliente_id uuid NOT NULL,
    mascota_id uuid,
    tipo character varying(40) NOT NULL,
    titulo character varying(200) NOT NULL,
    mensaje text,
    fecha_objetivo date NOT NULL,
    canal core.canal_notificacion DEFAULT 'whatsapp'::core.canal_notificacion NOT NULL,
    enviado_at timestamp with time zone,
    completado boolean DEFAULT false NOT NULL,
    entidad_ref character varying(60),
    entidad_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: rol_permisos; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.rol_permisos (
    rol_id uuid NOT NULL,
    permiso_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: roles; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.roles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    codigo character varying(50) NOT NULL,
    nombre character varying(100) NOT NULL,
    descripcion text,
    scope core.scope_rol DEFAULT 'empresa'::core.scope_rol NOT NULL,
    is_sistema boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: servicios; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.servicios (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id uuid NOT NULL,
    codigo character varying(40) NOT NULL,
    nombre character varying(180) NOT NULL,
    descripcion text,
    tipo core.tipo_servicio DEFAULT 'consulta'::core.tipo_servicio NOT NULL,
    categoria_id uuid,
    precio numeric(12,2) DEFAULT 0 NOT NULL,
    costo_estimado numeric(12,2) DEFAULT 0 NOT NULL,
    duracion_min integer DEFAULT 30 NOT NULL,
    requiere_ayuno boolean DEFAULT false NOT NULL,
    requiere_cita boolean DEFAULT true NOT NULL,
    afecto_igv boolean DEFAULT true NOT NULL,
    producto_id uuid,
    estado core.estado_generico DEFAULT 'activo'::core.estado_generico NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    created_by uuid,
    updated_by uuid
);


--
-- Name: sesiones; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.sesiones (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    jti character varying(64) NOT NULL,
    ip character varying(45),
    user_agent text,
    expira_at timestamp with time zone NOT NULL,
    revocado_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: stock; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.stock (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id uuid NOT NULL,
    producto_id uuid NOT NULL,
    almacen_id uuid NOT NULL,
    cantidad numeric(12,2) DEFAULT 0 NOT NULL,
    reservado numeric(12,2) DEFAULT 0 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: tratamientos; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.tratamientos (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id uuid NOT NULL,
    mascota_id uuid NOT NULL,
    consulta_id uuid,
    veterinario_id uuid,
    producto_id uuid,
    medicamento character varying(200) NOT NULL,
    principio_activo character varying(200),
    dosis character varying(120) NOT NULL,
    via core.via_administracion DEFAULT 'oral'::core.via_administracion NOT NULL,
    frecuencia_horas integer,
    duracion_dias integer,
    fecha_inicio date NOT NULL,
    fecha_fin date,
    indicaciones text,
    estado core.estado_tratamiento DEFAULT 'activo'::core.estado_tratamiento NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid
);


--
-- Name: users; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    codigo character varying(20),
    email character varying(150) NOT NULL,
    password_hash text NOT NULL,
    nombres character varying(150) NOT NULL,
    apellido_paterno character varying(100) NOT NULL,
    apellido_materno character varying(100),
    tipo_documento core.tipo_documento_identidad DEFAULT 'DNI'::core.tipo_documento_identidad NOT NULL,
    numero_documento character varying(20) NOT NULL,
    telefono character varying(30),
    foto_url text,
    empresa_id uuid,
    is_super_admin boolean DEFAULT false NOT NULL,
    rol_id uuid,
    es_veterinario boolean DEFAULT false NOT NULL,
    colegiatura character varying(30),
    especializacion_id uuid,
    color_agenda character varying(7),
    estado core.estado_user DEFAULT 'activo'::core.estado_user NOT NULL,
    ultimo_login_at timestamp with time zone,
    intentos_fallidos integer DEFAULT 0 NOT NULL,
    bloqueado_hasta timestamp with time zone,
    password_reset_token character varying(255),
    password_reset_expires timestamp with time zone,
    must_change_password boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    created_by uuid,
    updated_by uuid,
    CONSTRAINT ck_users_super_admin_empresa CHECK ((NOT ((is_super_admin = true) AND (empresa_id IS NOT NULL)))),
    CONSTRAINT ck_users_veterinario_colegiatura CHECK (((es_veterinario = false) OR (colegiatura IS NOT NULL)))
);


--
-- Name: vacunas; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.vacunas (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id uuid NOT NULL,
    mascota_id uuid NOT NULL,
    veterinario_id uuid,
    consulta_id uuid,
    esquema_id uuid,
    producto_id uuid,
    nombre_vacuna character varying(150) NOT NULL,
    laboratorio character varying(120),
    lote character varying(60),
    fecha_aplicacion date NOT NULL,
    dosis_numero integer DEFAULT 1 NOT NULL,
    proximo_refuerzo date,
    via core.via_administracion DEFAULT 'subcutanea'::core.via_administracion NOT NULL,
    reaccion_adversa text,
    observaciones text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid
);


--
-- Data for Name: almacenes; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.almacenes (id, empresa_id, codigo, nombre, ubicacion, es_principal, estado, created_at, updated_at) FROM stdin;
1c132cba-0595-4444-9f61-b6ef4278cac0	1ba3bd1a-4075-4009-b992-7057472e1e56	ALM-01	Almacén principal	Trastienda	t	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05
dae49bdd-3c18-41c9-b84d-af6ddefe1e3d	1ba3bd1a-4075-4009-b992-7057472e1e56	ALM-02	Botiquín de quirófano	Quirófano	f	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05
720ad333-4de0-447f-84bb-dc46e664dd76	a64719a9-57fc-4ac0-b104-b9d861370dc7	ALM-01	Almacén principal	\N	t	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05
\.


--
-- Data for Name: asistencia; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.asistencia (id, empresa_id, user_id, fecha, hora_entrada, hora_salida, horas_trabajadas, estado, observaciones, created_at, updated_at) FROM stdin;
af8533af-94d5-43e5-87e7-4bbce5974935	1ba3bd1a-4075-4009-b992-7057472e1e56	12ed7993-4f79-41ee-827e-731ead5aad4b	2026-09-10	08:50:00	18:06:00	9.27	puntual	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05
33a80e39-ed26-4ef6-9621-eb0f2736978e	1ba3bd1a-4075-4009-b992-7057472e1e56	12ed7993-4f79-41ee-827e-731ead5aad4b	2026-09-11	08:50:00	18:05:00	9.25	puntual	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05
79932dda-38f0-481a-8af3-009cc89f1a1c	1ba3bd1a-4075-4009-b992-7057472e1e56	12ed7993-4f79-41ee-827e-731ead5aad4b	2026-09-12	08:52:00	18:05:00	9.22	puntual	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05
6a745b2e-6a6c-4ee1-8140-daf4469c8293	1ba3bd1a-4075-4009-b992-7057472e1e56	12ed7993-4f79-41ee-827e-731ead5aad4b	2026-09-14	08:55:00	18:06:00	9.18	puntual	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05
7e1f3a09-dc1c-4e97-ae0a-830f89b82aff	1ba3bd1a-4075-4009-b992-7057472e1e56	12ed7993-4f79-41ee-827e-731ead5aad4b	2026-09-15	08:55:00	18:01:00	9.10	tardanza	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05
497f1d8a-8bb6-4ad5-be95-91a64640fffb	1ba3bd1a-4075-4009-b992-7057472e1e56	12ed7993-4f79-41ee-827e-731ead5aad4b	2026-09-16	08:56:00	18:03:00	9.12	puntual	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05
8ccda3d5-e6fd-42aa-94c1-959670bfbaa8	1ba3bd1a-4075-4009-b992-7057472e1e56	12ed7993-4f79-41ee-827e-731ead5aad4b	2026-09-17	08:50:00	18:03:00	9.22	puntual	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05
48a6fea1-5a8e-4d7b-812f-c16052e0599e	1ba3bd1a-4075-4009-b992-7057472e1e56	12ed7993-4f79-41ee-827e-731ead5aad4b	2026-09-18	08:50:00	18:00:00	9.17	puntual	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05
5c3a3d22-8e67-46d7-9f71-349499f0a0cd	1ba3bd1a-4075-4009-b992-7057472e1e56	12ed7993-4f79-41ee-827e-731ead5aad4b	2026-09-19	08:57:00	18:05:00	9.13	puntual	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05
400b852d-5008-4cdd-a8f2-5e738c103a3f	1ba3bd1a-4075-4009-b992-7057472e1e56	5dc67c3d-1666-4a68-8cb5-489997a6bf08	2026-09-10	08:55:00	18:03:00	9.13	puntual	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05
bc6c5864-c2b8-4841-838c-1b76032fcfb0	1ba3bd1a-4075-4009-b992-7057472e1e56	5dc67c3d-1666-4a68-8cb5-489997a6bf08	2026-09-11	08:53:00	18:08:00	9.25	puntual	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05
ba297f22-6a03-42fd-9aa3-bcb41532fd9d	1ba3bd1a-4075-4009-b992-7057472e1e56	5dc67c3d-1666-4a68-8cb5-489997a6bf08	2026-09-12	08:52:00	18:00:00	9.13	puntual	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05
dfc98805-4bd2-42b4-bd4a-12865118bf2e	1ba3bd1a-4075-4009-b992-7057472e1e56	5dc67c3d-1666-4a68-8cb5-489997a6bf08	2026-09-14	08:56:00	18:04:00	9.13	puntual	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05
94af4159-dafb-4cd8-9928-1c3e77c00192	1ba3bd1a-4075-4009-b992-7057472e1e56	5dc67c3d-1666-4a68-8cb5-489997a6bf08	2026-09-15	08:50:00	18:03:00	9.22	puntual	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05
c1899fce-47ba-4c67-8449-93111f62eafb	1ba3bd1a-4075-4009-b992-7057472e1e56	5dc67c3d-1666-4a68-8cb5-489997a6bf08	2026-09-16	08:53:00	18:07:00	9.23	puntual	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05
7ec5b6bc-bf9e-4ac1-a072-64a7bf53e0da	1ba3bd1a-4075-4009-b992-7057472e1e56	5dc67c3d-1666-4a68-8cb5-489997a6bf08	2026-09-17	08:55:00	18:01:00	9.10	puntual	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05
0b3e04d8-8d20-4636-b271-ffcdcab52ea9	1ba3bd1a-4075-4009-b992-7057472e1e56	5dc67c3d-1666-4a68-8cb5-489997a6bf08	2026-09-18	08:52:00	18:03:00	9.18	puntual	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05
624215f0-1559-4d57-aeeb-d3a2fee340d7	1ba3bd1a-4075-4009-b992-7057472e1e56	5dc67c3d-1666-4a68-8cb5-489997a6bf08	2026-09-19	08:50:00	18:00:00	9.17	puntual	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05
64c3fb85-7e09-4550-8937-5b80a89dab38	1ba3bd1a-4075-4009-b992-7057472e1e56	419047f7-804f-4e15-90ca-276e3a463644	2026-09-10	08:50:00	18:05:00	9.25	puntual	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05
70bbb342-b189-442d-9d24-7dac8f218cd1	1ba3bd1a-4075-4009-b992-7057472e1e56	419047f7-804f-4e15-90ca-276e3a463644	2026-09-11	08:56:00	18:07:00	9.18	puntual	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05
1cf835b8-3c49-4396-a388-1e4c36ebb6c0	1ba3bd1a-4075-4009-b992-7057472e1e56	419047f7-804f-4e15-90ca-276e3a463644	2026-09-12	08:53:00	18:08:00	9.25	tardanza	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05
3cd3124d-38a3-422f-936b-912989a781d3	1ba3bd1a-4075-4009-b992-7057472e1e56	419047f7-804f-4e15-90ca-276e3a463644	2026-09-14	08:50:00	18:03:00	9.22	puntual	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05
e2811554-ae40-47e6-88dc-93471378ad12	1ba3bd1a-4075-4009-b992-7057472e1e56	419047f7-804f-4e15-90ca-276e3a463644	2026-09-15	08:56:00	18:08:00	9.20	puntual	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05
23c25054-193b-4006-b396-5b9d68561784	1ba3bd1a-4075-4009-b992-7057472e1e56	419047f7-804f-4e15-90ca-276e3a463644	2026-09-16	08:56:00	18:01:00	9.08	puntual	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05
55c120bd-c9b9-4666-b680-87fc772036ad	1ba3bd1a-4075-4009-b992-7057472e1e56	419047f7-804f-4e15-90ca-276e3a463644	2026-09-17	08:50:00	18:06:00	9.27	tardanza	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05
6f9b6b74-3a91-413c-b166-dc214d2e662e	1ba3bd1a-4075-4009-b992-7057472e1e56	419047f7-804f-4e15-90ca-276e3a463644	2026-09-18	08:50:00	18:03:00	9.22	tardanza	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05
ed66abe9-2ebf-459e-a3fb-b0ca5526d743	1ba3bd1a-4075-4009-b992-7057472e1e56	419047f7-804f-4e15-90ca-276e3a463644	2026-09-19	08:58:00	18:07:00	9.15	puntual	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05
2251ec48-b9b2-44c8-bc06-6ff4c481cda1	1ba3bd1a-4075-4009-b992-7057472e1e56	9faa05e4-2294-45f4-b7dd-4cadbb84b673	2026-09-10	08:56:00	18:01:00	9.08	puntual	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05
6216dee9-95a4-4b09-8479-2bef0f7aad99	1ba3bd1a-4075-4009-b992-7057472e1e56	9faa05e4-2294-45f4-b7dd-4cadbb84b673	2026-09-11	08:58:00	18:08:00	9.17	puntual	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05
98300ca6-046a-4002-92a6-18b12c5b96c5	1ba3bd1a-4075-4009-b992-7057472e1e56	9faa05e4-2294-45f4-b7dd-4cadbb84b673	2026-09-12	08:50:00	18:04:00	9.23	puntual	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05
7f1891bb-4cb3-4826-b1b6-675ea4941b76	1ba3bd1a-4075-4009-b992-7057472e1e56	9faa05e4-2294-45f4-b7dd-4cadbb84b673	2026-09-14	08:56:00	18:01:00	9.08	puntual	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05
33c8408b-e84b-4a6b-b825-9e62c2e3f83d	1ba3bd1a-4075-4009-b992-7057472e1e56	9faa05e4-2294-45f4-b7dd-4cadbb84b673	2026-09-15	08:56:00	18:05:00	9.15	puntual	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05
3f3b08fc-12b7-4a94-b675-1951bf3c4b21	1ba3bd1a-4075-4009-b992-7057472e1e56	9faa05e4-2294-45f4-b7dd-4cadbb84b673	2026-09-16	08:55:00	18:03:00	9.13	puntual	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05
e025b889-3b44-41d0-a48a-c5e2caaffe86	1ba3bd1a-4075-4009-b992-7057472e1e56	9faa05e4-2294-45f4-b7dd-4cadbb84b673	2026-09-17	08:55:00	18:05:00	9.17	puntual	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05
85c8ff6f-f572-4306-a8eb-cb39a264fbf5	1ba3bd1a-4075-4009-b992-7057472e1e56	9faa05e4-2294-45f4-b7dd-4cadbb84b673	2026-09-18	08:52:00	18:01:00	9.15	puntual	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05
54089873-a859-4350-bbba-a8367d2dc46f	1ba3bd1a-4075-4009-b992-7057472e1e56	9faa05e4-2294-45f4-b7dd-4cadbb84b673	2026-09-19	08:50:00	18:03:00	9.22	puntual	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05
e74372b9-b1b9-40fb-89a8-5d4c39772c3c	1ba3bd1a-4075-4009-b992-7057472e1e56	46a1df90-27dc-483f-83ed-19fc88d3d3ae	2026-09-10	08:51:00	18:05:00	9.23	puntual	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05
1ad5d811-d25e-4e54-be35-8ce1a3b3d658	1ba3bd1a-4075-4009-b992-7057472e1e56	46a1df90-27dc-483f-83ed-19fc88d3d3ae	2026-09-11	08:50:00	18:00:00	9.17	puntual	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05
dffb2c8d-e7e3-4b1e-8879-8ed81e281809	1ba3bd1a-4075-4009-b992-7057472e1e56	46a1df90-27dc-483f-83ed-19fc88d3d3ae	2026-09-12	08:51:00	18:07:00	9.27	puntual	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05
220ec10f-d148-4793-9803-fb3bcc18d0a5	1ba3bd1a-4075-4009-b992-7057472e1e56	46a1df90-27dc-483f-83ed-19fc88d3d3ae	2026-09-14	08:52:00	18:08:00	9.27	puntual	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05
583c649a-5de2-4693-a050-bef32d1c09b8	1ba3bd1a-4075-4009-b992-7057472e1e56	46a1df90-27dc-483f-83ed-19fc88d3d3ae	2026-09-15	08:54:00	18:02:00	9.13	puntual	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05
275adfb7-00be-4815-9c3e-fa6bf3421a2a	1ba3bd1a-4075-4009-b992-7057472e1e56	46a1df90-27dc-483f-83ed-19fc88d3d3ae	2026-09-16	08:58:00	18:07:00	9.15	puntual	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05
e9ec5ad2-9e1c-460e-b544-06185cbe28c9	1ba3bd1a-4075-4009-b992-7057472e1e56	46a1df90-27dc-483f-83ed-19fc88d3d3ae	2026-09-17	08:56:00	18:00:00	9.07	puntual	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05
eea0c134-ad7e-4d0b-8885-d3854b784129	1ba3bd1a-4075-4009-b992-7057472e1e56	46a1df90-27dc-483f-83ed-19fc88d3d3ae	2026-09-18	08:54:00	18:02:00	9.13	puntual	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05
f417b626-c1fe-4161-9b5c-58c183ef7060	1ba3bd1a-4075-4009-b992-7057472e1e56	46a1df90-27dc-483f-83ed-19fc88d3d3ae	2026-09-19	08:55:00	18:01:00	9.10	tardanza	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05
\.


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.audit_log (id, user_id, empresa_id, accion, entidad, entidad_id, datos_antes, datos_despues, diff, ip, user_agent, created_at) FROM stdin;
2a8b18d3-0452-4440-b66d-d66b12789029	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	1ba3bd1a-4075-4009-b992-7057472e1e56	emitir	comprobantes	7b96ea92-aa2a-4506-8945-040c248d3088	\N	{"tipo": "boleta", "serie": "B001", "numero": 1}	{"_creado": {"tipo": "boleta", "serie": "B001", "numero": 1}}	\N	\N	2026-09-20 19:58:52.873138-05
03bb69bc-55b3-44ec-bf92-7cdd131d5c1e	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	1ba3bd1a-4075-4009-b992-7057472e1e56	emitir	comprobantes	3f8fac68-eddb-4500-888c-962dfe6801e4	\N	{"tipo": "boleta", "serie": "B001", "numero": 2}	{"_creado": {"tipo": "boleta", "serie": "B001", "numero": 2}}	\N	\N	2026-09-20 19:58:52.873138-05
78e08ff0-4b62-4e85-975c-2471f836f6e5	9faa05e4-2294-45f4-b7dd-4cadbb84b673	1ba3bd1a-4075-4009-b992-7057472e1e56	registrar_pago	pagos	7676facb-df96-4368-92dc-06ab06342ca3	\N	{"monto": 60.00, "metodo": "tarjeta", "caja_id": "8c9f5165-375a-495f-be11-4c5257e48d8b", "cliente_id": "2c27a5b1-37e3-467c-82d0-a43adb274a9d"}	{"_creado": {"monto": 60.00, "metodo": "tarjeta", "caja_id": "8c9f5165-375a-495f-be11-4c5257e48d8b", "cliente_id": "2c27a5b1-37e3-467c-82d0-a43adb274a9d"}}	\N	\N	2026-09-20 19:58:52.873138-05
d00cdb6b-bc98-4ad0-b1b5-6899835ab822	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	1ba3bd1a-4075-4009-b992-7057472e1e56	emitir	comprobantes	9501efd4-ee86-4326-ab23-9f0b0181ed5b	\N	{"tipo": "boleta", "serie": "B001", "numero": 3}	{"_creado": {"tipo": "boleta", "serie": "B001", "numero": 3}}	\N	\N	2026-09-20 19:58:52.873138-05
8d13d140-a2d1-4f4f-94d6-f64ce43156a6	9faa05e4-2294-45f4-b7dd-4cadbb84b673	1ba3bd1a-4075-4009-b992-7057472e1e56	registrar_pago	pagos	20a3dfde-8f15-4de2-80f7-d8eb6395e92d	\N	{"monto": 60.00, "metodo": "tarjeta", "caja_id": "8c9f5165-375a-495f-be11-4c5257e48d8b", "cliente_id": "2dcfe029-99b2-4667-aa5d-6b3cfabda19f"}	{"_creado": {"monto": 60.00, "metodo": "tarjeta", "caja_id": "8c9f5165-375a-495f-be11-4c5257e48d8b", "cliente_id": "2dcfe029-99b2-4667-aa5d-6b3cfabda19f"}}	\N	\N	2026-09-20 19:58:52.873138-05
57688f94-75f9-436d-9456-d4398f442be5	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	1ba3bd1a-4075-4009-b992-7057472e1e56	emitir	comprobantes	c9bd86fa-b2f8-4452-94f0-182271197847	\N	{"tipo": "boleta", "serie": "B001", "numero": 4}	{"_creado": {"tipo": "boleta", "serie": "B001", "numero": 4}}	\N	\N	2026-09-20 19:58:52.873138-05
66af49cf-fdb3-49e7-b688-0272304e6a7b	9faa05e4-2294-45f4-b7dd-4cadbb84b673	1ba3bd1a-4075-4009-b992-7057472e1e56	registrar_pago	pagos	bf8845c3-e76c-49f0-a2bd-4ab792e78a94	\N	{"monto": 120.00, "metodo": "tarjeta", "caja_id": "8c9f5165-375a-495f-be11-4c5257e48d8b", "cliente_id": "6385d210-351d-4d4c-82a3-c3c57507cdf8"}	{"_creado": {"monto": 120.00, "metodo": "tarjeta", "caja_id": "8c9f5165-375a-495f-be11-4c5257e48d8b", "cliente_id": "6385d210-351d-4d4c-82a3-c3c57507cdf8"}}	\N	\N	2026-09-20 19:58:52.873138-05
21d6e3b9-f0f1-4acc-a082-14c8bf99d210	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	1ba3bd1a-4075-4009-b992-7057472e1e56	emitir	comprobantes	3ab77376-6998-4fd8-af0b-50daa227247d	\N	{"tipo": "boleta", "serie": "B001", "numero": 5}	{"_creado": {"tipo": "boleta", "serie": "B001", "numero": 5}}	\N	\N	2026-09-20 19:58:52.873138-05
5f72b11d-b33f-4244-a226-86192adaee65	9faa05e4-2294-45f4-b7dd-4cadbb84b673	1ba3bd1a-4075-4009-b992-7057472e1e56	registrar_pago	pagos	e6e8c030-8ac3-4ebb-8e17-5ad225637aaf	\N	{"monto": 60.00, "metodo": "yape", "caja_id": "8c9f5165-375a-495f-be11-4c5257e48d8b", "cliente_id": "8c82237b-e4f3-4b71-b66d-97a616290625"}	{"_creado": {"monto": 60.00, "metodo": "yape", "caja_id": "8c9f5165-375a-495f-be11-4c5257e48d8b", "cliente_id": "8c82237b-e4f3-4b71-b66d-97a616290625"}}	\N	\N	2026-09-20 19:58:52.873138-05
f770fa2b-91e0-49d2-8ba8-a2a37c0a303b	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	1ba3bd1a-4075-4009-b992-7057472e1e56	emitir	comprobantes	b84e97d9-f351-45a9-bad9-281341d87e66	\N	{"tipo": "boleta", "serie": "B001", "numero": 6}	{"_creado": {"tipo": "boleta", "serie": "B001", "numero": 6}}	\N	\N	2026-09-20 19:58:52.873138-05
016c1229-c95c-41d7-bc3f-94b9a21c1dff	9faa05e4-2294-45f4-b7dd-4cadbb84b673	1ba3bd1a-4075-4009-b992-7057472e1e56	registrar_pago	pagos	01a70202-2d13-4cac-8f7b-bc6de47d2f58	\N	{"monto": 60.00, "metodo": "tarjeta", "caja_id": "8c9f5165-375a-495f-be11-4c5257e48d8b", "cliente_id": "976e5703-78d6-41e0-860e-a5f300ebec0e"}	{"_creado": {"monto": 60.00, "metodo": "tarjeta", "caja_id": "8c9f5165-375a-495f-be11-4c5257e48d8b", "cliente_id": "976e5703-78d6-41e0-860e-a5f300ebec0e"}}	\N	\N	2026-09-20 19:58:52.873138-05
bd16635d-0d23-4a77-8fa6-ff149f83c8b8	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	1ba3bd1a-4075-4009-b992-7057472e1e56	emitir	comprobantes	5e951870-3242-4e52-809d-7d4fbb936023	\N	{"tipo": "boleta", "serie": "B001", "numero": 7}	{"_creado": {"tipo": "boleta", "serie": "B001", "numero": 7}}	\N	\N	2026-09-20 19:58:52.873138-05
2b4dab20-bc00-4984-b2ad-125ef0d97628	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	1ba3bd1a-4075-4009-b992-7057472e1e56	emitir	comprobantes	244181d7-bfdc-4807-a283-a91e051388f6	\N	{"tipo": "boleta", "serie": "B001", "numero": 8}	{"_creado": {"tipo": "boleta", "serie": "B001", "numero": 8}}	\N	\N	2026-09-20 19:58:52.873138-05
0b36c629-2d2d-49c5-b366-05a53d7198af	9faa05e4-2294-45f4-b7dd-4cadbb84b673	1ba3bd1a-4075-4009-b992-7057472e1e56	registrar_pago	pagos	439645b4-c164-473c-9791-3cab1266e449	\N	{"monto": 60.00, "metodo": "yape", "caja_id": "8c9f5165-375a-495f-be11-4c5257e48d8b", "cliente_id": "a27a10a9-9bff-4744-bbd4-fc7cff8377e3"}	{"_creado": {"monto": 60.00, "metodo": "yape", "caja_id": "8c9f5165-375a-495f-be11-4c5257e48d8b", "cliente_id": "a27a10a9-9bff-4744-bbd4-fc7cff8377e3"}}	\N	\N	2026-09-20 19:58:52.873138-05
25e21c3e-aeb0-45c8-80f2-c4a014c58346	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	1ba3bd1a-4075-4009-b992-7057472e1e56	emitir	comprobantes	ac9fb05f-e1ff-4a4b-af73-e2775ca7ca33	\N	{"tipo": "boleta", "serie": "B001", "numero": 9}	{"_creado": {"tipo": "boleta", "serie": "B001", "numero": 9}}	\N	\N	2026-09-20 19:58:52.873138-05
8671b7ad-6974-4a16-8edc-cbaaebffe57f	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	1ba3bd1a-4075-4009-b992-7057472e1e56	emitir	comprobantes	0ab1acd9-94ad-433b-b998-ff5c8df9cd50	\N	{"tipo": "boleta", "serie": "B001", "numero": 10}	{"_creado": {"tipo": "boleta", "serie": "B001", "numero": 10}}	\N	\N	2026-09-20 19:58:52.873138-05
297efa20-3572-43a5-be60-002709dd6b37	9faa05e4-2294-45f4-b7dd-4cadbb84b673	1ba3bd1a-4075-4009-b992-7057472e1e56	registrar_pago	pagos	f65984c6-7f91-4f2c-9a6f-96cf2f2ca69c	\N	{"monto": 120.00, "metodo": "yape", "caja_id": "8c9f5165-375a-495f-be11-4c5257e48d8b", "cliente_id": "e4b74708-4127-4227-8144-7df4d7484c7a"}	{"_creado": {"monto": 120.00, "metodo": "yape", "caja_id": "8c9f5165-375a-495f-be11-4c5257e48d8b", "cliente_id": "e4b74708-4127-4227-8144-7df4d7484c7a"}}	\N	\N	2026-09-20 19:58:52.873138-05
\.


--
-- Data for Name: cajas; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.cajas (id, empresa_id, numero, user_apertura_id, user_cierre_id, fecha_apertura, fecha_cierre, monto_apertura, total_ingresos, total_egresos, total_efectivo, total_tarjeta, total_digital, monto_esperado, monto_contado, diferencia, estado, observaciones, created_at, updated_at) FROM stdin;
8c9f5165-375a-495f-be11-4c5257e48d8b	1ba3bd1a-4075-4009-b992-7057472e1e56	CAJA-00001	9faa05e4-2294-45f4-b7dd-4cadbb84b673	\N	2026-09-20 19:58:52.873138-05	\N	200.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	abierta	Apertura de turno	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05
\.


--
-- Data for Name: categorias; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.categorias (id, empresa_id, ambito, codigo, nombre, descripcion, padre_id, orden, estado, created_at, updated_at) FROM stdin;
f57d3798-ec1a-47d5-b6ee-3f0e21ad4073	1ba3bd1a-4075-4009-b992-7057472e1e56	servicio	CONSULTAS	Consultas	\N	\N	1	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05
0dde3ea9-0db4-4d6b-b89a-1263d5c238be	1ba3bd1a-4075-4009-b992-7057472e1e56	servicio	PREVENTIVA	Medicina preventiva	\N	\N	2	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05
d7ce382c-9e78-4841-a7c3-ca3f989f50af	1ba3bd1a-4075-4009-b992-7057472e1e56	servicio	CIRUGIA	Cirugía	\N	\N	3	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05
4ce5060f-3c4f-4336-b796-8db1a20792eb	1ba3bd1a-4075-4009-b992-7057472e1e56	servicio	DIAGNOSTICO	Diagnóstico	\N	\N	4	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05
736834d8-2fe8-4cd4-9fe3-8a23f843fdc1	1ba3bd1a-4075-4009-b992-7057472e1e56	servicio	ESTETICA	Estética y grooming	\N	\N	5	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05
b318d63c-9f8d-46d0-90fe-f2b563521ce6	1ba3bd1a-4075-4009-b992-7057472e1e56	producto	MEDICAMENTO	Medicamentos	\N	\N	1	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05
d573dc50-dd3d-4f66-b762-004b899e9b5f	1ba3bd1a-4075-4009-b992-7057472e1e56	producto	INSUMO	Insumos médicos	\N	\N	2	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05
ce0682e6-d0b1-4e55-902a-ce02dbb45ce0	1ba3bd1a-4075-4009-b992-7057472e1e56	producto	ALIMENTO	Alimento balanceado	\N	\N	3	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05
adf9d988-107f-4100-82a7-44e1611ae595	1ba3bd1a-4075-4009-b992-7057472e1e56	producto	ACCESORIO	Accesorios	\N	\N	4	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05
4225f4a2-33bb-43a8-a4d5-7bc1948ae857	1ba3bd1a-4075-4009-b992-7057472e1e56	proveedor	LABORATORIO	Laboratorios	\N	\N	1	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05
95ed1a86-3f11-4c59-8b92-5d329de56c34	1ba3bd1a-4075-4009-b992-7057472e1e56	proveedor	DISTRIBUIDOR	Distribuidores	\N	\N	2	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05
29ee3f74-c8ad-452d-aba7-eb8f0f1b8744	a64719a9-57fc-4ac0-b104-b9d861370dc7	servicio	CONSULTAS	Consultas	\N	\N	1	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05
076bb559-0050-4359-9f9e-31445280bca0	a64719a9-57fc-4ac0-b104-b9d861370dc7	servicio	PREVENTIVA	Medicina preventiva	\N	\N	2	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05
a7f71717-a9bd-4219-8836-6a1324187bf2	a64719a9-57fc-4ac0-b104-b9d861370dc7	producto	MEDICAMENTO	Medicamentos	\N	\N	1	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05
3ad4054e-81b6-4c98-93bc-d4187abf09ba	a64719a9-57fc-4ac0-b104-b9d861370dc7	producto	INSUMO	Insumos médicos	\N	\N	2	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05
\.


--
-- Data for Name: cirugias; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.cirugias (id, empresa_id, codigo, mascota_id, cirujano_id, anestesista_id, consultorio_id, servicio_id, cita_id, nombre, descripcion, fecha_programada, fecha_inicio, fecha_fin, anestesia_tipo, anestesia_dosis, hallazgos, complicaciones, resultado, cuidados_post, consentimiento_firmado, estado, created_at, updated_at, created_by, updated_by) FROM stdin;
c0a67a3d-3de5-47d7-9b46-e89e8a35ddab	1ba3bd1a-4075-4009-b992-7057472e1e56	CIR-00001	8faa65e3-0f52-48a8-940e-11f261b0b78c	419047f7-804f-4e15-90ca-276e3a463644	5dc67c3d-1666-4a68-8cb5-489997a6bf08	28f41900-e18e-4a4b-928e-8b7ab72b4485	b4d1d43a-cf35-4ba4-947a-9ec52f5c0860	\N	Ovariohisterectomía	Esterilización electiva	2026-09-22 11:00:00-05	\N	\N	Inhalatoria (isoflurano)	\N	\N	\N	\N	\N	t	programada	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	419047f7-804f-4e15-90ca-276e3a463644	\N
\.


--
-- Data for Name: citas; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.citas (id, empresa_id, codigo, cliente_id, mascota_id, veterinario_id, servicio_id, consultorio_id, fecha_hora, duracion_min, motivo, prioridad, origen, estado, hora_llegada, hora_atencion, hora_salida, recordatorio_enviado_at, motivo_cancelacion, observaciones, created_at, updated_at, deleted_at, created_by, updated_by) FROM stdin;
719832b2-21bc-424f-b04f-9002eefecd21	1ba3bd1a-4075-4009-b992-7057472e1e56	CIT-000001	e4b74708-4127-4227-8144-7df4d7484c7a	b4cbd8de-2439-4495-bd52-7c03a6bee07e	419047f7-804f-4e15-90ca-276e3a463644	3547474b-85d1-4280-97f1-4d14966b7841	\N	2026-09-18 10:35:00-05	30	Decaimiento y falta de apetito	normal	mostrador	completada	\N	\N	\N	\N	\N	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N	9faa05e4-2294-45f4-b7dd-4cadbb84b673	\N
2a4d4fe9-4ce9-453e-8e4f-98ea4d49d14d	1ba3bd1a-4075-4009-b992-7057472e1e56	CIT-000002	e4b74708-4127-4227-8144-7df4d7484c7a	b4cbd8de-2439-4495-bd52-7c03a6bee07e	5dc67c3d-1666-4a68-8cb5-489997a6bf08	1a84418b-151d-4814-ab5c-9166a679004a	8ed63944-dd81-4213-838a-0faf8cbbc9e5	2026-09-21 09:40:00-05	30	Vacunación programada	normal	telefono	confirmada	\N	\N	\N	\N	\N	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N	9faa05e4-2294-45f4-b7dd-4cadbb84b673	\N
7cac4a3c-9e6e-4f3d-bb79-195f2d030dcc	1ba3bd1a-4075-4009-b992-7057472e1e56	CIT-000003	e4b74708-4127-4227-8144-7df4d7484c7a	7035d850-c693-4743-880f-d1725c46e17c	5dc67c3d-1666-4a68-8cb5-489997a6bf08	3547474b-85d1-4280-97f1-4d14966b7841	\N	2026-09-17 11:10:00-05	30	Vómitos desde ayer	normal	mostrador	completada	\N	\N	\N	\N	\N	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N	9faa05e4-2294-45f4-b7dd-4cadbb84b673	\N
c2bac5da-623e-4bc5-a636-7a614fb7b189	1ba3bd1a-4075-4009-b992-7057472e1e56	CIT-000004	e4b74708-4127-4227-8144-7df4d7484c7a	7035d850-c693-4743-880f-d1725c46e17c	419047f7-804f-4e15-90ca-276e3a463644	5066f985-c4c9-4447-b46a-28128c41ba1e	8ed63944-dd81-4213-838a-0faf8cbbc9e5	2026-09-22 10:20:00-05	30	Desparasitación	normal	whatsapp	confirmada	\N	\N	\N	\N	\N	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N	9faa05e4-2294-45f4-b7dd-4cadbb84b673	\N
3f5a2894-7aea-41c7-bf23-72f7cdb4cc4b	1ba3bd1a-4075-4009-b992-7057472e1e56	CIT-000005	a27a10a9-9bff-4744-bbd4-fc7cff8377e3	43509380-78ff-488d-8590-7346e7769aa0	419047f7-804f-4e15-90ca-276e3a463644	3547474b-85d1-4280-97f1-4d14966b7841	\N	2026-09-16 11:45:00-05	30	Chequeo preventivo	normal	mostrador	completada	\N	\N	\N	\N	\N	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N	9faa05e4-2294-45f4-b7dd-4cadbb84b673	\N
386266b3-d1f1-4169-925b-85047bb21b23	1ba3bd1a-4075-4009-b992-7057472e1e56	CIT-000006	a27a10a9-9bff-4744-bbd4-fc7cff8377e3	43509380-78ff-488d-8590-7346e7769aa0	5dc67c3d-1666-4a68-8cb5-489997a6bf08	1c482355-7d77-49c3-b796-957d3bc4d87b	8ed63944-dd81-4213-838a-0faf8cbbc9e5	2026-09-23 11:00:00-05	30	Baño medicado	urgencia	portal	programada	\N	\N	\N	\N	\N	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N	9faa05e4-2294-45f4-b7dd-4cadbb84b673	\N
4f6b7ca5-7d46-4fd8-b35f-2ccfda909d70	1ba3bd1a-4075-4009-b992-7057472e1e56	CIT-000007	2c27a5b1-37e3-467c-82d0-a43adb274a9d	2ab9d0d1-f0e0-45e0-87b0-b7037c9942fa	5dc67c3d-1666-4a68-8cb5-489997a6bf08	3547474b-85d1-4280-97f1-4d14966b7841	\N	2026-09-15 12:20:00-05	30	Cojera de miembro posterior	normal	mostrador	completada	\N	\N	\N	\N	\N	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N	9faa05e4-2294-45f4-b7dd-4cadbb84b673	\N
c4dcce58-005d-44e2-a586-da297b3eeebb	1ba3bd1a-4075-4009-b992-7057472e1e56	CIT-000008	2c27a5b1-37e3-467c-82d0-a43adb274a9d	2ab9d0d1-f0e0-45e0-87b0-b7037c9942fa	419047f7-804f-4e15-90ca-276e3a463644	3547474b-85d1-4280-97f1-4d14966b7841	8ed63944-dd81-4213-838a-0faf8cbbc9e5	2026-09-20 11:40:00-05	30	Revisión post-operatoria	normal	mostrador	programada	\N	\N	\N	\N	\N	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N	9faa05e4-2294-45f4-b7dd-4cadbb84b673	\N
268e2cb4-ce58-4b8d-88ba-b1f5972d41ad	1ba3bd1a-4075-4009-b992-7057472e1e56	CIT-000009	2dcfe029-99b2-4667-aa5d-6b3cfabda19f	e485ee0b-d6f9-4052-ba2f-2e63f3f1fd76	419047f7-804f-4e15-90ca-276e3a463644	3547474b-85d1-4280-97f1-4d14966b7841	\N	2026-09-19 12:55:00-05	30	Revisión de piel	normal	mostrador	completada	\N	\N	\N	\N	\N	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N	9faa05e4-2294-45f4-b7dd-4cadbb84b673	\N
f4ae6b4b-26bc-4a44-baba-3ebfeb4bf25c	1ba3bd1a-4075-4009-b992-7057472e1e56	CIT-000010	2dcfe029-99b2-4667-aa5d-6b3cfabda19f	e485ee0b-d6f9-4052-ba2f-2e63f3f1fd76	5dc67c3d-1666-4a68-8cb5-489997a6bf08	1a84418b-151d-4814-ab5c-9166a679004a	8ed63944-dd81-4213-838a-0faf8cbbc9e5	2026-09-21 12:20:00-05	30	Control de tratamiento	normal	telefono	confirmada	\N	\N	\N	\N	\N	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N	9faa05e4-2294-45f4-b7dd-4cadbb84b673	\N
f52590e8-a35b-4b31-a58f-6533a3904e5a	1ba3bd1a-4075-4009-b992-7057472e1e56	CIT-000011	e282ecd9-0ef4-4730-820a-065589f39268	7a2e7560-c4a8-4f72-accd-6b64967fab66	5dc67c3d-1666-4a68-8cb5-489997a6bf08	3547474b-85d1-4280-97f1-4d14966b7841	\N	2026-09-18 13:30:00-05	30	Control anual	normal	mostrador	completada	\N	\N	\N	\N	\N	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N	9faa05e4-2294-45f4-b7dd-4cadbb84b673	\N
902d779c-33c8-4c05-9632-83892b9ea350	1ba3bd1a-4075-4009-b992-7057472e1e56	CIT-000012	e282ecd9-0ef4-4730-820a-065589f39268	7a2e7560-c4a8-4f72-accd-6b64967fab66	419047f7-804f-4e15-90ca-276e3a463644	5066f985-c4c9-4447-b46a-28128c41ba1e	8ed63944-dd81-4213-838a-0faf8cbbc9e5	2026-09-22 13:00:00-05	30	Vacunación programada	normal	whatsapp	confirmada	\N	\N	\N	\N	\N	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N	9faa05e4-2294-45f4-b7dd-4cadbb84b673	\N
33dc6def-9f84-452d-a89b-d22f61b65583	1ba3bd1a-4075-4009-b992-7057472e1e56	CIT-000013	a00187d7-281c-4691-8e20-ce62af59ce4e	cbbced34-52c2-45d5-adf1-e96954285557	419047f7-804f-4e15-90ca-276e3a463644	3547474b-85d1-4280-97f1-4d14966b7841	\N	2026-09-17 14:05:00-05	30	Decaimiento y falta de apetito	normal	mostrador	completada	\N	\N	\N	\N	\N	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N	9faa05e4-2294-45f4-b7dd-4cadbb84b673	\N
6546f1bd-d57b-4aab-bfb4-2cc86071bb36	1ba3bd1a-4075-4009-b992-7057472e1e56	CIT-000014	a00187d7-281c-4691-8e20-ce62af59ce4e	cbbced34-52c2-45d5-adf1-e96954285557	5dc67c3d-1666-4a68-8cb5-489997a6bf08	1c482355-7d77-49c3-b796-957d3bc4d87b	8ed63944-dd81-4213-838a-0faf8cbbc9e5	2026-09-23 13:40:00-05	30	Desparasitación	normal	portal	programada	\N	\N	\N	\N	\N	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N	9faa05e4-2294-45f4-b7dd-4cadbb84b673	\N
5ddabc0c-bc98-4ec2-8238-e3f68b22099d	1ba3bd1a-4075-4009-b992-7057472e1e56	CIT-000015	2a2f2866-944b-4edb-bd6d-f68cf7f814e6	6818d890-9824-4de4-8ce5-4e7084079e8e	5dc67c3d-1666-4a68-8cb5-489997a6bf08	3547474b-85d1-4280-97f1-4d14966b7841	\N	2026-09-16 14:40:00-05	30	Vómitos desde ayer	normal	mostrador	completada	\N	\N	\N	\N	\N	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N	9faa05e4-2294-45f4-b7dd-4cadbb84b673	\N
c3d53661-9244-4718-9d71-88a9a720b856	1ba3bd1a-4075-4009-b992-7057472e1e56	CIT-000016	2a2f2866-944b-4edb-bd6d-f68cf7f814e6	6818d890-9824-4de4-8ce5-4e7084079e8e	419047f7-804f-4e15-90ca-276e3a463644	3547474b-85d1-4280-97f1-4d14966b7841	8ed63944-dd81-4213-838a-0faf8cbbc9e5	2026-09-20 14:20:00-05	30	Baño medicado	normal	mostrador	programada	\N	\N	\N	\N	\N	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N	9faa05e4-2294-45f4-b7dd-4cadbb84b673	\N
e22fc738-f9ce-49a9-be74-6c5399483633	1ba3bd1a-4075-4009-b992-7057472e1e56	CIT-000017	6385d210-351d-4d4c-82a3-c3c57507cdf8	b7b98cfc-fff1-4d55-afb3-9f3c03cd431a	419047f7-804f-4e15-90ca-276e3a463644	3547474b-85d1-4280-97f1-4d14966b7841	\N	2026-09-15 15:15:00-05	30	Chequeo preventivo	normal	mostrador	completada	\N	\N	\N	\N	\N	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N	9faa05e4-2294-45f4-b7dd-4cadbb84b673	\N
300bdbc7-e21e-42f9-a129-912e993d40d6	1ba3bd1a-4075-4009-b992-7057472e1e56	CIT-000018	6385d210-351d-4d4c-82a3-c3c57507cdf8	b7b98cfc-fff1-4d55-afb3-9f3c03cd431a	5dc67c3d-1666-4a68-8cb5-489997a6bf08	1a84418b-151d-4814-ab5c-9166a679004a	8ed63944-dd81-4213-838a-0faf8cbbc9e5	2026-09-21 15:00:00-05	30	Revisión post-operatoria	normal	telefono	confirmada	\N	\N	\N	\N	\N	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N	9faa05e4-2294-45f4-b7dd-4cadbb84b673	\N
2cdaa77b-278b-435b-b1e1-5c86bb19430c	1ba3bd1a-4075-4009-b992-7057472e1e56	CIT-000019	6385d210-351d-4d4c-82a3-c3c57507cdf8	8faa65e3-0f52-48a8-940e-11f261b0b78c	5dc67c3d-1666-4a68-8cb5-489997a6bf08	3547474b-85d1-4280-97f1-4d14966b7841	\N	2026-09-19 15:50:00-05	30	Cojera de miembro posterior	normal	mostrador	completada	\N	\N	\N	\N	\N	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N	9faa05e4-2294-45f4-b7dd-4cadbb84b673	\N
76f78226-e810-4da0-99d3-09a713f42118	1ba3bd1a-4075-4009-b992-7057472e1e56	CIT-000020	6385d210-351d-4d4c-82a3-c3c57507cdf8	8faa65e3-0f52-48a8-940e-11f261b0b78c	419047f7-804f-4e15-90ca-276e3a463644	5066f985-c4c9-4447-b46a-28128c41ba1e	8ed63944-dd81-4213-838a-0faf8cbbc9e5	2026-09-22 15:40:00-05	30	Control de tratamiento	normal	whatsapp	confirmada	\N	\N	\N	\N	\N	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N	9faa05e4-2294-45f4-b7dd-4cadbb84b673	\N
c838f213-73c7-4aa1-a1b4-81dfda816a67	1ba3bd1a-4075-4009-b992-7057472e1e56	CIT-000021	976e5703-78d6-41e0-860e-a5f300ebec0e	7da7fd75-767c-4176-ac1a-3396c31a2eba	419047f7-804f-4e15-90ca-276e3a463644	3547474b-85d1-4280-97f1-4d14966b7841	\N	2026-09-18 16:25:00-05	30	Revisión de piel	normal	mostrador	completada	\N	\N	\N	\N	\N	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N	9faa05e4-2294-45f4-b7dd-4cadbb84b673	\N
991b80a5-1c1d-4db5-838e-3a7c27a8d90d	1ba3bd1a-4075-4009-b992-7057472e1e56	CIT-000022	976e5703-78d6-41e0-860e-a5f300ebec0e	7da7fd75-767c-4176-ac1a-3396c31a2eba	5dc67c3d-1666-4a68-8cb5-489997a6bf08	1c482355-7d77-49c3-b796-957d3bc4d87b	8ed63944-dd81-4213-838a-0faf8cbbc9e5	2026-09-23 16:20:00-05	30	Vacunación programada	normal	portal	programada	\N	\N	\N	\N	\N	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N	9faa05e4-2294-45f4-b7dd-4cadbb84b673	\N
50c99593-7163-4af9-9218-d139b4b5dcec	1ba3bd1a-4075-4009-b992-7057472e1e56	CIT-000023	8c82237b-e4f3-4b71-b66d-97a616290625	a7b2f548-685d-43f6-ba66-77776a0ed1f5	5dc67c3d-1666-4a68-8cb5-489997a6bf08	3547474b-85d1-4280-97f1-4d14966b7841	\N	2026-09-17 17:00:00-05	30	Control anual	normal	mostrador	completada	\N	\N	\N	\N	\N	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N	9faa05e4-2294-45f4-b7dd-4cadbb84b673	\N
b698e98f-7f18-4355-9b99-c52bb4a4aaaa	1ba3bd1a-4075-4009-b992-7057472e1e56	CIT-000024	8c82237b-e4f3-4b71-b66d-97a616290625	a7b2f548-685d-43f6-ba66-77776a0ed1f5	419047f7-804f-4e15-90ca-276e3a463644	3547474b-85d1-4280-97f1-4d14966b7841	8ed63944-dd81-4213-838a-0faf8cbbc9e5	2026-09-20 17:00:00-05	30	Desparasitación	normal	mostrador	programada	\N	\N	\N	\N	\N	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N	9faa05e4-2294-45f4-b7dd-4cadbb84b673	\N
\.


--
-- Data for Name: citas_historial; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.citas_historial (id, cita_id, accion, fecha_hora_antes, fecha_hora_despues, motivo, user_id, created_at) FROM stdin;
\.


--
-- Data for Name: citas_lista_espera; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.citas_lista_espera (id, empresa_id, cliente_id, mascota_id, servicio_id, veterinario_id, desde, hasta, nota, atendido, created_at) FROM stdin;
\.


--
-- Data for Name: clausulas; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.clausulas (id, empresa_id, tipo, titulo, contenido, orden, estado, created_at, updated_at) FROM stdin;
88d2d48d-dde9-4379-9964-76211904fb32	1ba3bd1a-4075-4009-b992-7057472e1e56	consentimiento	Consentimiento informado quirúrgico	Autorizo al equipo médico de la clínica a realizar el procedimiento quirúrgico indicado, así como la administración de anestesia y los procedimientos complementarios que resulten necesarios. Declaro haber sido informado de los riesgos inherentes al acto anestésico y quirúrgico, y de que no existe garantía de resultado.	1	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05
e71c00c4-4436-47ad-bedf-6cc236850574	1ba3bd1a-4075-4009-b992-7057472e1e56	consentimiento	Autorización de hospitalización	Autorizo el internamiento de mi mascota y los tratamientos que el médico veterinario tratante considere necesarios durante su permanencia. Me comprometo a cubrir los costos derivados de la hospitalización.	2	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05
576e4ce5-5d61-48fc-a524-756810c2763f	1ba3bd1a-4075-4009-b992-7057472e1e56	politica	Política de cancelación de citas	Las citas pueden reprogramarse o cancelarse hasta 4 horas antes del horario reservado. La inasistencia reiterada sin aviso puede restringir la reserva anticipada.	3	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05
\.


--
-- Data for Name: clientes; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.clientes (id, empresa_id, codigo, tipo_documento, numero_documento, nombres, apellido_paterno, apellido_materno, razon_social, telefono, telefono_alterno, correo, direccion, ubigeo, fecha_nacimiento, linea_credito, dias_credito, acepta_marketing, portal_acceso, portal_password_hash, portal_ultimo_login_at, estado, observaciones, created_at, updated_at, deleted_at, created_by, updated_by) FROM stdin;
2c27a5b1-37e3-467c-82d0-a43adb274a9d	1ba3bd1a-4075-4009-b992-7057472e1e56	CLI-00003	DNI	43887766	Sofía	Camacho	León	\N	985443322	\N	sofia.camacho@gmail.com	Av. Benavides 1890, Surco	\N	\N	0.00	0	t	f	\N	\N	activo	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N
2dcfe029-99b2-4667-aa5d-6b3cfabda19f	1ba3bd1a-4075-4009-b992-7057472e1e56	CLI-00004	DNI	40998877	Diego	Ramírez	Ochoa	\N	984556677	\N	dramirez@gmail.com	Calle Bolívar 780, Miraflores	\N	\N	0.00	0	t	f	\N	\N	activo	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N
e282ecd9-0ef4-4730-820a-065589f39268	1ba3bd1a-4075-4009-b992-7057472e1e56	CLI-00005	DNI	45667788	Valeria	Huamán	Castro	\N	983221144	\N	valeria.h@hotmail.com	Av. Angamos Este 1520, Surquillo	\N	\N	0.00	0	t	f	\N	\N	activo	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N
a00187d7-281c-4691-8e20-ce62af59ce4e	1ba3bd1a-4075-4009-b992-7057472e1e56	CLI-00006	DNI	42334455	Renzo	Aguilar	Ponce	\N	982778899	\N	renzo.aguilar@gmail.com	Jr. Colón 340, Miraflores	\N	\N	0.00	0	t	f	\N	\N	activo	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N
2a2f2866-944b-4edb-bd6d-f68cf7f814e6	1ba3bd1a-4075-4009-b992-7057472e1e56	CLI-00007	DNI	46778899	Paola	Ninahuanca	Silva	\N	981334455	\N	paola.n@gmail.com	Av. Petit Thouars 4200, San Isidro	\N	\N	0.00	0	t	f	\N	\N	activo	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N
6385d210-351d-4d4c-82a3-c3c57507cdf8	1ba3bd1a-4075-4009-b992-7057472e1e56	CLI-00008	RUC	20601122334	Refugio Huellitas	\N	\N	Refugio Huellitas	980112233	\N	contacto@huellitas.org	Av. Universitaria 3400, Los Olivos	\N	\N	0.00	0	t	f	\N	\N	activo	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N
976e5703-78d6-41e0-860e-a5f300ebec0e	1ba3bd1a-4075-4009-b992-7057472e1e56	CLI-00009	DNI	47889900	Gonzalo	Medina	Rojas	\N	979445566	\N	gmedina@gmail.com	Calle Manuel Bonilla 120, Miraflores	\N	\N	0.00	0	t	f	\N	\N	activo	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N
8c82237b-e4f3-4b71-b66d-97a616290625	1ba3bd1a-4075-4009-b992-7057472e1e56	CLI-00010	DNI	48990011	Ximena	Bravo	Ríos	\N	978556677	\N	xbravo@gmail.com	Av. La Mar 2300, Magdalena	\N	\N	0.00	0	t	f	\N	\N	activo	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N
a27a10a9-9bff-4744-bbd4-fc7cff8377e3	1ba3bd1a-4075-4009-b992-7057472e1e56	CLI-00002	DNI	41223344	Miguel	Torres	Nuñez	\N	986112233	\N	mtorres@outlook.com	Jr. Berlín 210, Miraflores	\N	\N	0.00	0	t	t	$2a$10$4wDOQiU/UBLP48DkD90fieBf9U3DPnKK20bLv2rrBvOBhiY3Nfr0a	\N	activo	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N
e4b74708-4127-4227-8144-7df4d7484c7a	1ba3bd1a-4075-4009-b992-7057472e1e56	CLI-00001	DNI	44556677	Carla	Zevallos	Ruiz	\N	987654321	\N	carla.zevallos@gmail.com	Av. Pardo 455, Miraflores	\N	\N	0.00	0	t	t	$2a$10$CkwWF6lwTn7HUJnPikYiTO4N2FqaXsmLNQ0jHqPM5qbJCWIGyej7e	\N	activo	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N
ba6e3efc-85b9-4afb-b021-59c90b1175ca	a64719a9-57fc-4ac0-b104-b9d861370dc7	CLI-00001	DNI	44556677	Carla	Zevallos	Ruiz	\N	987654321	\N	\N	Av. Javier Prado 1200	\N	\N	0.00	0	t	f	\N	\N	activo	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N
f55d340b-afe4-4411-bc87-f676d44c5a95	a64719a9-57fc-4ac0-b104-b9d861370dc7	CLI-00002	DNI	39887766	Alonso	Ibáñez	Ferrer	\N	976554433	\N	\N	Calle Los Robles 88	\N	\N	0.00	0	t	f	\N	\N	activo	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N
b6aa1bbe-b47e-43f2-b441-787446f4036a	a64719a9-57fc-4ac0-b104-b9d861370dc7	CLI-00003	DNI	38776655	Rosa	Chávez	Delgado	\N	975443322	\N	\N	Av. Aramburú 560	\N	\N	0.00	0	t	f	\N	\N	activo	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N
\.


--
-- Data for Name: comprobante_items; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.comprobante_items (id, comprobante_id, tipo_item, servicio_id, producto_id, orden_servicio_id, codigo, descripcion, cantidad, precio_unitario, descuento, afecto_igv, subtotal, igv, total, orden, insumo_id, tipo_afectacion_igv, unidad_medida, item_ref_id) FROM stdin;
20f2e73b-5c57-4360-9640-37a7ebdefd71	7b96ea92-aa2a-4506-8945-040c248d3088	servicio	3547474b-85d1-4280-97f1-4d14966b7841	\N	55378df3-de75-4279-b93c-b428421ee8a3	SRV-0001	Consulta general — Milo	1.00	60.0000	0.00	t	50.85	9.15	60.00	1	\N	10	ZZ	\N
a6fb29d6-3c19-4754-af2c-1c355a0ca847	3f8fac68-eddb-4500-888c-962dfe6801e4	servicio	3547474b-85d1-4280-97f1-4d14966b7841	\N	75fb96ba-e60f-4449-b62f-f794b42123e3	SRV-0001	Consulta general — Maya	1.00	60.0000	0.00	t	50.85	9.15	60.00	1	\N	10	ZZ	\N
20fd0f97-ca61-4515-95b5-dc4d14d0a90b	9501efd4-ee86-4326-ab23-9f0b0181ed5b	servicio	3547474b-85d1-4280-97f1-4d14966b7841	\N	f3ee0853-7a5a-4e60-abaf-b0c7c50833d8	SRV-0001	Consulta general — Thor	1.00	60.0000	0.00	t	50.85	9.15	60.00	1	\N	10	ZZ	\N
5a8137dc-82c3-4cd4-a747-d31da433b34e	c9bd86fa-b2f8-4452-94f0-182271197847	servicio	3547474b-85d1-4280-97f1-4d14966b7841	\N	78d48535-de11-41fe-ae5c-c843bd4bcd50	SRV-0001	Consulta general — Bruno	1.00	60.0000	0.00	t	50.85	9.15	60.00	1	\N	10	ZZ	\N
aaa5ee14-6512-44bc-8efa-61ec20087eb4	c9bd86fa-b2f8-4452-94f0-182271197847	servicio	3547474b-85d1-4280-97f1-4d14966b7841	\N	4859ec41-7c5c-40ab-b6a3-222aca529aa6	SRV-0001	Consulta general — Chispa	1.00	60.0000	0.00	t	50.85	9.15	60.00	2	\N	10	ZZ	\N
39eb08c8-0c0b-465e-b377-fa144e8720e0	3ab77376-6998-4fd8-af0b-50daa227247d	servicio	3547474b-85d1-4280-97f1-4d14966b7841	\N	8e367415-e2f7-42ad-9f59-dc68b7d4c58b	SRV-0001	Consulta general — Pelusa	1.00	60.0000	0.00	t	50.85	9.15	60.00	1	\N	10	ZZ	\N
97c3c4bb-f289-4000-82af-0cd8864d40a2	b84e97d9-f351-45a9-bad9-281341d87e66	servicio	3547474b-85d1-4280-97f1-4d14966b7841	\N	d415a9c0-9add-4df0-a349-5c0c769ad084	SRV-0001	Consulta general — Kira	1.00	60.0000	0.00	t	50.85	9.15	60.00	1	\N	10	ZZ	\N
414dd98f-3bbf-45dd-830c-fd91520cd6a8	5e951870-3242-4e52-809d-7d4fbb936023	servicio	3547474b-85d1-4280-97f1-4d14966b7841	\N	31f050a1-58de-4e8c-b94b-d5862b2a8cd3	SRV-0001	Consulta general — Coco	1.00	60.0000	0.00	t	50.85	9.15	60.00	1	\N	10	ZZ	\N
52c93cfd-7ab8-41f9-a25b-b4b11612c70d	244181d7-bfdc-4807-a283-a91e051388f6	servicio	3547474b-85d1-4280-97f1-4d14966b7841	\N	8c7ba4e7-90a8-49a8-bb19-e467244544ea	SRV-0001	Consulta general — Rocky	1.00	60.0000	0.00	t	50.85	9.15	60.00	1	\N	10	ZZ	\N
d2aa55bc-ea84-43e1-9c85-ee556d6175de	ac9fb05f-e1ff-4a4b-af73-e2775ca7ca33	servicio	3547474b-85d1-4280-97f1-4d14966b7841	\N	d1288a7d-2249-481b-b92e-ed001ea1e729	SRV-0001	Consulta general — Nala	1.00	60.0000	0.00	t	50.85	9.15	60.00	1	\N	10	ZZ	\N
38691ad0-30e6-4adf-97a1-baf74c25a83f	0ab1acd9-94ad-433b-b998-ff5c8df9cd50	servicio	3547474b-85d1-4280-97f1-4d14966b7841	\N	7c3ba082-e5d3-4e8a-954e-b5ca1aa8e9b2	SRV-0001	Consulta general — Luna	1.00	60.0000	0.00	t	50.85	9.15	60.00	1	\N	10	ZZ	\N
692370f2-bea4-4478-a623-aec6d721dcac	0ab1acd9-94ad-433b-b998-ff5c8df9cd50	servicio	3547474b-85d1-4280-97f1-4d14966b7841	\N	575049ee-fec7-4513-8f1f-867f93a4e5a8	SRV-0001	Consulta general — Simón	1.00	60.0000	0.00	t	50.85	9.15	60.00	2	\N	10	ZZ	\N
\.


--
-- Data for Name: comprobante_pse_log; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.comprobante_pse_log (id, comprobante_id, intento, operacion, request, response, exito, mensaje, duracion_ms, created_at, created_by) FROM stdin;
\.


--
-- Data for Name: comprobantes; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.comprobantes (id, empresa_id, tipo, serie, numero, cliente_id, mascota_id, cita_id, consulta_id, caja_id, fecha_emision, fecha_vencimiento, moneda, tipo_cambio, subtotal, descuento_global, igv, total, saldo_pendiente, estado, estado_pago, hash_cpe, xml_url, pdf_url, cdr_url, sunat_codigo, sunat_mensaje, documento_ref_id, motivo_nota, observaciones, anulado_at, created_at, updated_at, deleted_at, created_by, updated_by, pse_request_id, pse_response, enviado_pse_at, aceptado_sunat_at, codigo_tipo_nota) FROM stdin;
7b96ea92-aa2a-4506-8945-040c248d3088	1ba3bd1a-4075-4009-b992-7057472e1e56	boleta	B001	1	2a2f2866-944b-4edb-bd6d-f68cf7f814e6	\N	\N	\N	8c9f5165-375a-495f-be11-4c5257e48d8b	2026-09-20 19:58:52.873138-05	2026-09-20	PEN	\N	50.85	0.00	9.15	60.00	60.00	emitido	pendiente	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N	\N	\N	\N	\N	\N
3f8fac68-eddb-4500-888c-962dfe6801e4	1ba3bd1a-4075-4009-b992-7057472e1e56	boleta	B001	2	2c27a5b1-37e3-467c-82d0-a43adb274a9d	\N	\N	\N	8c9f5165-375a-495f-be11-4c5257e48d8b	2026-09-20 19:58:52.873138-05	2026-09-20	PEN	\N	50.85	0.00	9.15	60.00	0.00	emitido	pagado	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N	\N	\N	\N	\N	\N
9501efd4-ee86-4326-ab23-9f0b0181ed5b	1ba3bd1a-4075-4009-b992-7057472e1e56	boleta	B001	3	2dcfe029-99b2-4667-aa5d-6b3cfabda19f	\N	\N	\N	8c9f5165-375a-495f-be11-4c5257e48d8b	2026-09-20 19:58:52.873138-05	2026-09-20	PEN	\N	50.85	0.00	9.15	60.00	0.00	emitido	pagado	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N	\N	\N	\N	\N	\N
c9bd86fa-b2f8-4452-94f0-182271197847	1ba3bd1a-4075-4009-b992-7057472e1e56	boleta	B001	4	6385d210-351d-4d4c-82a3-c3c57507cdf8	\N	\N	\N	8c9f5165-375a-495f-be11-4c5257e48d8b	2026-09-20 19:58:52.873138-05	2026-09-20	PEN	\N	101.70	0.00	18.30	120.00	0.00	emitido	pagado	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N	\N	\N	\N	\N	\N
3ab77376-6998-4fd8-af0b-50daa227247d	1ba3bd1a-4075-4009-b992-7057472e1e56	boleta	B001	5	8c82237b-e4f3-4b71-b66d-97a616290625	\N	\N	\N	8c9f5165-375a-495f-be11-4c5257e48d8b	2026-09-20 19:58:52.873138-05	2026-09-20	PEN	\N	50.85	0.00	9.15	60.00	0.00	emitido	pagado	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N	\N	\N	\N	\N	\N
b84e97d9-f351-45a9-bad9-281341d87e66	1ba3bd1a-4075-4009-b992-7057472e1e56	boleta	B001	6	976e5703-78d6-41e0-860e-a5f300ebec0e	\N	\N	\N	8c9f5165-375a-495f-be11-4c5257e48d8b	2026-09-20 19:58:52.873138-05	2026-09-20	PEN	\N	50.85	0.00	9.15	60.00	0.00	emitido	pagado	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N	\N	\N	\N	\N	\N
5e951870-3242-4e52-809d-7d4fbb936023	1ba3bd1a-4075-4009-b992-7057472e1e56	boleta	B001	7	a00187d7-281c-4691-8e20-ce62af59ce4e	\N	\N	\N	8c9f5165-375a-495f-be11-4c5257e48d8b	2026-09-20 19:58:52.873138-05	2026-09-20	PEN	\N	50.85	0.00	9.15	60.00	60.00	emitido	pendiente	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N	\N	\N	\N	\N	\N
244181d7-bfdc-4807-a283-a91e051388f6	1ba3bd1a-4075-4009-b992-7057472e1e56	boleta	B001	8	a27a10a9-9bff-4744-bbd4-fc7cff8377e3	\N	\N	\N	8c9f5165-375a-495f-be11-4c5257e48d8b	2026-09-20 19:58:52.873138-05	2026-09-20	PEN	\N	50.85	0.00	9.15	60.00	0.00	emitido	pagado	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N	\N	\N	\N	\N	\N
ac9fb05f-e1ff-4a4b-af73-e2775ca7ca33	1ba3bd1a-4075-4009-b992-7057472e1e56	boleta	B001	9	e282ecd9-0ef4-4730-820a-065589f39268	\N	\N	\N	8c9f5165-375a-495f-be11-4c5257e48d8b	2026-09-20 19:58:52.873138-05	2026-09-20	PEN	\N	50.85	0.00	9.15	60.00	60.00	emitido	pendiente	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N	\N	\N	\N	\N	\N
0ab1acd9-94ad-433b-b998-ff5c8df9cd50	1ba3bd1a-4075-4009-b992-7057472e1e56	boleta	B001	10	e4b74708-4127-4227-8144-7df4d7484c7a	\N	\N	\N	8c9f5165-375a-495f-be11-4c5257e48d8b	2026-09-20 19:58:52.873138-05	2026-09-20	PEN	\N	101.70	0.00	18.30	120.00	0.00	emitido	pagado	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: comunicaciones; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.comunicaciones (id, empresa_id, cliente_id, mascota_id, user_id, tipo, asunto, mensaje, requiere_seguimiento, fecha_seguimiento, fecha, created_at, created_by) FROM stdin;
30059bf6-6c09-4ea4-8777-2cc05534be8e	1ba3bd1a-4075-4009-b992-7057472e1e56	2dcfe029-99b2-4667-aa5d-6b3cfabda19f	\N	9faa05e4-2294-45f4-b7dd-4cadbb84b673	whatsapp	Recordatorio de cita	Se envió recordatorio de la cita programada. El propietario confirmó asistencia.	f	\N	2026-09-19 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N
6e055726-b5b9-4315-b88f-080811d1517a	1ba3bd1a-4075-4009-b992-7057472e1e56	a27a10a9-9bff-4744-bbd4-fc7cff8377e3	\N	9faa05e4-2294-45f4-b7dd-4cadbb84b673	whatsapp	Recordatorio de cita	Se envió recordatorio de la cita programada. El propietario confirmó asistencia.	f	\N	2026-09-19 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N
e64769c3-3410-4eb2-bafc-da11141bcea1	1ba3bd1a-4075-4009-b992-7057472e1e56	a00187d7-281c-4691-8e20-ce62af59ce4e	\N	9faa05e4-2294-45f4-b7dd-4cadbb84b673	whatsapp	Recordatorio de cita	Se envió recordatorio de la cita programada. El propietario confirmó asistencia.	f	\N	2026-09-19 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N
894d7df1-95af-4507-92fe-10c0020d58de	1ba3bd1a-4075-4009-b992-7057472e1e56	2c27a5b1-37e3-467c-82d0-a43adb274a9d	\N	9faa05e4-2294-45f4-b7dd-4cadbb84b673	whatsapp	Recordatorio de cita	Se envió recordatorio de la cita programada. El propietario confirmó asistencia.	f	\N	2026-09-19 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N
fc2e7094-7776-4473-896b-b5560ffa5620	1ba3bd1a-4075-4009-b992-7057472e1e56	e4b74708-4127-4227-8144-7df4d7484c7a	\N	9faa05e4-2294-45f4-b7dd-4cadbb84b673	whatsapp	Recordatorio de cita	Se envió recordatorio de la cita programada. El propietario confirmó asistencia.	f	\N	2026-09-19 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N
\.


--
-- Data for Name: consultas; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.consultas (id, empresa_id, codigo, mascota_id, cliente_id, veterinario_id, cita_id, fecha, motivo, anamnesis, peso_kg, temperatura_c, frecuencia_cardiaca, frecuencia_respiratoria, mucosas, tllc_seg, condicion_corporal, examen_fisico, diagnostico, diagnostico_diferencial, pronostico, plan_terapeutico, prescripcion, indicaciones_casa, proxima_visita, estado, created_at, updated_at, deleted_at, created_by, updated_by) FROM stdin;
7d8f9f37-6998-4093-b279-01f32bf2b1ff	1ba3bd1a-4075-4009-b992-7057472e1e56	CON-000001	b4cbd8de-2439-4495-bd52-7c03a6bee07e	e4b74708-4127-4227-8144-7df4d7484c7a	419047f7-804f-4e15-90ca-276e3a463644	719832b2-21bc-424f-b04f-9002eefecd21	2026-09-18 10:35:00-05	Decaimiento y falta de apetito	El propietario refiere el cuadro desde hace 2 días.	28.40	38.1	91	21	rosadas	\N	5	Paciente alerta, hidratado. Auscultación cardiopulmonar sin hallazgos relevantes.	Dermatitis alérgica	\N	\N	Tratamiento sintomático y control en 7 días.	\N	Dieta blanda por 3 días. Regresar si el cuadro empeora.	\N	cerrada	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N	419047f7-804f-4e15-90ca-276e3a463644	\N
bb1c5d85-6d73-4661-9b52-0a63cf55bb6d	1ba3bd1a-4075-4009-b992-7057472e1e56	CON-000002	7035d850-c693-4743-880f-d1725c46e17c	e4b74708-4127-4227-8144-7df4d7484c7a	5dc67c3d-1666-4a68-8cb5-489997a6bf08	7cac4a3c-9e6e-4f3d-bb79-195f2d030dcc	2026-09-17 11:10:00-05	Vómitos desde ayer	El propietario refiere el cuadro desde hace 3 días.	4.80	38.2	92	22	rosadas	\N	6	Paciente alerta, hidratado. Auscultación cardiopulmonar sin hallazgos relevantes.	Sano — control preventivo	\N	\N	Tratamiento sintomático y control en 7 días.	\N	Dieta blanda por 3 días. Regresar si el cuadro empeora.	\N	cerrada	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N	5dc67c3d-1666-4a68-8cb5-489997a6bf08	\N
a044cd96-9aff-4485-83a0-77bd77662820	1ba3bd1a-4075-4009-b992-7057472e1e56	CON-000003	43509380-78ff-488d-8590-7346e7769aa0	a27a10a9-9bff-4744-bbd4-fc7cff8377e3	419047f7-804f-4e15-90ca-276e3a463644	3f5a2894-7aea-41c7-bf23-72f7cdb4cc4b	2026-09-16 11:45:00-05	Chequeo preventivo	El propietario refiere el cuadro desde hace 4 días.	12.10	38.3	93	23	rosadas	\N	4	Paciente alerta, hidratado. Auscultación cardiopulmonar sin hallazgos relevantes.	Otitis externa	\N	\N	Tratamiento sintomático y control en 7 días.	\N	Dieta blanda por 3 días. Regresar si el cuadro empeora.	\N	cerrada	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N	419047f7-804f-4e15-90ca-276e3a463644	\N
aacc8ba9-d826-4d3e-b9f9-9756da527594	1ba3bd1a-4075-4009-b992-7057472e1e56	CON-000004	2ab9d0d1-f0e0-45e0-87b0-b7037c9942fa	2c27a5b1-37e3-467c-82d0-a43adb274a9d	5dc67c3d-1666-4a68-8cb5-489997a6bf08	4f6b7ca5-7d46-4fd8-b35f-2ccfda909d70	2026-09-15 12:20:00-05	Cojera de miembro posterior	El propietario refiere el cuadro desde hace 1 días.	18.70	38.4	94	24	rosadas	\N	5	Paciente alerta, hidratado. Auscultación cardiopulmonar sin hallazgos relevantes.	Contusión de miembro posterior	\N	\N	Tratamiento sintomático y control en 7 días.	\N	Dieta blanda por 3 días. Regresar si el cuadro empeora.	\N	cerrada	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N	5dc67c3d-1666-4a68-8cb5-489997a6bf08	\N
bbe65666-df5b-4edd-adc9-3cf4736e8b68	1ba3bd1a-4075-4009-b992-7057472e1e56	CON-000005	e485ee0b-d6f9-4052-ba2f-2e63f3f1fd76	2dcfe029-99b2-4667-aa5d-6b3cfabda19f	419047f7-804f-4e15-90ca-276e3a463644	268e2cb4-ce58-4b8d-88ba-b1f5972d41ad	2026-09-19 12:55:00-05	Revisión de piel	El propietario refiere el cuadro desde hace 2 días.	34.20	38.5	95	25	rosadas	\N	6	Paciente alerta, hidratado. Auscultación cardiopulmonar sin hallazgos relevantes.	Sobrepeso grado 2	\N	\N	Tratamiento sintomático y control en 7 días.	\N	Dieta blanda por 3 días. Regresar si el cuadro empeora.	\N	cerrada	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N	419047f7-804f-4e15-90ca-276e3a463644	\N
7f8840fc-d591-415d-b171-cd1540efd22f	1ba3bd1a-4075-4009-b992-7057472e1e56	CON-000006	7a2e7560-c4a8-4f72-accd-6b64967fab66	e282ecd9-0ef4-4730-820a-065589f39268	5dc67c3d-1666-4a68-8cb5-489997a6bf08	f52590e8-a35b-4b31-a58f-6533a3904e5a	2026-09-18 13:30:00-05	Control anual	El propietario refiere el cuadro desde hace 3 días.	3.60	38.6	96	26	rosadas	\N	4	Paciente alerta, hidratado. Auscultación cardiopulmonar sin hallazgos relevantes.	Gastroenteritis leve	\N	\N	Tratamiento sintomático y control en 7 días.	\N	Dieta blanda por 3 días. Regresar si el cuadro empeora.	\N	cerrada	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N	5dc67c3d-1666-4a68-8cb5-489997a6bf08	\N
95ec86f8-fe2d-462d-b40a-bec91a6e00cc	1ba3bd1a-4075-4009-b992-7057472e1e56	CON-000007	cbbced34-52c2-45d5-adf1-e96954285557	a00187d7-281c-4691-8e20-ce62af59ce4e	419047f7-804f-4e15-90ca-276e3a463644	33dc6def-9f84-452d-a89b-d22f61b65583	2026-09-17 14:05:00-05	Decaimiento y falta de apetito	El propietario refiere el cuadro desde hace 4 días.	6.30	38.7	97	27	rosadas	\N	5	Paciente alerta, hidratado. Auscultación cardiopulmonar sin hallazgos relevantes.	Dermatitis alérgica	\N	\N	Tratamiento sintomático y control en 7 días.	\N	Dieta blanda por 3 días. Regresar si el cuadro empeora.	\N	cerrada	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N	419047f7-804f-4e15-90ca-276e3a463644	\N
57e65017-8dec-4fbc-b23d-5fc393974c70	1ba3bd1a-4075-4009-b992-7057472e1e56	CON-000008	6818d890-9824-4de4-8ce5-4e7084079e8e	2a2f2866-944b-4edb-bd6d-f68cf7f814e6	5dc67c3d-1666-4a68-8cb5-489997a6bf08	5ddabc0c-bc98-4ec2-8238-e3f68b22099d	2026-09-16 14:40:00-05	Vómitos desde ayer	El propietario refiere el cuadro desde hace 1 días.	5.10	38.8	98	28	rosadas	\N	6	Paciente alerta, hidratado. Auscultación cardiopulmonar sin hallazgos relevantes.	Sano — control preventivo	\N	\N	Tratamiento sintomático y control en 7 días.	\N	Dieta blanda por 3 días. Regresar si el cuadro empeora.	\N	cerrada	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N	5dc67c3d-1666-4a68-8cb5-489997a6bf08	\N
86cf4a68-2368-4766-97d8-c162d5f0a004	1ba3bd1a-4075-4009-b992-7057472e1e56	CON-000009	b7b98cfc-fff1-4d55-afb3-9f3c03cd431a	6385d210-351d-4d4c-82a3-c3c57507cdf8	419047f7-804f-4e15-90ca-276e3a463644	e22fc738-f9ce-49a9-be74-6c5399483633	2026-09-15 15:15:00-05	Chequeo preventivo	El propietario refiere el cuadro desde hace 2 días.	21.50	38.9	99	29	rosadas	\N	4	Paciente alerta, hidratado. Auscultación cardiopulmonar sin hallazgos relevantes.	Otitis externa	\N	\N	Tratamiento sintomático y control en 7 días.	\N	Dieta blanda por 3 días. Regresar si el cuadro empeora.	\N	cerrada	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N	419047f7-804f-4e15-90ca-276e3a463644	\N
82caad5b-71a7-4543-a370-f9f6284138c2	1ba3bd1a-4075-4009-b992-7057472e1e56	CON-000010	8faa65e3-0f52-48a8-940e-11f261b0b78c	6385d210-351d-4d4c-82a3-c3c57507cdf8	5dc67c3d-1666-4a68-8cb5-489997a6bf08	2cdaa77b-278b-435b-b1e1-5c86bb19430c	2026-09-19 15:50:00-05	Cojera de miembro posterior	El propietario refiere el cuadro desde hace 3 días.	14.80	39.0	100	30	rosadas	\N	5	Paciente alerta, hidratado. Auscultación cardiopulmonar sin hallazgos relevantes.	Contusión de miembro posterior	\N	\N	Tratamiento sintomático y control en 7 días.	\N	Dieta blanda por 3 días. Regresar si el cuadro empeora.	\N	cerrada	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N	5dc67c3d-1666-4a68-8cb5-489997a6bf08	\N
23d274c1-92fa-41bc-98af-4291409acafa	1ba3bd1a-4075-4009-b992-7057472e1e56	CON-000011	7da7fd75-767c-4176-ac1a-3396c31a2eba	976e5703-78d6-41e0-860e-a5f300ebec0e	419047f7-804f-4e15-90ca-276e3a463644	c838f213-73c7-4aa1-a1b4-81dfda816a67	2026-09-18 16:25:00-05	Revisión de piel	El propietario refiere el cuadro desde hace 4 días.	22.90	39.1	101	31	rosadas	\N	6	Paciente alerta, hidratado. Auscultación cardiopulmonar sin hallazgos relevantes.	Sobrepeso grado 2	\N	\N	Tratamiento sintomático y control en 7 días.	\N	Dieta blanda por 3 días. Regresar si el cuadro empeora.	\N	cerrada	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N	419047f7-804f-4e15-90ca-276e3a463644	\N
c6af74b9-b1ab-441b-b498-74a1e8650e75	1ba3bd1a-4075-4009-b992-7057472e1e56	CON-000012	a7b2f548-685d-43f6-ba66-77776a0ed1f5	8c82237b-e4f3-4b71-b66d-97a616290625	5dc67c3d-1666-4a68-8cb5-489997a6bf08	50c99593-7163-4af9-9218-d139b4b5dcec	2026-09-17 17:00:00-05	Control anual	El propietario refiere el cuadro desde hace 1 días.	4.20	38.0	102	32	rosadas	\N	4	Paciente alerta, hidratado. Auscultación cardiopulmonar sin hallazgos relevantes.	Gastroenteritis leve	\N	\N	Tratamiento sintomático y control en 7 días.	\N	Dieta blanda por 3 días. Regresar si el cuadro empeora.	\N	cerrada	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N	5dc67c3d-1666-4a68-8cb5-489997a6bf08	\N
\.


--
-- Data for Name: consultorios; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.consultorios (id, empresa_id, nombre, tipo, capacidad, estado, created_at, updated_at) FROM stdin;
8ed63944-dd81-4213-838a-0faf8cbbc9e5	1ba3bd1a-4075-4009-b992-7057472e1e56	Consultorio 1	consulta	1	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05
a18e235e-9290-4071-9f1f-6003d1822e84	1ba3bd1a-4075-4009-b992-7057472e1e56	Consultorio 2	consulta	1	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05
28f41900-e18e-4a4b-928e-8b7ab72b4485	1ba3bd1a-4075-4009-b992-7057472e1e56	Quirófano	quirofano	1	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05
580f2672-163a-4a82-913c-30d6bd5fc9f4	1ba3bd1a-4075-4009-b992-7057472e1e56	Hospitalización	hospitalizacion	1	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05
caf1e08b-9fc0-41a3-b987-8dfc23dffdff	1ba3bd1a-4075-4009-b992-7057472e1e56	Sala de grooming	grooming	1	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05
53ac640f-dbd6-4851-a435-5f07cca004df	a64719a9-57fc-4ac0-b104-b9d861370dc7	Consultorio 1	consulta	1	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05
64b27817-77b7-4898-bda0-8e4e1abbd7b1	a64719a9-57fc-4ac0-b104-b9d861370dc7	Consultorio 2	consulta	1	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05
\.


--
-- Data for Name: contratos_personal; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.contratos_personal (id, empresa_id, user_id, tipo, cargo, fecha_inicio, fecha_fin, salario, moneda, documento_url, vigente, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: correlativos; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.correlativos (empresa_id, tipo_documento, serie, ultimo_numero, updated_at) FROM stdin;
1ba3bd1a-4075-4009-b992-7057472e1e56	CLI	0001	10	2026-09-20 19:58:52.873138-05
1ba3bd1a-4075-4009-b992-7057472e1e56	HC	0001	12	2026-09-20 19:58:52.873138-05
1ba3bd1a-4075-4009-b992-7057472e1e56	CON	0001	12	2026-09-20 19:58:52.873138-05
1ba3bd1a-4075-4009-b992-7057472e1e56	OS	0001	12	2026-09-20 19:58:52.873138-05
1ba3bd1a-4075-4009-b992-7057472e1e56	CIT	0001	24	2026-09-20 19:58:52.873138-05
1ba3bd1a-4075-4009-b992-7057472e1e56	HOSP	0001	1	2026-09-20 19:58:52.873138-05
1ba3bd1a-4075-4009-b992-7057472e1e56	CIR	0001	1	2026-09-20 19:58:52.873138-05
1ba3bd1a-4075-4009-b992-7057472e1e56	CAJA	0001	1	2026-09-20 19:58:52.873138-05
1ba3bd1a-4075-4009-b992-7057472e1e56	boleta	B001	10	2026-09-20 19:58:52.873138-05
1ba3bd1a-4075-4009-b992-7057472e1e56	PAG	0001	7	2026-09-20 19:58:52.873138-05
a64719a9-57fc-4ac0-b104-b9d861370dc7	CLI	0001	3	2026-09-20 19:58:52.873138-05
a64719a9-57fc-4ac0-b104-b9d861370dc7	HC	0001	3	2026-09-20 19:58:52.873138-05
\.


--
-- Data for Name: desparasitaciones; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.desparasitaciones (id, empresa_id, mascota_id, veterinario_id, consulta_id, producto_id, producto_nombre, tipo, dosis, fecha_aplicacion, proxima_dosis, observaciones, created_at, created_by) FROM stdin;
\.


--
-- Data for Name: disponibilidad; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.disponibilidad (id, empresa_id, user_id, fecha, hora_inicio, hora_fin, tipo, consultorio_id, nota, created_at, updated_at, permiso_id) FROM stdin;
1b578776-08ff-4152-b7d2-c8b86c6db6ac	1ba3bd1a-4075-4009-b992-7057472e1e56	5dc67c3d-1666-4a68-8cb5-489997a6bf08	2026-09-21	09:00:00	18:00:00	laboral	\N	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N
5b677905-c940-4183-8029-1e896b941eeb	1ba3bd1a-4075-4009-b992-7057472e1e56	5dc67c3d-1666-4a68-8cb5-489997a6bf08	2026-09-22	09:00:00	18:00:00	laboral	\N	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N
947c0e4c-5fab-490f-a352-3766358a3a8a	1ba3bd1a-4075-4009-b992-7057472e1e56	5dc67c3d-1666-4a68-8cb5-489997a6bf08	2026-09-23	09:00:00	18:00:00	laboral	\N	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N
ddde09f1-0993-47bb-a931-0b39e34405ce	1ba3bd1a-4075-4009-b992-7057472e1e56	5dc67c3d-1666-4a68-8cb5-489997a6bf08	2026-09-24	09:00:00	18:00:00	laboral	\N	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N
f6261119-fc48-46fa-9fbd-e6bfcd5ef87c	1ba3bd1a-4075-4009-b992-7057472e1e56	5dc67c3d-1666-4a68-8cb5-489997a6bf08	2026-09-25	09:00:00	18:00:00	laboral	\N	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N
85d5f823-e1f5-4885-abf0-b51c2bc9d49e	1ba3bd1a-4075-4009-b992-7057472e1e56	5dc67c3d-1666-4a68-8cb5-489997a6bf08	2026-09-26	09:00:00	18:00:00	laboral	\N	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N
5212ce0a-43da-4eb2-a94a-d5ef773e65bc	1ba3bd1a-4075-4009-b992-7057472e1e56	5dc67c3d-1666-4a68-8cb5-489997a6bf08	2026-09-28	09:00:00	18:00:00	laboral	\N	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N
becb878e-2727-4006-976f-6de1a23afc02	1ba3bd1a-4075-4009-b992-7057472e1e56	5dc67c3d-1666-4a68-8cb5-489997a6bf08	2026-09-29	09:00:00	18:00:00	laboral	\N	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N
90e1c44f-e509-428e-b1b9-a28706afbb93	1ba3bd1a-4075-4009-b992-7057472e1e56	5dc67c3d-1666-4a68-8cb5-489997a6bf08	2026-09-30	09:00:00	18:00:00	laboral	\N	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N
3c4a0373-d799-4594-8eb2-6dacb8e964a3	1ba3bd1a-4075-4009-b992-7057472e1e56	5dc67c3d-1666-4a68-8cb5-489997a6bf08	2026-10-01	09:00:00	18:00:00	laboral	\N	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N
6b005e2e-2c9b-4e7a-a353-ec9f654ce0e2	1ba3bd1a-4075-4009-b992-7057472e1e56	5dc67c3d-1666-4a68-8cb5-489997a6bf08	2026-10-02	09:00:00	18:00:00	laboral	\N	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N
16a65862-3069-4b7e-97cb-362c2ada2b00	1ba3bd1a-4075-4009-b992-7057472e1e56	5dc67c3d-1666-4a68-8cb5-489997a6bf08	2026-10-03	09:00:00	18:00:00	laboral	\N	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N
7bbb4df5-cdc2-4f24-8d66-c1ae35ef62fe	1ba3bd1a-4075-4009-b992-7057472e1e56	419047f7-804f-4e15-90ca-276e3a463644	2026-09-21	09:00:00	18:00:00	laboral	\N	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N
016678e8-f01c-4a1f-a2bd-c595a697acb0	1ba3bd1a-4075-4009-b992-7057472e1e56	419047f7-804f-4e15-90ca-276e3a463644	2026-09-22	09:00:00	18:00:00	laboral	\N	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N
6a69cbb7-766b-4a30-8c11-87422234e16c	1ba3bd1a-4075-4009-b992-7057472e1e56	419047f7-804f-4e15-90ca-276e3a463644	2026-09-23	09:00:00	18:00:00	laboral	\N	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N
09318256-053b-40d8-9dd8-5661a62865de	1ba3bd1a-4075-4009-b992-7057472e1e56	419047f7-804f-4e15-90ca-276e3a463644	2026-09-24	09:00:00	18:00:00	laboral	\N	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N
33ef32ff-9b78-4411-96a9-98e4d333c737	1ba3bd1a-4075-4009-b992-7057472e1e56	419047f7-804f-4e15-90ca-276e3a463644	2026-09-25	09:00:00	18:00:00	laboral	\N	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N
a3e2731b-d682-49d5-9437-7c43817fe787	1ba3bd1a-4075-4009-b992-7057472e1e56	419047f7-804f-4e15-90ca-276e3a463644	2026-09-26	09:00:00	18:00:00	laboral	\N	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N
31ddea81-51af-46c8-a4b1-f5227f102183	1ba3bd1a-4075-4009-b992-7057472e1e56	419047f7-804f-4e15-90ca-276e3a463644	2026-09-28	09:00:00	18:00:00	laboral	\N	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N
63166cdb-dbc4-4361-bc84-ed282bcce84c	1ba3bd1a-4075-4009-b992-7057472e1e56	419047f7-804f-4e15-90ca-276e3a463644	2026-09-29	09:00:00	18:00:00	laboral	\N	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N
5a6c8715-7c5b-4872-a35a-9664aa4522fd	1ba3bd1a-4075-4009-b992-7057472e1e56	419047f7-804f-4e15-90ca-276e3a463644	2026-09-30	09:00:00	18:00:00	laboral	\N	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N
73273b15-7c90-420d-b978-858f7efdd9af	1ba3bd1a-4075-4009-b992-7057472e1e56	419047f7-804f-4e15-90ca-276e3a463644	2026-10-01	09:00:00	18:00:00	laboral	\N	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N
99400008-77cd-4b7f-bf6f-1dff7cb30d7c	1ba3bd1a-4075-4009-b992-7057472e1e56	419047f7-804f-4e15-90ca-276e3a463644	2026-10-02	09:00:00	18:00:00	laboral	\N	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N
44afe1dd-e627-4e04-8903-e06cac9ac40a	1ba3bd1a-4075-4009-b992-7057472e1e56	419047f7-804f-4e15-90ca-276e3a463644	2026-10-03	09:00:00	18:00:00	laboral	\N	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N
\.


--
-- Data for Name: documentos_medicos; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.documentos_medicos (id, empresa_id, mascota_id, consulta_id, tipo, titulo, descripcion, storage_key, mime_type, tamanio_bytes, created_at, created_by) FROM stdin;
\.


--
-- Data for Name: empresas; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.empresas (id, ruc, razon_social, nombre_comercial, direccion_fiscal, ubigeo, telefono, correo, logo_url, pse_endpoint, pse_usuario, pse_password_enc, serie_factura_default, serie_boleta_default, serie_nota_venta_default, igv_tasa, moneda_default, aforo_consultorios, duracion_cita_min, estado, created_at, updated_at, deleted_at, created_by, updated_by, emite_electronico, pse_proveedor, pse_ruc, urbanizacion, distrito, provincia, departamento, serie_nota_credito_default) FROM stdin;
1ba3bd1a-4075-4009-b992-7057472e1e56	20601234567	Clínica Veterinaria Patitas S.A.C.	Vet Patitas	Av. Larco 1234, Miraflores	150122	014455667	contacto@vetpatitas.pe	\N	\N	\N	\N	F001	B001	NV01	0.1800	PEN	3	30	activa	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	\N	\N	\N	f	the_factory_hka	\N	\N	\N	\N	\N	\N
a64719a9-57fc-4ac0-b104-b9d861370dc7	20609876543	Centro Veterinario Huellitas E.I.R.L.	Vet Huellitas	Av. Javier Prado Este 456, San Isidro	150131	014455668	contacto@vethuellitas.pe	\N	\N	\N	\N	F002	B002	\N	0.1800	PEN	2	30	activa	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	\N	\N	\N	f	the_factory_hka	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: especializaciones; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.especializaciones (id, codigo, nombre, descripcion, estado, created_at, updated_at) FROM stdin;
7edd3986-a10a-4e08-b1f4-12a809c0e8d9	MEDICINA_GENERAL	Medicina general	Consulta y medicina preventiva	activo	2026-09-20 19:58:52.280758-05	2026-09-20 19:58:52.280758-05
74d234f9-2fe3-4519-9459-799249d1d0b1	CIRUGIA	Cirugía	Cirugía de tejidos blandos y ortopedia	activo	2026-09-20 19:58:52.280758-05	2026-09-20 19:58:52.280758-05
2a0e256e-fa1c-4355-9a45-646bc88023a8	DERMATOLOGIA	Dermatología	Enfermedades de piel y anexos	activo	2026-09-20 19:58:52.280758-05	2026-09-20 19:58:52.280758-05
f817d0f8-186c-4e70-9992-e10654b1c000	CARDIOLOGIA	Cardiología	Enfermedades cardiovasculares	activo	2026-09-20 19:58:52.280758-05	2026-09-20 19:58:52.280758-05
f45c82ae-471b-48fe-9988-765292ea1605	ODONTOLOGIA	Odontología	Salud bucal y profilaxis dental	activo	2026-09-20 19:58:52.280758-05	2026-09-20 19:58:52.280758-05
a9b78832-9569-454a-893c-4dd3d283d403	OFTALMOLOGIA	Oftalmología	Enfermedades oculares	activo	2026-09-20 19:58:52.280758-05	2026-09-20 19:58:52.280758-05
5060d68e-63fa-424d-9594-c19532642b0a	TRAUMATOLOGIA	Traumatología	Lesiones óseas y articulares	activo	2026-09-20 19:58:52.280758-05	2026-09-20 19:58:52.280758-05
e334c1bd-e839-4c1d-9a5c-f6bf78ef36f3	EXOTICOS	Animales exóticos	Aves, reptiles y pequeños mamíferos	activo	2026-09-20 19:58:52.280758-05	2026-09-20 19:58:52.280758-05
e3d39db0-17da-4ff8-9acc-7cbbecd6e0ee	IMAGENOLOGIA	Diagnóstico por imagen	Radiografía y ecografía	activo	2026-09-20 19:58:52.280758-05	2026-09-20 19:58:52.280758-05
\.


--
-- Data for Name: especies; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.especies (id, codigo, nombre, nombre_cria, icono, estado, created_at, updated_at) FROM stdin;
ea82e665-7d26-4287-8e61-a6b786b8a5df	CANINO	Canino	Cachorro	Dog	activo	2026-09-20 19:58:52.282417-05	2026-09-20 19:58:52.282417-05
2e253998-3b20-42b9-a228-a5cb7ddc3394	FELINO	Felino	Gatito	Cat	activo	2026-09-20 19:58:52.282417-05	2026-09-20 19:58:52.282417-05
522afbf5-2d53-4c55-969b-9ed9d6fb36b2	AVE	Ave	Polluelo	Bird	activo	2026-09-20 19:58:52.282417-05	2026-09-20 19:58:52.282417-05
ff5ae48c-b35a-4606-84a6-65e6a602e2eb	ROEDOR	Roedor	Cría	Rat	activo	2026-09-20 19:58:52.282417-05	2026-09-20 19:58:52.282417-05
4909f69d-4881-4bf7-9b29-bb3d62406f73	CONEJO	Conejo	Gazapo	Rabbit	activo	2026-09-20 19:58:52.282417-05	2026-09-20 19:58:52.282417-05
fe404847-62bc-4aeb-adfd-2dbf7e4986f1	REPTIL	Reptil	Cría	Turtle	activo	2026-09-20 19:58:52.282417-05	2026-09-20 19:58:52.282417-05
9aa7534f-f625-4480-b4c8-3680be6a8da1	EQUINO	Equino	Potrillo	Rabbit	activo	2026-09-20 19:58:52.282417-05	2026-09-20 19:58:52.282417-05
5dc2f89d-d3ce-476a-90b6-814289b69648	OTRO	Otro	Cría	PawPrint	activo	2026-09-20 19:58:52.282417-05	2026-09-20 19:58:52.282417-05
\.


--
-- Data for Name: esquemas_vacunacion; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.esquemas_vacunacion (id, empresa_id, especie_id, nombre, descripcion, obligatoria, edad_inicio_semanas, intervalo_dias, dosis_totales, revacunacion_meses, estado, created_at, updated_at) FROM stdin;
f1b8afca-32f2-46d2-ae83-a82477f3396c	1ba3bd1a-4075-4009-b992-7057472e1e56	ea82e665-7d26-4287-8e61-a6b786b8a5df	Antirrábica canina	Obligatoria por normativa	t	12	365	1	12	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05
965f3439-10b1-4d16-acbe-4a9507db9231	1ba3bd1a-4075-4009-b992-7057472e1e56	ea82e665-7d26-4287-8e61-a6b786b8a5df	Quíntuple canina	Moquillo, parvovirus, hepatitis…	t	6	21	3	12	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05
e1359ae0-56a5-450b-a6bc-b4040f9dcb97	1ba3bd1a-4075-4009-b992-7057472e1e56	ea82e665-7d26-4287-8e61-a6b786b8a5df	Tos de las perreras	Bordetella bronchiseptica	f	12	365	1	12	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05
fee09040-d41d-4f43-80ce-9f54499e8f34	1ba3bd1a-4075-4009-b992-7057472e1e56	2e253998-3b20-42b9-a228-a5cb7ddc3394	Antirrábica felina	Obligatoria por normativa	t	12	365	1	12	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05
b5794fc8-50ec-4466-8379-ed0f31e46ca1	1ba3bd1a-4075-4009-b992-7057472e1e56	2e253998-3b20-42b9-a228-a5cb7ddc3394	Triple felina	Rinotraqueítis, calicivirus, panleuc.	t	8	21	2	12	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05
f312521e-684c-4f4b-977a-63b8bd702201	1ba3bd1a-4075-4009-b992-7057472e1e56	2e253998-3b20-42b9-a228-a5cb7ddc3394	Leucemia felina	Previa prueba de descarte	f	9	21	2	12	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05
\.


--
-- Data for Name: evaluaciones_personal; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.evaluaciones_personal (id, empresa_id, user_id, evaluador_id, periodo, fecha, puntualidad, eficiencia, calidad_atencion, trabajo_equipo, promedio, observaciones, created_at) FROM stdin;
\.


--
-- Data for Name: examenes; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.examenes (id, empresa_id, mascota_id, consulta_id, servicio_id, veterinario_id, tipo, nombre, fecha_solicitud, fecha_resultado, resultado, valores, interpretacion, archivo_url, created_at, created_by) FROM stdin;
\.


--
-- Data for Name: historia_clinica; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.historia_clinica (id, empresa_id, mascota_id, cliente_id, veterinario_id, cita_id, tipo_evento, fecha, titulo, resumen, entidad_id, created_at, created_by) FROM stdin;
1ee810b5-2efb-4b4d-a89a-c3f0eea7ecbd	1ba3bd1a-4075-4009-b992-7057472e1e56	b4cbd8de-2439-4495-bd52-7c03a6bee07e	e4b74708-4127-4227-8144-7df4d7484c7a	419047f7-804f-4e15-90ca-276e3a463644	719832b2-21bc-424f-b04f-9002eefecd21	consulta	2026-09-18 10:35:00-05	Consulta: Decaimiento y falta de apetito	Dermatitis alérgica	7d8f9f37-6998-4093-b279-01f32bf2b1ff	2026-09-20 19:58:52.873138-05	419047f7-804f-4e15-90ca-276e3a463644
f2137639-da8f-4afe-a584-070b746be7cf	1ba3bd1a-4075-4009-b992-7057472e1e56	b4cbd8de-2439-4495-bd52-7c03a6bee07e	e4b74708-4127-4227-8144-7df4d7484c7a	5dc67c3d-1666-4a68-8cb5-489997a6bf08	719832b2-21bc-424f-b04f-9002eefecd21	vacuna	2026-09-18 10:35:00-05	Vacuna: Antirrábica	Próximo refuerzo en 12 meses	\N	2026-09-20 19:58:52.873138-05	5dc67c3d-1666-4a68-8cb5-489997a6bf08
4d4c513a-62e5-4a02-84ca-2956fc99c83c	1ba3bd1a-4075-4009-b992-7057472e1e56	7035d850-c693-4743-880f-d1725c46e17c	e4b74708-4127-4227-8144-7df4d7484c7a	5dc67c3d-1666-4a68-8cb5-489997a6bf08	7cac4a3c-9e6e-4f3d-bb79-195f2d030dcc	consulta	2026-09-17 11:10:00-05	Consulta: Vómitos desde ayer	Sano — control preventivo	bb1c5d85-6d73-4661-9b52-0a63cf55bb6d	2026-09-20 19:58:52.873138-05	5dc67c3d-1666-4a68-8cb5-489997a6bf08
39b569ba-2f62-4149-b32e-3d24c0abf094	1ba3bd1a-4075-4009-b992-7057472e1e56	43509380-78ff-488d-8590-7346e7769aa0	a27a10a9-9bff-4744-bbd4-fc7cff8377e3	419047f7-804f-4e15-90ca-276e3a463644	3f5a2894-7aea-41c7-bf23-72f7cdb4cc4b	consulta	2026-09-16 11:45:00-05	Consulta: Chequeo preventivo	Otitis externa	a044cd96-9aff-4485-83a0-77bd77662820	2026-09-20 19:58:52.873138-05	419047f7-804f-4e15-90ca-276e3a463644
1ba313a0-fd7a-41d1-8245-b89331fb67bb	1ba3bd1a-4075-4009-b992-7057472e1e56	43509380-78ff-488d-8590-7346e7769aa0	a27a10a9-9bff-4744-bbd4-fc7cff8377e3	5dc67c3d-1666-4a68-8cb5-489997a6bf08	3f5a2894-7aea-41c7-bf23-72f7cdb4cc4b	vacuna	2026-09-16 11:45:00-05	Vacuna: Quíntuple canina	Próximo refuerzo en 12 meses	\N	2026-09-20 19:58:52.873138-05	5dc67c3d-1666-4a68-8cb5-489997a6bf08
2ac338ed-0a29-4e04-bc46-6d371fd37d8e	1ba3bd1a-4075-4009-b992-7057472e1e56	2ab9d0d1-f0e0-45e0-87b0-b7037c9942fa	2c27a5b1-37e3-467c-82d0-a43adb274a9d	5dc67c3d-1666-4a68-8cb5-489997a6bf08	4f6b7ca5-7d46-4fd8-b35f-2ccfda909d70	consulta	2026-09-15 12:20:00-05	Consulta: Cojera de miembro posterior	Contusión de miembro posterior	aacc8ba9-d826-4d3e-b9f9-9756da527594	2026-09-20 19:58:52.873138-05	5dc67c3d-1666-4a68-8cb5-489997a6bf08
587db50a-e106-45d1-b2f4-0937905ec250	1ba3bd1a-4075-4009-b992-7057472e1e56	e485ee0b-d6f9-4052-ba2f-2e63f3f1fd76	2dcfe029-99b2-4667-aa5d-6b3cfabda19f	419047f7-804f-4e15-90ca-276e3a463644	268e2cb4-ce58-4b8d-88ba-b1f5972d41ad	consulta	2026-09-19 12:55:00-05	Consulta: Revisión de piel	Sobrepeso grado 2	bbe65666-df5b-4edd-adc9-3cf4736e8b68	2026-09-20 19:58:52.873138-05	419047f7-804f-4e15-90ca-276e3a463644
6485c1d5-cf9c-4bbe-b4c8-397ec6a2a3da	1ba3bd1a-4075-4009-b992-7057472e1e56	e485ee0b-d6f9-4052-ba2f-2e63f3f1fd76	2dcfe029-99b2-4667-aa5d-6b3cfabda19f	5dc67c3d-1666-4a68-8cb5-489997a6bf08	268e2cb4-ce58-4b8d-88ba-b1f5972d41ad	vacuna	2026-09-19 12:55:00-05	Vacuna: Antirrábica	Próximo refuerzo en 12 meses	\N	2026-09-20 19:58:52.873138-05	5dc67c3d-1666-4a68-8cb5-489997a6bf08
a4481b04-ee4b-4fbe-a8aa-c7d06274fc83	1ba3bd1a-4075-4009-b992-7057472e1e56	7a2e7560-c4a8-4f72-accd-6b64967fab66	e282ecd9-0ef4-4730-820a-065589f39268	5dc67c3d-1666-4a68-8cb5-489997a6bf08	f52590e8-a35b-4b31-a58f-6533a3904e5a	consulta	2026-09-18 13:30:00-05	Consulta: Control anual	Gastroenteritis leve	7f8840fc-d591-415d-b171-cd1540efd22f	2026-09-20 19:58:52.873138-05	5dc67c3d-1666-4a68-8cb5-489997a6bf08
bef7ac66-eb6f-41fb-8632-b578981a0206	1ba3bd1a-4075-4009-b992-7057472e1e56	cbbced34-52c2-45d5-adf1-e96954285557	a00187d7-281c-4691-8e20-ce62af59ce4e	419047f7-804f-4e15-90ca-276e3a463644	33dc6def-9f84-452d-a89b-d22f61b65583	consulta	2026-09-17 14:05:00-05	Consulta: Decaimiento y falta de apetito	Dermatitis alérgica	95ec86f8-fe2d-462d-b40a-bec91a6e00cc	2026-09-20 19:58:52.873138-05	419047f7-804f-4e15-90ca-276e3a463644
ae9c7d66-52f3-4439-a1af-5e14cb1fb9ae	1ba3bd1a-4075-4009-b992-7057472e1e56	cbbced34-52c2-45d5-adf1-e96954285557	a00187d7-281c-4691-8e20-ce62af59ce4e	5dc67c3d-1666-4a68-8cb5-489997a6bf08	33dc6def-9f84-452d-a89b-d22f61b65583	vacuna	2026-09-17 14:05:00-05	Vacuna: Quíntuple canina	Próximo refuerzo en 12 meses	\N	2026-09-20 19:58:52.873138-05	5dc67c3d-1666-4a68-8cb5-489997a6bf08
ff682590-a0f4-47d8-b1f8-1628e8834597	1ba3bd1a-4075-4009-b992-7057472e1e56	6818d890-9824-4de4-8ce5-4e7084079e8e	2a2f2866-944b-4edb-bd6d-f68cf7f814e6	5dc67c3d-1666-4a68-8cb5-489997a6bf08	5ddabc0c-bc98-4ec2-8238-e3f68b22099d	consulta	2026-09-16 14:40:00-05	Consulta: Vómitos desde ayer	Sano — control preventivo	57e65017-8dec-4fbc-b23d-5fc393974c70	2026-09-20 19:58:52.873138-05	5dc67c3d-1666-4a68-8cb5-489997a6bf08
22b94dad-a465-4bc3-a6a6-c4288351d72c	1ba3bd1a-4075-4009-b992-7057472e1e56	b7b98cfc-fff1-4d55-afb3-9f3c03cd431a	6385d210-351d-4d4c-82a3-c3c57507cdf8	419047f7-804f-4e15-90ca-276e3a463644	e22fc738-f9ce-49a9-be74-6c5399483633	consulta	2026-09-15 15:15:00-05	Consulta: Chequeo preventivo	Otitis externa	86cf4a68-2368-4766-97d8-c162d5f0a004	2026-09-20 19:58:52.873138-05	419047f7-804f-4e15-90ca-276e3a463644
907be0e3-2264-4278-b0af-34e9ac20bd01	1ba3bd1a-4075-4009-b992-7057472e1e56	b7b98cfc-fff1-4d55-afb3-9f3c03cd431a	6385d210-351d-4d4c-82a3-c3c57507cdf8	5dc67c3d-1666-4a68-8cb5-489997a6bf08	e22fc738-f9ce-49a9-be74-6c5399483633	vacuna	2026-09-15 15:15:00-05	Vacuna: Antirrábica	Próximo refuerzo en 12 meses	\N	2026-09-20 19:58:52.873138-05	5dc67c3d-1666-4a68-8cb5-489997a6bf08
f0527a7b-951f-4be2-803b-0b268f51fb4c	1ba3bd1a-4075-4009-b992-7057472e1e56	8faa65e3-0f52-48a8-940e-11f261b0b78c	6385d210-351d-4d4c-82a3-c3c57507cdf8	5dc67c3d-1666-4a68-8cb5-489997a6bf08	2cdaa77b-278b-435b-b1e1-5c86bb19430c	consulta	2026-09-19 15:50:00-05	Consulta: Cojera de miembro posterior	Contusión de miembro posterior	82caad5b-71a7-4543-a370-f9f6284138c2	2026-09-20 19:58:52.873138-05	5dc67c3d-1666-4a68-8cb5-489997a6bf08
11fcbecf-79b5-422f-bebb-2903c2b000fe	1ba3bd1a-4075-4009-b992-7057472e1e56	7da7fd75-767c-4176-ac1a-3396c31a2eba	976e5703-78d6-41e0-860e-a5f300ebec0e	419047f7-804f-4e15-90ca-276e3a463644	c838f213-73c7-4aa1-a1b4-81dfda816a67	consulta	2026-09-18 16:25:00-05	Consulta: Revisión de piel	Sobrepeso grado 2	23d274c1-92fa-41bc-98af-4291409acafa	2026-09-20 19:58:52.873138-05	419047f7-804f-4e15-90ca-276e3a463644
a85ab492-07ad-47b2-b938-7f1ca737c4c9	1ba3bd1a-4075-4009-b992-7057472e1e56	7da7fd75-767c-4176-ac1a-3396c31a2eba	976e5703-78d6-41e0-860e-a5f300ebec0e	5dc67c3d-1666-4a68-8cb5-489997a6bf08	c838f213-73c7-4aa1-a1b4-81dfda816a67	vacuna	2026-09-18 16:25:00-05	Vacuna: Quíntuple canina	Próximo refuerzo en 12 meses	\N	2026-09-20 19:58:52.873138-05	5dc67c3d-1666-4a68-8cb5-489997a6bf08
dd2d1eae-44eb-4cdc-845a-11c14786b503	1ba3bd1a-4075-4009-b992-7057472e1e56	a7b2f548-685d-43f6-ba66-77776a0ed1f5	8c82237b-e4f3-4b71-b66d-97a616290625	5dc67c3d-1666-4a68-8cb5-489997a6bf08	50c99593-7163-4af9-9218-d139b4b5dcec	consulta	2026-09-17 17:00:00-05	Consulta: Control anual	Gastroenteritis leve	c6af74b9-b1ab-441b-b498-74a1e8650e75	2026-09-20 19:58:52.873138-05	5dc67c3d-1666-4a68-8cb5-489997a6bf08
ff8b2880-9622-41ea-9060-2157e3483db4	1ba3bd1a-4075-4009-b992-7057472e1e56	e485ee0b-d6f9-4052-ba2f-2e63f3f1fd76	2dcfe029-99b2-4667-aa5d-6b3cfabda19f	419047f7-804f-4e15-90ca-276e3a463644	\N	hospitalizacion	2026-09-20 01:58:52.873138-05	Ingreso a hospitalización	Deshidratación severa por cuadro gastroentérico	\N	2026-09-20 19:58:52.873138-05	419047f7-804f-4e15-90ca-276e3a463644
eab560d9-8741-4888-85b2-49f51b71bae4	1ba3bd1a-4075-4009-b992-7057472e1e56	8faa65e3-0f52-48a8-940e-11f261b0b78c	6385d210-351d-4d4c-82a3-c3c57507cdf8	419047f7-804f-4e15-90ca-276e3a463644	\N	cirugia	2026-09-20 19:58:52.873138-05	Cirugía programada: Ovariohisterectomía	Esterilización electiva	\N	2026-09-20 19:58:52.873138-05	419047f7-804f-4e15-90ca-276e3a463644
\.


--
-- Data for Name: horarios_atencion; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.horarios_atencion (id, empresa_id, dia_semana, hora_inicio, hora_fin, activo, es_guardia, created_at, updated_at) FROM stdin;
c6586bd5-27e2-4b9b-97d6-25712253ff11	1ba3bd1a-4075-4009-b992-7057472e1e56	1	09:00:00	20:00:00	t	f	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05
059bd3c0-474b-4b77-b280-c1b587b6279a	1ba3bd1a-4075-4009-b992-7057472e1e56	2	09:00:00	20:00:00	t	f	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05
79c2f58f-1eda-4da4-8d65-c4546b0835ea	1ba3bd1a-4075-4009-b992-7057472e1e56	3	09:00:00	20:00:00	t	f	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05
3fef86f7-4fe9-4052-8a38-a350f6750f83	1ba3bd1a-4075-4009-b992-7057472e1e56	4	09:00:00	20:00:00	t	f	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05
f6b8a058-4d12-42fa-8b93-da7dfd5f9b9c	1ba3bd1a-4075-4009-b992-7057472e1e56	5	09:00:00	20:00:00	t	f	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05
620216c9-4b5c-417f-bc5c-47907ae9f462	1ba3bd1a-4075-4009-b992-7057472e1e56	6	09:00:00	14:00:00	t	f	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05
7a7b61bc-a3bd-42a2-8a84-547e98463925	a64719a9-57fc-4ac0-b104-b9d861370dc7	1	10:00:00	19:00:00	t	f	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05
2a33e381-128f-424b-926f-edda97649c15	a64719a9-57fc-4ac0-b104-b9d861370dc7	2	10:00:00	19:00:00	t	f	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05
b5a4e693-8799-47d6-93a3-271b14daf12a	a64719a9-57fc-4ac0-b104-b9d861370dc7	3	10:00:00	19:00:00	t	f	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05
38226607-8231-4cec-8225-97c76fb2673b	a64719a9-57fc-4ac0-b104-b9d861370dc7	4	10:00:00	19:00:00	t	f	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05
e2d96651-03ec-41db-b182-f866491d2ea5	a64719a9-57fc-4ac0-b104-b9d861370dc7	5	10:00:00	19:00:00	t	f	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05
\.


--
-- Data for Name: hospitalizacion_evoluciones; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.hospitalizacion_evoluciones (id, hospitalizacion_id, user_id, fecha_hora, temperatura_c, frecuencia_cardiaca, frecuencia_respiratoria, come, orina, defeca, nota, created_at) FROM stdin;
4623cb57-3444-4f47-bb91-e8fef7ef1bba	76217dbb-32de-4d3b-b870-02f4b318ab11	419047f7-804f-4e15-90ca-276e3a463644	2026-09-20 13:58:52.873138-05	38.4	105	\N	f	t	f	Ingreso. Se instaura fluidoterapia.	2026-09-20 19:58:52.873138-05
dadc8df9-6766-491a-a0d7-a21d708d27c3	76217dbb-32de-4d3b-b870-02f4b318ab11	419047f7-804f-4e15-90ca-276e3a463644	2026-09-20 07:58:52.873138-05	38.2	100	\N	t	t	f	Mejora del estado de hidratación. Tolera agua.	2026-09-20 19:58:52.873138-05
c8e837dc-2f4e-4c7f-a2e1-706508ee12ad	76217dbb-32de-4d3b-b870-02f4b318ab11	419047f7-804f-4e15-90ca-276e3a463644	2026-09-20 01:58:52.873138-05	38.0	95	\N	t	t	t	Come dieta blanda sin vomitar. Se mantiene fluido.	2026-09-20 19:58:52.873138-05
\.


--
-- Data for Name: hospitalizaciones; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.hospitalizaciones (id, empresa_id, codigo, mascota_id, veterinario_id, consultorio_id, jaula, motivo, diagnostico, fecha_ingreso, fecha_alta, indicaciones_alta, estado, created_at, updated_at, created_by) FROM stdin;
76217dbb-32de-4d3b-b870-02f4b318ab11	1ba3bd1a-4075-4009-b992-7057472e1e56	HOSP-00001	e485ee0b-d6f9-4052-ba2f-2e63f3f1fd76	419047f7-804f-4e15-90ca-276e3a463644	\N	J-03	Deshidratación severa por cuadro gastroentérico	Gastroenteritis aguda con deshidratación grado II	2026-09-20 01:58:52.873138-05	\N	\N	en_observacion	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	419047f7-804f-4e15-90ca-276e3a463644
\.


--
-- Data for Name: insumos_utilizados; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.insumos_utilizados (id, empresa_id, producto_id, mascota_id, consulta_id, cirugia_id, hospitalizacion_id, orden_servicio_id, cantidad, precio_unitario, facturado, fecha, created_by) FROM stdin;
\.


--
-- Data for Name: lotes; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.lotes (id, empresa_id, producto_id, numero_lote, fecha_vencimiento, cantidad, costo_unitario, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: mascotas; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.mascotas (id, empresa_id, codigo, cliente_id, nombre, especie_id, raza_id, sexo, color, senias_particulares, fecha_nacimiento, edad_aproximada_meses, peso_kg, tamanio, esterilizado, fecha_esterilizacion, microchip, num_placa, foto_url, alergias, condiciones_cronicas, observaciones, estado, fecha_fallecimiento, created_at, updated_at, deleted_at, created_by, updated_by) FROM stdin;
b4cbd8de-2439-4495-bd52-7c03a6bee07e	1ba3bd1a-4075-4009-b992-7057472e1e56	HC-000001	e4b74708-4127-4227-8144-7df4d7484c7a	Luna	ea82e665-7d26-4287-8e61-a6b786b8a5df	377e1589-8563-4d44-a6e2-caf493061c26	hembra	Dorado	\N	2021-03-14	\N	28.40	\N	t	\N	\N	\N	\N	Ninguna conocida	\N	\N	activo	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N
7035d850-c693-4743-880f-d1725c46e17c	1ba3bd1a-4075-4009-b992-7057472e1e56	HC-000002	e4b74708-4127-4227-8144-7df4d7484c7a	Simón	2e253998-3b20-42b9-a228-a5cb7ddc3394	6011ef97-78ab-4de0-b8f9-fc95b6195d09	macho	Crema y marrón	\N	2022-07-02	\N	4.80	\N	t	\N	\N	\N	\N	\N	\N	\N	activo	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N
43509380-78ff-488d-8590-7346e7769aa0	1ba3bd1a-4075-4009-b992-7057472e1e56	HC-000003	a27a10a9-9bff-4744-bbd4-fc7cff8377e3	Rocky	ea82e665-7d26-4287-8e61-a6b786b8a5df	ec90f3e5-2d30-42fe-be6e-c5442bc1ed3e	macho	Atigrado	\N	2020-11-20	\N	12.10	\N	f	\N	\N	\N	\N	Alergia alimentaria al pollo	\N	\N	activo	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N
2ab9d0d1-f0e0-45e0-87b0-b7037c9942fa	1ba3bd1a-4075-4009-b992-7057472e1e56	HC-000004	2c27a5b1-37e3-467c-82d0-a43adb274a9d	Maya	ea82e665-7d26-4287-8e61-a6b786b8a5df	a9e5c66a-bde9-4af5-babe-ee6f4aa3fd27	hembra	Negro	\N	2019-05-08	\N	18.70	\N	t	\N	\N	\N	\N	\N	\N	\N	activo	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N
e485ee0b-d6f9-4052-ba2f-2e63f3f1fd76	1ba3bd1a-4075-4009-b992-7057472e1e56	HC-000005	2dcfe029-99b2-4667-aa5d-6b3cfabda19f	Thor	ea82e665-7d26-4287-8e61-a6b786b8a5df	bb94f809-a643-4df2-9490-6f6c284b49c8	macho	Negro y fuego	\N	2018-09-30	\N	34.20	\N	f	\N	\N	\N	\N	\N	\N	\N	activo	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N
7a2e7560-c4a8-4f72-accd-6b64967fab66	1ba3bd1a-4075-4009-b992-7057472e1e56	HC-000006	e282ecd9-0ef4-4730-820a-065589f39268	Nala	2e253998-3b20-42b9-a228-a5cb7ddc3394	2a8e2678-1db8-4813-8813-23493bccdc09	hembra	Naranja	\N	2023-01-17	\N	3.60	\N	t	\N	\N	\N	\N	\N	\N	\N	activo	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N
cbbced34-52c2-45d5-adf1-e96954285557	1ba3bd1a-4075-4009-b992-7057472e1e56	HC-000007	a00187d7-281c-4691-8e20-ce62af59ce4e	Coco	ea82e665-7d26-4287-8e61-a6b786b8a5df	9cae2c0b-bcd0-490d-87fb-ade7693d2c18	macho	Blanco	\N	2017-04-25	\N	6.30	\N	t	\N	\N	\N	\N	Sensibilidad a la ivermectina	\N	\N	activo	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N
6818d890-9824-4de4-8ce5-4e7084079e8e	1ba3bd1a-4075-4009-b992-7057472e1e56	HC-000008	2a2f2866-944b-4edb-bd6d-f68cf7f814e6	Milo	2e253998-3b20-42b9-a228-a5cb7ddc3394	cd05c847-2fae-433d-920b-0ab37bd1f7d8	macho	Gris	\N	2021-12-11	\N	5.10	\N	t	\N	\N	\N	\N	\N	\N	\N	activo	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N
b7b98cfc-fff1-4d55-afb3-9f3c03cd431a	1ba3bd1a-4075-4009-b992-7057472e1e56	HC-000009	6385d210-351d-4d4c-82a3-c3c57507cdf8	Bruno	ea82e665-7d26-4287-8e61-a6b786b8a5df	a9e5c66a-bde9-4af5-babe-ee6f4aa3fd27	macho	Marrón	\N	2022-02-05	\N	21.50	\N	f	\N	\N	\N	\N	\N	\N	\N	activo	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N
8faa65e3-0f52-48a8-940e-11f261b0b78c	1ba3bd1a-4075-4009-b992-7057472e1e56	HC-000010	6385d210-351d-4d4c-82a3-c3c57507cdf8	Chispa	ea82e665-7d26-4287-8e61-a6b786b8a5df	a9e5c66a-bde9-4af5-babe-ee6f4aa3fd27	hembra	Blanco y negro	\N	2023-06-19	\N	14.80	\N	f	\N	\N	\N	\N	\N	\N	\N	activo	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N
7da7fd75-767c-4176-ac1a-3396c31a2eba	1ba3bd1a-4075-4009-b992-7057472e1e56	HC-000011	976e5703-78d6-41e0-860e-a5f300ebec0e	Kira	ea82e665-7d26-4287-8e61-a6b786b8a5df	1f5262bb-287e-4a16-9725-23174cc551da	hembra	Gris y blanco	\N	2020-08-14	\N	22.90	\N	t	\N	\N	\N	\N	\N	\N	\N	activo	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N
a7b2f548-685d-43f6-ba66-77776a0ed1f5	1ba3bd1a-4075-4009-b992-7057472e1e56	HC-000012	8c82237b-e4f3-4b71-b66d-97a616290625	Pelusa	2e253998-3b20-42b9-a228-a5cb7ddc3394	ea461041-3bc4-4576-b65b-039115d7a081	hembra	Blanco	\N	2019-10-03	\N	4.20	\N	t	\N	\N	\N	\N	Asma felino diagnosticado	\N	\N	activo	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N
c5f101ad-e153-46e9-b14e-f96202a411aa	a64719a9-57fc-4ac0-b104-b9d861370dc7	HC-000001	ba6e3efc-85b9-4afb-b021-59c90b1175ca	Toby	ea82e665-7d26-4287-8e61-a6b786b8a5df	6f999bc3-190e-4b2f-ac27-1fe996ed299a	macho	Tricolor	\N	2021-06-10	\N	11.20	\N	f	\N	\N	\N	\N	\N	\N	\N	activo	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N
55ba21b8-5041-4a9e-855b-dd0b40964720	a64719a9-57fc-4ac0-b104-b9d861370dc7	HC-000002	f55d340b-afe4-4411-bc87-f676d44c5a95	Michi	2e253998-3b20-42b9-a228-a5cb7ddc3394	2a8e2678-1db8-4813-8813-23493bccdc09	hembra	Atigrado	\N	2022-09-22	\N	3.90	\N	f	\N	\N	\N	\N	\N	\N	\N	activo	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N
9e33a848-097f-4c8b-84eb-77e12446da57	a64719a9-57fc-4ac0-b104-b9d861370dc7	HC-000003	b6aa1bbe-b47e-43f2-b441-787446f4036a	Duque	ea82e665-7d26-4287-8e61-a6b786b8a5df	893ba9e2-e738-4883-921c-70d772feff5b	macho	Sal y pimienta	\N	2019-11-05	\N	8.40	\N	f	\N	\N	\N	\N	\N	\N	\N	activo	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N
\.


--
-- Data for Name: mascotas_extraviadas; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.mascotas_extraviadas (id, empresa_id, mascota_id, fecha_extravio, zona, descripcion, contacto, recompensa, encontrado, fecha_hallazgo, created_at, updated_at, created_by) FROM stdin;
\.


--
-- Data for Name: movimientos_caja; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.movimientos_caja (id, empresa_id, caja_id, tipo, metodo, concepto, monto, pago_id, comprobante_id, fecha, created_at, created_by) FROM stdin;
e72d8e11-197f-4b38-b02a-ef225610866d	1ba3bd1a-4075-4009-b992-7057472e1e56	8c9f5165-375a-495f-be11-4c5257e48d8b	ingreso	tarjeta	Cobro a cliente	60.00	7676facb-df96-4368-92dc-06ab06342ca3	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	9faa05e4-2294-45f4-b7dd-4cadbb84b673
55ee2307-1a63-4713-a344-c0dd82f77012	1ba3bd1a-4075-4009-b992-7057472e1e56	8c9f5165-375a-495f-be11-4c5257e48d8b	ingreso	tarjeta	Cobro a cliente	60.00	20a3dfde-8f15-4de2-80f7-d8eb6395e92d	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	9faa05e4-2294-45f4-b7dd-4cadbb84b673
57c0246e-0198-442d-89c3-4d9a8b65d244	1ba3bd1a-4075-4009-b992-7057472e1e56	8c9f5165-375a-495f-be11-4c5257e48d8b	ingreso	tarjeta	Cobro a cliente	120.00	bf8845c3-e76c-49f0-a2bd-4ab792e78a94	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	9faa05e4-2294-45f4-b7dd-4cadbb84b673
0c6de428-c085-4dd2-be30-2be5730a9a28	1ba3bd1a-4075-4009-b992-7057472e1e56	8c9f5165-375a-495f-be11-4c5257e48d8b	ingreso	yape	Cobro a cliente	60.00	e6e8c030-8ac3-4ebb-8e17-5ad225637aaf	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	9faa05e4-2294-45f4-b7dd-4cadbb84b673
a0895b7c-ff41-4ed0-ba9f-5e8ed7a1abe0	1ba3bd1a-4075-4009-b992-7057472e1e56	8c9f5165-375a-495f-be11-4c5257e48d8b	ingreso	tarjeta	Cobro a cliente	60.00	01a70202-2d13-4cac-8f7b-bc6de47d2f58	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	9faa05e4-2294-45f4-b7dd-4cadbb84b673
e2873680-112b-488d-b202-63be3a3fd4ba	1ba3bd1a-4075-4009-b992-7057472e1e56	8c9f5165-375a-495f-be11-4c5257e48d8b	ingreso	yape	Cobro a cliente	60.00	439645b4-c164-473c-9791-3cab1266e449	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	9faa05e4-2294-45f4-b7dd-4cadbb84b673
c93a6663-71c4-4a0f-b2a4-a8486ada7482	1ba3bd1a-4075-4009-b992-7057472e1e56	8c9f5165-375a-495f-be11-4c5257e48d8b	ingreso	yape	Cobro a cliente	120.00	f65984c6-7f91-4f2c-9a6f-96cf2f2ca69c	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	9faa05e4-2294-45f4-b7dd-4cadbb84b673
\.


--
-- Data for Name: movimientos_inventario; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.movimientos_inventario (id, empresa_id, producto_id, almacen_id, almacen_destino_id, lote_id, tipo, motivo, cantidad, costo_unitario, saldo_despues, cliente_id, proveedor_id, mascota_id, consulta_id, comprobante_id, orden_compra_id, observaciones, fecha, created_at, created_by) FROM stdin;
8c097685-011f-4a9b-a6c7-fcb7c9e4e7f9	1ba3bd1a-4075-4009-b992-7057472e1e56	5197b443-2077-49ff-97dc-784ce06c27ea	1c132cba-0595-4444-9f61-b6ef4278cac0	\N	\N	entrada	ajuste_inventario	40.00	18.00	40.00	\N	\N	\N	\N	\N	\N	Carga inicial de inventario	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	af48d096-86a1-48c0-a4a2-c2971a0dcf6a
9d167521-d108-4f0a-82ba-6fcbe0f7fb10	1ba3bd1a-4075-4009-b992-7057472e1e56	3a26ca77-3d71-4964-acf5-eacfc6eeb479	1c132cba-0595-4444-9f61-b6ef4278cac0	\N	\N	entrada	ajuste_inventario	40.00	28.00	40.00	\N	\N	\N	\N	\N	\N	Carga inicial de inventario	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	af48d096-86a1-48c0-a4a2-c2971a0dcf6a
ceae598e-00cc-488c-a007-50884e4deb1f	1ba3bd1a-4075-4009-b992-7057472e1e56	535ffa99-0ab3-4c7b-a753-7d42b7d21894	1c132cba-0595-4444-9f61-b6ef4278cac0	\N	\N	entrada	ajuste_inventario	40.00	30.00	40.00	\N	\N	\N	\N	\N	\N	Carga inicial de inventario	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	af48d096-86a1-48c0-a4a2-c2971a0dcf6a
c62cf8a8-cde1-416a-a8cc-ba204442626a	1ba3bd1a-4075-4009-b992-7057472e1e56	33aa9c82-ab26-4a59-8b0f-7550accda742	1c132cba-0595-4444-9f61-b6ef4278cac0	\N	\N	entrada	ajuste_inventario	40.00	22.00	40.00	\N	\N	\N	\N	\N	\N	Carga inicial de inventario	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	af48d096-86a1-48c0-a4a2-c2971a0dcf6a
dbf935f0-acb1-4f8f-82c7-51da5f56a0d6	1ba3bd1a-4075-4009-b992-7057472e1e56	342d9253-5690-4114-8da3-394eaae27f4d	1c132cba-0595-4444-9f61-b6ef4278cac0	\N	\N	entrada	ajuste_inventario	40.00	35.00	40.00	\N	\N	\N	\N	\N	\N	Carga inicial de inventario	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	af48d096-86a1-48c0-a4a2-c2971a0dcf6a
5d691db8-3d36-460e-b6e0-48572289c5fd	1ba3bd1a-4075-4009-b992-7057472e1e56	5acf001e-68e8-449f-be32-2f03a06e0d7a	1c132cba-0595-4444-9f61-b6ef4278cac0	\N	\N	entrada	ajuste_inventario	40.00	28.00	40.00	\N	\N	\N	\N	\N	\N	Carga inicial de inventario	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	af48d096-86a1-48c0-a4a2-c2971a0dcf6a
4b1aa544-d6d3-4f36-961f-ffa6178ba7e1	1ba3bd1a-4075-4009-b992-7057472e1e56	430c17cf-0b6f-452c-bd6a-25b2fa13741f	1c132cba-0595-4444-9f61-b6ef4278cac0	\N	\N	entrada	ajuste_inventario	40.00	14.00	40.00	\N	\N	\N	\N	\N	\N	Carga inicial de inventario	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	af48d096-86a1-48c0-a4a2-c2971a0dcf6a
2c3cf8ff-055f-458f-bc6c-bb1c2371b0e1	1ba3bd1a-4075-4009-b992-7057472e1e56	71e823f6-3cd6-4e63-ad6f-c276ab8c4780	1c132cba-0595-4444-9f61-b6ef4278cac0	\N	\N	entrada	ajuste_inventario	120.00	6.50	120.00	\N	\N	\N	\N	\N	\N	Carga inicial de inventario	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	af48d096-86a1-48c0-a4a2-c2971a0dcf6a
7c6ccca7-b25e-43d6-b200-3152f048d718	1ba3bd1a-4075-4009-b992-7057472e1e56	828b6821-c928-46ca-a9f1-dee6d771b855	1c132cba-0595-4444-9f61-b6ef4278cac0	\N	\N	entrada	ajuste_inventario	120.00	0.60	120.00	\N	\N	\N	\N	\N	\N	Carga inicial de inventario	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	af48d096-86a1-48c0-a4a2-c2971a0dcf6a
c6aaddb2-0b9c-4ddd-8771-e80c72287d18	1ba3bd1a-4075-4009-b992-7057472e1e56	188a1d71-db83-46b3-9bc2-eabee528fdfc	1c132cba-0595-4444-9f61-b6ef4278cac0	\N	\N	entrada	ajuste_inventario	120.00	3.50	120.00	\N	\N	\N	\N	\N	\N	Carga inicial de inventario	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	af48d096-86a1-48c0-a4a2-c2971a0dcf6a
76812fec-f965-488f-9569-c7762da585ba	1ba3bd1a-4075-4009-b992-7057472e1e56	6a3b4ab7-0337-4d68-8162-b680c554bd0e	1c132cba-0595-4444-9f61-b6ef4278cac0	\N	\N	entrada	ajuste_inventario	120.00	12.00	120.00	\N	\N	\N	\N	\N	\N	Carga inicial de inventario	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	af48d096-86a1-48c0-a4a2-c2971a0dcf6a
0d58cfe9-7190-432e-9802-112320dd65f2	1ba3bd1a-4075-4009-b992-7057472e1e56	78a55878-39f1-44ce-9870-45b64caa4899	1c132cba-0595-4444-9f61-b6ef4278cac0	\N	\N	entrada	ajuste_inventario	12.00	78.00	12.00	\N	\N	\N	\N	\N	\N	Carga inicial de inventario	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	af48d096-86a1-48c0-a4a2-c2971a0dcf6a
4c8dc817-210a-415f-a59d-4a4775a3e8ae	1ba3bd1a-4075-4009-b992-7057472e1e56	0f7bcb71-f93c-4a51-89a5-18e0ff0fb0d6	1c132cba-0595-4444-9f61-b6ef4278cac0	\N	\N	entrada	ajuste_inventario	12.00	145.00	12.00	\N	\N	\N	\N	\N	\N	Carga inicial de inventario	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	af48d096-86a1-48c0-a4a2-c2971a0dcf6a
563e63e5-82dc-4203-aa54-286550cf13ff	1ba3bd1a-4075-4009-b992-7057472e1e56	3365e863-88c4-4e0d-acd1-17cb6af032fd	1c132cba-0595-4444-9f61-b6ef4278cac0	\N	\N	entrada	ajuste_inventario	40.00	32.00	40.00	\N	\N	\N	\N	\N	\N	Carga inicial de inventario	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	af48d096-86a1-48c0-a4a2-c2971a0dcf6a
3f74de37-ace2-429d-9877-d305bac3b644	1ba3bd1a-4075-4009-b992-7057472e1e56	63916ee9-bd0e-4d14-812c-1ce3b567ab6c	1c132cba-0595-4444-9f61-b6ef4278cac0	\N	\N	entrada	ajuste_inventario	40.00	12.00	40.00	\N	\N	\N	\N	\N	\N	Carga inicial de inventario	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	af48d096-86a1-48c0-a4a2-c2971a0dcf6a
e4b991b7-b2fc-4f7f-b04c-f1579bdcd10c	a64719a9-57fc-4ac0-b104-b9d861370dc7	e42496b2-d4f7-46f1-9817-5e94a7c527c4	720ad333-4de0-447f-84bb-dc46e664dd76	\N	\N	entrada	ajuste_inventario	30.00	18.00	30.00	\N	\N	\N	\N	\N	\N	Carga inicial de inventario	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	af48d096-86a1-48c0-a4a2-c2971a0dcf6a
9371261c-395d-4b63-9cb8-5fa84f189d86	a64719a9-57fc-4ac0-b104-b9d861370dc7	31c219b2-abd2-4cf5-9bf2-563598c49d93	720ad333-4de0-447f-84bb-dc46e664dd76	\N	\N	entrada	ajuste_inventario	30.00	22.00	30.00	\N	\N	\N	\N	\N	\N	Carga inicial de inventario	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	af48d096-86a1-48c0-a4a2-c2971a0dcf6a
eb260599-f7f2-41ac-9ede-69795f63da7e	a64719a9-57fc-4ac0-b104-b9d861370dc7	ee3a9fba-8417-4784-99af-b869ddb996fa	720ad333-4de0-447f-84bb-dc46e664dd76	\N	\N	entrada	ajuste_inventario	100.00	0.60	100.00	\N	\N	\N	\N	\N	\N	Carga inicial de inventario	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	af48d096-86a1-48c0-a4a2-c2971a0dcf6a
d09d1cad-1ba2-45c4-96de-814d3ed5d82f	a64719a9-57fc-4ac0-b104-b9d861370dc7	271b60e3-dd2b-459e-9e49-5d1110e74b7c	720ad333-4de0-447f-84bb-dc46e664dd76	\N	\N	entrada	ajuste_inventario	100.00	6.50	100.00	\N	\N	\N	\N	\N	\N	Carga inicial de inventario	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	af48d096-86a1-48c0-a4a2-c2971a0dcf6a
\.


--
-- Data for Name: notas_medicas; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.notas_medicas (id, empresa_id, mascota_id, user_id, nota, destacada, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: notificaciones; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.notificaciones (id, user_id, empresa_id, canal, titulo, cuerpo, url, entidad, entidad_id, leida_at, created_at) FROM stdin;
\.


--
-- Data for Name: orden_compra_items; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.orden_compra_items (id, orden_compra_id, producto_id, descripcion, cantidad, cantidad_recibida, precio_unitario, descuento, subtotal, numero_lote, fecha_vencimiento, orden) FROM stdin;
\.


--
-- Data for Name: ordenes_compra; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.ordenes_compra (id, empresa_id, numero, proveedor_id, almacen_id, fecha_emision, fecha_estimada, fecha_recepcion, moneda, subtotal, igv, total, saldo_pendiente, estado, estado_pago, observaciones, created_at, updated_at, deleted_at, created_by, updated_by) FROM stdin;
\.


--
-- Data for Name: ordenes_servicio; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.ordenes_servicio (id, empresa_id, codigo, mascota_id, cliente_id, servicio_id, veterinario_id, cita_id, consulta_id, cantidad, precio_unitario, descuento, total, descripcion, estado, facturado, comprobante_id, fecha, created_at, updated_at, created_by, origen_tabla, origen_id) FROM stdin;
55378df3-de75-4279-b93c-b428421ee8a3	1ba3bd1a-4075-4009-b992-7057472e1e56	OS-000008	6818d890-9824-4de4-8ce5-4e7084079e8e	2a2f2866-944b-4edb-bd6d-f68cf7f814e6	3547474b-85d1-4280-97f1-4d14966b7841	5dc67c3d-1666-4a68-8cb5-489997a6bf08	5ddabc0c-bc98-4ec2-8238-e3f68b22099d	57e65017-8dec-4fbc-b23d-5fc393974c70	1.00	60.00	0.00	60.00	\N	completado	t	7b96ea92-aa2a-4506-8945-040c248d3088	2026-09-16 14:40:00-05	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	9faa05e4-2294-45f4-b7dd-4cadbb84b673	\N	\N
75fb96ba-e60f-4449-b62f-f794b42123e3	1ba3bd1a-4075-4009-b992-7057472e1e56	OS-000004	2ab9d0d1-f0e0-45e0-87b0-b7037c9942fa	2c27a5b1-37e3-467c-82d0-a43adb274a9d	3547474b-85d1-4280-97f1-4d14966b7841	5dc67c3d-1666-4a68-8cb5-489997a6bf08	4f6b7ca5-7d46-4fd8-b35f-2ccfda909d70	aacc8ba9-d826-4d3e-b9f9-9756da527594	1.00	60.00	0.00	60.00	\N	completado	t	3f8fac68-eddb-4500-888c-962dfe6801e4	2026-09-15 12:20:00-05	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	9faa05e4-2294-45f4-b7dd-4cadbb84b673	\N	\N
f3ee0853-7a5a-4e60-abaf-b0c7c50833d8	1ba3bd1a-4075-4009-b992-7057472e1e56	OS-000005	e485ee0b-d6f9-4052-ba2f-2e63f3f1fd76	2dcfe029-99b2-4667-aa5d-6b3cfabda19f	3547474b-85d1-4280-97f1-4d14966b7841	419047f7-804f-4e15-90ca-276e3a463644	268e2cb4-ce58-4b8d-88ba-b1f5972d41ad	bbe65666-df5b-4edd-adc9-3cf4736e8b68	1.00	60.00	0.00	60.00	\N	completado	t	9501efd4-ee86-4326-ab23-9f0b0181ed5b	2026-09-19 12:55:00-05	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	9faa05e4-2294-45f4-b7dd-4cadbb84b673	\N	\N
78d48535-de11-41fe-ae5c-c843bd4bcd50	1ba3bd1a-4075-4009-b992-7057472e1e56	OS-000009	b7b98cfc-fff1-4d55-afb3-9f3c03cd431a	6385d210-351d-4d4c-82a3-c3c57507cdf8	3547474b-85d1-4280-97f1-4d14966b7841	419047f7-804f-4e15-90ca-276e3a463644	e22fc738-f9ce-49a9-be74-6c5399483633	86cf4a68-2368-4766-97d8-c162d5f0a004	1.00	60.00	0.00	60.00	\N	completado	t	c9bd86fa-b2f8-4452-94f0-182271197847	2026-09-15 15:15:00-05	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	9faa05e4-2294-45f4-b7dd-4cadbb84b673	\N	\N
4859ec41-7c5c-40ab-b6a3-222aca529aa6	1ba3bd1a-4075-4009-b992-7057472e1e56	OS-000010	8faa65e3-0f52-48a8-940e-11f261b0b78c	6385d210-351d-4d4c-82a3-c3c57507cdf8	3547474b-85d1-4280-97f1-4d14966b7841	5dc67c3d-1666-4a68-8cb5-489997a6bf08	2cdaa77b-278b-435b-b1e1-5c86bb19430c	82caad5b-71a7-4543-a370-f9f6284138c2	1.00	60.00	0.00	60.00	\N	completado	t	c9bd86fa-b2f8-4452-94f0-182271197847	2026-09-19 15:50:00-05	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	9faa05e4-2294-45f4-b7dd-4cadbb84b673	\N	\N
8e367415-e2f7-42ad-9f59-dc68b7d4c58b	1ba3bd1a-4075-4009-b992-7057472e1e56	OS-000012	a7b2f548-685d-43f6-ba66-77776a0ed1f5	8c82237b-e4f3-4b71-b66d-97a616290625	3547474b-85d1-4280-97f1-4d14966b7841	5dc67c3d-1666-4a68-8cb5-489997a6bf08	50c99593-7163-4af9-9218-d139b4b5dcec	c6af74b9-b1ab-441b-b498-74a1e8650e75	1.00	60.00	0.00	60.00	\N	completado	t	3ab77376-6998-4fd8-af0b-50daa227247d	2026-09-17 17:00:00-05	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	9faa05e4-2294-45f4-b7dd-4cadbb84b673	\N	\N
d415a9c0-9add-4df0-a349-5c0c769ad084	1ba3bd1a-4075-4009-b992-7057472e1e56	OS-000011	7da7fd75-767c-4176-ac1a-3396c31a2eba	976e5703-78d6-41e0-860e-a5f300ebec0e	3547474b-85d1-4280-97f1-4d14966b7841	419047f7-804f-4e15-90ca-276e3a463644	c838f213-73c7-4aa1-a1b4-81dfda816a67	23d274c1-92fa-41bc-98af-4291409acafa	1.00	60.00	0.00	60.00	\N	completado	t	b84e97d9-f351-45a9-bad9-281341d87e66	2026-09-18 16:25:00-05	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	9faa05e4-2294-45f4-b7dd-4cadbb84b673	\N	\N
31f050a1-58de-4e8c-b94b-d5862b2a8cd3	1ba3bd1a-4075-4009-b992-7057472e1e56	OS-000007	cbbced34-52c2-45d5-adf1-e96954285557	a00187d7-281c-4691-8e20-ce62af59ce4e	3547474b-85d1-4280-97f1-4d14966b7841	419047f7-804f-4e15-90ca-276e3a463644	33dc6def-9f84-452d-a89b-d22f61b65583	95ec86f8-fe2d-462d-b40a-bec91a6e00cc	1.00	60.00	0.00	60.00	\N	completado	t	5e951870-3242-4e52-809d-7d4fbb936023	2026-09-17 14:05:00-05	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	9faa05e4-2294-45f4-b7dd-4cadbb84b673	\N	\N
8c7ba4e7-90a8-49a8-bb19-e467244544ea	1ba3bd1a-4075-4009-b992-7057472e1e56	OS-000003	43509380-78ff-488d-8590-7346e7769aa0	a27a10a9-9bff-4744-bbd4-fc7cff8377e3	3547474b-85d1-4280-97f1-4d14966b7841	419047f7-804f-4e15-90ca-276e3a463644	3f5a2894-7aea-41c7-bf23-72f7cdb4cc4b	a044cd96-9aff-4485-83a0-77bd77662820	1.00	60.00	0.00	60.00	\N	completado	t	244181d7-bfdc-4807-a283-a91e051388f6	2026-09-16 11:45:00-05	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	9faa05e4-2294-45f4-b7dd-4cadbb84b673	\N	\N
d1288a7d-2249-481b-b92e-ed001ea1e729	1ba3bd1a-4075-4009-b992-7057472e1e56	OS-000006	7a2e7560-c4a8-4f72-accd-6b64967fab66	e282ecd9-0ef4-4730-820a-065589f39268	3547474b-85d1-4280-97f1-4d14966b7841	5dc67c3d-1666-4a68-8cb5-489997a6bf08	f52590e8-a35b-4b31-a58f-6533a3904e5a	7f8840fc-d591-415d-b171-cd1540efd22f	1.00	60.00	0.00	60.00	\N	completado	t	ac9fb05f-e1ff-4a4b-af73-e2775ca7ca33	2026-09-18 13:30:00-05	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	9faa05e4-2294-45f4-b7dd-4cadbb84b673	\N	\N
7c3ba082-e5d3-4e8a-954e-b5ca1aa8e9b2	1ba3bd1a-4075-4009-b992-7057472e1e56	OS-000001	b4cbd8de-2439-4495-bd52-7c03a6bee07e	e4b74708-4127-4227-8144-7df4d7484c7a	3547474b-85d1-4280-97f1-4d14966b7841	419047f7-804f-4e15-90ca-276e3a463644	719832b2-21bc-424f-b04f-9002eefecd21	7d8f9f37-6998-4093-b279-01f32bf2b1ff	1.00	60.00	0.00	60.00	\N	completado	t	0ab1acd9-94ad-433b-b998-ff5c8df9cd50	2026-09-18 10:35:00-05	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	9faa05e4-2294-45f4-b7dd-4cadbb84b673	\N	\N
575049ee-fec7-4513-8f1f-867f93a4e5a8	1ba3bd1a-4075-4009-b992-7057472e1e56	OS-000002	7035d850-c693-4743-880f-d1725c46e17c	e4b74708-4127-4227-8144-7df4d7484c7a	3547474b-85d1-4280-97f1-4d14966b7841	5dc67c3d-1666-4a68-8cb5-489997a6bf08	7cac4a3c-9e6e-4f3d-bb79-195f2d030dcc	bb1c5d85-6d73-4661-9b52-0a63cf55bb6d	1.00	60.00	0.00	60.00	\N	completado	t	0ab1acd9-94ad-433b-b998-ff5c8df9cd50	2026-09-17 11:10:00-05	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	9faa05e4-2294-45f4-b7dd-4cadbb84b673	\N	\N
\.


--
-- Data for Name: pago_aplicaciones; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.pago_aplicaciones (id, pago_id, comprobante_id, monto_aplicado, created_at) FROM stdin;
60157f5f-03a2-4afc-9cc5-22bfe638229b	7676facb-df96-4368-92dc-06ab06342ca3	3f8fac68-eddb-4500-888c-962dfe6801e4	60.00	2026-09-20 19:58:52.873138-05
87da7a0b-21ff-4196-ae7e-adc3c24af601	20a3dfde-8f15-4de2-80f7-d8eb6395e92d	9501efd4-ee86-4326-ab23-9f0b0181ed5b	60.00	2026-09-20 19:58:52.873138-05
5e97dc11-5ee2-42f5-8ed9-cbfc86302c3c	bf8845c3-e76c-49f0-a2bd-4ab792e78a94	c9bd86fa-b2f8-4452-94f0-182271197847	120.00	2026-09-20 19:58:52.873138-05
078dd928-e7b4-45be-ba70-f2fbd7b205bb	e6e8c030-8ac3-4ebb-8e17-5ad225637aaf	3ab77376-6998-4fd8-af0b-50daa227247d	60.00	2026-09-20 19:58:52.873138-05
c4374583-dada-4c59-8207-bdf437800a5a	01a70202-2d13-4cac-8f7b-bc6de47d2f58	b84e97d9-f351-45a9-bad9-281341d87e66	60.00	2026-09-20 19:58:52.873138-05
017e7fb7-1d58-45a6-b8ed-32fdba682a59	439645b4-c164-473c-9791-3cab1266e449	244181d7-bfdc-4807-a283-a91e051388f6	60.00	2026-09-20 19:58:52.873138-05
0de1e01b-a2d2-4518-8982-ea28ca1d5f34	f65984c6-7f91-4f2c-9a6f-96cf2f2ca69c	0ab1acd9-94ad-433b-b998-ff5c8df9cd50	120.00	2026-09-20 19:58:52.873138-05
\.


--
-- Data for Name: pagos; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.pagos (id, empresa_id, cliente_id, caja_id, numero, metodo, monto, moneda, referencia, fecha_pago, anulado_at, observaciones, created_at, created_by) FROM stdin;
7676facb-df96-4368-92dc-06ab06342ca3	1ba3bd1a-4075-4009-b992-7057472e1e56	2c27a5b1-37e3-467c-82d0-a43adb274a9d	8c9f5165-375a-495f-be11-4c5257e48d8b	PAG-000001	tarjeta	60.00	PEN	\N	2026-09-20 19:58:52.873138-05	\N	\N	2026-09-20 19:58:52.873138-05	9faa05e4-2294-45f4-b7dd-4cadbb84b673
20a3dfde-8f15-4de2-80f7-d8eb6395e92d	1ba3bd1a-4075-4009-b992-7057472e1e56	2dcfe029-99b2-4667-aa5d-6b3cfabda19f	8c9f5165-375a-495f-be11-4c5257e48d8b	PAG-000002	tarjeta	60.00	PEN	\N	2026-09-20 19:58:52.873138-05	\N	\N	2026-09-20 19:58:52.873138-05	9faa05e4-2294-45f4-b7dd-4cadbb84b673
bf8845c3-e76c-49f0-a2bd-4ab792e78a94	1ba3bd1a-4075-4009-b992-7057472e1e56	6385d210-351d-4d4c-82a3-c3c57507cdf8	8c9f5165-375a-495f-be11-4c5257e48d8b	PAG-000003	tarjeta	120.00	PEN	\N	2026-09-20 19:58:52.873138-05	\N	\N	2026-09-20 19:58:52.873138-05	9faa05e4-2294-45f4-b7dd-4cadbb84b673
e6e8c030-8ac3-4ebb-8e17-5ad225637aaf	1ba3bd1a-4075-4009-b992-7057472e1e56	8c82237b-e4f3-4b71-b66d-97a616290625	8c9f5165-375a-495f-be11-4c5257e48d8b	PAG-000004	yape	60.00	PEN	\N	2026-09-20 19:58:52.873138-05	\N	\N	2026-09-20 19:58:52.873138-05	9faa05e4-2294-45f4-b7dd-4cadbb84b673
01a70202-2d13-4cac-8f7b-bc6de47d2f58	1ba3bd1a-4075-4009-b992-7057472e1e56	976e5703-78d6-41e0-860e-a5f300ebec0e	8c9f5165-375a-495f-be11-4c5257e48d8b	PAG-000005	tarjeta	60.00	PEN	\N	2026-09-20 19:58:52.873138-05	\N	\N	2026-09-20 19:58:52.873138-05	9faa05e4-2294-45f4-b7dd-4cadbb84b673
439645b4-c164-473c-9791-3cab1266e449	1ba3bd1a-4075-4009-b992-7057472e1e56	a27a10a9-9bff-4744-bbd4-fc7cff8377e3	8c9f5165-375a-495f-be11-4c5257e48d8b	PAG-000006	yape	60.00	PEN	\N	2026-09-20 19:58:52.873138-05	\N	\N	2026-09-20 19:58:52.873138-05	9faa05e4-2294-45f4-b7dd-4cadbb84b673
f65984c6-7f91-4f2c-9a6f-96cf2f2ca69c	1ba3bd1a-4075-4009-b992-7057472e1e56	e4b74708-4127-4227-8144-7df4d7484c7a	8c9f5165-375a-495f-be11-4c5257e48d8b	PAG-000007	yape	120.00	PEN	\N	2026-09-20 19:58:52.873138-05	\N	\N	2026-09-20 19:58:52.873138-05	9faa05e4-2294-45f4-b7dd-4cadbb84b673
\.


--
-- Data for Name: pagos_proveedor; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.pagos_proveedor (id, empresa_id, proveedor_id, orden_compra_id, numero, metodo, monto, moneda, referencia, comprobante_url, fecha_pago, anulado_at, observaciones, created_at, created_by) FROM stdin;
\.


--
-- Data for Name: permisos; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.permisos (id, codigo, modulo, accion, descripcion, created_at) FROM stdin;
d5a8bc61-ca3f-4679-be57-3f2b751c2a37	dashboard:ver	dashboard	ver	Ver el panel de control	2026-09-20 19:58:52.262673-05
b63a0aeb-cec4-4d45-824b-926cc4f4ca57	clientes:listar	clientes	listar	Ver el directorio de propietarios	2026-09-20 19:58:52.262673-05
6948b9fa-0798-4cab-8e21-5fe97e78cbe9	clientes:crear	clientes	crear	Registrar propietarios	2026-09-20 19:58:52.262673-05
b92e16fe-4f82-4a62-a310-b06239069ade	clientes:editar	clientes	editar	Editar datos de propietarios	2026-09-20 19:58:52.262673-05
d8670e30-71c7-425d-b918-97e3cf857a07	clientes:eliminar	clientes	eliminar	Dar de baja propietarios	2026-09-20 19:58:52.262673-05
56e930f9-cdb2-4f85-99a9-c6bd0a088a9f	mascotas:listar	mascotas	listar	Ver el listado de pacientes	2026-09-20 19:58:52.262673-05
1ca0f0ee-eef7-418e-a06d-979f2bdabcc7	mascotas:crear	mascotas	crear	Registrar pacientes	2026-09-20 19:58:52.262673-05
7d1d445c-5b4a-47ad-9d76-754b093aaa09	mascotas:editar	mascotas	editar	Editar la ficha del paciente	2026-09-20 19:58:52.262673-05
8fe8a3e7-d4f6-4064-94e4-1f794d8b6c6a	mascotas:eliminar	mascotas	eliminar	Dar de baja pacientes	2026-09-20 19:58:52.262673-05
0809cf0b-eb5d-47c2-940d-acb6df787c28	citas:listar	citas	listar	Ver la agenda	2026-09-20 19:58:52.262673-05
665d7baf-0f89-4ef9-896a-967de9338066	citas:crear	citas	crear	Agendar citas	2026-09-20 19:58:52.262673-05
e0e9f953-87c2-4936-aba9-286b5121671a	citas:editar	citas	editar	Reprogramar y cambiar estado de citas	2026-09-20 19:58:52.262673-05
d866c3d3-2230-4024-a135-dbe419da7669	citas:eliminar	citas	eliminar	Eliminar citas	2026-09-20 19:58:52.262673-05
6ea8dd2d-16b3-4ca0-ad20-151bbb7dfc04	clinico:ver	clinico	ver	Ver la historia clínica	2026-09-20 19:58:52.262673-05
0b58c7ec-6189-4eed-a330-a93767e82a39	clinico:registrar	clinico	registrar	Registrar actos clínicos	2026-09-20 19:58:52.262673-05
3bdaf794-c122-4410-adb3-8b91d508afe8	servicios:gestionar	servicios	gestionar	Administrar el catálogo de servicios	2026-09-20 19:58:52.262673-05
ac6de34d-afa5-4c78-a948-c5b554608851	catalogos:gestionar	catalogos	gestionar	Administrar catálogos maestros	2026-09-20 19:58:52.262673-05
e4593c14-13d4-4e25-975a-8988bdfd0ce5	inventario:ver	inventario	ver	Consultar inventario y stock	2026-09-20 19:58:52.262673-05
342ca47e-6b3a-4cc3-8afb-5c34a97d5720	inventario:gestionar	inventario	gestionar	Administrar productos y almacenes	2026-09-20 19:58:52.262673-05
e2053b44-a0ea-4196-929e-410f0d48afd0	inventario:mover	inventario	mover	Registrar movimientos de stock	2026-09-20 19:58:52.262673-05
7ddff749-fcb8-4ea4-a5e4-ce0faebfea50	compras:ver	compras	ver	Ver proveedores y órdenes de compra	2026-09-20 19:58:52.262673-05
3995ac52-0e45-4a2a-ba17-00aabffb501e	compras:gestionar	compras	gestionar	Crear y editar órdenes de compra	2026-09-20 19:58:52.262673-05
1c9725e4-0861-491d-a6a0-7333367b006d	compras:recibir	compras	recibir	Recibir mercadería	2026-09-20 19:58:52.262673-05
8fc1c674-9a20-4d00-8ffa-09a808151cc3	compras:pagar	compras	pagar	Registrar pagos a proveedores	2026-09-20 19:58:52.262673-05
4e61cf46-b447-40f9-82c8-2081456016a5	facturacion:ver	facturacion	ver	Consultar comprobantes	2026-09-20 19:58:52.262673-05
db018279-91f0-4aca-9a9f-a65abb4e27f3	facturacion:emitir	facturacion	emitir	Emitir comprobantes de venta	2026-09-20 19:58:52.262673-05
504f64eb-395a-49c9-8fa1-27722a43ca37	facturacion:anular	facturacion	anular	Anular comprobantes	2026-09-20 19:58:52.262673-05
0cf699f4-9a35-4bef-8422-3cd33677b296	pagos:ver	pagos	ver	Consultar cobros	2026-09-20 19:58:52.262673-05
fecc62a8-85bf-4080-8821-96a1726ea733	pagos:registrar	pagos	registrar	Registrar cobros de clientes	2026-09-20 19:58:52.262673-05
3ddca28c-069d-41ab-91ae-18f2c78ce38d	pagos:anular	pagos	anular	Anular cobros	2026-09-20 19:58:52.262673-05
df8cf7e3-ffe7-4da1-977a-000aa9e8ed19	caja:operar	caja	operar	Abrir, mover y cerrar caja	2026-09-20 19:58:52.262673-05
c24a182b-b8df-4c39-9970-3b88772fcc01	caja:ver	caja	ver	Ver arqueos de caja	2026-09-20 19:58:52.262673-05
a1303cff-f739-4e3e-98ce-4dbb62ef8239	rrhh:ver	rrhh	ver	Ver información del equipo	2026-09-20 19:58:52.262673-05
524d298d-5abd-48fe-a4a2-d29216a0d104	rrhh:gestionar	rrhh	gestionar	Administrar turnos, contratos y evaluaciones	2026-09-20 19:58:52.262673-05
3e83caba-50ba-4abc-a079-f7ec12616d73	rrhh:aprobar	rrhh	aprobar	Aprobar permisos y vacaciones	2026-09-20 19:58:52.262673-05
e7a4ff4b-6803-46fa-b7d6-ee0a9c947606	reportes:ver	reportes	ver	Ver reportes operativos	2026-09-20 19:58:52.262673-05
66f2f759-1697-4a5b-9777-cc059002862a	reportes:ejecutivo	reportes	ejecutivo	Ver el reporte ejecutivo	2026-09-20 19:58:52.262673-05
5221f2ec-1469-4f33-b5fc-dd8bbaf83755	usuarios:listar	usuarios	listar	Ver los usuarios del sistema	2026-09-20 19:58:52.262673-05
adf808ab-557c-4658-ad47-b485bb24223e	usuarios:crear	usuarios	crear	Crear usuarios	2026-09-20 19:58:52.262673-05
59badc62-ac6d-4063-818a-14c220cf741c	usuarios:editar	usuarios	editar	Editar usuarios	2026-09-20 19:58:52.262673-05
99359ab3-0ee4-48cc-8a85-56a4e9bd9467	usuarios:eliminar	usuarios	eliminar	Eliminar usuarios	2026-09-20 19:58:52.262673-05
21bf3005-2ccb-4ce4-b25f-fdcddbe41cce	usuarios:asignar_rol	usuarios	asignar_rol	Cambiar el rol de un usuario	2026-09-20 19:58:52.262673-05
1e357e9e-0dce-44f4-8cc3-39696c43d2ad	auditoria:ver	auditoria	ver	Ver la bitácora del sistema	2026-09-20 19:58:52.262673-05
b7f5a456-5820-4932-a52d-28c4d18cbc17	empresas:gestionar	empresas	gestionar	Administrar empresas	2026-09-20 19:58:52.262673-05
e88bb4f2-ab1b-41cb-8f8f-15f2f22d7b59	empresa:configurar	empresas	configurar	Configurar los datos y series de su empresa	2026-09-20 19:58:52.262673-05
07128133-5d2e-421a-b042-0b226a7d8776	facturacion:sunat	facturacion	sunat	Cargar o corregir la respuesta de SUNAT	2026-09-20 19:58:52.262673-05
\.


--
-- Data for Name: permisos_laborales; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.permisos_laborales (id, empresa_id, user_id, tipo, fecha_inicio, fecha_fin, hora_inicio, hora_fin, motivo, estado, aprobado_por, aprobado_at, comentario_aprobacion, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: plantillas_mensaje; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.plantillas_mensaje (id, empresa_id, tipo, canal, nombre, texto, estado, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: productos; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.productos (id, empresa_id, codigo, codigo_barras, nombre, descripcion, tipo, categoria_id, principio_activo, laboratorio, presentacion, unidad_medida, requiere_receta, controlado, refrigerado, precio_compra, precio_venta, margen_pct, afecto_igv, stock_actual, stock_minimo, stock_maximo, maneja_lotes, estado, created_at, updated_at, deleted_at, created_by, updated_by) FROM stdin;
5197b443-2077-49ff-97dc-784ce06c27ea	1ba3bd1a-4075-4009-b992-7057472e1e56	PRD-0001	\N	Vacuna antirrábica canina	\N	vacuna	\N	Virus rábico inactivado	Zoetis	Frasco 1 dosis	UND	t	f	t	18.00	45.00	\N	t	40.00	20.00	\N	t	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N
3a26ca77-3d71-4964-acf5-eacfc6eeb479	1ba3bd1a-4075-4009-b992-7057472e1e56	PRD-0002	\N	Vacuna quíntuple canina	\N	vacuna	\N	Vanguard Plus 5	Zoetis	Frasco 1 dosis	UND	t	f	t	28.00	65.00	\N	t	40.00	15.00	\N	t	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N
535ffa99-0ab3-4c7b-a753-7d42b7d21894	1ba3bd1a-4075-4009-b992-7057472e1e56	PRD-0003	\N	Vacuna triple felina	\N	vacuna	\N	Felocell 3	Zoetis	Frasco 1 dosis	UND	t	f	t	30.00	70.00	\N	t	40.00	10.00	\N	t	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N
33aa9c82-ab26-4a59-8b0f-7550accda742	1ba3bd1a-4075-4009-b992-7057472e1e56	PRD-0004	\N	Amoxicilina 500 mg	\N	medicamento	b318d63c-9f8d-46d0-90fe-f2b563521ce6	Amoxicilina	Genérico	Caja x 20 tabletas	CAJA	t	f	f	22.00	48.00	\N	t	40.00	10.00	\N	t	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N
342d9253-5690-4114-8da3-394eaae27f4d	1ba3bd1a-4075-4009-b992-7057472e1e56	PRD-0005	\N	Meloxicam 1,5 mg/ml	\N	medicamento	b318d63c-9f8d-46d0-90fe-f2b563521ce6	Meloxicam	Boehringer	Frasco 10 ml	UND	t	f	f	35.00	72.00	\N	t	40.00	8.00	\N	t	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N
5acf001e-68e8-449f-be32-2f03a06e0d7a	1ba3bd1a-4075-4009-b992-7057472e1e56	PRD-0006	\N	Ivermectina inyectable	\N	medicamento	b318d63c-9f8d-46d0-90fe-f2b563521ce6	Ivermectina 1%	Agrovet	Frasco 50 ml	UND	t	f	f	28.00	60.00	\N	t	40.00	6.00	\N	t	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N
430c17cf-0b6f-452c-bd6a-25b2fa13741f	1ba3bd1a-4075-4009-b992-7057472e1e56	PRD-0007	\N	Antiparasitario oral	\N	medicamento	b318d63c-9f8d-46d0-90fe-f2b563521ce6	Praziquantel + Pirantel	Bayer	Caja x 4 tabletas	CAJA	f	f	f	14.00	32.00	\N	t	40.00	15.00	\N	t	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N
71e823f6-3cd6-4e63-ad6f-c276ab8c4780	1ba3bd1a-4075-4009-b992-7057472e1e56	PRD-0008	\N	Suero fisiológico 0,9%	\N	insumo	\N	Cloruro de sodio	Genérico	Bolsa 500 ml	UND	f	f	f	6.50	15.00	\N	t	120.00	25.00	\N	f	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N
828b6821-c928-46ca-a9f1-dee6d771b855	1ba3bd1a-4075-4009-b992-7057472e1e56	PRD-0009	\N	Jeringa 5 ml estéril	\N	insumo	\N	\N	Nipro	Unidad	UND	f	f	f	0.60	1.50	\N	t	120.00	100.00	\N	f	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N
188a1d71-db83-46b3-9bc2-eabee528fdfc	1ba3bd1a-4075-4009-b992-7057472e1e56	PRD-0010	\N	Gasa estéril 10x10	\N	insumo	\N	\N	Genérico	Paquete x 10	PQT	f	f	f	3.50	8.00	\N	t	120.00	30.00	\N	f	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N
6a3b4ab7-0337-4d68-8162-b680c554bd0e	1ba3bd1a-4075-4009-b992-7057472e1e56	PRD-0011	\N	Sutura absorbible 3/0	\N	insumo	\N	Ácido poliglicólico	Ethicon	Sobre unidad	UND	f	f	f	12.00	26.00	\N	t	120.00	20.00	\N	t	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N
78a55878-39f1-44ce-9870-45b64caa4899	1ba3bd1a-4075-4009-b992-7057472e1e56	PRD-0012	\N	Alimento medicado renal 3 kg	\N	alimento	ce0682e6-d0b1-4e55-902a-ce02dbb45ce0	\N	Royal Canin	Bolsa 3 kg	UND	f	f	f	78.00	145.00	\N	t	12.00	6.00	\N	f	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N
0f7bcb71-f93c-4a51-89a5-18e0ff0fb0d6	1ba3bd1a-4075-4009-b992-7057472e1e56	PRD-0013	\N	Alimento cachorro 15 kg	\N	alimento	ce0682e6-d0b1-4e55-902a-ce02dbb45ce0	\N	Pro Plan	Bolsa 15 kg	UND	f	f	f	145.00	235.00	\N	t	12.00	4.00	\N	f	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N
3365e863-88c4-4e0d-acd1-17cb6af032fd	1ba3bd1a-4075-4009-b992-7057472e1e56	PRD-0014	\N	Shampoo medicado clorhexidina	\N	medicamento	b318d63c-9f8d-46d0-90fe-f2b563521ce6	Clorhexidina 2%	Virbac	Frasco 250 ml	UND	f	f	f	32.00	68.00	\N	t	40.00	8.00	\N	f	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N
63916ee9-bd0e-4d14-812c-1ce3b567ab6c	1ba3bd1a-4075-4009-b992-7057472e1e56	PRD-0015	\N	Collar isabelino mediano	\N	accesorio	\N	\N	Genérico	Unidad	UND	f	f	f	12.00	28.00	\N	t	40.00	10.00	\N	f	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N
e42496b2-d4f7-46f1-9817-5e94a7c527c4	a64719a9-57fc-4ac0-b104-b9d861370dc7	PRD-0001	\N	Vacuna antirrábica canina	\N	vacuna	\N	\N	\N	Frasco 1 dosis	UND	f	f	f	18.00	50.00	\N	t	30.00	15.00	\N	f	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N
31c219b2-abd2-4cf5-9bf2-563598c49d93	a64719a9-57fc-4ac0-b104-b9d861370dc7	PRD-0002	\N	Amoxicilina 500 mg	\N	medicamento	\N	\N	\N	Caja x 20 tabletas	CAJA	f	f	f	22.00	52.00	\N	t	30.00	10.00	\N	f	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N
ee3a9fba-8417-4784-99af-b869ddb996fa	a64719a9-57fc-4ac0-b104-b9d861370dc7	PRD-0003	\N	Jeringa 5 ml estéril	\N	insumo	\N	\N	\N	Unidad	UND	f	f	f	0.60	1.60	\N	t	100.00	80.00	\N	f	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N
271b60e3-dd2b-459e-9e49-5d1110e74b7c	a64719a9-57fc-4ac0-b104-b9d861370dc7	PRD-0004	\N	Suero fisiológico 0,9%	\N	insumo	\N	\N	\N	Bolsa 500 ml	UND	f	f	f	6.50	16.00	\N	t	100.00	20.00	\N	f	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N
\.


--
-- Data for Name: proveedor_contactos; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.proveedor_contactos (id, proveedor_id, nombres, cargo, telefono, correo, es_principal, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: proveedores; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.proveedores (id, empresa_id, codigo, tipo_documento, numero_documento, razon_social, nombre_comercial, categoria_id, direccion, telefono, correo, web, dias_credito, cuenta_bancaria, banco, estado, observaciones, created_at, updated_at, deleted_at, created_by, updated_by) FROM stdin;
d3e627f1-df4d-4071-8544-b2143806f892	1ba3bd1a-4075-4009-b992-7057472e1e56	PRV-0001	RUC	20512345678	Distribuidora Veterinaria Andina S.A.C.	DistriVet	4225f4a2-33bb-43a8-a4d5-7bc1948ae857	Av. Colonial 2450, Lima	013344556	ventas@distrivet.pe	\N	30	\N	BCP	activo	\N	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N
411ca471-b105-43ee-a275-740e5ad28db3	1ba3bd1a-4075-4009-b992-7057472e1e56	PRV-0002	RUC	20487654321	Laboratorios Zoetis Perú S.A.	Zoetis	4225f4a2-33bb-43a8-a4d5-7bc1948ae857	Av. Canaval y Moreyra 380, San Isidro	012223344	pedidos@zoetis.pe	\N	45	\N	BBVA	activo	\N	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N
cff12da2-beb0-4aec-a0f4-6cc77eed998e	1ba3bd1a-4075-4009-b992-7057472e1e56	PRV-0003	RUC	20556677889	Nutrición Animal del Perú S.A.C.	NutriPet	\N	Av. Argentina 1500, Callao	014455667	contacto@nutripet.pe	\N	15	\N	Interbank	activo	\N	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N
\.


--
-- Data for Name: razas; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.razas (id, especie_id, empresa_id, nombre, tamanio_referencia, peso_min_kg, peso_max_kg, esperanza_vida, estado, created_at, updated_at) FROM stdin;
1f5262bb-287e-4a16-9725-23174cc551da	ea82e665-7d26-4287-8e61-a6b786b8a5df	\N	Husky Siberiano	grande	16.00	27.00	12	activo	2026-09-20 19:58:52.284919-05	2026-09-20 19:58:52.284919-05
02f53036-4059-4c41-bb9c-0a0833945c8c	ea82e665-7d26-4287-8e61-a6b786b8a5df	\N	Pug	pequenio	6.00	8.00	13	activo	2026-09-20 19:58:52.284919-05	2026-09-20 19:58:52.284919-05
2dbac0f4-262e-4473-b7f5-579e72934d48	ea82e665-7d26-4287-8e61-a6b786b8a5df	\N	Cocker Spaniel	mediano	12.00	15.00	13	activo	2026-09-20 19:58:52.284919-05	2026-09-20 19:58:52.284919-05
e65967a9-6388-4842-8bd3-e0a43a3ae48e	ea82e665-7d26-4287-8e61-a6b786b8a5df	\N	Border Collie	mediano	14.00	20.00	13	activo	2026-09-20 19:58:52.284919-05	2026-09-20 19:58:52.284919-05
53e5b45c-b491-429e-9258-0bb9ddd59dfe	ea82e665-7d26-4287-8e61-a6b786b8a5df	\N	Rottweiler	grande	35.00	60.00	10	activo	2026-09-20 19:58:52.284919-05	2026-09-20 19:58:52.284919-05
99ea5072-4d10-4e45-9e6f-7556ab1983e8	ea82e665-7d26-4287-8e61-a6b786b8a5df	\N	Yorkshire Terrier	toy	2.00	3.50	15	activo	2026-09-20 19:58:52.284919-05	2026-09-20 19:58:52.284919-05
893ba9e2-e738-4883-921c-70d772feff5b	ea82e665-7d26-4287-8e61-a6b786b8a5df	\N	Schnauzer	mediano	6.00	9.00	14	activo	2026-09-20 19:58:52.284919-05	2026-09-20 19:58:52.284919-05
6f999bc3-190e-4b2f-ac27-1fe996ed299a	ea82e665-7d26-4287-8e61-a6b786b8a5df	\N	Beagle	mediano	9.00	11.00	13	activo	2026-09-20 19:58:52.284919-05	2026-09-20 19:58:52.284919-05
2c41a73c-44ce-4e95-8855-d0f7e529436f	ea82e665-7d26-4287-8e61-a6b786b8a5df	\N	Shih Tzu	pequenio	4.00	7.50	14	activo	2026-09-20 19:58:52.284919-05	2026-09-20 19:58:52.284919-05
edb8921b-05a4-4f26-a51c-175f09b0168f	ea82e665-7d26-4287-8e61-a6b786b8a5df	\N	Chihuahua	toy	1.50	3.00	16	activo	2026-09-20 19:58:52.284919-05	2026-09-20 19:58:52.284919-05
9cae2c0b-bcd0-490d-87fb-ade7693d2c18	ea82e665-7d26-4287-8e61-a6b786b8a5df	\N	Poodle	pequenio	3.00	8.00	15	activo	2026-09-20 19:58:52.284919-05	2026-09-20 19:58:52.284919-05
ec90f3e5-2d30-42fe-be6e-c5442bc1ed3e	ea82e665-7d26-4287-8e61-a6b786b8a5df	\N	Bulldog Francés	pequenio	8.00	14.00	11	activo	2026-09-20 19:58:52.284919-05	2026-09-20 19:58:52.284919-05
bb94f809-a643-4df2-9490-6f6c284b49c8	ea82e665-7d26-4287-8e61-a6b786b8a5df	\N	Pastor Alemán	grande	22.00	40.00	11	activo	2026-09-20 19:58:52.284919-05	2026-09-20 19:58:52.284919-05
377e1589-8563-4d44-a6e2-caf493061c26	ea82e665-7d26-4287-8e61-a6b786b8a5df	\N	Golden Retriever	grande	25.00	34.00	12	activo	2026-09-20 19:58:52.284919-05	2026-09-20 19:58:52.284919-05
620fbc54-6337-4778-9f0f-ed2e6794d564	ea82e665-7d26-4287-8e61-a6b786b8a5df	\N	Labrador Retriever	grande	25.00	36.00	12	activo	2026-09-20 19:58:52.284919-05	2026-09-20 19:58:52.284919-05
a9e5c66a-bde9-4af5-babe-ee6f4aa3fd27	ea82e665-7d26-4287-8e61-a6b786b8a5df	\N	Mestizo	mediano	5.00	30.00	14	activo	2026-09-20 19:58:52.284919-05	2026-09-20 19:58:52.284919-05
08cfb1be-3f3b-410e-bcb6-742a11d2a469	2e253998-3b20-42b9-a228-a5cb7ddc3394	\N	Esfinge	mediano	3.50	5.00	14	activo	2026-09-20 19:58:52.284919-05	2026-09-20 19:58:52.284919-05
d9a3d5d5-6e86-4998-8404-ebcdc23d4c71	2e253998-3b20-42b9-a228-a5cb7ddc3394	\N	Bengalí	mediano	4.00	7.00	15	activo	2026-09-20 19:58:52.284919-05	2026-09-20 19:58:52.284919-05
e3d3d827-1ab8-45b9-a4f5-e9f64b26dfd6	2e253998-3b20-42b9-a228-a5cb7ddc3394	\N	Maine Coon	grande	5.00	11.00	13	activo	2026-09-20 19:58:52.284919-05	2026-09-20 19:58:52.284919-05
ea461041-3bc4-4576-b65b-039115d7a081	2e253998-3b20-42b9-a228-a5cb7ddc3394	\N	Angora	mediano	2.50	5.00	15	activo	2026-09-20 19:58:52.284919-05	2026-09-20 19:58:52.284919-05
cd05c847-2fae-433d-920b-0ab37bd1f7d8	2e253998-3b20-42b9-a228-a5cb7ddc3394	\N	Persa	mediano	3.00	5.50	15	activo	2026-09-20 19:58:52.284919-05	2026-09-20 19:58:52.284919-05
6011ef97-78ab-4de0-b8f9-fc95b6195d09	2e253998-3b20-42b9-a228-a5cb7ddc3394	\N	Siamés	mediano	2.50	5.50	16	activo	2026-09-20 19:58:52.284919-05	2026-09-20 19:58:52.284919-05
2a8e2678-1db8-4813-8813-23493bccdc09	2e253998-3b20-42b9-a228-a5cb7ddc3394	\N	Mestizo	mediano	3.00	6.00	15	activo	2026-09-20 19:58:52.284919-05	2026-09-20 19:58:52.284919-05
07120108-5aba-44bf-9b4d-cfb85d1e75a8	522afbf5-2d53-4c55-969b-9ed9d6fb36b2	\N	Loro	pequenio	0.40	1.50	50	activo	2026-09-20 19:58:52.284919-05	2026-09-20 19:58:52.284919-05
467238eb-83be-4df8-93ad-46a5bcdbc714	522afbf5-2d53-4c55-969b-9ed9d6fb36b2	\N	Cacatúa	pequenio	0.30	1.20	40	activo	2026-09-20 19:58:52.284919-05	2026-09-20 19:58:52.284919-05
14ffb19f-ed6d-4af2-ac78-22b4065b6468	522afbf5-2d53-4c55-969b-9ed9d6fb36b2	\N	Periquito	toy	0.03	0.04	12	activo	2026-09-20 19:58:52.284919-05	2026-09-20 19:58:52.284919-05
61a3d7e0-5acf-4851-8de6-56a8c586f07e	522afbf5-2d53-4c55-969b-9ed9d6fb36b2	\N	Canario	toy	0.02	0.03	10	activo	2026-09-20 19:58:52.284919-05	2026-09-20 19:58:52.284919-05
e8e22e3f-28b2-4317-97e2-4a0ea6e45a46	ff5ae48c-b35a-4606-84a6-65e6a602e2eb	\N	Chinchilla	pequenio	0.40	0.80	15	activo	2026-09-20 19:58:52.284919-05	2026-09-20 19:58:52.284919-05
5dd8a14a-7659-4824-9339-2e45b0e7b1cd	ff5ae48c-b35a-4606-84a6-65e6a602e2eb	\N	Cuy	pequenio	0.70	1.20	6	activo	2026-09-20 19:58:52.284919-05	2026-09-20 19:58:52.284919-05
78c6ae88-d144-462c-9129-f01d5e245c9a	ff5ae48c-b35a-4606-84a6-65e6a602e2eb	\N	Hámster	toy	0.02	0.20	3	activo	2026-09-20 19:58:52.284919-05	2026-09-20 19:58:52.284919-05
14d3a89f-fd57-4e5b-bd61-66d67ce496c0	4909f69d-4881-4bf7-9b29-bb3d62406f73	\N	Cabeza de León	pequenio	1.20	1.80	9	activo	2026-09-20 19:58:52.284919-05	2026-09-20 19:58:52.284919-05
3eba844c-ede0-434f-806f-f95a38ee11d0	4909f69d-4881-4bf7-9b29-bb3d62406f73	\N	Mini Lop	pequenio	1.30	2.50	9	activo	2026-09-20 19:58:52.284919-05	2026-09-20 19:58:52.284919-05
6de9054c-4633-4699-aa14-82b782e2c95f	fe404847-62bc-4aeb-adfd-2dbf7e4986f1	\N	Iguana	mediano	1.00	8.00	15	activo	2026-09-20 19:58:52.284919-05	2026-09-20 19:58:52.284919-05
2ebd6a5d-2be0-4f1a-9760-3c7accf0b56a	fe404847-62bc-4aeb-adfd-2dbf7e4986f1	\N	Tortuga terrestre	pequenio	0.50	5.00	50	activo	2026-09-20 19:58:52.284919-05	2026-09-20 19:58:52.284919-05
\.


--
-- Data for Name: recordatorios; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.recordatorios (id, empresa_id, cliente_id, mascota_id, tipo, titulo, mensaje, fecha_objetivo, canal, enviado_at, completado, entidad_ref, entidad_id, created_at) FROM stdin;
\.


--
-- Data for Name: rol_permisos; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.rol_permisos (rol_id, permiso_id, created_at) FROM stdin;
1afb8576-af29-4f85-ae59-93bd22142499	d5a8bc61-ca3f-4679-be57-3f2b751c2a37	2026-09-20 19:58:52.26919-05
1afb8576-af29-4f85-ae59-93bd22142499	b63a0aeb-cec4-4d45-824b-926cc4f4ca57	2026-09-20 19:58:52.26919-05
1afb8576-af29-4f85-ae59-93bd22142499	56e930f9-cdb2-4f85-99a9-c6bd0a088a9f	2026-09-20 19:58:52.26919-05
1afb8576-af29-4f85-ae59-93bd22142499	0809cf0b-eb5d-47c2-940d-acb6df787c28	2026-09-20 19:58:52.26919-05
1afb8576-af29-4f85-ae59-93bd22142499	6ea8dd2d-16b3-4ca0-ad20-151bbb7dfc04	2026-09-20 19:58:52.26919-05
1afb8576-af29-4f85-ae59-93bd22142499	e4593c14-13d4-4e25-975a-8988bdfd0ce5	2026-09-20 19:58:52.26919-05
1afb8576-af29-4f85-ae59-93bd22142499	7ddff749-fcb8-4ea4-a5e4-ce0faebfea50	2026-09-20 19:58:52.26919-05
1afb8576-af29-4f85-ae59-93bd22142499	4e61cf46-b447-40f9-82c8-2081456016a5	2026-09-20 19:58:52.26919-05
1afb8576-af29-4f85-ae59-93bd22142499	0cf699f4-9a35-4bef-8422-3cd33677b296	2026-09-20 19:58:52.26919-05
1afb8576-af29-4f85-ae59-93bd22142499	c24a182b-b8df-4c39-9970-3b88772fcc01	2026-09-20 19:58:52.26919-05
1afb8576-af29-4f85-ae59-93bd22142499	a1303cff-f739-4e3e-98ce-4dbb62ef8239	2026-09-20 19:58:52.26919-05
1afb8576-af29-4f85-ae59-93bd22142499	e7a4ff4b-6803-46fa-b7d6-ee0a9c947606	2026-09-20 19:58:52.26919-05
1afb8576-af29-4f85-ae59-93bd22142499	66f2f759-1697-4a5b-9777-cc059002862a	2026-09-20 19:58:52.26919-05
1afb8576-af29-4f85-ae59-93bd22142499	1e357e9e-0dce-44f4-8cc3-39696c43d2ad	2026-09-20 19:58:52.26919-05
62bbd548-dcaf-452b-a61e-9c91a436a9b4	d5a8bc61-ca3f-4679-be57-3f2b751c2a37	2026-09-20 19:58:52.271875-05
62bbd548-dcaf-452b-a61e-9c91a436a9b4	b63a0aeb-cec4-4d45-824b-926cc4f4ca57	2026-09-20 19:58:52.271875-05
62bbd548-dcaf-452b-a61e-9c91a436a9b4	6948b9fa-0798-4cab-8e21-5fe97e78cbe9	2026-09-20 19:58:52.271875-05
62bbd548-dcaf-452b-a61e-9c91a436a9b4	b92e16fe-4f82-4a62-a310-b06239069ade	2026-09-20 19:58:52.271875-05
62bbd548-dcaf-452b-a61e-9c91a436a9b4	d8670e30-71c7-425d-b918-97e3cf857a07	2026-09-20 19:58:52.271875-05
62bbd548-dcaf-452b-a61e-9c91a436a9b4	56e930f9-cdb2-4f85-99a9-c6bd0a088a9f	2026-09-20 19:58:52.271875-05
62bbd548-dcaf-452b-a61e-9c91a436a9b4	1ca0f0ee-eef7-418e-a06d-979f2bdabcc7	2026-09-20 19:58:52.271875-05
62bbd548-dcaf-452b-a61e-9c91a436a9b4	7d1d445c-5b4a-47ad-9d76-754b093aaa09	2026-09-20 19:58:52.271875-05
62bbd548-dcaf-452b-a61e-9c91a436a9b4	8fe8a3e7-d4f6-4064-94e4-1f794d8b6c6a	2026-09-20 19:58:52.271875-05
62bbd548-dcaf-452b-a61e-9c91a436a9b4	0809cf0b-eb5d-47c2-940d-acb6df787c28	2026-09-20 19:58:52.271875-05
62bbd548-dcaf-452b-a61e-9c91a436a9b4	665d7baf-0f89-4ef9-896a-967de9338066	2026-09-20 19:58:52.271875-05
62bbd548-dcaf-452b-a61e-9c91a436a9b4	e0e9f953-87c2-4936-aba9-286b5121671a	2026-09-20 19:58:52.271875-05
62bbd548-dcaf-452b-a61e-9c91a436a9b4	d866c3d3-2230-4024-a135-dbe419da7669	2026-09-20 19:58:52.271875-05
62bbd548-dcaf-452b-a61e-9c91a436a9b4	6ea8dd2d-16b3-4ca0-ad20-151bbb7dfc04	2026-09-20 19:58:52.271875-05
62bbd548-dcaf-452b-a61e-9c91a436a9b4	0b58c7ec-6189-4eed-a330-a93767e82a39	2026-09-20 19:58:52.271875-05
62bbd548-dcaf-452b-a61e-9c91a436a9b4	3bdaf794-c122-4410-adb3-8b91d508afe8	2026-09-20 19:58:52.271875-05
62bbd548-dcaf-452b-a61e-9c91a436a9b4	ac6de34d-afa5-4c78-a948-c5b554608851	2026-09-20 19:58:52.271875-05
62bbd548-dcaf-452b-a61e-9c91a436a9b4	e4593c14-13d4-4e25-975a-8988bdfd0ce5	2026-09-20 19:58:52.271875-05
62bbd548-dcaf-452b-a61e-9c91a436a9b4	342ca47e-6b3a-4cc3-8afb-5c34a97d5720	2026-09-20 19:58:52.271875-05
62bbd548-dcaf-452b-a61e-9c91a436a9b4	e2053b44-a0ea-4196-929e-410f0d48afd0	2026-09-20 19:58:52.271875-05
62bbd548-dcaf-452b-a61e-9c91a436a9b4	7ddff749-fcb8-4ea4-a5e4-ce0faebfea50	2026-09-20 19:58:52.271875-05
62bbd548-dcaf-452b-a61e-9c91a436a9b4	3995ac52-0e45-4a2a-ba17-00aabffb501e	2026-09-20 19:58:52.271875-05
62bbd548-dcaf-452b-a61e-9c91a436a9b4	1c9725e4-0861-491d-a6a0-7333367b006d	2026-09-20 19:58:52.271875-05
62bbd548-dcaf-452b-a61e-9c91a436a9b4	8fc1c674-9a20-4d00-8ffa-09a808151cc3	2026-09-20 19:58:52.271875-05
62bbd548-dcaf-452b-a61e-9c91a436a9b4	4e61cf46-b447-40f9-82c8-2081456016a5	2026-09-20 19:58:52.271875-05
62bbd548-dcaf-452b-a61e-9c91a436a9b4	db018279-91f0-4aca-9a9f-a65abb4e27f3	2026-09-20 19:58:52.271875-05
62bbd548-dcaf-452b-a61e-9c91a436a9b4	504f64eb-395a-49c9-8fa1-27722a43ca37	2026-09-20 19:58:52.271875-05
62bbd548-dcaf-452b-a61e-9c91a436a9b4	0cf699f4-9a35-4bef-8422-3cd33677b296	2026-09-20 19:58:52.271875-05
62bbd548-dcaf-452b-a61e-9c91a436a9b4	fecc62a8-85bf-4080-8821-96a1726ea733	2026-09-20 19:58:52.271875-05
62bbd548-dcaf-452b-a61e-9c91a436a9b4	3ddca28c-069d-41ab-91ae-18f2c78ce38d	2026-09-20 19:58:52.271875-05
62bbd548-dcaf-452b-a61e-9c91a436a9b4	df8cf7e3-ffe7-4da1-977a-000aa9e8ed19	2026-09-20 19:58:52.271875-05
62bbd548-dcaf-452b-a61e-9c91a436a9b4	c24a182b-b8df-4c39-9970-3b88772fcc01	2026-09-20 19:58:52.271875-05
62bbd548-dcaf-452b-a61e-9c91a436a9b4	a1303cff-f739-4e3e-98ce-4dbb62ef8239	2026-09-20 19:58:52.271875-05
62bbd548-dcaf-452b-a61e-9c91a436a9b4	524d298d-5abd-48fe-a4a2-d29216a0d104	2026-09-20 19:58:52.271875-05
62bbd548-dcaf-452b-a61e-9c91a436a9b4	3e83caba-50ba-4abc-a079-f7ec12616d73	2026-09-20 19:58:52.271875-05
62bbd548-dcaf-452b-a61e-9c91a436a9b4	e7a4ff4b-6803-46fa-b7d6-ee0a9c947606	2026-09-20 19:58:52.271875-05
62bbd548-dcaf-452b-a61e-9c91a436a9b4	66f2f759-1697-4a5b-9777-cc059002862a	2026-09-20 19:58:52.271875-05
62bbd548-dcaf-452b-a61e-9c91a436a9b4	5221f2ec-1469-4f33-b5fc-dd8bbaf83755	2026-09-20 19:58:52.271875-05
62bbd548-dcaf-452b-a61e-9c91a436a9b4	adf808ab-557c-4658-ad47-b485bb24223e	2026-09-20 19:58:52.271875-05
62bbd548-dcaf-452b-a61e-9c91a436a9b4	59badc62-ac6d-4063-818a-14c220cf741c	2026-09-20 19:58:52.271875-05
62bbd548-dcaf-452b-a61e-9c91a436a9b4	99359ab3-0ee4-48cc-8a85-56a4e9bd9467	2026-09-20 19:58:52.271875-05
62bbd548-dcaf-452b-a61e-9c91a436a9b4	21bf3005-2ccb-4ce4-b25f-fdcddbe41cce	2026-09-20 19:58:52.271875-05
62bbd548-dcaf-452b-a61e-9c91a436a9b4	1e357e9e-0dce-44f4-8cc3-39696c43d2ad	2026-09-20 19:58:52.271875-05
62bbd548-dcaf-452b-a61e-9c91a436a9b4	e88bb4f2-ab1b-41cb-8f8f-15f2f22d7b59	2026-09-20 19:58:52.271875-05
62bbd548-dcaf-452b-a61e-9c91a436a9b4	07128133-5d2e-421a-b042-0b226a7d8776	2026-09-20 19:58:52.271875-05
de4c9b73-5d17-4b01-92b1-392c07404df9	d5a8bc61-ca3f-4679-be57-3f2b751c2a37	2026-09-20 19:58:52.274456-05
de4c9b73-5d17-4b01-92b1-392c07404df9	b63a0aeb-cec4-4d45-824b-926cc4f4ca57	2026-09-20 19:58:52.274456-05
de4c9b73-5d17-4b01-92b1-392c07404df9	6948b9fa-0798-4cab-8e21-5fe97e78cbe9	2026-09-20 19:58:52.274456-05
de4c9b73-5d17-4b01-92b1-392c07404df9	b92e16fe-4f82-4a62-a310-b06239069ade	2026-09-20 19:58:52.274456-05
de4c9b73-5d17-4b01-92b1-392c07404df9	56e930f9-cdb2-4f85-99a9-c6bd0a088a9f	2026-09-20 19:58:52.274456-05
de4c9b73-5d17-4b01-92b1-392c07404df9	1ca0f0ee-eef7-418e-a06d-979f2bdabcc7	2026-09-20 19:58:52.274456-05
de4c9b73-5d17-4b01-92b1-392c07404df9	7d1d445c-5b4a-47ad-9d76-754b093aaa09	2026-09-20 19:58:52.274456-05
de4c9b73-5d17-4b01-92b1-392c07404df9	0809cf0b-eb5d-47c2-940d-acb6df787c28	2026-09-20 19:58:52.274456-05
de4c9b73-5d17-4b01-92b1-392c07404df9	665d7baf-0f89-4ef9-896a-967de9338066	2026-09-20 19:58:52.274456-05
de4c9b73-5d17-4b01-92b1-392c07404df9	e0e9f953-87c2-4936-aba9-286b5121671a	2026-09-20 19:58:52.274456-05
de4c9b73-5d17-4b01-92b1-392c07404df9	6ea8dd2d-16b3-4ca0-ad20-151bbb7dfc04	2026-09-20 19:58:52.274456-05
de4c9b73-5d17-4b01-92b1-392c07404df9	0b58c7ec-6189-4eed-a330-a93767e82a39	2026-09-20 19:58:52.274456-05
de4c9b73-5d17-4b01-92b1-392c07404df9	e4593c14-13d4-4e25-975a-8988bdfd0ce5	2026-09-20 19:58:52.274456-05
de4c9b73-5d17-4b01-92b1-392c07404df9	e2053b44-a0ea-4196-929e-410f0d48afd0	2026-09-20 19:58:52.274456-05
de4c9b73-5d17-4b01-92b1-392c07404df9	a1303cff-f739-4e3e-98ce-4dbb62ef8239	2026-09-20 19:58:52.274456-05
de4c9b73-5d17-4b01-92b1-392c07404df9	e7a4ff4b-6803-46fa-b7d6-ee0a9c947606	2026-09-20 19:58:52.274456-05
05e83714-54bc-47f9-9b90-164c3a729afa	d5a8bc61-ca3f-4679-be57-3f2b751c2a37	2026-09-20 19:58:52.276132-05
05e83714-54bc-47f9-9b90-164c3a729afa	b63a0aeb-cec4-4d45-824b-926cc4f4ca57	2026-09-20 19:58:52.276132-05
05e83714-54bc-47f9-9b90-164c3a729afa	6948b9fa-0798-4cab-8e21-5fe97e78cbe9	2026-09-20 19:58:52.276132-05
05e83714-54bc-47f9-9b90-164c3a729afa	b92e16fe-4f82-4a62-a310-b06239069ade	2026-09-20 19:58:52.276132-05
05e83714-54bc-47f9-9b90-164c3a729afa	56e930f9-cdb2-4f85-99a9-c6bd0a088a9f	2026-09-20 19:58:52.276132-05
05e83714-54bc-47f9-9b90-164c3a729afa	1ca0f0ee-eef7-418e-a06d-979f2bdabcc7	2026-09-20 19:58:52.276132-05
05e83714-54bc-47f9-9b90-164c3a729afa	7d1d445c-5b4a-47ad-9d76-754b093aaa09	2026-09-20 19:58:52.276132-05
05e83714-54bc-47f9-9b90-164c3a729afa	0809cf0b-eb5d-47c2-940d-acb6df787c28	2026-09-20 19:58:52.276132-05
05e83714-54bc-47f9-9b90-164c3a729afa	665d7baf-0f89-4ef9-896a-967de9338066	2026-09-20 19:58:52.276132-05
05e83714-54bc-47f9-9b90-164c3a729afa	e0e9f953-87c2-4936-aba9-286b5121671a	2026-09-20 19:58:52.276132-05
05e83714-54bc-47f9-9b90-164c3a729afa	d866c3d3-2230-4024-a135-dbe419da7669	2026-09-20 19:58:52.276132-05
05e83714-54bc-47f9-9b90-164c3a729afa	6ea8dd2d-16b3-4ca0-ad20-151bbb7dfc04	2026-09-20 19:58:52.276132-05
05e83714-54bc-47f9-9b90-164c3a729afa	e4593c14-13d4-4e25-975a-8988bdfd0ce5	2026-09-20 19:58:52.276132-05
05e83714-54bc-47f9-9b90-164c3a729afa	4e61cf46-b447-40f9-82c8-2081456016a5	2026-09-20 19:58:52.276132-05
05e83714-54bc-47f9-9b90-164c3a729afa	db018279-91f0-4aca-9a9f-a65abb4e27f3	2026-09-20 19:58:52.276132-05
05e83714-54bc-47f9-9b90-164c3a729afa	0cf699f4-9a35-4bef-8422-3cd33677b296	2026-09-20 19:58:52.276132-05
05e83714-54bc-47f9-9b90-164c3a729afa	fecc62a8-85bf-4080-8821-96a1726ea733	2026-09-20 19:58:52.276132-05
05e83714-54bc-47f9-9b90-164c3a729afa	df8cf7e3-ffe7-4da1-977a-000aa9e8ed19	2026-09-20 19:58:52.276132-05
05e83714-54bc-47f9-9b90-164c3a729afa	c24a182b-b8df-4c39-9970-3b88772fcc01	2026-09-20 19:58:52.276132-05
7a73b6b1-e683-45c4-9056-95d07d7e42cb	d5a8bc61-ca3f-4679-be57-3f2b751c2a37	2026-09-20 19:58:52.277886-05
7a73b6b1-e683-45c4-9056-95d07d7e42cb	e4593c14-13d4-4e25-975a-8988bdfd0ce5	2026-09-20 19:58:52.277886-05
7a73b6b1-e683-45c4-9056-95d07d7e42cb	342ca47e-6b3a-4cc3-8afb-5c34a97d5720	2026-09-20 19:58:52.277886-05
7a73b6b1-e683-45c4-9056-95d07d7e42cb	e2053b44-a0ea-4196-929e-410f0d48afd0	2026-09-20 19:58:52.277886-05
7a73b6b1-e683-45c4-9056-95d07d7e42cb	7ddff749-fcb8-4ea4-a5e4-ce0faebfea50	2026-09-20 19:58:52.277886-05
7a73b6b1-e683-45c4-9056-95d07d7e42cb	3995ac52-0e45-4a2a-ba17-00aabffb501e	2026-09-20 19:58:52.277886-05
7a73b6b1-e683-45c4-9056-95d07d7e42cb	1c9725e4-0861-491d-a6a0-7333367b006d	2026-09-20 19:58:52.277886-05
7a73b6b1-e683-45c4-9056-95d07d7e42cb	e7a4ff4b-6803-46fa-b7d6-ee0a9c947606	2026-09-20 19:58:52.277886-05
937d8f64-aa45-44a9-b13e-b1d2f49233f1	d5a8bc61-ca3f-4679-be57-3f2b751c2a37	2026-09-20 19:58:52.279402-05
937d8f64-aa45-44a9-b13e-b1d2f49233f1	b63a0aeb-cec4-4d45-824b-926cc4f4ca57	2026-09-20 19:58:52.279402-05
937d8f64-aa45-44a9-b13e-b1d2f49233f1	e4593c14-13d4-4e25-975a-8988bdfd0ce5	2026-09-20 19:58:52.279402-05
937d8f64-aa45-44a9-b13e-b1d2f49233f1	7ddff749-fcb8-4ea4-a5e4-ce0faebfea50	2026-09-20 19:58:52.279402-05
937d8f64-aa45-44a9-b13e-b1d2f49233f1	8fc1c674-9a20-4d00-8ffa-09a808151cc3	2026-09-20 19:58:52.279402-05
937d8f64-aa45-44a9-b13e-b1d2f49233f1	4e61cf46-b447-40f9-82c8-2081456016a5	2026-09-20 19:58:52.279402-05
937d8f64-aa45-44a9-b13e-b1d2f49233f1	db018279-91f0-4aca-9a9f-a65abb4e27f3	2026-09-20 19:58:52.279402-05
937d8f64-aa45-44a9-b13e-b1d2f49233f1	504f64eb-395a-49c9-8fa1-27722a43ca37	2026-09-20 19:58:52.279402-05
937d8f64-aa45-44a9-b13e-b1d2f49233f1	0cf699f4-9a35-4bef-8422-3cd33677b296	2026-09-20 19:58:52.279402-05
937d8f64-aa45-44a9-b13e-b1d2f49233f1	fecc62a8-85bf-4080-8821-96a1726ea733	2026-09-20 19:58:52.279402-05
937d8f64-aa45-44a9-b13e-b1d2f49233f1	3ddca28c-069d-41ab-91ae-18f2c78ce38d	2026-09-20 19:58:52.279402-05
937d8f64-aa45-44a9-b13e-b1d2f49233f1	c24a182b-b8df-4c39-9970-3b88772fcc01	2026-09-20 19:58:52.279402-05
937d8f64-aa45-44a9-b13e-b1d2f49233f1	e7a4ff4b-6803-46fa-b7d6-ee0a9c947606	2026-09-20 19:58:52.279402-05
937d8f64-aa45-44a9-b13e-b1d2f49233f1	66f2f759-1697-4a5b-9777-cc059002862a	2026-09-20 19:58:52.279402-05
937d8f64-aa45-44a9-b13e-b1d2f49233f1	1e357e9e-0dce-44f4-8cc3-39696c43d2ad	2026-09-20 19:58:52.279402-05
937d8f64-aa45-44a9-b13e-b1d2f49233f1	07128133-5d2e-421a-b042-0b226a7d8776	2026-09-20 19:58:52.279402-05
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.roles (id, codigo, nombre, descripcion, scope, is_sistema, created_at, updated_at) FROM stdin;
44c16a6e-5b40-4cd4-a696-a24540e59f79	super_admin	Super administrador	Acceso total a todas las empresas	global	t	2026-09-20 19:58:52.265849-05	2026-09-20 19:58:52.265849-05
1afb8576-af29-4f85-ae59-93bd22142499	gerente	Gerencia	Visibilidad de todas las empresas, sin administración	global_restricted	t	2026-09-20 19:58:52.265849-05	2026-09-20 19:58:52.265849-05
62bbd548-dcaf-452b-a61e-9c91a436a9b4	admin_empresa	Administrador de empresa	Gestiona por completo una empresa	empresa	t	2026-09-20 19:58:52.265849-05	2026-09-20 19:58:52.265849-05
de4c9b73-5d17-4b01-92b1-392c07404df9	veterinario	Veterinario	Atiende pacientes y firma historia clínica	empresa	t	2026-09-20 19:58:52.265849-05	2026-09-20 19:58:52.265849-05
05e83714-54bc-47f9-9b90-164c3a729afa	recepcion	Recepción	Agenda, clientes y cobros de mostrador	empresa	t	2026-09-20 19:58:52.265849-05	2026-09-20 19:58:52.265849-05
7a73b6b1-e683-45c4-9056-95d07d7e42cb	almacen	Almacén	Inventario y compras	empresa	t	2026-09-20 19:58:52.265849-05	2026-09-20 19:58:52.265849-05
937d8f64-aa45-44a9-b13e-b1d2f49233f1	contador	Contabilidad	Facturación, cobranzas y reportes	empresa	t	2026-09-20 19:58:52.265849-05	2026-09-20 19:58:52.265849-05
\.


--
-- Data for Name: servicios; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.servicios (id, empresa_id, codigo, nombre, descripcion, tipo, categoria_id, precio, costo_estimado, duracion_min, requiere_ayuno, requiere_cita, afecto_igv, producto_id, estado, created_at, updated_at, deleted_at, created_by, updated_by) FROM stdin;
3547474b-85d1-4280-97f1-4d14966b7841	1ba3bd1a-4075-4009-b992-7057472e1e56	SRV-0001	Consulta general	Evaluación clínica completa	consulta	f57d3798-ec1a-47d5-b6ee-3f0e21ad4073	60.00	15.00	30	f	t	t	\N	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N
5440535f-04f1-41f8-a4b9-ce7ff8f2ed34	1ba3bd1a-4075-4009-b992-7057472e1e56	SRV-0002	Consulta de urgencia	Atención inmediata fuera de agenda	consulta	f57d3798-ec1a-47d5-b6ee-3f0e21ad4073	120.00	30.00	45	f	t	t	\N	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N
5a9d1d67-3b32-43e2-914a-6bdfea889d34	1ba3bd1a-4075-4009-b992-7057472e1e56	SRV-0003	Control post-operatorio	Revisión de herida y retiro de puntos	consulta	f57d3798-ec1a-47d5-b6ee-3f0e21ad4073	40.00	10.00	20	f	t	t	\N	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N
1a84418b-151d-4814-ab5c-9166a679004a	1ba3bd1a-4075-4009-b992-7057472e1e56	SRV-0004	Vacunación antirrábica	Aplicación de vacuna antirrábica	vacunacion	\N	45.00	18.00	15	f	t	t	\N	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N
48421dc9-9d43-4736-a370-278afe9b99a7	1ba3bd1a-4075-4009-b992-7057472e1e56	SRV-0005	Vacuna quíntuple canina	Refuerzo quíntuple	vacunacion	\N	65.00	28.00	15	f	t	t	\N	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N
9e94261e-11c2-43cb-8b8c-04bd8e89350f	1ba3bd1a-4075-4009-b992-7057472e1e56	SRV-0006	Vacuna triple felina	Refuerzo triple felina	vacunacion	\N	70.00	30.00	15	f	t	t	\N	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N
5066f985-c4c9-4447-b46a-28128c41ba1e	1ba3bd1a-4075-4009-b992-7057472e1e56	SRV-0007	Desparasitación interna	Antiparasitario oral según peso	desparasitacion	\N	35.00	12.00	10	f	t	t	\N	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N
b4d1d43a-cf35-4ba4-947a-9ec52f5c0860	1ba3bd1a-4075-4009-b992-7057472e1e56	SRV-0008	Esterilización canina hembra	Ovariohisterectomía	cirugia	\N	450.00	150.00	120	t	t	t	\N	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N
a43c2ece-85df-489f-b5a5-fb168ab898c2	1ba3bd1a-4075-4009-b992-7057472e1e56	SRV-0009	Esterilización canina macho	Orquiectomía	cirugia	\N	320.00	100.00	90	t	t	t	\N	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N
863784d6-0b41-4d0e-a2d8-5b3300decb7f	1ba3bd1a-4075-4009-b992-7057472e1e56	SRV-0010	Esterilización felina	Castración de gato	cirugia	\N	260.00	85.00	75	t	t	t	\N	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N
aaeb4547-8d80-44e6-8479-64c943847a43	1ba3bd1a-4075-4009-b992-7057472e1e56	SRV-0011	Profilaxis dental	Limpieza dental con anestesia	cirugia	\N	280.00	90.00	60	t	t	t	\N	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N
dfbd334e-10f3-4f6b-b355-7f05194fad55	1ba3bd1a-4075-4009-b992-7057472e1e56	SRV-0012	Hemograma completo	Análisis hematológico	laboratorio	\N	85.00	35.00	20	t	t	t	\N	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N
f01521f5-253a-472a-9888-3f9f3e83f80b	1ba3bd1a-4075-4009-b992-7057472e1e56	SRV-0013	Perfil bioquímico	Función renal y hepática	laboratorio	\N	140.00	60.00	20	t	t	t	\N	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N
5cd18b41-ab49-4c52-b269-6fa46869bfa3	1ba3bd1a-4075-4009-b992-7057472e1e56	SRV-0014	Radiografía digital	Estudio radiográfico 2 proyecciones	imagen	\N	120.00	40.00	30	f	t	t	\N	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N
47d43be6-7cd8-4c1b-b2c6-93696f301eb7	1ba3bd1a-4075-4009-b992-7057472e1e56	SRV-0015	Ecografía abdominal	Ultrasonido abdominal completo	imagen	\N	160.00	50.00	40	t	t	t	\N	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N
1c482355-7d77-49c3-b796-957d3bc4d87b	1ba3bd1a-4075-4009-b992-7057472e1e56	SRV-0016	Baño medicado	Baño con shampoo terapéutico	grooming	\N	55.00	15.00	60	f	t	t	\N	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N
a4b261a3-899d-4745-bddd-40da1b09ff8c	1ba3bd1a-4075-4009-b992-7057472e1e56	SRV-0017	Corte y peinado	Grooming estético completo	grooming	\N	75.00	20.00	90	f	t	t	\N	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N
074282f4-d54d-4d2b-b51f-7d67ab490b43	1ba3bd1a-4075-4009-b992-7057472e1e56	SRV-0018	Día de hospitalización	Internamiento con monitoreo	hospitalizacion	\N	180.00	60.00	0	f	t	t	\N	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N
10abc4bd-abcf-40d2-abb1-4a951faa91cf	a64719a9-57fc-4ac0-b104-b9d861370dc7	SRV-0001	Consulta general	Evaluación clínica completa	consulta	\N	70.00	18.00	30	f	t	t	\N	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N
00ab0b9b-c960-410f-bd70-79947d66736b	a64719a9-57fc-4ac0-b104-b9d861370dc7	SRV-0002	Consulta de urgencia	Atención inmediata	consulta	\N	140.00	35.00	45	f	t	t	\N	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N
ec59c9c9-d28c-4007-891c-4e23f08ea59d	a64719a9-57fc-4ac0-b104-b9d861370dc7	SRV-0003	Vacunación antirrábica	Aplicación de antirrábica	vacunacion	\N	50.00	18.00	15	f	t	t	\N	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N
79a0293b-d889-4a98-a698-34ecec04b9fe	a64719a9-57fc-4ac0-b104-b9d861370dc7	SRV-0004	Desparasitación	Antiparasitario según peso	desparasitacion	\N	40.00	12.00	10	f	t	t	\N	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N
b9b1c2f1-37c5-4e02-8555-31be2e6bc8de	a64719a9-57fc-4ac0-b104-b9d861370dc7	SRV-0005	Baño medicado	Shampoo terapéutico	grooming	\N	65.00	15.00	60	f	t	t	\N	activo	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	\N	af48d096-86a1-48c0-a4a2-c2971a0dcf6a	\N
\.


--
-- Data for Name: sesiones; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.sesiones (id, user_id, jti, ip, user_agent, expira_at, revocado_at, created_at) FROM stdin;
\.


--
-- Data for Name: stock; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.stock (id, empresa_id, producto_id, almacen_id, cantidad, reservado, updated_at) FROM stdin;
379696c3-5a97-45a5-a797-f0d365f85d38	1ba3bd1a-4075-4009-b992-7057472e1e56	5197b443-2077-49ff-97dc-784ce06c27ea	1c132cba-0595-4444-9f61-b6ef4278cac0	40.00	0.00	2026-09-20 19:58:52.289529-05
f72eaa29-e65a-4476-9657-3f8478e15029	1ba3bd1a-4075-4009-b992-7057472e1e56	3a26ca77-3d71-4964-acf5-eacfc6eeb479	1c132cba-0595-4444-9f61-b6ef4278cac0	40.00	0.00	2026-09-20 19:58:52.289529-05
7034b2f6-2573-44b4-94e2-d4b2ac5a0c5f	1ba3bd1a-4075-4009-b992-7057472e1e56	535ffa99-0ab3-4c7b-a753-7d42b7d21894	1c132cba-0595-4444-9f61-b6ef4278cac0	40.00	0.00	2026-09-20 19:58:52.289529-05
3877fecc-4083-41ed-9c36-4b1f16f02ff0	1ba3bd1a-4075-4009-b992-7057472e1e56	33aa9c82-ab26-4a59-8b0f-7550accda742	1c132cba-0595-4444-9f61-b6ef4278cac0	40.00	0.00	2026-09-20 19:58:52.289529-05
033c74d2-53a8-45dd-a275-63b9e8e5de69	1ba3bd1a-4075-4009-b992-7057472e1e56	342d9253-5690-4114-8da3-394eaae27f4d	1c132cba-0595-4444-9f61-b6ef4278cac0	40.00	0.00	2026-09-20 19:58:52.289529-05
3a0cec7d-921f-48a1-ad9e-499152009fc7	1ba3bd1a-4075-4009-b992-7057472e1e56	5acf001e-68e8-449f-be32-2f03a06e0d7a	1c132cba-0595-4444-9f61-b6ef4278cac0	40.00	0.00	2026-09-20 19:58:52.289529-05
12b82bea-92a5-4d8b-831b-190d6273c773	1ba3bd1a-4075-4009-b992-7057472e1e56	430c17cf-0b6f-452c-bd6a-25b2fa13741f	1c132cba-0595-4444-9f61-b6ef4278cac0	40.00	0.00	2026-09-20 19:58:52.289529-05
bede411f-3bb7-4cb9-ab87-b1cc2d7bfc98	1ba3bd1a-4075-4009-b992-7057472e1e56	71e823f6-3cd6-4e63-ad6f-c276ab8c4780	1c132cba-0595-4444-9f61-b6ef4278cac0	120.00	0.00	2026-09-20 19:58:52.289529-05
78b97fbd-277e-4d0a-9ff2-eb0dfeff6c4d	1ba3bd1a-4075-4009-b992-7057472e1e56	828b6821-c928-46ca-a9f1-dee6d771b855	1c132cba-0595-4444-9f61-b6ef4278cac0	120.00	0.00	2026-09-20 19:58:52.289529-05
0f7f3050-8f01-401d-8daf-01d5d9f29cf2	1ba3bd1a-4075-4009-b992-7057472e1e56	188a1d71-db83-46b3-9bc2-eabee528fdfc	1c132cba-0595-4444-9f61-b6ef4278cac0	120.00	0.00	2026-09-20 19:58:52.289529-05
ce7a0647-1805-4245-9c68-3257619197d7	1ba3bd1a-4075-4009-b992-7057472e1e56	6a3b4ab7-0337-4d68-8162-b680c554bd0e	1c132cba-0595-4444-9f61-b6ef4278cac0	120.00	0.00	2026-09-20 19:58:52.289529-05
fcba7db8-8597-4bf9-af58-f71647da2bd6	1ba3bd1a-4075-4009-b992-7057472e1e56	78a55878-39f1-44ce-9870-45b64caa4899	1c132cba-0595-4444-9f61-b6ef4278cac0	12.00	0.00	2026-09-20 19:58:52.289529-05
913d8f70-2957-4b6e-94bd-1dc2e41b339d	1ba3bd1a-4075-4009-b992-7057472e1e56	0f7bcb71-f93c-4a51-89a5-18e0ff0fb0d6	1c132cba-0595-4444-9f61-b6ef4278cac0	12.00	0.00	2026-09-20 19:58:52.289529-05
e6c6ebe3-16bc-43bc-a10f-974316a46134	1ba3bd1a-4075-4009-b992-7057472e1e56	3365e863-88c4-4e0d-acd1-17cb6af032fd	1c132cba-0595-4444-9f61-b6ef4278cac0	40.00	0.00	2026-09-20 19:58:52.289529-05
12552f53-0ddb-459f-af7b-9bbad003de96	1ba3bd1a-4075-4009-b992-7057472e1e56	63916ee9-bd0e-4d14-812c-1ce3b567ab6c	1c132cba-0595-4444-9f61-b6ef4278cac0	40.00	0.00	2026-09-20 19:58:52.289529-05
5ee1fff5-33bd-4745-9b91-f50632a86d79	a64719a9-57fc-4ac0-b104-b9d861370dc7	e42496b2-d4f7-46f1-9817-5e94a7c527c4	720ad333-4de0-447f-84bb-dc46e664dd76	30.00	0.00	2026-09-20 19:58:52.289529-05
59bc0992-c156-4820-9aeb-a00bd6a964f7	a64719a9-57fc-4ac0-b104-b9d861370dc7	31c219b2-abd2-4cf5-9bf2-563598c49d93	720ad333-4de0-447f-84bb-dc46e664dd76	30.00	0.00	2026-09-20 19:58:52.289529-05
1534943d-9e32-4d96-ab1a-22334bce12a3	a64719a9-57fc-4ac0-b104-b9d861370dc7	ee3a9fba-8417-4784-99af-b869ddb996fa	720ad333-4de0-447f-84bb-dc46e664dd76	100.00	0.00	2026-09-20 19:58:52.289529-05
fda759f4-9d66-466b-bfd8-eb1e352a366e	a64719a9-57fc-4ac0-b104-b9d861370dc7	271b60e3-dd2b-459e-9e49-5d1110e74b7c	720ad333-4de0-447f-84bb-dc46e664dd76	100.00	0.00	2026-09-20 19:58:52.289529-05
\.


--
-- Data for Name: tratamientos; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.tratamientos (id, empresa_id, mascota_id, consulta_id, veterinario_id, producto_id, medicamento, principio_activo, dosis, via, frecuencia_horas, duracion_dias, fecha_inicio, fecha_fin, indicaciones, estado, created_at, updated_at, created_by) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.users (id, codigo, email, password_hash, nombres, apellido_paterno, apellido_materno, tipo_documento, numero_documento, telefono, foto_url, empresa_id, is_super_admin, rol_id, es_veterinario, colegiatura, especializacion_id, color_agenda, estado, ultimo_login_at, intentos_fallidos, bloqueado_hasta, password_reset_token, password_reset_expires, must_change_password, created_at, updated_at, deleted_at, created_by, updated_by) FROM stdin;
af48d096-86a1-48c0-a4a2-c2971a0dcf6a	USR-0001	admin@vetpatitas.pe	$2a$10$s7cKPnR.wZcrlsHfRYpZBuleyBpAFW4J5wx.cpD6kKjRuOIj.yk7.	Fernando	Carbajal	Ríos	DNI	10000001	999000001	\N	\N	t	44c16a6e-5b40-4cd4-a696-a24540e59f79	f	\N	\N	#07B162	activo	\N	0	\N	\N	\N	f	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	\N	\N	\N
12ed7993-4f79-41ee-827e-731ead5aad4b	USR-0002	administracion@vetpatitas.pe	$2a$10$NuAuxiy5bd2f89cxUwecdevXBrxSugEBGD6PCvpPGkSzf/ukrDJiC	Lucía	Mendoza	Paredes	DNI	10000002	999000002	\N	1ba3bd1a-4075-4009-b992-7057472e1e56	f	62bbd548-dcaf-452b-a61e-9c91a436a9b4	f	\N	\N	#2D7EE5	activo	\N	0	\N	\N	\N	f	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	\N	\N	\N
5dc67c3d-1666-4a68-8cb5-489997a6bf08	USR-0003	jperez@vetpatitas.pe	$2a$10$lPXi0z/sRgnY3KbynWX0gOjLhdl1uP3uE8/rzod7ahAB2lHybRyHW	Jorge	Pérez	Salas	DNI	10000003	999000003	\N	1ba3bd1a-4075-4009-b992-7057472e1e56	f	de4c9b73-5d17-4b01-92b1-392c07404df9	t	CMVP-8421	7edd3986-a10a-4e08-b1f4-12a809c0e8d9	#07B162	activo	\N	0	\N	\N	\N	f	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	\N	\N	\N
419047f7-804f-4e15-90ca-276e3a463644	USR-0004	mrojas@vetpatitas.pe	$2a$10$KWM0YPmkzFh43t8XPaWqFe6RohJRSKS856932bdGZd6AJy0yEHLem	María	Rojas	Quispe	DNI	10000004	999000004	\N	1ba3bd1a-4075-4009-b992-7057472e1e56	f	de4c9b73-5d17-4b01-92b1-392c07404df9	t	CMVP-9137	74d234f9-2fe3-4519-9459-799249d1d0b1	#8359E5	activo	\N	0	\N	\N	\N	f	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	\N	\N	\N
9faa05e4-2294-45f4-b7dd-4cadbb84b673	USR-0005	recepcion@vetpatitas.pe	$2a$10$XX0yTv.EVP3qtL.0SLz.E.vhu33FKVW0/nB7izhRVY1CjsoIw7I.i	Andrea	Vargas	Luna	DNI	10000005	999000005	\N	1ba3bd1a-4075-4009-b992-7057472e1e56	f	05e83714-54bc-47f9-9b90-164c3a729afa	f	\N	\N	#E89A1F	activo	\N	0	\N	\N	\N	f	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	\N	\N	\N
46a1df90-27dc-483f-83ed-19fc88d3d3ae	USR-0006	almacen@vetpatitas.pe	$2a$10$nm4kRslP3wlDuLRnVsh2tuRtSLoLb6Vz1TzAQjzH.23kr1YUue48G	Ricardo	Flores	Tapia	DNI	10000006	999000006	\N	1ba3bd1a-4075-4009-b992-7057472e1e56	f	7a73b6b1-e683-45c4-9056-95d07d7e42cb	f	\N	\N	#DC4040	activo	\N	0	\N	\N	\N	f	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	\N	\N	\N
0d73fe82-3e6f-4689-b641-a22f36ffc160	USR-0007	gerencia@vetpatitas.pe	$2a$10$EbGhsPJ9M2oSK1d6z4Mo5OiQ.erjyoqTbhEi/CadfeanWgBzhKW6q	Patricia	Soto	Aguirre	DNI	10000007	999000007	\N	\N	f	1afb8576-af29-4f85-ae59-93bd22142499	f	\N	\N	\N	activo	\N	0	\N	\N	\N	f	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	\N	\N	\N
170bb7a1-65b8-40b3-a515-1371432b02a4	USR-0101	administracion@vethuellitas.pe	$2a$10$.qfCjwZsnY0bnnvFXllxJeNBX0YPmxx0h230KuF6I2fFhD05RxGAO	Carmen	Ibáñez	Delgado	DNI	10000101	999000101	\N	a64719a9-57fc-4ac0-b104-b9d861370dc7	f	62bbd548-dcaf-452b-a61e-9c91a436a9b4	f	\N	\N	#2D7EE5	activo	\N	0	\N	\N	\N	f	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	\N	\N	\N
edd68eb9-a68e-4711-b9a4-a294cf372d2f	USR-0102	dvaldez@vethuellitas.pe	$2a$10$BUynTCBmgYBrnn7zUdEeUuNvGIiGUvEEDT81FdZhO2u0Tsso7N86G	Diego	Valdez	Cornejo	DNI	10000102	999000102	\N	a64719a9-57fc-4ac0-b104-b9d861370dc7	f	de4c9b73-5d17-4b01-92b1-392c07404df9	t	CMVP-7755	7edd3986-a10a-4e08-b1f4-12a809c0e8d9	#07B162	activo	\N	0	\N	\N	\N	f	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	\N	\N	\N
abb8ebf6-b925-41ee-94fe-e03cbbb718ec	USR-0103	recepcion@vethuellitas.pe	$2a$10$KFdz69KVYYUts44FHKgWCeZcezpnwJ6JVpryKGcHAGuSX0TAY3Tdq	Sofía	Ramírez	Ochoa	DNI	10000103	999000103	\N	a64719a9-57fc-4ac0-b104-b9d861370dc7	f	05e83714-54bc-47f9-9b90-164c3a729afa	f	\N	\N	#E89A1F	activo	\N	0	\N	\N	\N	f	2026-09-20 19:58:52.289529-05	2026-09-20 19:58:52.289529-05	\N	\N	\N
\.


--
-- Data for Name: vacunas; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.vacunas (id, empresa_id, mascota_id, veterinario_id, consulta_id, esquema_id, producto_id, nombre_vacuna, laboratorio, lote, fecha_aplicacion, dosis_numero, proximo_refuerzo, via, reaccion_adversa, observaciones, created_at, updated_at, created_by) FROM stdin;
b96f6c73-b0df-4aae-a32f-a59fdfcf9dc0	1ba3bd1a-4075-4009-b992-7057472e1e56	b4cbd8de-2439-4495-bd52-7c03a6bee07e	5dc67c3d-1666-4a68-8cb5-489997a6bf08	7d8f9f37-6998-4093-b279-01f32bf2b1ff	\N	\N	Antirrábica	Zoetis	LT-2026-001	2026-09-18	1	2027-09-18	subcutanea	\N	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	5dc67c3d-1666-4a68-8cb5-489997a6bf08
141ad5ed-7be3-445b-94a4-a139a1c07b47	1ba3bd1a-4075-4009-b992-7057472e1e56	43509380-78ff-488d-8590-7346e7769aa0	5dc67c3d-1666-4a68-8cb5-489997a6bf08	a044cd96-9aff-4485-83a0-77bd77662820	\N	\N	Quíntuple canina	Zoetis	LT-2026-003	2026-09-16	1	2027-09-16	subcutanea	\N	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	5dc67c3d-1666-4a68-8cb5-489997a6bf08
6ff79d8f-50b3-4633-ad47-8829199f4f27	1ba3bd1a-4075-4009-b992-7057472e1e56	e485ee0b-d6f9-4052-ba2f-2e63f3f1fd76	5dc67c3d-1666-4a68-8cb5-489997a6bf08	bbe65666-df5b-4edd-adc9-3cf4736e8b68	\N	\N	Antirrábica	Zoetis	LT-2026-005	2026-09-19	1	2027-09-19	subcutanea	\N	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	5dc67c3d-1666-4a68-8cb5-489997a6bf08
a8aa0f8a-4412-49b4-ac01-412068f360c2	1ba3bd1a-4075-4009-b992-7057472e1e56	cbbced34-52c2-45d5-adf1-e96954285557	5dc67c3d-1666-4a68-8cb5-489997a6bf08	95ec86f8-fe2d-462d-b40a-bec91a6e00cc	\N	\N	Quíntuple canina	Zoetis	LT-2026-007	2026-09-17	1	2027-09-17	subcutanea	\N	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	5dc67c3d-1666-4a68-8cb5-489997a6bf08
d1a263ab-215e-4a97-b2a8-bc66ec3fd611	1ba3bd1a-4075-4009-b992-7057472e1e56	b7b98cfc-fff1-4d55-afb3-9f3c03cd431a	5dc67c3d-1666-4a68-8cb5-489997a6bf08	86cf4a68-2368-4766-97d8-c162d5f0a004	\N	\N	Antirrábica	Zoetis	LT-2026-009	2026-09-15	1	2027-09-15	subcutanea	\N	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	5dc67c3d-1666-4a68-8cb5-489997a6bf08
5165551a-f284-4326-9549-bf539ce41585	1ba3bd1a-4075-4009-b992-7057472e1e56	7da7fd75-767c-4176-ac1a-3396c31a2eba	5dc67c3d-1666-4a68-8cb5-489997a6bf08	23d274c1-92fa-41bc-98af-4291409acafa	\N	\N	Quíntuple canina	Zoetis	LT-2026-011	2026-09-18	1	2027-09-18	subcutanea	\N	\N	2026-09-20 19:58:52.873138-05	2026-09-20 19:58:52.873138-05	5dc67c3d-1666-4a68-8cb5-489997a6bf08
\.


--
-- Name: almacenes almacenes_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.almacenes
    ADD CONSTRAINT almacenes_pkey PRIMARY KEY (id);


--
-- Name: asistencia asistencia_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.asistencia
    ADD CONSTRAINT asistencia_pkey PRIMARY KEY (id);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: cajas cajas_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.cajas
    ADD CONSTRAINT cajas_pkey PRIMARY KEY (id);


--
-- Name: categorias categorias_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.categorias
    ADD CONSTRAINT categorias_pkey PRIMARY KEY (id);


--
-- Name: cirugias cirugias_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.cirugias
    ADD CONSTRAINT cirugias_pkey PRIMARY KEY (id);


--
-- Name: citas_historial citas_historial_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.citas_historial
    ADD CONSTRAINT citas_historial_pkey PRIMARY KEY (id);


--
-- Name: citas_lista_espera citas_lista_espera_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.citas_lista_espera
    ADD CONSTRAINT citas_lista_espera_pkey PRIMARY KEY (id);


--
-- Name: citas citas_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.citas
    ADD CONSTRAINT citas_pkey PRIMARY KEY (id);


--
-- Name: clausulas clausulas_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.clausulas
    ADD CONSTRAINT clausulas_pkey PRIMARY KEY (id);


--
-- Name: clientes clientes_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.clientes
    ADD CONSTRAINT clientes_pkey PRIMARY KEY (id);


--
-- Name: comprobante_items comprobante_items_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.comprobante_items
    ADD CONSTRAINT comprobante_items_pkey PRIMARY KEY (id);


--
-- Name: comprobante_pse_log comprobante_pse_log_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.comprobante_pse_log
    ADD CONSTRAINT comprobante_pse_log_pkey PRIMARY KEY (id);


--
-- Name: comprobantes comprobantes_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.comprobantes
    ADD CONSTRAINT comprobantes_pkey PRIMARY KEY (id);


--
-- Name: comunicaciones comunicaciones_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.comunicaciones
    ADD CONSTRAINT comunicaciones_pkey PRIMARY KEY (id);


--
-- Name: consultas consultas_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.consultas
    ADD CONSTRAINT consultas_pkey PRIMARY KEY (id);


--
-- Name: consultorios consultorios_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.consultorios
    ADD CONSTRAINT consultorios_pkey PRIMARY KEY (id);


--
-- Name: contratos_personal contratos_personal_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.contratos_personal
    ADD CONSTRAINT contratos_personal_pkey PRIMARY KEY (id);


--
-- Name: correlativos correlativos_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.correlativos
    ADD CONSTRAINT correlativos_pkey PRIMARY KEY (empresa_id, tipo_documento, serie);


--
-- Name: desparasitaciones desparasitaciones_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.desparasitaciones
    ADD CONSTRAINT desparasitaciones_pkey PRIMARY KEY (id);


--
-- Name: disponibilidad disponibilidad_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.disponibilidad
    ADD CONSTRAINT disponibilidad_pkey PRIMARY KEY (id);


--
-- Name: documentos_medicos documentos_medicos_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.documentos_medicos
    ADD CONSTRAINT documentos_medicos_pkey PRIMARY KEY (id);


--
-- Name: empresas empresas_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.empresas
    ADD CONSTRAINT empresas_pkey PRIMARY KEY (id);


--
-- Name: empresas empresas_ruc_key; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.empresas
    ADD CONSTRAINT empresas_ruc_key UNIQUE (ruc);


--
-- Name: especializaciones especializaciones_codigo_key; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.especializaciones
    ADD CONSTRAINT especializaciones_codigo_key UNIQUE (codigo);


--
-- Name: especializaciones especializaciones_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.especializaciones
    ADD CONSTRAINT especializaciones_pkey PRIMARY KEY (id);


--
-- Name: especies especies_codigo_key; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.especies
    ADD CONSTRAINT especies_codigo_key UNIQUE (codigo);


--
-- Name: especies especies_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.especies
    ADD CONSTRAINT especies_pkey PRIMARY KEY (id);


--
-- Name: esquemas_vacunacion esquemas_vacunacion_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.esquemas_vacunacion
    ADD CONSTRAINT esquemas_vacunacion_pkey PRIMARY KEY (id);


--
-- Name: evaluaciones_personal evaluaciones_personal_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.evaluaciones_personal
    ADD CONSTRAINT evaluaciones_personal_pkey PRIMARY KEY (id);


--
-- Name: examenes examenes_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.examenes
    ADD CONSTRAINT examenes_pkey PRIMARY KEY (id);


--
-- Name: historia_clinica historia_clinica_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.historia_clinica
    ADD CONSTRAINT historia_clinica_pkey PRIMARY KEY (id);


--
-- Name: horarios_atencion horarios_atencion_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.horarios_atencion
    ADD CONSTRAINT horarios_atencion_pkey PRIMARY KEY (id);


--
-- Name: hospitalizacion_evoluciones hospitalizacion_evoluciones_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.hospitalizacion_evoluciones
    ADD CONSTRAINT hospitalizacion_evoluciones_pkey PRIMARY KEY (id);


--
-- Name: hospitalizaciones hospitalizaciones_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.hospitalizaciones
    ADD CONSTRAINT hospitalizaciones_pkey PRIMARY KEY (id);


--
-- Name: insumos_utilizados insumos_utilizados_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.insumos_utilizados
    ADD CONSTRAINT insumos_utilizados_pkey PRIMARY KEY (id);


--
-- Name: lotes lotes_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.lotes
    ADD CONSTRAINT lotes_pkey PRIMARY KEY (id);


--
-- Name: mascotas_extraviadas mascotas_extraviadas_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.mascotas_extraviadas
    ADD CONSTRAINT mascotas_extraviadas_pkey PRIMARY KEY (id);


--
-- Name: mascotas mascotas_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.mascotas
    ADD CONSTRAINT mascotas_pkey PRIMARY KEY (id);


--
-- Name: movimientos_caja movimientos_caja_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.movimientos_caja
    ADD CONSTRAINT movimientos_caja_pkey PRIMARY KEY (id);


--
-- Name: movimientos_inventario movimientos_inventario_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.movimientos_inventario
    ADD CONSTRAINT movimientos_inventario_pkey PRIMARY KEY (id);


--
-- Name: notas_medicas notas_medicas_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.notas_medicas
    ADD CONSTRAINT notas_medicas_pkey PRIMARY KEY (id);


--
-- Name: notificaciones notificaciones_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.notificaciones
    ADD CONSTRAINT notificaciones_pkey PRIMARY KEY (id);


--
-- Name: orden_compra_items orden_compra_items_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.orden_compra_items
    ADD CONSTRAINT orden_compra_items_pkey PRIMARY KEY (id);


--
-- Name: ordenes_compra ordenes_compra_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.ordenes_compra
    ADD CONSTRAINT ordenes_compra_pkey PRIMARY KEY (id);


--
-- Name: ordenes_servicio ordenes_servicio_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.ordenes_servicio
    ADD CONSTRAINT ordenes_servicio_pkey PRIMARY KEY (id);


--
-- Name: pago_aplicaciones pago_aplicaciones_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.pago_aplicaciones
    ADD CONSTRAINT pago_aplicaciones_pkey PRIMARY KEY (id);


--
-- Name: pagos pagos_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.pagos
    ADD CONSTRAINT pagos_pkey PRIMARY KEY (id);


--
-- Name: pagos_proveedor pagos_proveedor_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.pagos_proveedor
    ADD CONSTRAINT pagos_proveedor_pkey PRIMARY KEY (id);


--
-- Name: permisos permisos_codigo_key; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.permisos
    ADD CONSTRAINT permisos_codigo_key UNIQUE (codigo);


--
-- Name: permisos_laborales permisos_laborales_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.permisos_laborales
    ADD CONSTRAINT permisos_laborales_pkey PRIMARY KEY (id);


--
-- Name: permisos permisos_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.permisos
    ADD CONSTRAINT permisos_pkey PRIMARY KEY (id);


--
-- Name: plantillas_mensaje plantillas_mensaje_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.plantillas_mensaje
    ADD CONSTRAINT plantillas_mensaje_pkey PRIMARY KEY (id);


--
-- Name: productos productos_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.productos
    ADD CONSTRAINT productos_pkey PRIMARY KEY (id);


--
-- Name: proveedor_contactos proveedor_contactos_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.proveedor_contactos
    ADD CONSTRAINT proveedor_contactos_pkey PRIMARY KEY (id);


--
-- Name: proveedores proveedores_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.proveedores
    ADD CONSTRAINT proveedores_pkey PRIMARY KEY (id);


--
-- Name: razas razas_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.razas
    ADD CONSTRAINT razas_pkey PRIMARY KEY (id);


--
-- Name: recordatorios recordatorios_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.recordatorios
    ADD CONSTRAINT recordatorios_pkey PRIMARY KEY (id);


--
-- Name: rol_permisos rol_permisos_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.rol_permisos
    ADD CONSTRAINT rol_permisos_pkey PRIMARY KEY (rol_id, permiso_id);


--
-- Name: roles roles_codigo_key; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.roles
    ADD CONSTRAINT roles_codigo_key UNIQUE (codigo);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: servicios servicios_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.servicios
    ADD CONSTRAINT servicios_pkey PRIMARY KEY (id);


--
-- Name: sesiones sesiones_jti_key; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.sesiones
    ADD CONSTRAINT sesiones_jti_key UNIQUE (jti);


--
-- Name: sesiones sesiones_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.sesiones
    ADD CONSTRAINT sesiones_pkey PRIMARY KEY (id);


--
-- Name: stock stock_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.stock
    ADD CONSTRAINT stock_pkey PRIMARY KEY (id);


--
-- Name: tratamientos tratamientos_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.tratamientos
    ADD CONSTRAINT tratamientos_pkey PRIMARY KEY (id);


--
-- Name: almacenes uq_almacenes_codigo; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.almacenes
    ADD CONSTRAINT uq_almacenes_codigo UNIQUE (empresa_id, codigo);


--
-- Name: asistencia uq_asistencia; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.asistencia
    ADD CONSTRAINT uq_asistencia UNIQUE (user_id, fecha);


--
-- Name: categorias uq_categorias_codigo; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.categorias
    ADD CONSTRAINT uq_categorias_codigo UNIQUE (empresa_id, ambito, codigo);


--
-- Name: clientes uq_clientes_documento; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.clientes
    ADD CONSTRAINT uq_clientes_documento UNIQUE (empresa_id, tipo_documento, numero_documento);


--
-- Name: comprobantes uq_comprobantes_numero; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.comprobantes
    ADD CONSTRAINT uq_comprobantes_numero UNIQUE (empresa_id, tipo, serie, numero);


--
-- Name: consultorios uq_consultorios_nombre; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.consultorios
    ADD CONSTRAINT uq_consultorios_nombre UNIQUE (empresa_id, nombre);


--
-- Name: lotes uq_lotes; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.lotes
    ADD CONSTRAINT uq_lotes UNIQUE (producto_id, numero_lote);


--
-- Name: ordenes_compra uq_ordenes_compra_numero; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.ordenes_compra
    ADD CONSTRAINT uq_ordenes_compra_numero UNIQUE (empresa_id, numero);


--
-- Name: plantillas_mensaje uq_plantillas_mensaje; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.plantillas_mensaje
    ADD CONSTRAINT uq_plantillas_mensaje UNIQUE (empresa_id, tipo, canal);


--
-- Name: productos uq_productos_codigo; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.productos
    ADD CONSTRAINT uq_productos_codigo UNIQUE (empresa_id, codigo);


--
-- Name: proveedores uq_proveedores_doc; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.proveedores
    ADD CONSTRAINT uq_proveedores_doc UNIQUE (empresa_id, numero_documento);


--
-- Name: servicios uq_servicios_codigo; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.servicios
    ADD CONSTRAINT uq_servicios_codigo UNIQUE (empresa_id, codigo);


--
-- Name: stock uq_stock; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.stock
    ADD CONSTRAINT uq_stock UNIQUE (producto_id, almacen_id);


--
-- Name: users uq_users_documento; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.users
    ADD CONSTRAINT uq_users_documento UNIQUE (tipo_documento, numero_documento);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: vacunas vacunas_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.vacunas
    ADD CONSTRAINT vacunas_pkey PRIMARY KEY (id);


--
-- Name: ix_asistencia_empresa; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_asistencia_empresa ON core.asistencia USING btree (empresa_id, fecha DESC);


--
-- Name: ix_audit_log_empresa; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_audit_log_empresa ON core.audit_log USING btree (empresa_id, created_at DESC);


--
-- Name: ix_audit_log_entidad; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_audit_log_entidad ON core.audit_log USING btree (entidad, entidad_id);


--
-- Name: ix_audit_log_user; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_audit_log_user ON core.audit_log USING btree (user_id, created_at DESC);


--
-- Name: ix_cajas_empresa; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_cajas_empresa ON core.cajas USING btree (empresa_id, fecha_apertura DESC);


--
-- Name: ix_categorias_empresa; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_categorias_empresa ON core.categorias USING btree (empresa_id, ambito) WHERE (estado = 'activo'::core.estado_generico);


--
-- Name: ix_cirugias_empresa; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_cirugias_empresa ON core.cirugias USING btree (empresa_id, estado);


--
-- Name: ix_cirugias_mascota; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_cirugias_mascota ON core.cirugias USING btree (mascota_id, fecha_programada DESC);


--
-- Name: ix_citas_cliente; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_citas_cliente ON core.citas USING btree (cliente_id, fecha_hora DESC);


--
-- Name: ix_citas_empresa_fecha; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_citas_empresa_fecha ON core.citas USING btree (empresa_id, fecha_hora) WHERE (deleted_at IS NULL);


--
-- Name: ix_citas_estado; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_citas_estado ON core.citas USING btree (empresa_id, estado) WHERE (deleted_at IS NULL);


--
-- Name: ix_citas_historial_cita; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_citas_historial_cita ON core.citas_historial USING btree (cita_id, created_at DESC);


--
-- Name: ix_citas_mascota; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_citas_mascota ON core.citas USING btree (mascota_id, fecha_hora DESC);


--
-- Name: ix_citas_veterinario; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_citas_veterinario ON core.citas USING btree (veterinario_id, fecha_hora) WHERE (deleted_at IS NULL);


--
-- Name: ix_clausulas_empresa; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_clausulas_empresa ON core.clausulas USING btree (empresa_id, tipo);


--
-- Name: ix_clientes_doc_trgm; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_clientes_doc_trgm ON core.clientes USING gin (numero_documento public.gin_trgm_ops);


--
-- Name: ix_clientes_empresa; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_clientes_empresa ON core.clientes USING btree (empresa_id) WHERE (deleted_at IS NULL);


--
-- Name: ix_clientes_estado; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_clientes_estado ON core.clientes USING btree (empresa_id, estado) WHERE (deleted_at IS NULL);


--
-- Name: ix_clientes_nombre_trgm; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_clientes_nombre_trgm ON core.clientes USING gin (nombres public.gin_trgm_ops);


--
-- Name: ix_clientes_telefono; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_clientes_telefono ON core.clientes USING btree (telefono);


--
-- Name: ix_comprobante_items; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_comprobante_items ON core.comprobante_items USING btree (comprobante_id);


--
-- Name: ix_comprobante_items_ref; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_comprobante_items_ref ON core.comprobante_items USING btree (item_ref_id) WHERE (item_ref_id IS NOT NULL);


--
-- Name: ix_comprobante_pse_log; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_comprobante_pse_log ON core.comprobante_pse_log USING btree (comprobante_id, created_at DESC);


--
-- Name: ix_comprobantes_cliente; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_comprobantes_cliente ON core.comprobantes USING btree (cliente_id, fecha_emision DESC);


--
-- Name: ix_comprobantes_empresa; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_comprobantes_empresa ON core.comprobantes USING btree (empresa_id, fecha_emision DESC) WHERE (deleted_at IS NULL);


--
-- Name: ix_comprobantes_pend; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_comprobantes_pend ON core.comprobantes USING btree (empresa_id, estado_pago) WHERE ((deleted_at IS NULL) AND (estado_pago <> 'pagado'::core.estado_pago));


--
-- Name: ix_comprobantes_por_enviar; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_comprobantes_por_enviar ON core.comprobantes USING btree (empresa_id, estado) WHERE ((deleted_at IS NULL) AND (estado = ANY (ARRAY['pendiente_envio'::core.estado_comprobante, 'rechazado_sunat'::core.estado_comprobante])));


--
-- Name: ix_comunicaciones_cliente; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_comunicaciones_cliente ON core.comunicaciones USING btree (cliente_id, fecha DESC);


--
-- Name: ix_comunicaciones_seguim; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_comunicaciones_seguim ON core.comunicaciones USING btree (empresa_id, fecha_seguimiento) WHERE (requiere_seguimiento = true);


--
-- Name: ix_consultas_empresa; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_consultas_empresa ON core.consultas USING btree (empresa_id, fecha DESC) WHERE (deleted_at IS NULL);


--
-- Name: ix_consultas_mascota; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_consultas_mascota ON core.consultas USING btree (mascota_id, fecha DESC) WHERE (deleted_at IS NULL);


--
-- Name: ix_consultas_vet; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_consultas_vet ON core.consultas USING btree (veterinario_id, fecha DESC);


--
-- Name: ix_contratos_personal; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_contratos_personal ON core.contratos_personal USING btree (empresa_id, user_id);


--
-- Name: ix_desparasitaciones_mascota; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_desparasitaciones_mascota ON core.desparasitaciones USING btree (mascota_id, fecha_aplicacion DESC);


--
-- Name: ix_disponibilidad; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_disponibilidad ON core.disponibilidad USING btree (empresa_id, fecha, user_id);


--
-- Name: ix_disponibilidad_permiso; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_disponibilidad_permiso ON core.disponibilidad USING btree (permiso_id) WHERE (permiso_id IS NOT NULL);


--
-- Name: ix_documentos_mascota; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_documentos_mascota ON core.documentos_medicos USING btree (mascota_id, created_at DESC);


--
-- Name: ix_empresas_estado; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_empresas_estado ON core.empresas USING btree (estado) WHERE (deleted_at IS NULL);


--
-- Name: ix_empresas_razon_trgm; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_empresas_razon_trgm ON core.empresas USING gin (razon_social public.gin_trgm_ops);


--
-- Name: ix_esquemas_vac_empresa; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_esquemas_vac_empresa ON core.esquemas_vacunacion USING btree (empresa_id, especie_id);


--
-- Name: ix_evaluaciones; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_evaluaciones ON core.evaluaciones_personal USING btree (empresa_id, user_id, fecha DESC);


--
-- Name: ix_examenes_mascota; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_examenes_mascota ON core.examenes USING btree (mascota_id, fecha_solicitud DESC);


--
-- Name: ix_historia_empresa; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_historia_empresa ON core.historia_clinica USING btree (empresa_id, fecha DESC);


--
-- Name: ix_historia_mascota; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_historia_mascota ON core.historia_clinica USING btree (mascota_id, fecha DESC);


--
-- Name: ix_historia_tipo; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_historia_tipo ON core.historia_clinica USING btree (mascota_id, tipo_evento);


--
-- Name: ix_horarios_empresa; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_horarios_empresa ON core.horarios_atencion USING btree (empresa_id, dia_semana);


--
-- Name: ix_hosp_evol; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_hosp_evol ON core.hospitalizacion_evoluciones USING btree (hospitalizacion_id, fecha_hora DESC);


--
-- Name: ix_hospitalizaciones_empresa; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_hospitalizaciones_empresa ON core.hospitalizaciones USING btree (empresa_id, estado);


--
-- Name: ix_hospitalizaciones_mascota; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_hospitalizaciones_mascota ON core.hospitalizaciones USING btree (mascota_id, fecha_ingreso DESC);


--
-- Name: ix_insumos_consulta; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_insumos_consulta ON core.insumos_utilizados USING btree (consulta_id);


--
-- Name: ix_insumos_empresa; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_insumos_empresa ON core.insumos_utilizados USING btree (empresa_id, fecha DESC);


--
-- Name: ix_lista_espera_empresa; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_lista_espera_empresa ON core.citas_lista_espera USING btree (empresa_id, desde) WHERE (atendido = false);


--
-- Name: ix_lotes_vencimiento; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_lotes_vencimiento ON core.lotes USING btree (empresa_id, fecha_vencimiento) WHERE (cantidad > (0)::numeric);


--
-- Name: ix_mascotas_cliente; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_mascotas_cliente ON core.mascotas USING btree (cliente_id) WHERE (deleted_at IS NULL);


--
-- Name: ix_mascotas_empresa; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_mascotas_empresa ON core.mascotas USING btree (empresa_id) WHERE (deleted_at IS NULL);


--
-- Name: ix_mascotas_especie; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_mascotas_especie ON core.mascotas USING btree (especie_id);


--
-- Name: ix_mascotas_estado; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_mascotas_estado ON core.mascotas USING btree (empresa_id, estado) WHERE (deleted_at IS NULL);


--
-- Name: ix_mascotas_extraviadas; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_mascotas_extraviadas ON core.mascotas_extraviadas USING btree (empresa_id, mascota_id);


--
-- Name: ix_mascotas_nombre_trgm; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_mascotas_nombre_trgm ON core.mascotas USING gin (nombre public.gin_trgm_ops);


--
-- Name: ix_mov_caja; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_mov_caja ON core.movimientos_caja USING btree (caja_id, fecha);


--
-- Name: ix_movimientos_empresa; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_movimientos_empresa ON core.movimientos_inventario USING btree (empresa_id, fecha DESC);


--
-- Name: ix_movimientos_producto; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_movimientos_producto ON core.movimientos_inventario USING btree (producto_id, fecha DESC);


--
-- Name: ix_notas_mascota; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_notas_mascota ON core.notas_medicas USING btree (mascota_id, created_at DESC);


--
-- Name: ix_notificaciones_user; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_notificaciones_user ON core.notificaciones USING btree (user_id, created_at DESC) WHERE (leida_at IS NULL);


--
-- Name: ix_oc_items; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_oc_items ON core.orden_compra_items USING btree (orden_compra_id);


--
-- Name: ix_ordenes_compra_empresa; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_ordenes_compra_empresa ON core.ordenes_compra USING btree (empresa_id, fecha_emision DESC) WHERE (deleted_at IS NULL);


--
-- Name: ix_ordenes_compra_proveedor; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_ordenes_compra_proveedor ON core.ordenes_compra USING btree (proveedor_id);


--
-- Name: ix_ordenes_servicio_empresa; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_ordenes_servicio_empresa ON core.ordenes_servicio USING btree (empresa_id, fecha DESC);


--
-- Name: ix_ordenes_servicio_mascota; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_ordenes_servicio_mascota ON core.ordenes_servicio USING btree (mascota_id, fecha DESC);


--
-- Name: ix_ordenes_servicio_pend; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_ordenes_servicio_pend ON core.ordenes_servicio USING btree (empresa_id, cliente_id) WHERE ((facturado = false) AND (estado <> 'anulado'::core.estado_orden_servicio));


--
-- Name: ix_pago_aplicaciones_comp; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_pago_aplicaciones_comp ON core.pago_aplicaciones USING btree (comprobante_id);


--
-- Name: ix_pago_aplicaciones_pago; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_pago_aplicaciones_pago ON core.pago_aplicaciones USING btree (pago_id);


--
-- Name: ix_pagos_cliente; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_pagos_cliente ON core.pagos USING btree (cliente_id, fecha_pago DESC);


--
-- Name: ix_pagos_empresa; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_pagos_empresa ON core.pagos USING btree (empresa_id, fecha_pago DESC);


--
-- Name: ix_pagos_proveedor; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_pagos_proveedor ON core.pagos_proveedor USING btree (empresa_id, fecha_pago DESC);


--
-- Name: ix_permisos_laborales; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_permisos_laborales ON core.permisos_laborales USING btree (empresa_id, estado, fecha_inicio);


--
-- Name: ix_permisos_modulo; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_permisos_modulo ON core.permisos USING btree (modulo);


--
-- Name: ix_plantillas_mensaje; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_plantillas_mensaje ON core.plantillas_mensaje USING btree (empresa_id, tipo);


--
-- Name: ix_productos_critico; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_productos_critico ON core.productos USING btree (empresa_id) WHERE ((deleted_at IS NULL) AND (stock_actual <= stock_minimo));


--
-- Name: ix_productos_empresa; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_productos_empresa ON core.productos USING btree (empresa_id) WHERE (deleted_at IS NULL);


--
-- Name: ix_productos_nombre_trgm; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_productos_nombre_trgm ON core.productos USING gin (nombre public.gin_trgm_ops);


--
-- Name: ix_proveedor_contactos; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_proveedor_contactos ON core.proveedor_contactos USING btree (proveedor_id);


--
-- Name: ix_proveedores_empresa; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_proveedores_empresa ON core.proveedores USING btree (empresa_id) WHERE (deleted_at IS NULL);


--
-- Name: ix_proveedores_razon_trgm; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_proveedores_razon_trgm ON core.proveedores USING gin (razon_social public.gin_trgm_ops);


--
-- Name: ix_razas_empresa; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_razas_empresa ON core.razas USING btree (empresa_id) WHERE (empresa_id IS NOT NULL);


--
-- Name: ix_razas_especie; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_razas_especie ON core.razas USING btree (especie_id);


--
-- Name: ix_recordatorios_pend; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_recordatorios_pend ON core.recordatorios USING btree (empresa_id, fecha_objetivo) WHERE (completado = false);


--
-- Name: ix_rol_permisos_permiso; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_rol_permisos_permiso ON core.rol_permisos USING btree (permiso_id);


--
-- Name: ix_servicios_empresa; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_servicios_empresa ON core.servicios USING btree (empresa_id) WHERE (deleted_at IS NULL);


--
-- Name: ix_servicios_nombre_trgm; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_servicios_nombre_trgm ON core.servicios USING gin (nombre public.gin_trgm_ops);


--
-- Name: ix_servicios_tipo; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_servicios_tipo ON core.servicios USING btree (empresa_id, tipo) WHERE (deleted_at IS NULL);


--
-- Name: ix_sesiones_user; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_sesiones_user ON core.sesiones USING btree (user_id) WHERE (revocado_at IS NULL);


--
-- Name: ix_stock_empresa; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_stock_empresa ON core.stock USING btree (empresa_id, almacen_id);


--
-- Name: ix_tratamientos_activos; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_tratamientos_activos ON core.tratamientos USING btree (empresa_id, estado) WHERE (estado = 'activo'::core.estado_tratamiento);


--
-- Name: ix_tratamientos_mascota; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_tratamientos_mascota ON core.tratamientos USING btree (mascota_id, fecha_inicio DESC);


--
-- Name: ix_users_email_lower; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_users_email_lower ON core.users USING btree (lower((email)::text));


--
-- Name: ix_users_empresa; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_users_empresa ON core.users USING btree (empresa_id) WHERE (deleted_at IS NULL);


--
-- Name: ix_users_estado; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_users_estado ON core.users USING btree (estado) WHERE (deleted_at IS NULL);


--
-- Name: ix_users_rol; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_users_rol ON core.users USING btree (rol_id);


--
-- Name: ix_users_veterinario; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_users_veterinario ON core.users USING btree (es_veterinario) WHERE ((deleted_at IS NULL) AND (es_veterinario = true));


--
-- Name: ix_vacunas_mascota; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_vacunas_mascota ON core.vacunas USING btree (mascota_id, fecha_aplicacion DESC);


--
-- Name: ix_vacunas_refuerzo; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_vacunas_refuerzo ON core.vacunas USING btree (empresa_id, proximo_refuerzo) WHERE (proximo_refuerzo IS NOT NULL);


--
-- Name: uq_caja_abierta_por_user; Type: INDEX; Schema: core; Owner: -
--

CREATE UNIQUE INDEX uq_caja_abierta_por_user ON core.cajas USING btree (empresa_id, user_apertura_id) WHERE (estado = 'abierta'::core.estado_caja);


--
-- Name: uq_mascotas_microchip; Type: INDEX; Schema: core; Owner: -
--

CREATE UNIQUE INDEX uq_mascotas_microchip ON core.mascotas USING btree (empresa_id, microchip) WHERE ((microchip IS NOT NULL) AND (deleted_at IS NULL));


--
-- Name: uq_ordenes_servicio_origen; Type: INDEX; Schema: core; Owner: -
--

CREATE UNIQUE INDEX uq_ordenes_servicio_origen ON core.ordenes_servicio USING btree (empresa_id, origen_tabla, origen_id) WHERE ((origen_tabla IS NOT NULL) AND (estado <> 'anulado'::core.estado_orden_servicio));


--
-- Name: uq_razas_globales; Type: INDEX; Schema: core; Owner: -
--

CREATE UNIQUE INDEX uq_razas_globales ON core.razas USING btree (especie_id, lower((nombre)::text)) WHERE (empresa_id IS NULL);


--
-- Name: uq_razas_por_empresa; Type: INDEX; Schema: core; Owner: -
--

CREATE UNIQUE INDEX uq_razas_por_empresa ON core.razas USING btree (empresa_id, especie_id, lower((nombre)::text)) WHERE (empresa_id IS NOT NULL);


--
-- Name: almacenes tg_almacenes_updated_at; Type: TRIGGER; Schema: core; Owner: -
--

CREATE TRIGGER tg_almacenes_updated_at BEFORE UPDATE ON core.almacenes FOR EACH ROW EXECUTE FUNCTION core.trg_touch_updated_at();


--
-- Name: asistencia tg_asistencia_horas; Type: TRIGGER; Schema: core; Owner: -
--

CREATE TRIGGER tg_asistencia_horas BEFORE INSERT OR UPDATE ON core.asistencia FOR EACH ROW EXECUTE FUNCTION core.trg_asistencia_horas();


--
-- Name: asistencia tg_asistencia_updated_at; Type: TRIGGER; Schema: core; Owner: -
--

CREATE TRIGGER tg_asistencia_updated_at BEFORE UPDATE ON core.asistencia FOR EACH ROW EXECUTE FUNCTION core.trg_touch_updated_at();


--
-- Name: cajas tg_cajas_updated_at; Type: TRIGGER; Schema: core; Owner: -
--

CREATE TRIGGER tg_cajas_updated_at BEFORE UPDATE ON core.cajas FOR EACH ROW EXECUTE FUNCTION core.trg_touch_updated_at();


--
-- Name: categorias tg_categorias_updated_at; Type: TRIGGER; Schema: core; Owner: -
--

CREATE TRIGGER tg_categorias_updated_at BEFORE UPDATE ON core.categorias FOR EACH ROW EXECUTE FUNCTION core.trg_touch_updated_at();


--
-- Name: cirugias tg_cirugias_updated_at; Type: TRIGGER; Schema: core; Owner: -
--

CREATE TRIGGER tg_cirugias_updated_at BEFORE UPDATE ON core.cirugias FOR EACH ROW EXECUTE FUNCTION core.trg_touch_updated_at();


--
-- Name: citas tg_citas_updated_at; Type: TRIGGER; Schema: core; Owner: -
--

CREATE TRIGGER tg_citas_updated_at BEFORE UPDATE ON core.citas FOR EACH ROW EXECUTE FUNCTION core.trg_touch_updated_at();


--
-- Name: clausulas tg_clausulas_updated_at; Type: TRIGGER; Schema: core; Owner: -
--

CREATE TRIGGER tg_clausulas_updated_at BEFORE UPDATE ON core.clausulas FOR EACH ROW EXECUTE FUNCTION core.trg_touch_updated_at();


--
-- Name: clientes tg_clientes_updated_at; Type: TRIGGER; Schema: core; Owner: -
--

CREATE TRIGGER tg_clientes_updated_at BEFORE UPDATE ON core.clientes FOR EACH ROW EXECUTE FUNCTION core.trg_touch_updated_at();


--
-- Name: comprobante_items tg_comprobante_recalcular; Type: TRIGGER; Schema: core; Owner: -
--

CREATE TRIGGER tg_comprobante_recalcular AFTER INSERT OR DELETE OR UPDATE ON core.comprobante_items FOR EACH ROW EXECUTE FUNCTION core.trg_comprobante_recalcular();


--
-- Name: comprobantes tg_comprobantes_updated_at; Type: TRIGGER; Schema: core; Owner: -
--

CREATE TRIGGER tg_comprobantes_updated_at BEFORE UPDATE ON core.comprobantes FOR EACH ROW EXECUTE FUNCTION core.trg_touch_updated_at();


--
-- Name: consultas tg_consulta_sync_peso; Type: TRIGGER; Schema: core; Owner: -
--

CREATE TRIGGER tg_consulta_sync_peso AFTER INSERT OR UPDATE OF peso_kg ON core.consultas FOR EACH ROW EXECUTE FUNCTION core.trg_consulta_sync_peso();


--
-- Name: consultas tg_consultas_updated_at; Type: TRIGGER; Schema: core; Owner: -
--

CREATE TRIGGER tg_consultas_updated_at BEFORE UPDATE ON core.consultas FOR EACH ROW EXECUTE FUNCTION core.trg_touch_updated_at();


--
-- Name: consultorios tg_consultorios_updated_at; Type: TRIGGER; Schema: core; Owner: -
--

CREATE TRIGGER tg_consultorios_updated_at BEFORE UPDATE ON core.consultorios FOR EACH ROW EXECUTE FUNCTION core.trg_touch_updated_at();


--
-- Name: contratos_personal tg_contratos_personal_updated_at; Type: TRIGGER; Schema: core; Owner: -
--

CREATE TRIGGER tg_contratos_personal_updated_at BEFORE UPDATE ON core.contratos_personal FOR EACH ROW EXECUTE FUNCTION core.trg_touch_updated_at();


--
-- Name: disponibilidad tg_disponibilidad_updated_at; Type: TRIGGER; Schema: core; Owner: -
--

CREATE TRIGGER tg_disponibilidad_updated_at BEFORE UPDATE ON core.disponibilidad FOR EACH ROW EXECUTE FUNCTION core.trg_touch_updated_at();


--
-- Name: empresas tg_empresas_updated_at; Type: TRIGGER; Schema: core; Owner: -
--

CREATE TRIGGER tg_empresas_updated_at BEFORE UPDATE ON core.empresas FOR EACH ROW EXECUTE FUNCTION core.trg_touch_updated_at();


--
-- Name: especializaciones tg_especializaciones_updated_at; Type: TRIGGER; Schema: core; Owner: -
--

CREATE TRIGGER tg_especializaciones_updated_at BEFORE UPDATE ON core.especializaciones FOR EACH ROW EXECUTE FUNCTION core.trg_touch_updated_at();


--
-- Name: especies tg_especies_updated_at; Type: TRIGGER; Schema: core; Owner: -
--

CREATE TRIGGER tg_especies_updated_at BEFORE UPDATE ON core.especies FOR EACH ROW EXECUTE FUNCTION core.trg_touch_updated_at();


--
-- Name: esquemas_vacunacion tg_esquemas_vacunacion_updated_at; Type: TRIGGER; Schema: core; Owner: -
--

CREATE TRIGGER tg_esquemas_vacunacion_updated_at BEFORE UPDATE ON core.esquemas_vacunacion FOR EACH ROW EXECUTE FUNCTION core.trg_touch_updated_at();


--
-- Name: evaluaciones_personal tg_evaluacion_promedio; Type: TRIGGER; Schema: core; Owner: -
--

CREATE TRIGGER tg_evaluacion_promedio BEFORE INSERT OR UPDATE ON core.evaluaciones_personal FOR EACH ROW EXECUTE FUNCTION core.trg_evaluacion_promedio();


--
-- Name: historia_clinica tg_historia_clinica_updated_at; Type: TRIGGER; Schema: core; Owner: -
--

CREATE TRIGGER tg_historia_clinica_updated_at BEFORE UPDATE ON core.historia_clinica FOR EACH ROW EXECUTE FUNCTION core.trg_touch_updated_at();


--
-- Name: horarios_atencion tg_horarios_atencion_updated_at; Type: TRIGGER; Schema: core; Owner: -
--

CREATE TRIGGER tg_horarios_atencion_updated_at BEFORE UPDATE ON core.horarios_atencion FOR EACH ROW EXECUTE FUNCTION core.trg_touch_updated_at();


--
-- Name: hospitalizaciones tg_hospitalizaciones_updated_at; Type: TRIGGER; Schema: core; Owner: -
--

CREATE TRIGGER tg_hospitalizaciones_updated_at BEFORE UPDATE ON core.hospitalizaciones FOR EACH ROW EXECUTE FUNCTION core.trg_touch_updated_at();


--
-- Name: lotes tg_lotes_updated_at; Type: TRIGGER; Schema: core; Owner: -
--

CREATE TRIGGER tg_lotes_updated_at BEFORE UPDATE ON core.lotes FOR EACH ROW EXECUTE FUNCTION core.trg_touch_updated_at();


--
-- Name: mascotas tg_mascota_fallecida; Type: TRIGGER; Schema: core; Owner: -
--

CREATE TRIGGER tg_mascota_fallecida AFTER UPDATE OF estado ON core.mascotas FOR EACH ROW EXECUTE FUNCTION core.trg_mascota_fallecida();


--
-- Name: mascotas_extraviadas tg_mascotas_extraviadas_updated_at; Type: TRIGGER; Schema: core; Owner: -
--

CREATE TRIGGER tg_mascotas_extraviadas_updated_at BEFORE UPDATE ON core.mascotas_extraviadas FOR EACH ROW EXECUTE FUNCTION core.trg_touch_updated_at();


--
-- Name: mascotas tg_mascotas_updated_at; Type: TRIGGER; Schema: core; Owner: -
--

CREATE TRIGGER tg_mascotas_updated_at BEFORE UPDATE ON core.mascotas FOR EACH ROW EXECUTE FUNCTION core.trg_touch_updated_at();


--
-- Name: movimientos_inventario tg_movimiento_aplicar_stock; Type: TRIGGER; Schema: core; Owner: -
--

CREATE TRIGGER tg_movimiento_aplicar_stock BEFORE INSERT ON core.movimientos_inventario FOR EACH ROW EXECUTE FUNCTION core.trg_movimiento_aplicar_stock();


--
-- Name: clientes tg_normalizar_cliente; Type: TRIGGER; Schema: core; Owner: -
--

CREATE TRIGGER tg_normalizar_cliente BEFORE INSERT OR UPDATE ON core.clientes FOR EACH ROW EXECUTE FUNCTION core.trg_normalizar_cliente();


--
-- Name: empresas tg_normalizar_empresa; Type: TRIGGER; Schema: core; Owner: -
--

CREATE TRIGGER tg_normalizar_empresa BEFORE INSERT OR UPDATE ON core.empresas FOR EACH ROW EXECUTE FUNCTION core.trg_normalizar_empresa();


--
-- Name: especies tg_normalizar_especie; Type: TRIGGER; Schema: core; Owner: -
--

CREATE TRIGGER tg_normalizar_especie BEFORE INSERT OR UPDATE ON core.especies FOR EACH ROW EXECUTE FUNCTION core.trg_normalizar_taxonomia();


--
-- Name: mascotas tg_normalizar_mascota; Type: TRIGGER; Schema: core; Owner: -
--

CREATE TRIGGER tg_normalizar_mascota BEFORE INSERT OR UPDATE ON core.mascotas FOR EACH ROW EXECUTE FUNCTION core.trg_normalizar_mascota();


--
-- Name: productos tg_normalizar_producto; Type: TRIGGER; Schema: core; Owner: -
--

CREATE TRIGGER tg_normalizar_producto BEFORE INSERT OR UPDATE ON core.productos FOR EACH ROW EXECUTE FUNCTION core.trg_normalizar_producto();


--
-- Name: proveedores tg_normalizar_proveedor; Type: TRIGGER; Schema: core; Owner: -
--

CREATE TRIGGER tg_normalizar_proveedor BEFORE INSERT OR UPDATE ON core.proveedores FOR EACH ROW EXECUTE FUNCTION core.trg_normalizar_proveedor();


--
-- Name: proveedor_contactos tg_normalizar_proveedor_contacto; Type: TRIGGER; Schema: core; Owner: -
--

CREATE TRIGGER tg_normalizar_proveedor_contacto BEFORE INSERT OR UPDATE ON core.proveedor_contactos FOR EACH ROW EXECUTE FUNCTION core.trg_normalizar_contacto();


--
-- Name: razas tg_normalizar_raza; Type: TRIGGER; Schema: core; Owner: -
--

CREATE TRIGGER tg_normalizar_raza BEFORE INSERT OR UPDATE ON core.razas FOR EACH ROW EXECUTE FUNCTION core.trg_normalizar_taxonomia();


--
-- Name: servicios tg_normalizar_servicio; Type: TRIGGER; Schema: core; Owner: -
--

CREATE TRIGGER tg_normalizar_servicio BEFORE INSERT OR UPDATE ON core.servicios FOR EACH ROW EXECUTE FUNCTION core.trg_normalizar_servicio();


--
-- Name: users tg_normalizar_user; Type: TRIGGER; Schema: core; Owner: -
--

CREATE TRIGGER tg_normalizar_user BEFORE INSERT OR UPDATE ON core.users FOR EACH ROW EXECUTE FUNCTION core.trg_normalizar_user();


--
-- Name: notas_medicas tg_notas_medicas_updated_at; Type: TRIGGER; Schema: core; Owner: -
--

CREATE TRIGGER tg_notas_medicas_updated_at BEFORE UPDATE ON core.notas_medicas FOR EACH ROW EXECUTE FUNCTION core.trg_touch_updated_at();


--
-- Name: ordenes_compra tg_ordenes_compra_updated_at; Type: TRIGGER; Schema: core; Owner: -
--

CREATE TRIGGER tg_ordenes_compra_updated_at BEFORE UPDATE ON core.ordenes_compra FOR EACH ROW EXECUTE FUNCTION core.trg_touch_updated_at();


--
-- Name: ordenes_servicio tg_ordenes_servicio_updated_at; Type: TRIGGER; Schema: core; Owner: -
--

CREATE TRIGGER tg_ordenes_servicio_updated_at BEFORE UPDATE ON core.ordenes_servicio FOR EACH ROW EXECUTE FUNCTION core.trg_touch_updated_at();


--
-- Name: permisos_laborales tg_permisos_laborales_updated_at; Type: TRIGGER; Schema: core; Owner: -
--

CREATE TRIGGER tg_permisos_laborales_updated_at BEFORE UPDATE ON core.permisos_laborales FOR EACH ROW EXECUTE FUNCTION core.trg_touch_updated_at();


--
-- Name: plantillas_mensaje tg_plantillas_mensaje_updated_at; Type: TRIGGER; Schema: core; Owner: -
--

CREATE TRIGGER tg_plantillas_mensaje_updated_at BEFORE UPDATE ON core.plantillas_mensaje FOR EACH ROW EXECUTE FUNCTION core.trg_touch_updated_at();


--
-- Name: productos tg_productos_updated_at; Type: TRIGGER; Schema: core; Owner: -
--

CREATE TRIGGER tg_productos_updated_at BEFORE UPDATE ON core.productos FOR EACH ROW EXECUTE FUNCTION core.trg_touch_updated_at();


--
-- Name: proveedor_contactos tg_proveedor_contactos_updated_at; Type: TRIGGER; Schema: core; Owner: -
--

CREATE TRIGGER tg_proveedor_contactos_updated_at BEFORE UPDATE ON core.proveedor_contactos FOR EACH ROW EXECUTE FUNCTION core.trg_touch_updated_at();


--
-- Name: proveedores tg_proveedores_updated_at; Type: TRIGGER; Schema: core; Owner: -
--

CREATE TRIGGER tg_proveedores_updated_at BEFORE UPDATE ON core.proveedores FOR EACH ROW EXECUTE FUNCTION core.trg_touch_updated_at();


--
-- Name: razas tg_razas_updated_at; Type: TRIGGER; Schema: core; Owner: -
--

CREATE TRIGGER tg_razas_updated_at BEFORE UPDATE ON core.razas FOR EACH ROW EXECUTE FUNCTION core.trg_touch_updated_at();


--
-- Name: roles tg_roles_updated_at; Type: TRIGGER; Schema: core; Owner: -
--

CREATE TRIGGER tg_roles_updated_at BEFORE UPDATE ON core.roles FOR EACH ROW EXECUTE FUNCTION core.trg_touch_updated_at();


--
-- Name: servicios tg_servicios_updated_at; Type: TRIGGER; Schema: core; Owner: -
--

CREATE TRIGGER tg_servicios_updated_at BEFORE UPDATE ON core.servicios FOR EACH ROW EXECUTE FUNCTION core.trg_touch_updated_at();


--
-- Name: stock tg_stock_updated_at; Type: TRIGGER; Schema: core; Owner: -
--

CREATE TRIGGER tg_stock_updated_at BEFORE UPDATE ON core.stock FOR EACH ROW EXECUTE FUNCTION core.trg_touch_updated_at();


--
-- Name: tratamientos tg_tratamientos_updated_at; Type: TRIGGER; Schema: core; Owner: -
--

CREATE TRIGGER tg_tratamientos_updated_at BEFORE UPDATE ON core.tratamientos FOR EACH ROW EXECUTE FUNCTION core.trg_touch_updated_at();


--
-- Name: users tg_users_updated_at; Type: TRIGGER; Schema: core; Owner: -
--

CREATE TRIGGER tg_users_updated_at BEFORE UPDATE ON core.users FOR EACH ROW EXECUTE FUNCTION core.trg_touch_updated_at();


--
-- Name: users tg_users_validate_rol_scope; Type: TRIGGER; Schema: core; Owner: -
--

CREATE TRIGGER tg_users_validate_rol_scope BEFORE INSERT OR UPDATE OF rol_id, empresa_id ON core.users FOR EACH ROW EXECUTE FUNCTION core.trg_users_validate_rol_scope();


--
-- Name: vacunas tg_vacunas_updated_at; Type: TRIGGER; Schema: core; Owner: -
--

CREATE TRIGGER tg_vacunas_updated_at BEFORE UPDATE ON core.vacunas FOR EACH ROW EXECUTE FUNCTION core.trg_touch_updated_at();


--
-- Name: almacenes almacenes_empresa_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.almacenes
    ADD CONSTRAINT almacenes_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES core.empresas(id) ON DELETE CASCADE;


--
-- Name: asistencia asistencia_empresa_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.asistencia
    ADD CONSTRAINT asistencia_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES core.empresas(id) ON DELETE CASCADE;


--
-- Name: asistencia asistencia_user_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.asistencia
    ADD CONSTRAINT asistencia_user_id_fkey FOREIGN KEY (user_id) REFERENCES core.users(id) ON DELETE CASCADE;


--
-- Name: cajas cajas_empresa_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.cajas
    ADD CONSTRAINT cajas_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES core.empresas(id) ON DELETE CASCADE;


--
-- Name: cajas cajas_user_apertura_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.cajas
    ADD CONSTRAINT cajas_user_apertura_id_fkey FOREIGN KEY (user_apertura_id) REFERENCES core.users(id);


--
-- Name: cajas cajas_user_cierre_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.cajas
    ADD CONSTRAINT cajas_user_cierre_id_fkey FOREIGN KEY (user_cierre_id) REFERENCES core.users(id);


--
-- Name: categorias categorias_empresa_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.categorias
    ADD CONSTRAINT categorias_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES core.empresas(id) ON DELETE CASCADE;


--
-- Name: categorias categorias_padre_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.categorias
    ADD CONSTRAINT categorias_padre_id_fkey FOREIGN KEY (padre_id) REFERENCES core.categorias(id) ON DELETE SET NULL;


--
-- Name: cirugias cirugias_anestesista_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.cirugias
    ADD CONSTRAINT cirugias_anestesista_id_fkey FOREIGN KEY (anestesista_id) REFERENCES core.users(id);


--
-- Name: cirugias cirugias_cirujano_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.cirugias
    ADD CONSTRAINT cirugias_cirujano_id_fkey FOREIGN KEY (cirujano_id) REFERENCES core.users(id);


--
-- Name: cirugias cirugias_cita_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.cirugias
    ADD CONSTRAINT cirugias_cita_id_fkey FOREIGN KEY (cita_id) REFERENCES core.citas(id) ON DELETE SET NULL;


--
-- Name: cirugias cirugias_consultorio_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.cirugias
    ADD CONSTRAINT cirugias_consultorio_id_fkey FOREIGN KEY (consultorio_id) REFERENCES core.consultorios(id);


--
-- Name: cirugias cirugias_empresa_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.cirugias
    ADD CONSTRAINT cirugias_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES core.empresas(id) ON DELETE CASCADE;


--
-- Name: cirugias cirugias_mascota_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.cirugias
    ADD CONSTRAINT cirugias_mascota_id_fkey FOREIGN KEY (mascota_id) REFERENCES core.mascotas(id) ON DELETE RESTRICT;


--
-- Name: cirugias cirugias_servicio_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.cirugias
    ADD CONSTRAINT cirugias_servicio_id_fkey FOREIGN KEY (servicio_id) REFERENCES core.servicios(id);


--
-- Name: citas citas_cliente_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.citas
    ADD CONSTRAINT citas_cliente_id_fkey FOREIGN KEY (cliente_id) REFERENCES core.clientes(id) ON DELETE RESTRICT;


--
-- Name: citas citas_consultorio_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.citas
    ADD CONSTRAINT citas_consultorio_id_fkey FOREIGN KEY (consultorio_id) REFERENCES core.consultorios(id);


--
-- Name: citas citas_empresa_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.citas
    ADD CONSTRAINT citas_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES core.empresas(id) ON DELETE CASCADE;


--
-- Name: citas_historial citas_historial_cita_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.citas_historial
    ADD CONSTRAINT citas_historial_cita_id_fkey FOREIGN KEY (cita_id) REFERENCES core.citas(id) ON DELETE CASCADE;


--
-- Name: citas_lista_espera citas_lista_espera_cliente_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.citas_lista_espera
    ADD CONSTRAINT citas_lista_espera_cliente_id_fkey FOREIGN KEY (cliente_id) REFERENCES core.clientes(id) ON DELETE CASCADE;


--
-- Name: citas_lista_espera citas_lista_espera_empresa_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.citas_lista_espera
    ADD CONSTRAINT citas_lista_espera_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES core.empresas(id) ON DELETE CASCADE;


--
-- Name: citas_lista_espera citas_lista_espera_mascota_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.citas_lista_espera
    ADD CONSTRAINT citas_lista_espera_mascota_id_fkey FOREIGN KEY (mascota_id) REFERENCES core.mascotas(id) ON DELETE CASCADE;


--
-- Name: citas_lista_espera citas_lista_espera_servicio_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.citas_lista_espera
    ADD CONSTRAINT citas_lista_espera_servicio_id_fkey FOREIGN KEY (servicio_id) REFERENCES core.servicios(id);


--
-- Name: citas_lista_espera citas_lista_espera_veterinario_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.citas_lista_espera
    ADD CONSTRAINT citas_lista_espera_veterinario_id_fkey FOREIGN KEY (veterinario_id) REFERENCES core.users(id);


--
-- Name: citas citas_mascota_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.citas
    ADD CONSTRAINT citas_mascota_id_fkey FOREIGN KEY (mascota_id) REFERENCES core.mascotas(id) ON DELETE RESTRICT;


--
-- Name: citas citas_servicio_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.citas
    ADD CONSTRAINT citas_servicio_id_fkey FOREIGN KEY (servicio_id) REFERENCES core.servicios(id);


--
-- Name: citas citas_veterinario_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.citas
    ADD CONSTRAINT citas_veterinario_id_fkey FOREIGN KEY (veterinario_id) REFERENCES core.users(id);


--
-- Name: clausulas clausulas_empresa_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.clausulas
    ADD CONSTRAINT clausulas_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES core.empresas(id) ON DELETE CASCADE;


--
-- Name: clientes clientes_empresa_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.clientes
    ADD CONSTRAINT clientes_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES core.empresas(id) ON DELETE RESTRICT;


--
-- Name: comprobante_items comprobante_items_comprobante_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.comprobante_items
    ADD CONSTRAINT comprobante_items_comprobante_id_fkey FOREIGN KEY (comprobante_id) REFERENCES core.comprobantes(id) ON DELETE CASCADE;


--
-- Name: comprobante_items comprobante_items_insumo_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.comprobante_items
    ADD CONSTRAINT comprobante_items_insumo_id_fkey FOREIGN KEY (insumo_id) REFERENCES core.insumos_utilizados(id) ON DELETE SET NULL;


--
-- Name: comprobante_items comprobante_items_item_ref_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.comprobante_items
    ADD CONSTRAINT comprobante_items_item_ref_id_fkey FOREIGN KEY (item_ref_id) REFERENCES core.comprobante_items(id) ON DELETE SET NULL;


--
-- Name: comprobante_items comprobante_items_orden_servicio_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.comprobante_items
    ADD CONSTRAINT comprobante_items_orden_servicio_id_fkey FOREIGN KEY (orden_servicio_id) REFERENCES core.ordenes_servicio(id);


--
-- Name: comprobante_items comprobante_items_producto_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.comprobante_items
    ADD CONSTRAINT comprobante_items_producto_id_fkey FOREIGN KEY (producto_id) REFERENCES core.productos(id);


--
-- Name: comprobante_items comprobante_items_servicio_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.comprobante_items
    ADD CONSTRAINT comprobante_items_servicio_id_fkey FOREIGN KEY (servicio_id) REFERENCES core.servicios(id);


--
-- Name: comprobante_pse_log comprobante_pse_log_comprobante_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.comprobante_pse_log
    ADD CONSTRAINT comprobante_pse_log_comprobante_id_fkey FOREIGN KEY (comprobante_id) REFERENCES core.comprobantes(id) ON DELETE CASCADE;


--
-- Name: comprobantes comprobantes_cita_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.comprobantes
    ADD CONSTRAINT comprobantes_cita_id_fkey FOREIGN KEY (cita_id) REFERENCES core.citas(id) ON DELETE SET NULL;


--
-- Name: comprobantes comprobantes_cliente_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.comprobantes
    ADD CONSTRAINT comprobantes_cliente_id_fkey FOREIGN KEY (cliente_id) REFERENCES core.clientes(id) ON DELETE RESTRICT;


--
-- Name: comprobantes comprobantes_consulta_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.comprobantes
    ADD CONSTRAINT comprobantes_consulta_id_fkey FOREIGN KEY (consulta_id) REFERENCES core.consultas(id) ON DELETE SET NULL;


--
-- Name: comprobantes comprobantes_documento_ref_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.comprobantes
    ADD CONSTRAINT comprobantes_documento_ref_id_fkey FOREIGN KEY (documento_ref_id) REFERENCES core.comprobantes(id);


--
-- Name: comprobantes comprobantes_empresa_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.comprobantes
    ADD CONSTRAINT comprobantes_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES core.empresas(id) ON DELETE CASCADE;


--
-- Name: comprobantes comprobantes_mascota_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.comprobantes
    ADD CONSTRAINT comprobantes_mascota_id_fkey FOREIGN KEY (mascota_id) REFERENCES core.mascotas(id);


--
-- Name: comunicaciones comunicaciones_cliente_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.comunicaciones
    ADD CONSTRAINT comunicaciones_cliente_id_fkey FOREIGN KEY (cliente_id) REFERENCES core.clientes(id) ON DELETE CASCADE;


--
-- Name: comunicaciones comunicaciones_empresa_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.comunicaciones
    ADD CONSTRAINT comunicaciones_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES core.empresas(id) ON DELETE CASCADE;


--
-- Name: comunicaciones comunicaciones_mascota_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.comunicaciones
    ADD CONSTRAINT comunicaciones_mascota_id_fkey FOREIGN KEY (mascota_id) REFERENCES core.mascotas(id) ON DELETE SET NULL;


--
-- Name: comunicaciones comunicaciones_user_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.comunicaciones
    ADD CONSTRAINT comunicaciones_user_id_fkey FOREIGN KEY (user_id) REFERENCES core.users(id);


--
-- Name: consultas consultas_cita_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.consultas
    ADD CONSTRAINT consultas_cita_id_fkey FOREIGN KEY (cita_id) REFERENCES core.citas(id) ON DELETE SET NULL;


--
-- Name: consultas consultas_cliente_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.consultas
    ADD CONSTRAINT consultas_cliente_id_fkey FOREIGN KEY (cliente_id) REFERENCES core.clientes(id) ON DELETE RESTRICT;


--
-- Name: consultas consultas_empresa_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.consultas
    ADD CONSTRAINT consultas_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES core.empresas(id) ON DELETE CASCADE;


--
-- Name: consultas consultas_mascota_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.consultas
    ADD CONSTRAINT consultas_mascota_id_fkey FOREIGN KEY (mascota_id) REFERENCES core.mascotas(id) ON DELETE RESTRICT;


--
-- Name: consultas consultas_veterinario_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.consultas
    ADD CONSTRAINT consultas_veterinario_id_fkey FOREIGN KEY (veterinario_id) REFERENCES core.users(id);


--
-- Name: consultorios consultorios_empresa_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.consultorios
    ADD CONSTRAINT consultorios_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES core.empresas(id) ON DELETE CASCADE;


--
-- Name: contratos_personal contratos_personal_empresa_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.contratos_personal
    ADD CONSTRAINT contratos_personal_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES core.empresas(id) ON DELETE CASCADE;


--
-- Name: contratos_personal contratos_personal_user_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.contratos_personal
    ADD CONSTRAINT contratos_personal_user_id_fkey FOREIGN KEY (user_id) REFERENCES core.users(id) ON DELETE CASCADE;


--
-- Name: desparasitaciones desparasitaciones_consulta_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.desparasitaciones
    ADD CONSTRAINT desparasitaciones_consulta_id_fkey FOREIGN KEY (consulta_id) REFERENCES core.consultas(id) ON DELETE SET NULL;


--
-- Name: desparasitaciones desparasitaciones_empresa_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.desparasitaciones
    ADD CONSTRAINT desparasitaciones_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES core.empresas(id) ON DELETE CASCADE;


--
-- Name: desparasitaciones desparasitaciones_mascota_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.desparasitaciones
    ADD CONSTRAINT desparasitaciones_mascota_id_fkey FOREIGN KEY (mascota_id) REFERENCES core.mascotas(id) ON DELETE CASCADE;


--
-- Name: desparasitaciones desparasitaciones_veterinario_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.desparasitaciones
    ADD CONSTRAINT desparasitaciones_veterinario_id_fkey FOREIGN KEY (veterinario_id) REFERENCES core.users(id);


--
-- Name: disponibilidad disponibilidad_consultorio_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.disponibilidad
    ADD CONSTRAINT disponibilidad_consultorio_id_fkey FOREIGN KEY (consultorio_id) REFERENCES core.consultorios(id);


--
-- Name: disponibilidad disponibilidad_empresa_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.disponibilidad
    ADD CONSTRAINT disponibilidad_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES core.empresas(id) ON DELETE CASCADE;


--
-- Name: disponibilidad disponibilidad_permiso_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.disponibilidad
    ADD CONSTRAINT disponibilidad_permiso_id_fkey FOREIGN KEY (permiso_id) REFERENCES core.permisos_laborales(id) ON DELETE CASCADE;


--
-- Name: disponibilidad disponibilidad_user_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.disponibilidad
    ADD CONSTRAINT disponibilidad_user_id_fkey FOREIGN KEY (user_id) REFERENCES core.users(id) ON DELETE CASCADE;


--
-- Name: documentos_medicos documentos_medicos_consulta_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.documentos_medicos
    ADD CONSTRAINT documentos_medicos_consulta_id_fkey FOREIGN KEY (consulta_id) REFERENCES core.consultas(id) ON DELETE SET NULL;


--
-- Name: documentos_medicos documentos_medicos_empresa_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.documentos_medicos
    ADD CONSTRAINT documentos_medicos_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES core.empresas(id) ON DELETE CASCADE;


--
-- Name: documentos_medicos documentos_medicos_mascota_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.documentos_medicos
    ADD CONSTRAINT documentos_medicos_mascota_id_fkey FOREIGN KEY (mascota_id) REFERENCES core.mascotas(id) ON DELETE CASCADE;


--
-- Name: esquemas_vacunacion esquemas_vacunacion_empresa_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.esquemas_vacunacion
    ADD CONSTRAINT esquemas_vacunacion_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES core.empresas(id) ON DELETE CASCADE;


--
-- Name: esquemas_vacunacion esquemas_vacunacion_especie_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.esquemas_vacunacion
    ADD CONSTRAINT esquemas_vacunacion_especie_id_fkey FOREIGN KEY (especie_id) REFERENCES core.especies(id);


--
-- Name: evaluaciones_personal evaluaciones_personal_empresa_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.evaluaciones_personal
    ADD CONSTRAINT evaluaciones_personal_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES core.empresas(id) ON DELETE CASCADE;


--
-- Name: evaluaciones_personal evaluaciones_personal_evaluador_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.evaluaciones_personal
    ADD CONSTRAINT evaluaciones_personal_evaluador_id_fkey FOREIGN KEY (evaluador_id) REFERENCES core.users(id);


--
-- Name: evaluaciones_personal evaluaciones_personal_user_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.evaluaciones_personal
    ADD CONSTRAINT evaluaciones_personal_user_id_fkey FOREIGN KEY (user_id) REFERENCES core.users(id) ON DELETE CASCADE;


--
-- Name: examenes examenes_consulta_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.examenes
    ADD CONSTRAINT examenes_consulta_id_fkey FOREIGN KEY (consulta_id) REFERENCES core.consultas(id) ON DELETE SET NULL;


--
-- Name: examenes examenes_empresa_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.examenes
    ADD CONSTRAINT examenes_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES core.empresas(id) ON DELETE CASCADE;


--
-- Name: examenes examenes_mascota_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.examenes
    ADD CONSTRAINT examenes_mascota_id_fkey FOREIGN KEY (mascota_id) REFERENCES core.mascotas(id) ON DELETE CASCADE;


--
-- Name: examenes examenes_servicio_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.examenes
    ADD CONSTRAINT examenes_servicio_id_fkey FOREIGN KEY (servicio_id) REFERENCES core.servicios(id);


--
-- Name: examenes examenes_veterinario_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.examenes
    ADD CONSTRAINT examenes_veterinario_id_fkey FOREIGN KEY (veterinario_id) REFERENCES core.users(id);


--
-- Name: comprobantes fk_comprobantes_caja; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.comprobantes
    ADD CONSTRAINT fk_comprobantes_caja FOREIGN KEY (caja_id) REFERENCES core.cajas(id);


--
-- Name: desparasitaciones fk_desparasitaciones_producto; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.desparasitaciones
    ADD CONSTRAINT fk_desparasitaciones_producto FOREIGN KEY (producto_id) REFERENCES core.productos(id);


--
-- Name: movimientos_inventario fk_movimientos_comprobante; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.movimientos_inventario
    ADD CONSTRAINT fk_movimientos_comprobante FOREIGN KEY (comprobante_id) REFERENCES core.comprobantes(id);


--
-- Name: movimientos_inventario fk_movimientos_oc; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.movimientos_inventario
    ADD CONSTRAINT fk_movimientos_oc FOREIGN KEY (orden_compra_id) REFERENCES core.ordenes_compra(id);


--
-- Name: movimientos_inventario fk_movimientos_proveedor; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.movimientos_inventario
    ADD CONSTRAINT fk_movimientos_proveedor FOREIGN KEY (proveedor_id) REFERENCES core.proveedores(id);


--
-- Name: ordenes_servicio fk_ordenes_servicio_comprobante; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.ordenes_servicio
    ADD CONSTRAINT fk_ordenes_servicio_comprobante FOREIGN KEY (comprobante_id) REFERENCES core.comprobantes(id);


--
-- Name: pagos fk_pagos_caja; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.pagos
    ADD CONSTRAINT fk_pagos_caja FOREIGN KEY (caja_id) REFERENCES core.cajas(id);


--
-- Name: servicios fk_servicios_producto; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.servicios
    ADD CONSTRAINT fk_servicios_producto FOREIGN KEY (producto_id) REFERENCES core.productos(id);


--
-- Name: tratamientos fk_tratamientos_producto; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.tratamientos
    ADD CONSTRAINT fk_tratamientos_producto FOREIGN KEY (producto_id) REFERENCES core.productos(id);


--
-- Name: vacunas fk_vacunas_producto; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.vacunas
    ADD CONSTRAINT fk_vacunas_producto FOREIGN KEY (producto_id) REFERENCES core.productos(id);


--
-- Name: historia_clinica historia_clinica_cita_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.historia_clinica
    ADD CONSTRAINT historia_clinica_cita_id_fkey FOREIGN KEY (cita_id) REFERENCES core.citas(id) ON DELETE SET NULL;


--
-- Name: historia_clinica historia_clinica_cliente_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.historia_clinica
    ADD CONSTRAINT historia_clinica_cliente_id_fkey FOREIGN KEY (cliente_id) REFERENCES core.clientes(id) ON DELETE RESTRICT;


--
-- Name: historia_clinica historia_clinica_empresa_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.historia_clinica
    ADD CONSTRAINT historia_clinica_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES core.empresas(id) ON DELETE CASCADE;


--
-- Name: historia_clinica historia_clinica_mascota_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.historia_clinica
    ADD CONSTRAINT historia_clinica_mascota_id_fkey FOREIGN KEY (mascota_id) REFERENCES core.mascotas(id) ON DELETE CASCADE;


--
-- Name: historia_clinica historia_clinica_veterinario_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.historia_clinica
    ADD CONSTRAINT historia_clinica_veterinario_id_fkey FOREIGN KEY (veterinario_id) REFERENCES core.users(id);


--
-- Name: horarios_atencion horarios_atencion_empresa_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.horarios_atencion
    ADD CONSTRAINT horarios_atencion_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES core.empresas(id) ON DELETE CASCADE;


--
-- Name: hospitalizacion_evoluciones hospitalizacion_evoluciones_hospitalizacion_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.hospitalizacion_evoluciones
    ADD CONSTRAINT hospitalizacion_evoluciones_hospitalizacion_id_fkey FOREIGN KEY (hospitalizacion_id) REFERENCES core.hospitalizaciones(id) ON DELETE CASCADE;


--
-- Name: hospitalizacion_evoluciones hospitalizacion_evoluciones_user_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.hospitalizacion_evoluciones
    ADD CONSTRAINT hospitalizacion_evoluciones_user_id_fkey FOREIGN KEY (user_id) REFERENCES core.users(id);


--
-- Name: hospitalizaciones hospitalizaciones_consultorio_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.hospitalizaciones
    ADD CONSTRAINT hospitalizaciones_consultorio_id_fkey FOREIGN KEY (consultorio_id) REFERENCES core.consultorios(id);


--
-- Name: hospitalizaciones hospitalizaciones_empresa_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.hospitalizaciones
    ADD CONSTRAINT hospitalizaciones_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES core.empresas(id) ON DELETE CASCADE;


--
-- Name: hospitalizaciones hospitalizaciones_mascota_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.hospitalizaciones
    ADD CONSTRAINT hospitalizaciones_mascota_id_fkey FOREIGN KEY (mascota_id) REFERENCES core.mascotas(id) ON DELETE RESTRICT;


--
-- Name: hospitalizaciones hospitalizaciones_veterinario_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.hospitalizaciones
    ADD CONSTRAINT hospitalizaciones_veterinario_id_fkey FOREIGN KEY (veterinario_id) REFERENCES core.users(id);


--
-- Name: insumos_utilizados insumos_utilizados_cirugia_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.insumos_utilizados
    ADD CONSTRAINT insumos_utilizados_cirugia_id_fkey FOREIGN KEY (cirugia_id) REFERENCES core.cirugias(id) ON DELETE CASCADE;


--
-- Name: insumos_utilizados insumos_utilizados_consulta_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.insumos_utilizados
    ADD CONSTRAINT insumos_utilizados_consulta_id_fkey FOREIGN KEY (consulta_id) REFERENCES core.consultas(id) ON DELETE CASCADE;


--
-- Name: insumos_utilizados insumos_utilizados_empresa_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.insumos_utilizados
    ADD CONSTRAINT insumos_utilizados_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES core.empresas(id) ON DELETE CASCADE;


--
-- Name: insumos_utilizados insumos_utilizados_hospitalizacion_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.insumos_utilizados
    ADD CONSTRAINT insumos_utilizados_hospitalizacion_id_fkey FOREIGN KEY (hospitalizacion_id) REFERENCES core.hospitalizaciones(id) ON DELETE CASCADE;


--
-- Name: insumos_utilizados insumos_utilizados_mascota_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.insumos_utilizados
    ADD CONSTRAINT insumos_utilizados_mascota_id_fkey FOREIGN KEY (mascota_id) REFERENCES core.mascotas(id);


--
-- Name: insumos_utilizados insumos_utilizados_orden_servicio_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.insumos_utilizados
    ADD CONSTRAINT insumos_utilizados_orden_servicio_id_fkey FOREIGN KEY (orden_servicio_id) REFERENCES core.ordenes_servicio(id) ON DELETE SET NULL;


--
-- Name: insumos_utilizados insumos_utilizados_producto_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.insumos_utilizados
    ADD CONSTRAINT insumos_utilizados_producto_id_fkey FOREIGN KEY (producto_id) REFERENCES core.productos(id) ON DELETE RESTRICT;


--
-- Name: lotes lotes_empresa_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.lotes
    ADD CONSTRAINT lotes_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES core.empresas(id) ON DELETE CASCADE;


--
-- Name: lotes lotes_producto_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.lotes
    ADD CONSTRAINT lotes_producto_id_fkey FOREIGN KEY (producto_id) REFERENCES core.productos(id) ON DELETE CASCADE;


--
-- Name: mascotas mascotas_cliente_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.mascotas
    ADD CONSTRAINT mascotas_cliente_id_fkey FOREIGN KEY (cliente_id) REFERENCES core.clientes(id) ON DELETE RESTRICT;


--
-- Name: mascotas mascotas_empresa_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.mascotas
    ADD CONSTRAINT mascotas_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES core.empresas(id) ON DELETE RESTRICT;


--
-- Name: mascotas mascotas_especie_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.mascotas
    ADD CONSTRAINT mascotas_especie_id_fkey FOREIGN KEY (especie_id) REFERENCES core.especies(id);


--
-- Name: mascotas_extraviadas mascotas_extraviadas_empresa_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.mascotas_extraviadas
    ADD CONSTRAINT mascotas_extraviadas_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES core.empresas(id) ON DELETE CASCADE;


--
-- Name: mascotas_extraviadas mascotas_extraviadas_mascota_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.mascotas_extraviadas
    ADD CONSTRAINT mascotas_extraviadas_mascota_id_fkey FOREIGN KEY (mascota_id) REFERENCES core.mascotas(id) ON DELETE CASCADE;


--
-- Name: mascotas mascotas_raza_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.mascotas
    ADD CONSTRAINT mascotas_raza_id_fkey FOREIGN KEY (raza_id) REFERENCES core.razas(id);


--
-- Name: movimientos_caja movimientos_caja_caja_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.movimientos_caja
    ADD CONSTRAINT movimientos_caja_caja_id_fkey FOREIGN KEY (caja_id) REFERENCES core.cajas(id) ON DELETE CASCADE;


--
-- Name: movimientos_caja movimientos_caja_comprobante_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.movimientos_caja
    ADD CONSTRAINT movimientos_caja_comprobante_id_fkey FOREIGN KEY (comprobante_id) REFERENCES core.comprobantes(id) ON DELETE SET NULL;


--
-- Name: movimientos_caja movimientos_caja_empresa_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.movimientos_caja
    ADD CONSTRAINT movimientos_caja_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES core.empresas(id) ON DELETE CASCADE;


--
-- Name: movimientos_caja movimientos_caja_pago_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.movimientos_caja
    ADD CONSTRAINT movimientos_caja_pago_id_fkey FOREIGN KEY (pago_id) REFERENCES core.pagos(id) ON DELETE SET NULL;


--
-- Name: movimientos_inventario movimientos_inventario_almacen_destino_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.movimientos_inventario
    ADD CONSTRAINT movimientos_inventario_almacen_destino_id_fkey FOREIGN KEY (almacen_destino_id) REFERENCES core.almacenes(id);


--
-- Name: movimientos_inventario movimientos_inventario_almacen_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.movimientos_inventario
    ADD CONSTRAINT movimientos_inventario_almacen_id_fkey FOREIGN KEY (almacen_id) REFERENCES core.almacenes(id);


--
-- Name: movimientos_inventario movimientos_inventario_cliente_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.movimientos_inventario
    ADD CONSTRAINT movimientos_inventario_cliente_id_fkey FOREIGN KEY (cliente_id) REFERENCES core.clientes(id);


--
-- Name: movimientos_inventario movimientos_inventario_consulta_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.movimientos_inventario
    ADD CONSTRAINT movimientos_inventario_consulta_id_fkey FOREIGN KEY (consulta_id) REFERENCES core.consultas(id);


--
-- Name: movimientos_inventario movimientos_inventario_empresa_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.movimientos_inventario
    ADD CONSTRAINT movimientos_inventario_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES core.empresas(id) ON DELETE CASCADE;


--
-- Name: movimientos_inventario movimientos_inventario_lote_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.movimientos_inventario
    ADD CONSTRAINT movimientos_inventario_lote_id_fkey FOREIGN KEY (lote_id) REFERENCES core.lotes(id);


--
-- Name: movimientos_inventario movimientos_inventario_mascota_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.movimientos_inventario
    ADD CONSTRAINT movimientos_inventario_mascota_id_fkey FOREIGN KEY (mascota_id) REFERENCES core.mascotas(id);


--
-- Name: movimientos_inventario movimientos_inventario_producto_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.movimientos_inventario
    ADD CONSTRAINT movimientos_inventario_producto_id_fkey FOREIGN KEY (producto_id) REFERENCES core.productos(id) ON DELETE RESTRICT;


--
-- Name: notas_medicas notas_medicas_empresa_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.notas_medicas
    ADD CONSTRAINT notas_medicas_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES core.empresas(id) ON DELETE CASCADE;


--
-- Name: notas_medicas notas_medicas_mascota_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.notas_medicas
    ADD CONSTRAINT notas_medicas_mascota_id_fkey FOREIGN KEY (mascota_id) REFERENCES core.mascotas(id) ON DELETE CASCADE;


--
-- Name: notas_medicas notas_medicas_user_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.notas_medicas
    ADD CONSTRAINT notas_medicas_user_id_fkey FOREIGN KEY (user_id) REFERENCES core.users(id);


--
-- Name: notificaciones notificaciones_empresa_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.notificaciones
    ADD CONSTRAINT notificaciones_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES core.empresas(id);


--
-- Name: notificaciones notificaciones_user_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.notificaciones
    ADD CONSTRAINT notificaciones_user_id_fkey FOREIGN KEY (user_id) REFERENCES core.users(id) ON DELETE CASCADE;


--
-- Name: orden_compra_items orden_compra_items_orden_compra_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.orden_compra_items
    ADD CONSTRAINT orden_compra_items_orden_compra_id_fkey FOREIGN KEY (orden_compra_id) REFERENCES core.ordenes_compra(id) ON DELETE CASCADE;


--
-- Name: orden_compra_items orden_compra_items_producto_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.orden_compra_items
    ADD CONSTRAINT orden_compra_items_producto_id_fkey FOREIGN KEY (producto_id) REFERENCES core.productos(id) ON DELETE RESTRICT;


--
-- Name: ordenes_compra ordenes_compra_almacen_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.ordenes_compra
    ADD CONSTRAINT ordenes_compra_almacen_id_fkey FOREIGN KEY (almacen_id) REFERENCES core.almacenes(id);


--
-- Name: ordenes_compra ordenes_compra_empresa_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.ordenes_compra
    ADD CONSTRAINT ordenes_compra_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES core.empresas(id) ON DELETE CASCADE;


--
-- Name: ordenes_compra ordenes_compra_proveedor_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.ordenes_compra
    ADD CONSTRAINT ordenes_compra_proveedor_id_fkey FOREIGN KEY (proveedor_id) REFERENCES core.proveedores(id) ON DELETE RESTRICT;


--
-- Name: ordenes_servicio ordenes_servicio_cita_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.ordenes_servicio
    ADD CONSTRAINT ordenes_servicio_cita_id_fkey FOREIGN KEY (cita_id) REFERENCES core.citas(id) ON DELETE SET NULL;


--
-- Name: ordenes_servicio ordenes_servicio_cliente_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.ordenes_servicio
    ADD CONSTRAINT ordenes_servicio_cliente_id_fkey FOREIGN KEY (cliente_id) REFERENCES core.clientes(id) ON DELETE RESTRICT;


--
-- Name: ordenes_servicio ordenes_servicio_consulta_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.ordenes_servicio
    ADD CONSTRAINT ordenes_servicio_consulta_id_fkey FOREIGN KEY (consulta_id) REFERENCES core.consultas(id) ON DELETE SET NULL;


--
-- Name: ordenes_servicio ordenes_servicio_empresa_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.ordenes_servicio
    ADD CONSTRAINT ordenes_servicio_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES core.empresas(id) ON DELETE CASCADE;


--
-- Name: ordenes_servicio ordenes_servicio_mascota_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.ordenes_servicio
    ADD CONSTRAINT ordenes_servicio_mascota_id_fkey FOREIGN KEY (mascota_id) REFERENCES core.mascotas(id) ON DELETE RESTRICT;


--
-- Name: ordenes_servicio ordenes_servicio_servicio_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.ordenes_servicio
    ADD CONSTRAINT ordenes_servicio_servicio_id_fkey FOREIGN KEY (servicio_id) REFERENCES core.servicios(id);


--
-- Name: ordenes_servicio ordenes_servicio_veterinario_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.ordenes_servicio
    ADD CONSTRAINT ordenes_servicio_veterinario_id_fkey FOREIGN KEY (veterinario_id) REFERENCES core.users(id);


--
-- Name: pago_aplicaciones pago_aplicaciones_comprobante_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.pago_aplicaciones
    ADD CONSTRAINT pago_aplicaciones_comprobante_id_fkey FOREIGN KEY (comprobante_id) REFERENCES core.comprobantes(id) ON DELETE CASCADE;


--
-- Name: pago_aplicaciones pago_aplicaciones_pago_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.pago_aplicaciones
    ADD CONSTRAINT pago_aplicaciones_pago_id_fkey FOREIGN KEY (pago_id) REFERENCES core.pagos(id) ON DELETE CASCADE;


--
-- Name: pagos pagos_cliente_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.pagos
    ADD CONSTRAINT pagos_cliente_id_fkey FOREIGN KEY (cliente_id) REFERENCES core.clientes(id) ON DELETE RESTRICT;


--
-- Name: pagos pagos_empresa_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.pagos
    ADD CONSTRAINT pagos_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES core.empresas(id) ON DELETE CASCADE;


--
-- Name: pagos_proveedor pagos_proveedor_empresa_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.pagos_proveedor
    ADD CONSTRAINT pagos_proveedor_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES core.empresas(id) ON DELETE CASCADE;


--
-- Name: pagos_proveedor pagos_proveedor_orden_compra_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.pagos_proveedor
    ADD CONSTRAINT pagos_proveedor_orden_compra_id_fkey FOREIGN KEY (orden_compra_id) REFERENCES core.ordenes_compra(id) ON DELETE SET NULL;


--
-- Name: pagos_proveedor pagos_proveedor_proveedor_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.pagos_proveedor
    ADD CONSTRAINT pagos_proveedor_proveedor_id_fkey FOREIGN KEY (proveedor_id) REFERENCES core.proveedores(id) ON DELETE RESTRICT;


--
-- Name: permisos_laborales permisos_laborales_aprobado_por_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.permisos_laborales
    ADD CONSTRAINT permisos_laborales_aprobado_por_fkey FOREIGN KEY (aprobado_por) REFERENCES core.users(id);


--
-- Name: permisos_laborales permisos_laborales_empresa_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.permisos_laborales
    ADD CONSTRAINT permisos_laborales_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES core.empresas(id) ON DELETE CASCADE;


--
-- Name: permisos_laborales permisos_laborales_user_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.permisos_laborales
    ADD CONSTRAINT permisos_laborales_user_id_fkey FOREIGN KEY (user_id) REFERENCES core.users(id) ON DELETE CASCADE;


--
-- Name: plantillas_mensaje plantillas_mensaje_empresa_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.plantillas_mensaje
    ADD CONSTRAINT plantillas_mensaje_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES core.empresas(id) ON DELETE CASCADE;


--
-- Name: productos productos_categoria_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.productos
    ADD CONSTRAINT productos_categoria_id_fkey FOREIGN KEY (categoria_id) REFERENCES core.categorias(id) ON DELETE SET NULL;


--
-- Name: productos productos_empresa_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.productos
    ADD CONSTRAINT productos_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES core.empresas(id) ON DELETE CASCADE;


--
-- Name: proveedor_contactos proveedor_contactos_proveedor_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.proveedor_contactos
    ADD CONSTRAINT proveedor_contactos_proveedor_id_fkey FOREIGN KEY (proveedor_id) REFERENCES core.proveedores(id) ON DELETE CASCADE;


--
-- Name: proveedores proveedores_categoria_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.proveedores
    ADD CONSTRAINT proveedores_categoria_id_fkey FOREIGN KEY (categoria_id) REFERENCES core.categorias(id) ON DELETE SET NULL;


--
-- Name: proveedores proveedores_empresa_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.proveedores
    ADD CONSTRAINT proveedores_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES core.empresas(id) ON DELETE CASCADE;


--
-- Name: razas razas_empresa_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.razas
    ADD CONSTRAINT razas_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES core.empresas(id) ON DELETE CASCADE;


--
-- Name: razas razas_especie_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.razas
    ADD CONSTRAINT razas_especie_id_fkey FOREIGN KEY (especie_id) REFERENCES core.especies(id) ON DELETE CASCADE;


--
-- Name: recordatorios recordatorios_cliente_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.recordatorios
    ADD CONSTRAINT recordatorios_cliente_id_fkey FOREIGN KEY (cliente_id) REFERENCES core.clientes(id) ON DELETE CASCADE;


--
-- Name: recordatorios recordatorios_empresa_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.recordatorios
    ADD CONSTRAINT recordatorios_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES core.empresas(id) ON DELETE CASCADE;


--
-- Name: recordatorios recordatorios_mascota_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.recordatorios
    ADD CONSTRAINT recordatorios_mascota_id_fkey FOREIGN KEY (mascota_id) REFERENCES core.mascotas(id) ON DELETE CASCADE;


--
-- Name: rol_permisos rol_permisos_permiso_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.rol_permisos
    ADD CONSTRAINT rol_permisos_permiso_id_fkey FOREIGN KEY (permiso_id) REFERENCES core.permisos(id) ON DELETE CASCADE;


--
-- Name: rol_permisos rol_permisos_rol_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.rol_permisos
    ADD CONSTRAINT rol_permisos_rol_id_fkey FOREIGN KEY (rol_id) REFERENCES core.roles(id) ON DELETE CASCADE;


--
-- Name: servicios servicios_categoria_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.servicios
    ADD CONSTRAINT servicios_categoria_id_fkey FOREIGN KEY (categoria_id) REFERENCES core.categorias(id) ON DELETE SET NULL;


--
-- Name: servicios servicios_empresa_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.servicios
    ADD CONSTRAINT servicios_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES core.empresas(id) ON DELETE CASCADE;


--
-- Name: sesiones sesiones_user_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.sesiones
    ADD CONSTRAINT sesiones_user_id_fkey FOREIGN KEY (user_id) REFERENCES core.users(id) ON DELETE CASCADE;


--
-- Name: stock stock_almacen_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.stock
    ADD CONSTRAINT stock_almacen_id_fkey FOREIGN KEY (almacen_id) REFERENCES core.almacenes(id) ON DELETE CASCADE;


--
-- Name: stock stock_empresa_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.stock
    ADD CONSTRAINT stock_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES core.empresas(id) ON DELETE CASCADE;


--
-- Name: stock stock_producto_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.stock
    ADD CONSTRAINT stock_producto_id_fkey FOREIGN KEY (producto_id) REFERENCES core.productos(id) ON DELETE CASCADE;


--
-- Name: tratamientos tratamientos_consulta_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.tratamientos
    ADD CONSTRAINT tratamientos_consulta_id_fkey FOREIGN KEY (consulta_id) REFERENCES core.consultas(id) ON DELETE SET NULL;


--
-- Name: tratamientos tratamientos_empresa_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.tratamientos
    ADD CONSTRAINT tratamientos_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES core.empresas(id) ON DELETE CASCADE;


--
-- Name: tratamientos tratamientos_mascota_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.tratamientos
    ADD CONSTRAINT tratamientos_mascota_id_fkey FOREIGN KEY (mascota_id) REFERENCES core.mascotas(id) ON DELETE CASCADE;


--
-- Name: tratamientos tratamientos_veterinario_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.tratamientos
    ADD CONSTRAINT tratamientos_veterinario_id_fkey FOREIGN KEY (veterinario_id) REFERENCES core.users(id);


--
-- Name: users users_empresa_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.users
    ADD CONSTRAINT users_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES core.empresas(id);


--
-- Name: users users_especializacion_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.users
    ADD CONSTRAINT users_especializacion_id_fkey FOREIGN KEY (especializacion_id) REFERENCES core.especializaciones(id);


--
-- Name: users users_rol_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.users
    ADD CONSTRAINT users_rol_id_fkey FOREIGN KEY (rol_id) REFERENCES core.roles(id);


--
-- Name: vacunas vacunas_consulta_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.vacunas
    ADD CONSTRAINT vacunas_consulta_id_fkey FOREIGN KEY (consulta_id) REFERENCES core.consultas(id) ON DELETE SET NULL;


--
-- Name: vacunas vacunas_empresa_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.vacunas
    ADD CONSTRAINT vacunas_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES core.empresas(id) ON DELETE CASCADE;


--
-- Name: vacunas vacunas_esquema_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.vacunas
    ADD CONSTRAINT vacunas_esquema_id_fkey FOREIGN KEY (esquema_id) REFERENCES core.esquemas_vacunacion(id);


--
-- Name: vacunas vacunas_mascota_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.vacunas
    ADD CONSTRAINT vacunas_mascota_id_fkey FOREIGN KEY (mascota_id) REFERENCES core.mascotas(id) ON DELETE CASCADE;


--
-- Name: vacunas vacunas_veterinario_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.vacunas
    ADD CONSTRAINT vacunas_veterinario_id_fkey FOREIGN KEY (veterinario_id) REFERENCES core.users(id);


--
-- PostgreSQL database dump complete
--

\unrestrict II8HBfhg7sMPd6avo7dD71qQAXjt5GLZHB2DL1h6TrQhlp9YIOOD9JKylYmcNb9

